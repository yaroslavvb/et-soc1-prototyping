# PLAN2 actions: verified finding texts, verbatim

Generated on 25 Sep 2026 from the validation workflow journal (wf_69d9be14-73b). One section per review group. For each finding: the verifier's verdict, then the text to apply.

Rules: CORRECTED replaces PROPOSAL when both are present; "as proposed" inside CORRECTED refers to the PROPOSAL printed under it. Refuted findings are listed at the end of each group and must not be applied. PLAN2.md §2–§3 decisions override anything here where they conflict (they name the ID). R-* items are the reproduction run's problems; M-* items are problems the verifiers found that the reviewers missed; neither was separately verified unless noted.



## Group hub-unmetered


### Reproduction problems


#### R-hub-1 [medium] docs/reports/data/2026-09-23-energy-manual/unmetered_fit.json (ddr_droop), mirrored in docs/reports/sources/limits-of-observability.data.json power.droop and manual.json unmetered

Problem: No committed script can regenerate the droop calibration that the hub displays: it came from an inline run whose windows were not recorded. §8 of the page says so, but its numbers still differ from what the committed script gives.

Evidence: fit_unmetered.py: 0.865 vs 0.841 mV/W (+2.9%), common 0.0286 vs 0.0250 (+14.6%), rms 0.375 vs 0.355, IR 0.070 vs 0.068, tload/scp/random 1.90 vs 1.74 mV, wire/hop6/random 1.16 vs 1.05. A search of 910 window and averaging variants reproduced none of the committed examples exactly.

Fix: Regenerate the file with `python3 tools/ettelem/fit_unmetered.py --out docs/reports/data/2026-09-23-energy-manual/unmetered_fit.json --overwrite`, copy ddr_droop into data.json power.droop, rerun build_energy_manual.py and render_catalogue.py, and rebuild both pages. Then update the hand-typed prose: hub body §4.3 '1–1.7 mV (… 1.74 mV and … 1.05 mV …), 0.6–1.5 mV' → '1.2–1.9 mV (1.90, 1.16), 0.7–1.6 mV'. Also update the §8 sentence, E30 in 03-experiments.md, 05-claims.md line 312 and the fit_unmetered.py docstring. The alternative is to keep the inline numbers and label them as not regenerable.


#### R-hub-2 [low] docs/reports/sources/limits-of-observability.script.js (fittext) and KPI/ladder wording

Problem: 'about a fifth of their unmetered power' understates the relative DRAM residual.

Evidence: rms residual on DRAM configurations over their mean unmetered W: 1.098/4.02 = 0.27 (aifoundry2), 1.285/5.09 = 0.25 (aifoundry3); rms over rms gives 0.24–0.25

Fix: Say 'about a quarter of their unmetered power'.


#### R-hub-3 [low] docs/reports/sources/limits-of-observability.body.html §4.1 (also docs/findings/19-observability-and-the-unmetered.md, 05-claims.md line 310)

Problem: The claim that a starved burst 'reads 45% low on aifoundry2' is the worst pass, stated as if it held in general.

Evidence: analyze_reruns.reduce_dir on 2026-09-23-reruns-aifoundry2-warm/rl-pass1..3 xshire16 gives 7.29, 8.19 and 8.86 pJ/B against aifoundry3's pooled 13.27 pJ/B: 45%, 38% and 33% low (mean 39%)

Fix: Say 'reads a third to 45% low' or 'up to 45% low'.


#### R-hub-4 [low] docs/reports/sources/limits-of-observability.body.html §4.2

Problem: 'on top of the 50–60 pJ the mesh, the SRAM and the delivery losses take on the way' holds only for random operands.

Evidence: catalogue config means, total pJ/B minus the fitted DRAM term: tload/dram/random 56.6/59.7, dramrow/stride1K/random 59.8/57.7, tstore/dram/random 67.4/62.9; zeros 17–20 pJ/B; const 25–30 pJ/B

Fix: Say '50–60 pJ on random data (about 20 on zeros)'.


#### R-hub-5 [low] docs/reports/data/2026-09-23-energy-manual/unmetered_fit.json examples, shown in the hub's droop table

Problem: The minion-rail droop reads -0.02 mV for add/zeros/h2, st_stream/dram/random and tstore/dram/random. The raw telemetry shows no such change; the value is an artefact of the unrecorded inline windows.

Evidence: die_mv.minion is 518 in every sample from t_lo-3 s to t_hi+1 s in all three add/zeros/h2 passes; fit_unmetered.py gives 0.00

Fix: This is fixed by regenerating the droop block (first problem). Otherwise show 0.00.


#### R-hub-6 [low] docs/reports/sources/limits-of-observability.data.json (power block) and body.html prose

Problem: The page's power numbers are copied by hand from unmetered_fit.json and dvfs.json, and several values are typed again in the prose (1.74, 1.05 and the ranges derived from them). A regenerated fit would not reach the page, and the copies duplicate the table.

Evidence: No script writes data.json power.fit, power.droop or power.idle_73c. They equal the source files today, but only because they were copied by hand.

Fix: Add a small sync step (or let build-report.py read the source files) that copies power.fit, power.droop and power.idle_73c from the data files. Generate the prose's example values in script.js from D.power.droop.examples rather than typing them.


#### R-hub-7 [low] workloads/enercat/analyze_catalogue.py comment; hub §4.1; docs/findings/14-card-behaviour.md

Problem: The rail filter's '61% after 1 s, 88% after 2 s' has no committed computation: it appears only as a comment in analyze_catalogue.py.

Evidence: A rough independent check on 242 aifoundry2 catalogue bursts with over 8 W on the minion rail gives 57% at 1 s and 86% at 2 s (median). This is consistent with τ ≈ 1 s but is not the stated figures.

Fix: Commit the step-response reduction, for example as a function in analyze_catalogue.py that writes the fractions into catalogue.json, and cite it.


#### R-hub-8 [low] tools/ettelem/fit_unmetered.py

Problem: For the requested interactive visualisations: the script writes only 8 droop examples, and no per-configuration rows exist for a fitted-vs-measured or droop-vs-DRAM-W chart.

Evidence: unmetered_fit.json has no per-configuration table. A scratch version is at /tmp/claude-1019/-home-yaroslavvb-claude/ed6d06d5-de26-4323-94f1-0dc808eafbda/scratchpad/validate2/wt/hub-unmetered-work/unmetered_per_config.json: 137 KB, 392+386 fit rows (measured and fitted unmetered W, class) and 386 droop rows (droop mV, off-rail DRAM W, class).

Fix: Add a per_config block to fit_unmetered.py's output. Then add to the hub's §4 two linked scatters with hover and a card toggle: unmetered W measured against fitted, coloured by instruction, DRAM or mesh; and DDR droop against off-rail DRAM W with the fitted line, marking the mesh and scratchpad outliers.


### Review findings


#### hub-u-01 — MODIFIED [claim/medium] et-soc1-limits-of-observability

Where: body.html §4.1 para 3 ('The sampler records its own latency with every sample, and bursts with that signature are dropped (rung 7).'); data.json improvements rung 7; workloads/enercat/analyze_catalogue.py (the §4.2 fit and §4.3 droop input)

Files: workloads/enercat/analyze_catalogue.py, tools/ettelem/fit_unmetered.py, docs/reports/sources/limits-of-observability.body.html, docs/reports/sources/limits-of-observability.data.json, docs/reports/data/2026-09-23-energy-manual/catalogue.json

Problem: The page says bursts that starve the meter are dropped, and it names only the s↔s+16 rings and the column tensor loads. On aifoundry2 the catalogue's DRAM-read bursts slow the sampler too, sometimes past the 60 ms rule that analyze_wire.py uses to drop bursts. analyze_catalogue.py never reads took_ms, so these bursts stay in catalogue.json, and they are the DRAM configurations that the unmetered fit and the droop slope rest on.


APPLY (CORRECTED): 1. As proposed, with the path tools/ettelem/analyze_reruns.py:75. Add sampler_median_ms/sampler_max_ms per burst and to summarise(), then regenerate with E27 (it reproduces byte-identically apart from the new fields).
2. Keep the bursts: dropping the three over 60 ms changes a2 to 71.8 pJ/B, rms 0.342.
3. §4.1, after '…bursts with that signature are dropped (rung 7).', insert: 'DRAM reads slow it too on aifoundry2 (a median of 23–206 ms per sample over a burst, the reading held for up to 1.2 s; aifoundry3 stays at 22 ms). The catalogue keeps those bursts: their board watts agree with aifoundry3's within the cards' usual 5%, though in the three slowest the rail readings are stale and the NoC rail reads up to 0.6 W low.'
4. Apply the rung-7 wording as part of hub-u-08's rewrite, not separately.
5. Fix the Board power note (hub-u-08 does this), 14-card-behaviour.md:179 and 19-observability.md:83 so that none says catalogue bursts are dropped.

Base PROPOSAL (for "as proposed" references): 1. In workloads/enercat/analyze_catalogue.py, load took_ms as analyze_reruns.py does (line 75: took = np.array([s.get('took_ms', 0) for s in tel])). Add "sampler_median_ms": float(np.median(took[busy])) and "sampler_max_ms": float(took[busy].max()) to each burst dict. In summarise(), add a per-config stat('sampler_median_ms'). Regenerate catalogue.json with the command in 03-experiments E27.
2. Decide whether to drop these bursts. If they are dropped (skip bursts with sampler_median_ms > 60 in fit_unmetered.config_means), refit and restate D10. If they are kept, say so on the page.
3. §4.1 (kept case): after '…bursts with that signature are dropped (rung 7).' insert 'DRAM reads slow it too on aifoundry2 (a median of 23–206 ms per sample over a burst, the board reading held for up to 1.2 s; aifoundry3 stays at 22 ms). The catalogue keeps those bursts: their averages agree with aifoundry3's within the cards' usual 5%.'
4. Rung 7 effect: after 'were found to be unmeasurable this way' add '; DRAM reads on aifoundry2 slow it without freezing it'.


Verifier note: Real. I recomputed took_ms over each catalogue burst's [t_lo+0.5, t_hi] from the committed telemetry, and the reviewer's figures match exactly. On aifoundry2, tload/dram/* and dramrow/stride1K/* have medians of 23–206 ms, maxima of 278–683 ms and board holds of up to 1.21 s. Three of 1,158 bursts are over the 60 ms rule: tload/dram/random p1, dramrow/stride1K/zeros p1 and dramrow/stride1K/random p2. Stores and every aifoundry3 burst stay at 21–23 ms. analyze_catalogue.py never reads took_ms, and the E27 command regenerates catalogue.json byte-identically, so step 1 is safe. The reviewer missed three things. (a) The starved passes' rail figures read low: each is the lowest NoC rail of its configuration (1.46 vs 1.86/1.74 W; 1.21 vs 1.86/1.61 W; 1.02 vs 1.07/1.19 W), because the SP's copy is stale while the rail is still rising. Their board over-idle is within the pass spread. (b) Dropping the three bursts moves aifoundry2's DRAM term from 72.9 to 71.8 pJ/B (under 1 se) and the rms from 0.346 to 0.342 W, so keeping them is defensible. (c) Other text makes the same false claim: the Board power ladder note ('the energy manual's analysis drops such bursts'), 14-card-behaviour.md line 179 and 19-observability line 83. Also, analyze_reruns.py is at tools/ettelem/, not workloads/enercat/, and step 4 conflicts with hub-u-08's rewrite of rung 7.


#### hub-u-02 — MODIFIED [claim/medium] et-soc1-limits-of-observability

Where: script.js fittext ('DRAM bytes are the bytes of the DRAM load, store and row configurations, streaming stores counted once.' … 'about a fifth of their unmetered power.'); body.html §4.2 'Three things follow' ('a byte written through the L1 costs twice that off-rail, because the line is read from DRAM before it is written'); tools/ettelem/fit_unmetered.py config_means

Files: docs/reports/sources/limits-of-observability.script.js, docs/reports/sources/limits-of-observability.body.html, tools/ettelem/fit_unmetered.py

Problem: The fit counts the DRAM bytes of the three stores through the L1 (st_stream, fsw.ps through the write-back path) once. The next paragraph says each such byte costs a line read as well. Those three configurations have the largest residuals and account for most of the '1.1–1.3 W rms on the DRAM configurations'. The page does not say what that residual is made of. 'Streaming stores' also reads like non-temporal stores, which they are not.


APPLY (CORRECTED): Use the minimal fix, and keep D10.
- fittext: 'DRAM bytes are the bytes the DRAM load, store and row configurations move; stores through the L1 (st_stream) count only the bytes written, not the line read before each write.'
- Residual sentence: 'The residual is small overall but not on DRAM traffic: 1.1–1.3 W rms on the DRAM configurations, about a quarter of their unmetered power. It has a pattern: the three stores through the L1 sit 1.3–2.7 W above the fit because their line reads are not counted (counting them brings the DRAM rms to 0.8 W); on the full-rate tensor loads, tensor stores and row walks, random data sits 0.6–1.5 W above it and zeros or constants 0.6–1.6 W below.'
If the fuller fix is chosen instead, the cascade must also restate the NoC coefficient (25–27%, §4.2 'Three things follow') and the SRAM coefficient in the fit table.

Base PROPOSAL (for "as proposed" references): Minimal fix, which keeps D10:
- In fittext, replace 'DRAM bytes are the bytes of the DRAM load, store and row configurations, streaming stores counted once.' with 'DRAM bytes are the bytes the DRAM load, store and row configurations move; stores through the L1 (st_stream) count only the bytes written, not the line read before each write.'
- Replace 'The residual is small overall but not on DRAM traffic: 1.1–1.3 W rms on the DRAM configurations, about a fifth of their unmetered power.' with 'The residual is small overall but not on DRAM traffic: 1.1–1.3 W rms on the DRAM configurations, about a quarter of their unmetered power. It has a pattern: the three stores through the L1 sit 1.3–2.7 W above the fit, because their line reads are not counted (counting them brings the DRAM rms down to 0.8 W), and on the loads random data sits 0.6–1.5 W above it and zeros or constants 0.6–1.6 W below.'
Fuller fix, which changes D10 and cascades: in fit_unmetered.config_means, set m['dram_bytes_per_s'] = 2 * m['bytes_per_s'] if cfg.startswith('st_stream/') and regenerate. Then restate 0.30/0.24 W rms, 0.76–0.80 W on DRAM and 66–70 pJ/B in the KPI, §2, §4.2, rung 2, the energy manual §4.3, docs/energy-manual/04a-fine-grain.md and 05-claims.md.


Verifier note: Real. I verified it with fit_unmetered's own functions. st_stream residuals are +2.72/+1.50/+1.32 W (a2) and +2.60/+1.65/+1.45 W (a3). Their off-rail cost is 122–174 pJ/B against 60–83 for tload on the same data (1.92–2.16×). Doubling st_stream bytes gives DRAM rms 1.098→0.761 / 1.285→0.801, overall 0.346→0.304 / 0.295→0.241, and DRAM 72.9→70.2 / 68.1→65.8 pJ/B. The kernel (EC_ST_STREAM) is ordinary fsw.ps through the L1 write-back path, not non-temporal. Two corrections. First, the minimal text says 'on the loads random data sits 0.6–1.5 W above', but the 0.6–1.5 range includes tensor stores (tstore/dram/random +0.61/+0.64) and row walks (+1.46/+0.94), and the low-rate dramrow2 random points are only +0.25–0.38. Second, the fuller fix also moves the NoC coefficient (0.286→0.268, 0.264→0.246) and SRAM (0.050→0.055, 0.064→0.069), and the reviewer's cascade omitted these; '26–29%' in §4.2 would become 25–27%.


#### hub-u-03 — MODIFIED [reproducibility/medium] et-soc1-limits-of-observability

Where: data.json power.droop (= unmetered_fit.json ddr_droop = manual.json unmetered.ddr_droop); body.html §4.3 prose; §8 span#fitsource

Files: docs/reports/data/2026-09-23-energy-manual/unmetered_fit.json, docs/reports/sources/limits-of-observability.data.json, docs/reports/sources/limits-of-observability.body.html, tools/ettelem/fit_unmetered.py, docs/energy-manual/04a-fine-grain.md, docs/reports/sources/energy-manual.script.js

Problem: The DDR-droop block that the hub displays came from an unrecorded inline run. The committed fit_unmetered.py gives 0.865 rather than 0.841 mV/W, a common term 15% higher, and example droops 0.1–0.17 mV higher. None of 910 window and averaging variants reproduced it. The page discloses this in §8, but none of its droop numbers can be regenerated from the repo.


APPLY (CORRECTED): Option A.
1. Regenerate unmetered_fit.json with --overwrite and rebuild manual.json and both pages.
2. In §4.3, replace the example sentence with: 'droops it by 1–2 mV (tload/scp/random 1.9 mV and wire/hop6/random 1.2 mV in the table above; up to 2.2 mV for L3 reads through the mesh), 0.7–1.7 mV more than the fit allows, which it would read as roughly 0.8–2 W of DRAM'. Better, generate it from per-configuration rows as in hub-u-15/22.
3. Ladder and rung 3: 0.84→0.87, 0.36→0.37, '(mesh traffic adds up to about 2 mV)'.
4. Replace span#fitsource as proposed.
5. Cascade to every file listed in the reason, plus those the reviewer named: energy-manual script.js droopText, 04a, energy-manual README:40–42, 09-method:122–124, 05-claims:312, PLAN D10, and the docstring.
Option B remains acceptable only if the whole list above is also labelled.

Base PROPOSAL (for "as proposed" references): Option A (recommended): make the script the source.
1. Run python3 tools/ettelem/fit_unmetered.py --out docs/reports/data/2026-09-23-energy-manual/unmetered_fit.json --overwrite, then python3 tools/ettelem/build_energy_manual.py and the sync step of hub-u-15, and rebuild the hub and the energy manual.
2. In body.html §4.3, replace 'droops it by 1–1.7 mV (<code>tload/scp/random</code> 1.74 mV and <code>wire/hop6/random</code> 1.05 mV in the table above), 0.6–1.5 mV more than the fit allows' with 'droops it by 1.2–1.9 mV (<code>tload/scp/random</code> 1.9 mV and <code>wire/hop6/random</code> 1.2 mV in the table above), 0.7–1.6 mV more than the fit allows', or generate it as in hub-u-15. 0.8–1.8 W is unchanged.
3. In the data.json ladder row 'DDR-rail droop' and rung 3, change 0.84 → 0.87 and 0.36 → 0.37, and in the note '(mesh traffic adds up to about 1.7 mV)' → 'about 1.9 mV'.
4. Replace span#fitsource with '<code>tools/ettelem/fit_unmetered.py</code> writes that file from the catalogue and its telemetry.'
5. Update the same numbers in the energy manual (script.js droopText, docs/energy-manual/04a-fine-grain.md table and text, README.md lines 40–41, 09-method.md lines 122–124), 03-experiments E30, 05-claims line 312, PLAN D10, and the fit_unmetered.py docstring.
Option B: keep the inline numbers, and label the droop table's caption and drooptext 'computed inline; the committed script gives 0.87 mV/W and droops 0.1–0.2 mV higher'.


Verifier note: Real. I ran tools/ettelem/fit_unmetered.py. The attribution reproduces exactly; the droop block gives 0.8651 vs 0.8409 mV/W, a common term of 0.0286 vs 0.0250, rms 0.375 vs 0.355 mV and IR drop 0.0703 vs 0.0684. The examples are tload/scp/random 1.90 vs 1.74 mV and wire/hop6/random 1.16 vs 1.05 mV, and the minion -0.022 becomes 0.000. Option A is the right direction, with three errors. (1) '0.8–1.8 W is unchanged' is wrong: with the script, the phantom DRAM is 0.69/0.865 = 0.79 W to 1.60/0.865 = 1.85 W, i.e. 0.8–1.9 W. (2) The cascade list is incomplete. 0.84 also appears in the root README.md:157, docs/getting-started.md:37, docs/findings/README.md:72, 04-artifacts.md:148, 19-observability.md:43/54–55, 03-experiments.md:676/686–687 and energy-manual.body.html:193, besides the files listed. (3) The two examples are not the largest non-DRAM droops. Across all 375 non-DRAM configurations, the script gives up to 2.0 mV (tstore/scp/random) and 2.24 mV (dramrow/stride8K/random, which is really an L3 read through the mesh; 05-claims.md:290). So '1–1.7 mV' and 'mesh traffic adds up to about 1.7 mV' understate.


#### hub-u-04 — MODIFIED [visualization/medium] et-soc1-limits-of-observability

Where: §4.2, directly after table#fittab (also replaces table#idletab in §4.1)

Files: tools/ettelem/fit_unmetered.py, docs/reports/sources/limits-of-observability.data.json, docs/reports/sources/limits-of-observability.script.js, docs/reports/sources/limits-of-observability.body.html

Problem: The page's main power result is what the unmetered remainder is made of: about a sixth of arithmetic and three fifths to three quarters of DRAM traffic, a four-term fit, and a structured 1.1–1.3 W DRAM residual. It exists only as prose and two number tables. A reader cannot see which configurations the fit explains, where the misfit sits, or how the idle 31.8 W and a workload's added watts divide between metered and unmetered power.


APPLY (CORRECTED): Build it as proposed, with these changes:
- Classify in order: st_stream → c5; other moves_dram → c4; /hN → c1; wire/ → c2; everything else → c3. Tooltips name dramrow/stride8K as 'L3 reads through the mesh'.
- Panel B: stack minion, SRAM and NoC rails, then fitted delivery loss and fitted DRAM term; draw the measured board-over-idle as a vertical tick, and print the residual as text (±W).
- Label the idle segments outside the bar when they are narrower than 40 px.
- The checkbox readout says 'DRAM rms 1.10→0.76 W; the random/zeros pattern remains'.
Do this before hub-u-05 and hub-u-22: it is the chart that carries §4's main result.

Base PROPOSAL (for "as proposed" references): 'Where a workload's watts go': a linked scatter and bar, in vanilla JS and SVG.

Question: of what each configuration adds above idle, how much is on no sensor, and does the four-term fit account for it?

Data:
- Add to fit_unmetered.py output fit[card]['per_config'] = [[cfg, over_idle_w, rail_minion_w, rail_sram_w, rail_noc_w, dram_GBps] …] (3 decimals; 392 + 386 rows, about 35 KB).
- Copy it to data.json power.per_config.{aifoundry2,aifoundry3} with the sync step of hub-u-15.
- Coefficients come from power.fit, already on the page; the idle bar comes from power.idle_73c.

Panel A, a scatter (viewBox 360×360, 0–8 W on both axes):
- x = fitted unmetered W, computed in JS as c.minion·minion + c.sram·sram + c.noc·noc + c.dram_pj_per_byte·GBps·1e-3.
- y = measured unmetered W (over_idle − the three rails).
- A dashed y = x line in var(--grid).
- Colour by class from cfg: /hN instructions var(--c1); tload|tstore|scpline|neigh|l1fill|dramrow/stride8K var(--c3); wire/ var(--c2); DRAM loads and rows var(--c4); st_stream var(--c5). Random operands filled, zeros and const hollow.

Panel B, stacked horizontal bars (viewBox 360×200):
- Row 1: idle at 73 °C: 11.05 minion, 2.00 SRAM, 3.64 mesh, 15.10 on no sensor, labelled in W.
- Row 2: the selected configuration's watts over idle: minion, SRAM and NoC rails, then the unmetered part split into fitted delivery loss, fitted DRAM term and the signed residual, with its unmetered share in %.
- A readout line: 'aifoundry2: rms 0.35 W over 392; 1.10 W over 17 DRAM configurations'.

Interactions:
- aifoundry2/aifoundry3 buttons (aria-pressed).
- Class chips that toggle visibility.
- Hover or tap a point to load it into Panel B. The SVG has tabindex=0, ←/→ step through points in residual order, and Enter pins a point.
- A checkbox 'Count the line read before each L1 store' doubles st_stream bytes and refits the four coefficients in the page by solving the 4×4 normal equations with Gaussian elimination. The dots, the readout and the coefficients update: a2 DRAM rms 1.10→0.76 W and 72.9→70.2 pJ/B; a3 1.29→0.80 and 68.1→65.8.

Layout: the panels sit side by side above 700 px and stack below, so there is no horizontal scroll at 390 px.

Replaces the idle table: its numbers become the idle bar's labels, and '31.79 ± 0.04 W, 300 samples over 60 s, 20.6 h idle' goes in the caption. It complements the fit table, which stays as the record. Understanding it gives: arithmetic hugs the diagonal near the origin with about a sixth unmetered, and DRAM sits at 4–7 W with three fifths to three quarters unmetered. The DRAM misfit is structured (L1 stores far above, random above, zeros below), and it largely disappears once the line read is counted.


Verifier note: The data and numbers hold. Per-configuration inputs are in catalogue.json. The median unmetered share is 0.17/0.15 for instructions and 0.69/0.65 for DRAM. The ranges are 0.09–7.5 W unmetered and 0.06–6.2 W fitted, so a 0–8 W axis fits. The in-page refit reproduces 1.10→0.76 W and 72.9→70.2 pJ/B on a2, and 1.29→0.80 W and 68.1→65.8 pJ/B on a3. The layout stacks on phones. The chart is feasible and is the right centrepiece for §4. Corrections: (a) The class rule needs a precedence. tload/dram, tstore/dram and dramrow/stride1K also match the on-chip regex, so test moves_dram first (st_stream → c5, other DRAM → c4). dramrow/stride8K is an L3 read, not a DRAM row, and should be labelled as such in the tooltip. (b) 'The misfit largely disappears once the line read is counted' overstates: the DRAM rms falls by about a third (to 0.76/0.80 W), and the random-above/zeros-below pattern remains. (c) The 'signed residual' cannot be a stacked segment when it is negative. Draw fitted parts as stacked segments and the measured total as a tick or outline. (d) The SRAM idle segment (2.00 W, 6%) is about 20 px wide on a phone, so its labels must sit outside the bar.


#### hub-u-05 — MODIFIED [visualization/medium] et-soc1-limits-of-observability

Where: §4.1, after the 'the workload can starve the meter' paragraph

Files: docs/reports/sources/limits-of-observability.data.json, docs/reports/sources/limits-of-observability.script.js, docs/reports/sources/limits-of-observability.body.html

Problem: §4.1 describes the meter chain in prose only. The prose covers board power refreshed every 133 ms, rails behind a first-order τ ≈ 1 s average, the DDR monitor, and the sampler slowing when the SP is starved. A reader never sees what these instruments show during a burst, which is what every number on the site is reduced from.


APPLY (CORRECTED): Keep it, simplified:
- Windows run from max(t_lo−3, prev_t_hi+2.5) to min(t_hi+4.4, next_t_lo−0.2), on an axis of −3 to +7.5 s.
- The dashed rail model is idle_before + (rail_end_asymptote − idle_before)·(1−e^(−t/τ)), with the τ slider set to 0.8–1.6 s.
- Caption: 'aifoundry2; its readings refresh every ~133 ms (aifoundry3's every ~250 ms)'.
- Keep the six bursts and the took_ms strip with the 60 ms line.
- Link to Power and temperature §2 for the long load step rather than repeating it.

Base PROPOSAL (for "as proposed" references): 'One burst through every meter': a scrubbable replay.

Question: when does board power move, how slowly do the rails follow, does the DDR monitor droop, and when does the sampler itself slow down?

Data: a new ~40-line tools/ettelem/extract_hub_replays.py writes data.json power.replays = [{cfg, card, pass, t_lo, t_hi, s: [[t_rel, board_w, minion_w, sram_w, noc_w, ddr_mv, took_ms], …]}] (about 30 KB). Each window runs from t_lo−3 s to t_hi+5 s. The windows:
- fmadd.ps/random/h2 (pass 0), tload/dram/random (pass 1: sampler median 173 ms, board held 1.2 s), st_stream/dram/random, tload/scp/random and wire/hop6/random, all from the aifoundry2 catalogue with t_lo/t_hi from catalogue.json.
- xshire16 from rl-pass1, with times from marks.jsonl and runs.jsonl.

Encoding: three stacked strips on a shared time axis (−3 to +8 s), with the burst shaded in var(--grid).
1. Watts over idle: board as a step line in var(--ink); minion, SRAM and NoC rails in var(--c1), var(--c3), var(--c2); a dashed first-order model of the rails, rail_end·(1−e^(−t/τ)), with τ from a slider.
2. The DDR monitor in mV, var(--c4), on an inverted axis so droop goes down.
3. Sampler latency took_ms on a log axis from 10 to 1,000 ms, with a dashed var(--bad) line at 60 ms.

Interactions:
- Six burst buttons.
- A range input for time: a cursor with a readout of board W, each rail W, DDR mV and took ms at that sample.
- A range input for τ, 0.3–2.0 s (default 1.1), that recomputes the dashed model.
- A toggle between raw W and W over idle.
- Everything works from the keyboard, and the frame scrolls at 390 px only if narrower than 340 px.

It complements the §4.1 prose and replaces nothing. Understanding it gives: the reader sees the 133 ms board steps; the ~1 s rail lag that forces the analysis to read only the last 0.6 s; the DDR droop on DRAM and on-chip traffic but not on arithmetic, which previews §4.3; and the meter starving (latency 150–400 ms, a flat board reading).


Verifier note: The data exists. I checked the tload/dram/random p0 burst: DDR 767→761 mV at +0.41 s, before the board step at +0.62 s; board 35.6→46.25 W; NoC 4.40→6.23 W still rising at the end; took_ms 297–302 ms, and 403 ms at launch. rl-pass1 has marks.jsonl with xshire16. Problems: (a) The gap between catalogue bursts is 4.7 s (median, p10 4.7 s). A window to t_hi+5 s, and an axis to +8 s, therefore include the next burst's step, and the window from t_lo−3 s starts 1.7 s after the previous burst, while its rail residue (about 18%) is still falling. The first-order overlay must start from that pre-burst level, not zero. (b) The 133 ms board steps are an aifoundry2 property: aifoundry3's values change only every ~250 ms (see missed). All proposed windows are from aifoundry2, which is fine, but the caption must say so. (c) Power and temperature §2 already charts a load step through the board and the three rails. The replay's distinct value is the DDR monitor, the sampler latency and the comparison across burst types, so it can be simpler. It is lower priority than hub-u-04.


#### hub-u-06 — MODIFIED [visualization/medium] et-soc1-limits-of-observability

Where: §2 chart div#gran (script.js 'granularity figure'; body.html '<div class="chart scroll" id="gran">')

Files: docs/reports/sources/limits-of-observability.script.js, docs/reports/sources/limits-of-observability.body.html, docs/reports/sources/limits-of-observability.data.json

Problem: The only chart on the page fails on phones and for keyboard users.
- At 390 px the 900-wide viewBox is forced to a min-width of 640 px, so the 12 px labels render at about 8 px. Only 1 ns to 10 µs is visible, and the power instruments' dots (0.1–3 s) sit off-screen with no cue.
- The row groups respond only to mousemove and touchstart; they have no tabindex and no focus handler.
- The status filter buttons right under it filter only the table.
- 'Per-shire frequency' is plotted at 133 ms, although its granularity is a 25 MHz step, not a time.


APPLY (CORRECTED): All of the proposal except the narrow-width geometry:
- Below 600 px, put each row's label on its own line above its track (row height about 34 px), and let the axis span the full width (L = 8). Label every other decade.
- Everything else as proposed: redraw on resize, drop .scroll, focusable rows with role/aria-label and a focus tip, filter buttons dimming rows, and an axis title.
- Enter scrolls to lad-<slug> after resetting the ladder filter to 'all'.
- Per-shire frequency: sec null, and add 'per-shire attribution' to the legend's list of table-only rows.

Base PROPOSAL (for "as proposed" references): In script.js:
- Replace 'const W = 900, H = 60 + rows.length * 19, L = 250' with 'const W = Math.max(340, host.clientWidth || 900), H = 60 + rows.length * 21, L = W < 600 ? 132 : 250'. Use a 11px font on narrow widths, label every other decade tick when W < 600, and redraw on a debounced resize.
- In body.html, change '<div class="chart scroll" id="gran">' to '<div class="chart" id="gran">'.
- Give each row g the attributes tabindex=0, role='button', data-status=r.status and aria-label=`${r.level}: ${r.gran}; ${STATUS[r.status]}`. Show the tip on focus, positioned from the circle's getBoundingClientRect, and hide it on blur. On Enter, scroll to the ladder row id lad-<slug> added in hub-u-07.
- In the ladder table's render(), add svg.querySelectorAll('g[data-status]').forEach(g => g.style.opacity = filter === 'all' || g.dataset.status === filter ? 1 : 0.15), so the buttons filter the chart as well.
- Add an x-axis title 'finest time step (log scale)'.
- Set 'Per-shire frequency' sec to null, which moves it to the 'rows without a single time step' note.


Verifier note: Confirmed by screenshot at 390 px. The SVG is forced to 640 px inside a 343 px frame, only 1 ns–10 µs is visible, most rows show no dot, and the labels are about 7 px. There are no keyboard handlers, the filter buttons do not touch the chart, and 'Per-shire frequency' has sec 0.133. The proposed narrow layout does not work, though: with L = 132 px at 11 px font, labels such as 'Shire-cache and memory-shire counters' (about 200 px) and 'Regulator input power per rail' overflow into the plot or clip. The plot area would also be 191 px for 10 decades. Setting Per-shire frequency to null also needs the table-only legend note to mention it.


#### hub-u-07 — MODIFIED [redundancy/medium] et-soc1-limits-of-observability

Where: §5 table#imptab 'What it adds' column (data.json improvements[].adds) vs §2 table#laddertab notes

Files: docs/reports/sources/limits-of-observability.data.json, docs/reports/sources/limits-of-observability.script.js

Problem: Nine of the 20 improvement rungs restate a §2 ladder row in other words. Rung 15 ('The counters are wired and read as zero because the SP never enables their sources; DRAM ECC is compiled off.') repeats the ECC errors note, and rung 17 repeats the Halted-hart state note. §5 is 3,160 px at 1280. What only §5 adds is the Cost and 'What changes in the numbers' columns.


APPLY (CORRECTED): Apply as proposed for rungs 1, 2, 3, 11, 15, 16 and 18. For rung 14, keep the adds text: 'Drop the 84-read snapshot and the 1 ms I2C busy-wait; record the PMIC's instantaneous power rather than its average.' For rung 17, use: 'Rehearse on sys_emu, which models the debug module. Also writes mhpmevent before a launch, choosing counter events without a firmware change.' Clicking any 'see §2' link sets the ladder filter to 'all' before scrolling.

Base PROPOSAL (for "as proposed" references): 1. In script.js laddertab, give each row an id: `<tr id="lad-${r.level.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')}">`.
2. In data.json improvements, add "row" to the rungs listed in the evidence, and replace their 'adds' text with a pointer:
   - rung 2: 'Method and fit in §4.2.'
   - rung 3: 'Calibration in §4.3.'
   - rungs 11, 14, 15, 16, 18: ''
   - rung 17: 'Rehearse on sys_emu, which models the debug module.'
3. In the imptab renderer, append ` <a href="#lad-${slug(r.row)}">see §2: ${esc(r.row)}</a>` to the 'What it adds' cell when r.row is set.
4. Keep the Cost, 'What changes in the numbers' and Status columns unchanged.


Verifier note: The overlap is real for most of the listed rungs: 1, 2, 3, 11, 15 and 18 restate their §2 rows almost word for word. Two cuts lose information. Rung 14's 'adds' is the only place that says what the firmware change is: drop the 84-read PMB snapshot and the 1 ms busy-wait, and record instantaneous rather than averaged power. hub-u-20 also removes the busy-wait from the Rail power note. Rung 17's 'adds' mentions 'mhpmevent writes before a launch', which is a way to choose counter events without a firmware change and appears nowhere in §2. Also, the ladder table re-renders under its filter, so a lad- link can point at a hidden row.


#### hub-u-08 — MODIFIED [redundancy/medium] et-soc1-limits-of-observability

Where: data.json ladder 'Board power' note; body.html §4.1 para 3; data.json rung 7 'adds'/'effect'

Files: docs/reports/sources/limits-of-observability.data.json, docs/reports/sources/limits-of-observability.body.html

Problem: The starved meter is described at length three times on the page. The poisoned management queue and the stray stores to physical address 0 are told twice, and both are canonical in Heat per millimetre §10 (#limits). The stray write is not a meter-chain limit, so §4.1 is the wrong place for it.


APPLY (CORRECTED): Steps 1, 2 and 4 as proposed. Step 3: add the wild write to §3 as its own sentence after the ECC bullet list, or drop it from the hub and rely on the §4.1 link to Heat per millimetre §10. Step 5, rung 7 effect: 'One ring configuration (s ↔ s+16) and one column configuration on aifoundry2 are unmeasurable this way (the ring read 33–45% low without the check); DRAM reads on aifoundry2 slow the sampler without freezing it (§4.1). After the drain, the second heat-per-mm run completed 132 bursts per card with no sampler restart.'

Base PROPOSAL (for "as proposed" references): 1. Board power note: replace from 'The meter can be starved by the workload:' to the end with 'Some workloads starve the SP and freeze the reading (§4.1).'
2. §4.1: replace 'and a way to stop the meter outright: a sampler killed in the middle of a request leaves its reply in the management queue, and every later opener crashes on that reply until one command drains it. The same runs sent about a second of stray tensor stores to physical address 0, through a bug in the test tool; no error counter, telemetry field or clock moved, so a wild write is one more thing the card does not report.' with 'and a way to stop the meter outright: a sampler killed mid-request leaves its reply in the management queue until one command drains it (<a href="https://spacesheep.dev/@yaroslavvb/et-soc1-heat-per-mm#limits">Heat per millimetre, §10</a>).'
3. §3, at the end of the ECC bullet, add ' Nor is a wild write: a second of stray tensor stores to physical address 0, from a test-tool bug, moved no counter or telemetry field (<a href="https://spacesheep.dev/@yaroslavvb/et-soc1-heat-per-mm#limits">Heat per millimetre, §10</a>).'
4. Rung 7 adds → 'Every ettelem sample records how long its six management commands took (took_ms); bursts during which the SP is starved (§4.1) are dropped. ettelem exits cleanly on SIGTERM, and the runners drain a poisoned management queue and retry.'
5. Rung 7 effect → 'Without the check the s ↔ s+16 ring's energy read 33–45% low on aifoundry2; after the drain the second heat-per-mm run completed 132 bursts per card with no sampler restart.'


Verifier note: The triple telling is real: the Board power note, §4.1 and rung 7. Heat per millimetre §10 holds the queue and the stray write, and it links back to hub #the-chain for the queue, so §4.1 must keep a short mention; the proposal does this. The Board power note's claim that 'the energy manual's analysis drops such bursts' is also false for the catalogue (hub-u-01), so cutting it is doubly right. Three problems. (a) Appending 'Nor is a wild write…' to §3's ECC bullet reads awkwardly: that bullet is about SRAM/DRAM ECC coverage, and 'Nor is' has no antecedent. (b) The proposed rung-7 effect drops 'One ring configuration and one column configuration on aifoundry2 were found to be unmeasurable this way', which tells the reader which numbers are missing. (c) hub-u-01 step 4 edits the same sentence.


#### hub-u-09 — MODIFIED [reorganize/low] et-soc1-limits-of-observability

Where: top of page (KPIs, div#terms, p.start, nav#toc) and §2 ladder notes

Files: docs/reports/sources/limits-of-observability.body.html, docs/reports/sources/limits-of-observability.script.js

Problem: A reader who comes for the index scrolls 1,760 px at 1280 (4,390 at 390) past the lede, KPIs, a four-paragraph glossary and a 'Start here' card before reaching §1. The 'Start here' card repeats the lede and the contents list ('§1 lists every report …; for what a power number can and cannot mean, read §4'). §2 is the longest section at 5,000 px at 1280 and 7,700 at 390, mostly the always-open notes in 26 rows.


APPLY (CORRECTED): Apply the order change, fold Start-here into the contents card, and make #terms a details element with the hash auto-open, as proposed. Show ladder notes in full at 600 px and wider. Below 600 px, where the ladder becomes stacked cards (hub-u-23), put each note in a details element with an 'expand all notes' button. The expected saving is about 480 px at 1280.

Base PROPOSAL (for "as proposed" references): New order, keeping all section numbers and ids:
1. Lede and KPIs.
2. nav#toc, with the Start-here text cut to its first line as the card's opening: '<p class="small">Every report is in §1; energy per instruction or byte is in the <a …>energy manual</a>.</p>'. Delete p.card.start.
3. The glossary as <details class="card" id="terms"><summary><b>The chip in brief</b>: minions, harts, shires, scratchpads, the SP, the PMIC and the other names on this page</summary>…the four paragraphs…</details>. Add to script.js: const T = document.getElementById('terms'); const openT = () => { if (location.hash === '#terms') T.open = true; }; openT(); addEventListener('hashchange', openT);
4. §1–§9 unchanged in order.

In the laddertab renderer, put each note in `<details class="small"><summary>details</summary>${esc(r.note)}</details>`, and add an 'expand all notes' button to div#filters. §1 moves up by about 800 px at 1280, and §2 shrinks by roughly half.


Verifier note: The offsets are right: #reports at 1,760, #ladder at 3,781 and #bits at 8,828 at 1280 px, and 4,394/7,389/15,119 at 390 px. The Start-here card duplicates the lede and the contents list. Incoming links are 24 to #terms, 11 to #reports and none to #related, so auto-opening the details element on #terms is required, and the proposal includes it. Two problems. (a) '§1 moves up by about 800 px' is overstated: collapsing the glossary (459 px) and removing the start card saves about 480 px at 1280. (b) Collapsing all 26 ladder notes at every width hides caveats that desktop readers scan, such as the droop's calibration, the halted-hart hazards and the ECC gaps. hub-u-19 and hub-u-20 already shorten the longest notes.


#### hub-u-10 — CONFIRMED [claim/low] et-soc1-limits-of-observability

Where: script.js fittext: 'about a fifth of their unmetered power'

Files: docs/reports/sources/limits-of-observability.script.js

Problem: The DRAM residual is about a quarter of those configurations' unmetered power, not a fifth.


APPLY (PROPOSAL): Change 'about a fifth of their unmetered power' to 'about a quarter of their unmetered power'. The replacement text in hub-u-02 already includes this.


Verifier note: Recomputed with fit_unmetered's own functions: DRAM-configuration rms over mean unmetered W is 1.098/4.02 = 0.27 (a2) and 1.285/5.09 = 0.25 (a3). 'A quarter' is right and 'a fifth' is wrong. hub-u-02's text already includes the fix.


#### hub-u-11 — CONFIRMED [claim/low] et-soc1-limits-of-observability

Where: body.html §4.1 ('so a burst measured through it reads 45% low on aifoundry2'); data.json rung 7 effect ('the ring's energy read 45% low'); docs/findings/05-claims.md line 310; docs/findings/19-observability-and-the-unmetered.md line 83

Files: docs/reports/sources/limits-of-observability.body.html, docs/reports/sources/limits-of-observability.data.json, docs/findings/05-claims.md, docs/findings/19-observability-and-the-unmetered.md

Problem: '45% low' is the worst of three passes, stated as if it always held.


APPLY (PROPOSAL): §4.1: 'reads 45% low on aifoundry2' → 'reads 33–45% low on aifoundry2 (three passes)'. Rung 7 (or the hub-u-08 text): 'read 45% low' → 'read 33–45% low'. Make the same change in 05-claims line 310 and 19-observability line 83.


Verifier note: analyze_reruns.reduce_dir on rl-pass1..3 gives xshire16 at 7.29, 8.19 and 8.86 pJ/B on aifoundry2 (sampler medians 146, 76 and 138 ms). aifoundry3 gives 13.81, 13.79 and 12.20 (mean 13.27), so aifoundry2 reads 45%, 38% and 33% low. '45%' is the worst pass. The same figure also sits in data.json rung 7 and 05-claims.md:310; the latter did not show in a naive grep because the line contains '.jsonl'.


#### hub-u-12 — MODIFIED [claim/low] et-soc1-limits-of-observability

Where: body.html §4.2 'Three things follow': 'about 70 pJ per byte in the DDR PHY, the I/O rail and the DRAM chips, on top of the 50–60 pJ the mesh, the SRAM and the delivery losses take on the way'

Files: docs/reports/sources/limits-of-observability.body.html

Problem: The split comes from subtracting the pooled 70 pJ/B coefficient from random-data totals, but the off-rail cost itself depends on the data. On random data it is 75–90 pJ/B, leaving 40–60 on the rails. On zeros it is 50–65, leaving about 30. The '50–60 pJ' holds only for random operands under the pooled coefficient.


APPLY (CORRECTED): Use the reviewer's replacement with '75–92 on random data'. Make the same change in docs/energy-manual/04a-fine-grain.md:160.

Base PROPOSAL (for "as proposed" references): Replace 'about 70 pJ per byte in the DDR PHY, the I/O rail and the DRAM chips, on top of the 50–60 pJ the mesh, the SRAM and the delivery losses take on the way; a byte written through the L1 costs twice that off-rail, because the line is read from DRAM before it is written.' with 'about 70 pJ per byte on average in the DDR PHY, the I/O rail and the DRAM chips (50–65 on zeros and constants, 75–90 on random data), on top of the 30–60 pJ the mesh, the SRAM and the delivery losses take on the way: together the energy manual's 91–129 pJ per byte for tensor loads from DRAM. A byte written through the L1 costs about twice that off-rail (120–175 pJ), because the line is read from DRAM before it is written.'


Verifier note: Real. '50–60 pJ' equals the random-data total (129.5/127.8 pJ/B) minus the pooled coefficient; on zeros the same subtraction gives about 20. Per configuration, off-rail on zeros/const is 51.2–64.3 and on random 76.5–92.1 (dramrow/stride1K/random 92.1 on a2). Total minus off-rail is 27.9–43.8 on zeros/const and 40.6–59.4 on random. st_stream off-rail is 121.9–173.9. So the random range is 75–92, not 75–90. The same sentence is in docs/energy-manual/04a-fine-grain.md:160 (with 73 pJ), and the reviewer did not list it.


#### hub-u-13 — MODIFIED [claim/low] et-soc1-limits-of-observability

Where: body.html KPI 3 ('Finest energy' / '133 µJ' / '1 mW × 133 ms on a rail; a bit flip is ~10⁻¹⁶ J; repetition gets the median bar to ±6% per event'); data.json ladder 'Energy per event' note ('… is a million times below the floor …')

Files: docs/reports/sources/limits-of-observability.body.html, docs/reports/sources/limits-of-observability.data.json

Problem: The lede gives the energy floor as 'a few joules' worth of identical events', while the KPI tile calls 133 µJ the 'finest energy'. The ladder note measures against an undefined 'floor' that only works out if the floor is 133 µJ. Because the rail value is the PMIC's τ ≈ 1 s average, a single short event of 133 µJ does not register at all: it raises the reading by E/τ, so 1 mW needs about 1 mJ.


APPLY (CORRECTED): KPI label: 'One reading's energy step'; value: 133 µJ. Sub-line: '1 mW × 133 ms on a rail (aifoundry2), spread over about a second by the PMIC's average, so one event must carry about 1 mJ to move it; the manual resolves events by repeating them (≥10⁹ a second for 3 s) to a median bar of ±6%; a bit flip is ~10⁻¹⁶ J.' Ladder note as proposed.

Base PROPOSAL (for "as proposed" references): KPI: change the label 'Finest energy' to 'One reading's energy step'. Change the sub-line to '1 mW × 133 ms on a rail, spread over about a second by the PMIC's average; an event is resolved only by repeating it (≥10⁹ a second for 3 s) to a median bar of ±6%; a bit flip is ~10⁻¹⁶ J'. Ladder note: 'is a million times below the floor' → 'is a million times below one reading's 133 µJ step'.


Verifier note: Real. 133 µJ is 1 mW × 133 ms, one reading's LSB-period. The rail value is the PMIC's τ≈1 s average, so an impulse E raises it by only E/τ at peak, and a single event needs about 1 mJ to move it one step. The board's 10 mW × 133 ms step is 1.3 mJ. The ladder note's 'a million times below the floor' works only with a 133 µJ floor, while the lede's floor is joules. The relabel is right. The sub-line should state the useful fact, about 1 mJ per single event, which the reviewer's evidence derives but the proposal omits. It should also note that 133 ms is aifoundry2's refresh (see missed).


#### hub-u-14 — MODIFIED [claim/low] et-soc1-limits-of-observability

Where: script.js drooptab (f(e.droop_ddr_mv), f(e.droop_minion_mv)) and its header 'unmetered W less fitted rail losses'

Files: docs/reports/sources/limits-of-observability.script.js, docs/reports/sources/limits-of-observability.body.html

Problem: Three minion-droop cells show -0.02 mV, although the raw monitor reads a constant 518 mV around all those bursts. Every droop is printed to 0.01 mV, from a 1 mV monitor with a 0.36 mV fit rms, against C5. The column header does not use the text's own name for the quantity, 'off-rail DRAM power'.


APPLY (CORRECTED): 1. Use mv1 for both droop columns, as proposed. 2. Keep the header 'unmetered W less fitted rail losses'. If the name matters, tie it in drooptext instead: '…per watt of off-rail DRAM power (the table's unmetered watts less fitted rail losses)'. 3. Round the prose to 0.1 mV, or generate it (hub-u-15). Option A of hub-u-03 removes the -0.02 at the source.

Base PROPOSAL (for "as proposed" references): 1. In script.js add const mv1 = v => (Math.round(v * 10) / 10).toFixed(1); (this renders -0.02 as 0.0, not -0.0). Use mv1 for both droop columns.
2. Rename the header 'unmetered W less fitted rail losses' to 'off-rail DRAM W (fitted)'.
3. In the §4.3 prose, change '1.74 mV' → '1.7 mV' and '1.05 mV' → '1.0 mV', or generate the prose as in hub-u-15.
hub-u-03 option A also fixes the -0.02 at the source.


Verifier note: The -0.02 mV is spurious. die_mv.minion is exactly 518 in every sample from t_lo−3 to t_hi+1 for all three passes of add/zeros/h2, st_stream/dram/random and tstore/dram/random, and the committed script gives 0.000. 0.01 mV precision exceeds what a 1 mV monitor with a 0.36 mV rms supports (C5). In JS, Math.round(-0.22) is -0 and (-0).toFixed(1) is '0.0', so mv1 works. But renaming the header to 'off-rail DRAM W (fitted)' reverses PLAN §3.2 item 4, which deliberately changed 'DRAM W off-rail (fit)' to 'unmetered W less fitted rail losses'. The energy manual's 04a table uses the same wording, so the rename would also break consistency between the two pages.


#### hub-u-15 — CONFIRMED [reproducibility/low] et-soc1-limits-of-observability

Where: data.json power.fit / power.droop / power.idle_73c; body.html §4.3 hand-typed '1–1.7 mV … 1.74 mV … 1.05 mV … 0.6–1.5 mV … 0.8–1.8 W'

Files: tools/ettelem/sync_hub_power.py, docs/reports/sources/limits-of-observability.body.html, docs/reports/sources/limits-of-observability.script.js, docs/findings/04-artifacts.md

Problem: No script writes the page's power block. It equals unmetered_fit.json and dvfs.json today only because it was copied by hand. The prose then types the example droops and the ranges derived from them a second time, so a refit reaches neither.


APPLY (PROPOSAL): 1. Add tools/ettelem/sync_hub_power.py (about 25 lines). It loads docs/reports/data/2026-09-23-energy-manual/unmetered_fit.json and docs/reports/data/2026-09-22-dvfs-aifoundry2/dvfs.json, and sets in docs/reports/sources/limits-of-observability.data.json:
   - power.fit = {aifoundry2, aifoundry3} (minus per_config)
   - power.droop = ddr_droop
   - power.idle_73c = {board_w, board_sd, minion_w: rails.minion, sram_w: rails.sram, noc_w: rails.noc, unsensed_w: board_minus_rails, die_c, hours: hours_idle}
   - power.per_config, if present (hub-u-04)
   Record it in 04-artifacts before build-report.py.
2. In body.html, replace 'droops it by 1–1.7 mV (<code>tload/scp/random</code> 1.74 mV and <code>wire/hop6/random</code> 1.05 mV in the table above), 0.6–1.5 mV more than the fit allows, which it would read as roughly 0.8–1.8 W of DRAM' with 'droops it <span id="droopmesh"></span>'.
3. In script.js after drooptext, add: const ex = c => Dp.examples.find(e => e.cfg === c), M = ['tload/scp/random', 'wire/hop6/random'].map(ex), X = M.map(e => e.droop_ddr_mv - Dp.mv_per_board_w_common * e.over_idle_w), a = Dp.mv_per_dram_offrail_w, lo = v => f(Math.min(...v), 1), hi = v => f(Math.max(...v), 1); document.getElementById('droopmesh').innerHTML = `by ${lo(M.map(e => e.droop_ddr_mv))}–${hi(M.map(e => e.droop_ddr_mv))} mV (<code>tload/scp/random</code> ${f(M[0].droop_ddr_mv, 1)} mV and <code>wire/hop6/random</code> ${f(M[1].droop_ddr_mv, 1)} mV in the table above), ${lo(X)}–${hi(X)} mV more than the fit allows, which it would read as roughly ${lo(X.map(x => x / a))}–${hi(X.map(x => x / a))} W of DRAM`;
   With the committed file this prints 1.0–1.7, 1.7, 1.0, 0.6–1.5 and 0.8–1.8.


Verifier note: power.fit, power.droop and power.idle_73c equal unmetered_fit.json (aifoundry2, aifoundry3, ddr_droop) and dvfs.json idle_check field for field, and nothing writes them. The prose repeats the example droops by hand. The proposed JS prints 1.0–1.7, 1.7, 1.0, 0.6–1.5 and 0.8–1.8 from the committed file; I checked the arithmetic, e.g. (1.735 − 0.02498·10.51)/0.8409 = 1.75. One addition: once per-configuration droop rows exist (hub-u-22), take the non-DRAM range from all configurations rather than the two examples, because those rows reach 2.0–2.2 mV.


#### hub-u-16 — MODIFIED [reproducibility/low] et-soc1-limits-of-observability

Where: body.html §4.1 ('a step reaches 61% after one second and 88% after two'); data.json rung 4; workloads/enercat/analyze_catalogue.py comment and its '/ 0.94' rail correction

Files: workloads/enercat/analyze_catalogue.py, docs/reports/sources/limits-of-observability.body.html, docs/reports/sources/limits-of-observability.data.json

Problem: The rail-filter figures (canonical D2) have no committed computation; they appear only in a comment. The same τ sets analyze_catalogue's 0.94 factor, which scales every rail figure the §4.2 fit uses.


APPLY (CORRECTED): 1. Add rail_filter(...) to analyze_catalogue.py as proposed, reporting the fall at 1 s and 2 s and τ per card, and cite it in §4.1 and rung 4: 'about 55–60% after one second and 85% after two (τ ≈ 1.1 s)'. Update D2, 14-card-behaviour.md:59, 19-observability.md:18, 09-method.md:46 and 03-experiments.md:99 to match.
2. Do not change 0.94 silently: it moves D10. Either keep 0.94 and state the systematic, or change it and restate D10 everywhere.
3. In §4.2 'Three things follow', after '18–20% … is lost', add: '(this rests on the rail meters' gain and on correcting their one-second average; each 1% in either moves it by about a point, and a 1.6% difference in rail scale would explain the cards' 10% difference)'.

Base PROPOSAL (for "as proposed" references): 1. Add rail_filter(t, rails, board, bursts) to analyze_catalogue.py. For bursts with rails_over.minion_w > 8 and at least 4 s of idle either side, it finds the board's down-step time t0, computes (rail(t0) − rail(t0+s)) / (rail(t0) − idle_after) for s = 1 and 2, and fits τ. Write catalogue.json rail_filter = {card: {frac_1s, frac_2s, tau_s, n}}.
2. Derive the 0.94 from the fitted τ rather than a constant.
3. Cite catalogue.json rail_filter in §4.1 and rung 4. If the committed result stands, change '61% after one second and 88% after two' to 'about 57% after one second and 85% after two (τ ≈ 1.1 s)', and update D2, 14-card-behaviour.md, 09-method.md and 03-experiments line 99.


Verifier note: Real: no committed code computes 61%/88%. I measured independently from the catalogue telemetry, over bursts with more than 8 W on the minion rail and at least 4 s of idle on each side. After the board step-down the rail has fallen 57%/84% at 1 s and 2 s (a2, n = 242) and 54%/83% (a3, n = 229); the rise relative to the end reading is 55–59% and 86–88%. That is τ ≈ 1.1–1.25 s, so 61% is slightly high. The reviewer missed why step 2 matters: the 0.94 sets the rail scale, and the minion delivery-loss coefficient is degenerate with it. Rescaling the rails gives exactly the same fit rms. A factor of 0.933 (τ 1.07) gives a minion coefficient of 0.186/0.168, 0.927 gives 0.180/0.161, and 0.919 gives 0.169/0.151. So D10's '18–20%' moves about 1.2 points per 1% of rail scale, and SRAM tends to 0. Also, aifoundry3's readings refresh only every ~250 ms (see missed), which biases its τ estimate. Some of the slow tail may be the die's own leakage rise after a burst rather than filter residue.


#### hub-u-17 — CONFIRMED [reproducibility/low] et-soc1-limits-of-observability

Where: §4.1 idle table source (data.json power.idle_73c ← dvfs.json idle_check); docs/findings/03-experiments.md E19; tools/ettelem/analyze_dvfs.py docstring

Files: docs/findings/03-experiments.md, tools/ettelem/analyze_dvfs.py

Problem: The idle table reproduces byte for byte, but no document records the command that builds dvfs.json. The reproduction had to reconstruct its inputs from five experiment entries.


APPLY (PROPOSAL): Add to E19 in 03-experiments.md and to the analyze_dvfs.py docstring:

D=docs/reports/data
python3 tools/ettelem/analyze_dvfs.py --cold $D/2026-09-21-horace-aifoundry2/cold1 $D/2026-09-21-horace-aifoundry2/cold2 --wakeup $D/2026-09-22-dvfs-aifoundry2/wakeup --idle $D/2026-09-22-dvfs-aifoundry2/idle_20h.jsonl.gz --since $D/2026-09-21-horace-aifoundry2/long2/runs.jsonl.gz --model $D/2026-09-21-horace-aifoundry2/model.json --ablation $D/2026-09-21-horace-aifoundry2/ablation.json --sptrace $D/2026-09-22-cards/sptrace-aifoundry3.bin --out $D/2026-09-22-dvfs-aifoundry2/dvfs.json

then python3 tools/ettelem/build_cards_data.py … --merge $D/2026-09-22-dvfs-aifoundry2/dvfs.json, with the arguments from the reproduction.


Verifier note: I ran the reviewer's analyze_dvfs.py command. Its idle_check equals the committed dvfs.json exactly, and every key other than 'cards' matches. 'cards' comes from build_cards_data.py --merge, whose full command is already in tools/ettelem/finish_horace.sh:60–65. Neither E19 nor the analyze_dvfs.py docstring gives the concrete inputs. The hub needs only idle_check, which the first command produces. Suggestion: add the analyze_dvfs command to finish_horace.sh just before its merge step, and cite that script in E19, instead of writing '…' for the merge arguments.


#### hub-u-18 — MODIFIED [redundancy/low] et-soc1-limits-of-observability

Where: data.json rung 2 effect; body.html §5 'What each rung does to the unmetered watts' paragraph

Files: docs/reports/sources/limits-of-observability.data.json, docs/reports/sources/limits-of-observability.body.html

Problem: '0.35 W rms (1.1–1.3 W rms on the DRAM configurations)' appears five times: the KPI tile, the §2 row, §4.2, rung 2 and the §5 paragraph. The last two add nothing to §4.2.


APPLY (CORRECTED): Rung 2 effect: 'Unmetered power above idle named per configuration: 18–20% delivery loss on the minion rail, 68–73 pJ per DRAM byte off-rail (§4.2). The idle 15 W stays unattributed.' §5 paragraph as proposed.

Base PROPOSAL (for "as proposed" references): Rung 2 effect → 'Unmetered power above idle named per configuration (§4.2); the idle 15 W stays unattributed.' In §5, replace 'the regression splits the part above idle by source to 0.35 W rms across the catalogue (1.1–1.3 W rms on the DRAM configurations) and leaves the idle 15 W unsplit (rungs 2 and 3, done).' with 'rungs 2 and 3 attribute the part above idle (§4.2, §4.3) and leave the idle 15 W unsplit.'


Verifier note: The repetition is real: the rms appears in the KPI, the §2 row, §4.2, rung 2 and the §5 paragraph. The §5 paragraph change is right. But rung 2's cell is the 'What changes in the numbers' column. Cutting it to a pointer removes the two named numbers (18–20% minion delivery loss, 68–73 pJ per DRAM byte), which a reader of the §5 table uses to see what the rung bought. The only duplicate part is the rms clause.


#### hub-u-19 — CONFIRMED [redundancy/low] et-soc1-limits-of-observability

Where: body.html §4.3 first paragraph; data.json ladder 'Temperature and voltage' note

Files: docs/reports/sources/limits-of-observability.body.html, docs/reports/sources/limits-of-observability.script.js, docs/reports/sources/limits-of-observability.data.json

Problem: The §4.3 opening paragraph restates table#pvttab almost cell for cell: 5 controllers, 8 temperature sensors, 2×16-channel monitors, 8 process detectors, 35 live, 12-bit and 0.061 °C, 125 points at 14-bit and 75 µV, the per-shire breakdown. The §2 note repeats it a third time.


APPLY (PROPOSAL): 1. Replace everything from 'The die carries a Moortec PVT subsystem:' to 'and none of them is read.' with 'The die's Moortec PVT subsystem, and what of it reaches the host, is in the table below.' Keep the spatial-brief sentence.
2. In script.js pvttab, extend the temperature Count cell to `${V.ts_active} live of 40 (${V.controllers} controllers × ${V.ts_per_controller}; one per minion shire and one in the IO shire, the PCIe shire's dropped from the RTL)`.
3. Ladder note: cut the first sentence 'Moortec PVT: 5 controllers, each 8 temperature sensors, 2 voltage monitors of 16 channels, 8 process detectors.' and end the note with '(§4.3)'.


Verifier note: The §4.3 opening paragraph restates pvttab nearly cell for cell: 5×8 temperature sensors (35 live, 0.061 °C, 12-bit), 125 VM points at 14-bit/75 µV with the per-shire breakdown, 35 of 40 process detectors, and the external inputs. The ladder note repeats the counts a third time. The only unique fact in the prose, which sensors are live (one per minion shire plus IO; the PCIe shire's dropped from the RTL), is carried into the table by the proposal. Nothing a reader needs is lost.


#### hub-u-20 — CONFIRMED [redundancy/low] et-soc1-limits-of-observability

Where: data.json ladder notes 'Rail power' and 'DDR-rail droop'

Files: docs/reports/sources/limits-of-observability.data.json

Problem: The Rail power note repeats §4.1: the 84 values, the unforwarded input side, the 1 ms I2C busy-wait and the rails without telemetry. The DDR-rail droop note repeats §4.3's load-line argument and the common term.


APPLY (PROPOSAL): Rail power note → 'The output side (w_out) of the three PMBus regulators only; the other rails have no power telemetry, and the input side is read by the SP but not forwarded (§4.1). ettelem --reset-ms reads the min/max over a chosen window.' DDR-rail droop note → 'Calibrated against the §4.2 regression, so not independent of the board meter; heavy mesh and scratchpad traffic moves it too (§4.3).'


Verifier note: The Rail power note restates §4.1: the 84 values, input side read but not forwarded, the 1 ms I2C wait, and the rails without telemetry (§4.1 prints the list in #norails). The DDR-droop note restates §4.3: the load line, calibration against the regression, and the 0.025 mV common term. The proposed pointers keep the ladder row's essential scope and the ettelem --reset-ms tip. See hub-u-07: keep rung 14's busy-wait text, so the firmware 'how' survives outside §4.1.


#### hub-u-21 — CONFIRMED [redundancy/low] et-soc1-limits-of-observability

Where: §9 'Related reports' (h2#related, ul#relatedlist from data.json related[8])

Files: docs/reports/sources/limits-of-observability.body.html, docs/reports/sources/limits-of-observability.data.json, docs/reports/sources/limits-of-observability.script.js

Problem: On the hub, §1 is already the full report index, with a sentence on what each report established. §9 lists eight of those reports again with reworded descriptions (654 px at 1280, 1,590 at 390). No other page links to #related.


APPLY (PROPOSAL): 1. Keep '<h2 id="related">9. Related reports</h2>', so the contents list and plan X1 still hold.
2. Replace its intro and ul#relatedlist with '<p>Every report is in <a href="#reports">§1</a>, with what it established and which instruments it used.</p>', followed by the existing docs/findings sentence.
3. Delete D.related from data.json and the relatedlist line from script.js.


Verifier note: On the hub, §1 is the full index with a description per report. §9's eight entries re-describe a subset; for example, Horace's 'zeros 38 W, ones 47 W, random 63 W' repeats §1. §9 is about 654 px at 1280 px and 1,590 at 390 px, and no page links to #related. This reverses PLAN §3.2 item 22, which built the list. The owner's new instruction to remove redundant information justifies that. Keeping the h2 satisfies X1 and check_page.sh, and §9 is last, so no section is renumbered.


#### hub-u-22 — MODIFIED [visualization/low] et-soc1-limits-of-observability

Where: §4.3, replacing table#drooptab (the eight-row droop table)

Files: tools/ettelem/fit_unmetered.py, docs/reports/sources/limits-of-observability.script.js, docs/reports/sources/limits-of-observability.body.html

Problem: §4.3 says the DDR monitor droops 0.84 mV per off-rail DRAM watt, that the slope rests on 11 configurations, and that mesh and scratchpad bursts sit 1–1.7 mV above the fit. The eight hand-picked rows cannot show the 386-point relation, the rms band, or how many non-DRAM bursts fool the meter.


APPLY (CORRECTED): As proposed, with these changes:
- Default view: x = W over idle (board), y = measured DDR droop, with the calibrated line for DRAM points and the ±rms band. Offer predicted-vs-measured as a toggle, next to the minion-rail view.
- Label dramrow/stride8K as 'L3 reads through the mesh'.
- The phantom-DRAM readout uses excess / 0.865.
- The §4.3 prose takes its non-DRAM range from these rows: up to about 2.2 mV, about 2 W of phantom DRAM.

Base PROPOSAL (for "as proposed" references): 'Is the DDR monitor a DRAM meter?' (contingent on hub-u-03 option A, so the rows match the published coefficients).

Data: fit_unmetered.droop() adds per_config = [[cfg, droop_ddr_mv, dram_offrail_w, over_idle_w, droop_minion_mv, rail_minion_w] …] (386 rows, about 20 KB), synced to data.json power.droop.per_config.

Encoding:
- Scatter with x = predicted droop (a·off-rail DRAM W + b·other W, from power.droop) and y = measured droop, both 0–7 mV.
- A y = x line with a ±rms band in var(--grid).
- Class colours as in hub-u-04, with the eight former table rows labelled.
- A second view (toggle) plots minion-rail droop against minion rail W with the 0.068 mV/W line, for the §4.3 IR-drop sentence.

Interactions: hover, tap, or ←/→ with Enter on the focusable SVG show cfg, measured and predicted droop, the excess in mV and 'reads as X W of phantom DRAM' (excess / a). Class chips toggle classes. Buttons switch views.

It replaces table#drooptab; the eight rows move into <details><summary>the numbers</summary>…</details>. Understanding it gives: the reader sees the 11 DRAM points on the line, and the cloud of mesh and scratchpad bursts 1–2 mV above zero that makes it a proxy rather than a meter.


Verifier note: Feasible and useful, and correctly made contingent on hub-u-03 option A. I rebuilt the script's per-configuration droops: 386 rows, 11 DRAM, smallest DRAM droop 2.94 mV (st_stream/dram/zeros), and residuals above 1 mV on 10 configurations. The largest are tstore/scp/random +1.71, dramrow/stride8K/random +1.64, tload/scp/random +1.60 and wire/hop2/random +1.55. The reviewer's picture needs two corrections. (a) The 'cloud' is not only mesh and scratchpad traffic: fswl.ps/random/h2 (+1.47) and several AMOs (+0.88) sit there too. (b) dramrow/stride8K/random, the second-largest non-DRAM droop at 2.24 mV, is an L3 read through the mesh that is named like a DRAM row (05-claims.md:290). Unlabelled, it will read as a DRAM point off the line. On axes: predicted-vs-measured squeezes all 375 non-DRAM points into x ≤ 0.75 mV. A view of x = board W over idle against y = DDR droop shows the key point better: fmadd at 26 W droops 0.55 mV while DRAM at 7–10 W droops 3–6 mV.


#### hub-u-23 — MODIFIED [layout/low] et-soc1-limits-of-observability

Where: body.html <style>: 'th,td{padding:6px 8px;overflow-wrap:anywhere}' and '@media (max-width:899px){#reportstab,#laddertab,#imptab,#contrast,#sessionstab,#pvttab,#drooptab{min-width:760px}}'

Files: docs/reports/sources/limits-of-observability.body.html, docs/reports/sources/report.template.html

Problem: At 390 px every big table is a 760 px sideways scroll. The narrow first columns break words mid-word: 'Unmetere d power', 'Temperatu re and voltage', 'Instrumen t', and '(publish ed 24 Sep)' in the Ridge points row. The page is 40,900 px tall on a phone. At 1280 px the four-number idle and fit tables stretch across 1,320 px, so each value sits far from its label.


APPLY (CORRECTED): CSS changes:
- 'th,td{padding:6px 8px;overflow-wrap:anywhere;-webkit-hyphens:auto;hyphens:auto}'. Set lang='en-GB' in the template, which is harmless for all pages.
- '#idletab,#fittab{max-width:680px}'.
- Below 600 px, turn #laddertab and #imptab into stacked cards as proposed. The renderers add data-label='<column name>' to each td, and CSS shows 'td[data-label]::before{content:attr(data-label);display:block;font-size:0.75rem;color:var(--muted)}' (the first cell excepted).
- Remove those two tables from the min-width list.
- For #reportstab, widen the When column (12%) or put the date under the title below 600 px.

Base PROPOSAL (for "as proposed" references): CSS changes in body.html's <style>:
- Replace 'th,td{padding:6px 8px;overflow-wrap:anywhere}' with 'th,td{padding:6px 8px;overflow-wrap:break-word;hyphens:auto}td code,td a{overflow-wrap:anywhere}', and set <html lang="en-GB"> in the template for hyphenation.
- Add '#idletab,#fittab{max-width:680px}'.
- Add '@media (max-width:599px){#laddertab thead,#imptab thead{display:none}#laddertab tr,#imptab tr{display:block;border-bottom:1px solid var(--border);padding:8px 0}#laddertab td,#imptab td{display:block;border:0;padding:2px 0}#laddertab td.lvl,#imptab td.lvl{font-weight:600}}'.
- Drop #laddertab and #imptab from the min-width:760px list, so both render as stacked cards with no sideways scroll.


Verifier note: The diagnosis is confirmed. At 390 px the headers break as 'Instrumen t', the tables are 760 px sideways scrolls, and the page is 40,903 px tall. At 1280 px the idle and fit tables span 1,233 px. But replacing overflow-wrap:anywhere with break-word does nothing under table-layout:fixed: column widths do not depend on content, and both values break an overflowing word at an arbitrary point. I rendered the swap at 390 px and 'Instrumen t' is unchanged. Only hyphens:auto (with lang, and -webkit-hyphens for Safari) or a wider or stacked layout fixes it. Stacked cards with the thead hidden would also drop the column meanings (granularity, how, who, cost, effect) unless each cell carries its own label.


#### hub-u-24 — MODIFIED [consistency/low] et-soc1-limits-of-observability

Where: §4.1 idle table header ('after about 20.6 h') and sessions row E18/E19, against PLAN.md D20 ('about 20.5 hours', 'since 15:08')

Files: docs/reports/data/2026-09-24-report-review/PLAN.md

Problem: The hub, DVFS, Horace, why-low-power and the findings files all say 20.6 h, which the data supports. The canonical D20 says 20.5 h and 15:08. An applier following D20 would introduce an error.


APPLY (CORRECTED): Leave the hub unchanged. PLAN.md is a dated record, so add an erratum line under D20 instead of rewriting it: 'Erratum (verified): dvfs.json idle_check gives 20.63 h; E16's last launch ended at 15:06 (telemetry to 15:08). Use about 20.6 hours wherever this plan says 20.5 (lines 183, 500, 1173, 1181, 2155, 2181); do not set hours_idle by hand.'

Base PROPOSAL (for "as proposed" references): Leave the hub unchanged. In PLAN.md and PLAN.json D20, change 'about 20.5 hours' → 'about 20.6 hours' and 'since 15:08 on 21 Sep' → 'since 15:06 on 21 Sep'.


Verifier note: Real. (1790102658913 − 1790028387724)/3.6e6 = 20.63 h. The last launch ended at 15:06:27 UTC−7 on 21 Sep, and the telemetry ran to 15:08. The hub, E19 and 16-dvfs.md:128 already say 20.6 h and 15:06, and no page says 20.5. But no PLAN.json exists; only PLAN.md. Besides D20 (line 183), PLAN.md also says 20.5 at lines 500, 1173, 1181 ('Set hours_idle to 20.5 and regenerate dvfs.json', which would actively introduce the error), 2155 and 2181.


#### hub-u-25 — MODIFIED [claim/low] et-soc1-limits-of-observability

Where: body.html §4.2 last sentence ('how the idle 12–15 W splits'); data.json ladder 'Unmetered power, attributed' note; rungs 9 and 20 ('the idle 12–15 W', 'The last 12–15 W of idle')

Files: docs/reports/sources/limits-of-observability.body.html, docs/reports/sources/limits-of-observability.data.json

Problem: The idle unsensed remainder across the catalogue reaches 16 W on aifoundry2.


APPLY (CORRECTED): Replace '12–15 W' with '12–16 W' in the four hub places. At the first one (§4.2), add '(12–13 W on aifoundry3 at 50–56 °C, 14–16 W on aifoundry2 at 66–83 °C)'. Make the same change in 04a-fine-grain.md:162, 19-observability.md:40, 05-claims.md:405 and 03-experiments.md:693.

Base PROPOSAL (for "as proposed" references): Replace '12–15 W' with '12–16 W' in all four places.


Verifier note: Real. Per burst, p_idle_w minus the three rail idles is 14.37–16.00 W on aifoundry2 at 66–83 °C (p95 15.67) and 12.04–13.41 W on aifoundry3 at 50–56 °C, so the range is 12–16 W. The same '12–15 W' also appears in docs/energy-manual/04a-fine-grain.md:162, 19-observability.md:40, 05-claims.md:405 and 03-experiments.md:693, which the reviewer did not list.


#### hub-u-26 — CONFIRMED [consistency/low] et-soc1-limits-of-observability

Where: §2 intro ('rows added after 20 September are unreviewed (·)'); §8 bullet 2 ('Those rows have not had the two-agent review.')

Files: docs/reports/sources/limits-of-observability.body.html

Problem: The power rows (DDR-rail droop, Unmetered power, attributed, Regulator input power per rail) show '·' and are called unreviewed. The 24 September cross-check did review and correct them (PLAN hub-2 and hub-3), and today's run reran their scripts, so a reader is told less than is true.


APPLY (PROPOSAL): §8: replace 'Those rows have not had the two-agent review.' with 'Those rows were not in the 20 September two-agent review; the 24 September cross-check recomputed their numbers from the data (<a href="https://github.com/yaroslavvb/et-soc1-prototyping/tree/main/docs/reports/data/2026-09-24-report-review/">its record</a>).' In the §2 intro, after 'rows added after 20 September are unreviewed (·)', add ' by that survey (§8)'.


Verifier note: The three power rows show '·' (check 'unverified', titled 'not reviewed'). PLAN §3.2 items 3–4 rewrote their text today against unmetered_fit.json, and fit_unmetered.py reproduces the attribution exactly (droop to 3%, which the adjacent span#fitsource already says). The proposed §8 and §2 wording is accurate and does not overclaim, and the linked review directory exists in the repo.


### Missed by the reviewers (found by the verifiers)


#### M-hub-1 [claim] et-soc1-limits-of-observability

Problem: The page says the card reports board power, rails and the DDR monitor 'every 133 ms', as a property of the card: in the lede, §4.1, the Board and Rail power ladder rows, the DDR-droop row, §4.3 'updating every 133 ms' and the KPI. That holds only on aifoundry2. On aifoundry3 the host-visible values change about every 250 ms. I measured how often the minion rail value changes while it is moving by more than 0.5 W per second, sampled at 100 ms: aifoundry2 146–175 ms in all 24 telemetry files; aifoundry3 242–262 ms in all 7 (horace-aifoundry3, catalogue, enercat, reruns rl-pass1–3, wire, wire2). Board changes under loads above 15 W: 162 vs 278 ms. took_ms is 22 ms on both cards, so the sampler is not the cause. Neither the page nor docs/findings mentions this.

APPLY: §4.1: 'The SP's copy refreshes every 133 ms on aifoundry2 (about every 250 ms on aifoundry3, from how often its readings change; whether its SP loop or its PMIC is slower is not established) …'. Board power gran: 'a new value every 133 ms (aifoundry2; ~250 ms on aifoundry3)'. Say the same in the lede, the DDR-droop row and §4.3, and add a line to 14-card-behaviour.md's board_w/sp.* table rows. hub-u-05's replay caption and hub-u-13's KPI should say 'aifoundry2'.


#### M-hub-2 [claim] et-soc1-limits-of-observability

Problem: '18–20% of what the minion rail delivers is lost between the 12 V input and the core' is presented as a measured delivery loss, pinned to ±1.4%. The coefficient is degenerate with the rails' scale: the PMIC's unverified gain, and analyze_catalogue's fixed /0.94 correction for the one-second average. Rescaling all rails leaves the fit rms identical (0.346/0.295 W for every factor I tried). The minion coefficient, though, moves about 1.2 points per 1%: factors of 0.944/0.933/0.927/0.919 give 0.201/0.186/0.180/0.169 (a2) and 0.182/0.168/0.161/0.151 (a3). The measured rail response (τ ≈ 1.1–1.2 s, hub-u-16) points to 0.92–0.93. The cards' 10% difference in this coefficient equals a 1.6% difference in rail scale.

APPLY: §4.2 'Three things follow', after '…between the 12 V input and the core': ' — as far as the rails' own meters can be trusted: the figure rests on their gain and on the correction for their one-second average, and each 1% in either moves it by about a point (a 1.6% difference in rail scale would explain the two cards' 10%)'. In fittext, change 'The minion coefficient is pinned to 1.4%' to 'The minion coefficient is pinned to 1.4% statistically'. Heat per millimetre §10 already says the mesh rail's gain is unchecked; link it.


#### M-hub-3 [claim] et-soc1-limits-of-observability

Problem: The non-DRAM droop in §4.3, the ladder note ('mesh traffic adds up to about 1.7 mV') and D10 ('1–1.7 mV, a phantom 0.8–1.8 W') come from two hand-picked examples. Across all 375 non-DRAM configurations, with the committed script's windows, the largest DDR droops are dramrow/stride8K/random 2.24 mV, tstore/scp/random 2.00, wire/hop2/random 1.97 and tload/scp/random 1.90. The largest residuals, +1.6 to +1.7 mV, read as about 2 W of phantom DRAM. dramrow/stride8K is L3 reads through the mesh named like a DRAM row (05-claims.md:290).

APPLY: State the range over all configurations: 'heavy mesh, scratchpad and L3 traffic with no DRAM access droops it by up to about 2 mV, which it would read as up to about 2 W of DRAM'. Generate it from per-configuration rows (hub-u-15/22) rather than typing it. Wherever a per-configuration chart or table shows dramrow/stride8K, label it 'L3 reads through the mesh'.



## Group energy-manual


### Reproduction problems


#### R-em-1 [medium] docs/reports/data/2026-09-23-energy-manual/enercat.json

Problem: The committed E26 reduction is stale. Its rails_busy and rails_idle fields (6 per record, 112 records) are the mean of the service processor's [avg, min, max] triple, not the average. The first-edition analyze_enercat.py read s['sp'][k] whole; commit 4845a60 fixed it to [0] but never regenerated the file. manual.json copies these values, and so does the data embedded in the published page (D.enercat). 09-method.md describes this triple-averaging as 'an earlier analysis', but the E26 data still carries it.

Evidence: Rerunning analyze_enercat.py changes exactly 672 numbers, all rails_*: aifoundry2 rails_idle.minion_w goes from 24.64 to 11.05 W, and aifoundry3 sram from 4.52 to 2.16 W. 24.64 ≈ (11.059+7.57+55.312)/3. git log shows enercat.json last written in 6377ce4, and the script changed later in 4845a60. The page and markdown do not read these fields, so no printed number changes.

Fix: Regenerate: analyze_enercat.py → enercat.json, build_energy_manual.py → manual.json, then build-report.py energy-manual. The rendered page text stays byte-identical. The worktree already holds the regenerated files.


#### R-em-2 [low] docs/reports/sources/energy-manual.script.js

Problem: The SRAM per-MB comparison mixes two definitions. The aifoundry2 figure (19.4 mW/MB) is the whole rail measured at 80 °C. The aifoundry3 figure ('fitted the same way, gives 27 mW/MB') is the fitted exponential term A/128, which 04a itself says 'is not the arrays' leakage'. E27 in 03-experiments quotes that fitted term for aifoundry2 as '22 mW/MB'.

Evidence: From catalogue.json: aifoundry2 fit gives P_fix −0.32 + A 2.81 W, so A/128 = 21.9 mW/MB, and the measured 80 °C bin is 2.483 W = 19.4 mW/MB. aifoundry3 fit gives 0.35 + 3.51 W, so A/128 = 27.4 mW/MB and the whole rail at 80 °C = 30.2 mW/MB. Affected text: script.js line 453, 04a-fine-grain.md line 83 (from render_catalogue.py), 03-experiments.md line 583.

Fix: Compare like with like: 21.9 against 27.4 mW/MB (fitted terms), or 19.4 measured against about 30 extrapolated (whole rail). Change 03-experiments E27 to 19.4 mW/MB for the whole rail, or label its 22 as the fitted term.


#### R-em-3 [low] docs/energy-manual/README.md

Problem: Two populations are used for the catalogue's scatter statistics, and the page, markdown and findings quote different ones for the same section. Page §3.1 and §9 use 161 random-data instructions on aifoundry2: SE 1.8%/5.4%, half-range ±5.9%/±11.7%. 03a.md, README §3.1, 09-method.md and E27/E29 use all configurations: SE 1.9%/6.1%, half-range ±5.6%/±11.5%.

Evidence: Recomputed from catalogue.json: over the 161 instructions, median SE 1.80%, p90 5.37%, half-range 5.85%/11.73%. analyze_catalogue.py prints 1.9%/6.1% and 5.6%/11.5% over all configurations. The README's §3.1 row says '1.9% in the median' next to 'all 161 instructions'.

Fix: Pick one definition, or state which population each figure covers wherever it appears.


#### R-em-4 [low] docs/findings/05-claims.md

Problem: Small numeric slips in claims that are not on the page: 's ↔ s+16 ... energy read 45% low', and st_stream 'at 26.6 GB/s'. Also in 03-experiments E28: 'the signal is 2–2.6 W over idle' and '68–70% of a DRAM read is on no metered rail'.

Evidence: The dropped aifoundry2 xshire16 passes give 7.29/8.19/8.86 pJ/B (mean 8.11) against 13.27 on aifoundry3: 45% low for pass 1 only, 39% on the mean. enercat st_stream runs at 26.9 GB/s on the device clock and 26.8 GB/s on the wall clock. dramrow2 over idle is 2.16–2.58 W on random data and 1.63–1.93 W on zeros; the unmetered share is 67–71% on random data and 73–75% on zeros.

Fix: Change to 'about 40% low (33–45% by pass)' and 26.9 GB/s. For E28, say 'random data' for the 2–2.6 W and 67–71% figures.


#### R-em-5 [low] docs/reports/data/2026-09-23-energy-manual/unmetered_fit.json

Problem: No committed script regenerates the droop block. It was computed inline, and fit_unmetered.py gives 0.865 mV/W, a common term of 0.0286 and an rms of 0.375, against the committed 0.841, 0.0250 and 0.355. This is already disclosed on the page, in the README, in 03-experiments and 05-claims, and in the script's docstring.

Evidence: fit_unmetered.py reports: 'attribution: reproduced exactly; droop block: differs by up to 15%'.

Fix: Optionally write the script's own fit into the file (with --overwrite) and quote 0.87 mV/W (1 mV ≈ 1.2 W still holds), so that every number comes from a script.


#### R-em-6 [low] scripts/build-report.py

Problem: A fresh checkout or worktree cannot build the page. tex2svg.js needs mathjax-full, which lives only in the main checkout's untracked node_modules.

Evidence: In the worktree: "tex2svg.js failed ... Cannot find module 'mathjax-full/js/mathjax.js'". It builds with NODE_PATH=/home/yaroslavvb/claude/et-soc1-prototyping/node_modules.

Fix: Add a package.json that pins mathjax-full, or mention `npm install --no-save mathjax-full` in 04-artifacts / the energy-manual README regeneration block.


### Review findings


#### em-r1 — CONFIRMED [reproducibility/medium] et-soc1-energy-manual

Where: docs/reports/data/2026-09-23-energy-manual/enercat.json (rails_busy/rails_idle); docs/reports/data/2026-09-22-hotline-aifoundry2/power.json and hotline.json (power.idle/runs *.minion_w, sram_w, noc_w); embedded in the page as D.enercat.cards.*.rails_* and D.sync.atomics.*

Files: docs/reports/data/2026-09-23-energy-manual/enercat.json, docs/reports/data/2026-09-22-hotline-aifoundry2/power.json, docs/reports/data/2026-09-22-hotline-aifoundry2/hotline.json, docs/reports/data/2026-09-23-energy-manual/manual.json

Problem: Two committed reductions still carry the first-edition bug that averaged the service processor's [avg, min, max] rail triple. Commit 4845a60 fixed analyze_enercat.py and analyze_hotline_power.py to read element [0] but did not regenerate enercat.json, power.json or hotline.json. The stale values flow into manual.json and into the data embedded in the published page. No printed number reads them today, but any future chart of the rails would be wrong by up to 13.6 W.


APPLY (CORRECTED): As proposed. When telling the hot-line group, add one thing: their page's own reproduction block (hot-line.body.html line 210, analyze_hotline.py … --out hotline.json) would also drop the hand-added 'context' block, so that command needs the same patch-the-power-block step or a note.

Base PROPOSAL (for "as proposed" references): Regenerate, patching only hotline.json's power block so that 'context' survives:
```
python3 workloads/enercat/analyze_enercat.py docs/reports/data/2026-09-23-enercat-aifoundry2 docs/reports/data/2026-09-23-enercat-aifoundry3 --out docs/reports/data/2026-09-23-energy-manual/enercat.json
python3 tools/ettelem/analyze_hotline_power.py docs/reports/data/2026-09-22-hotline-aifoundry2 --out docs/reports/data/2026-09-22-hotline-aifoundry2/power.json
python3 -c "import json;p='docs/reports/data/2026-09-22-hotline-aifoundry2/';h=json.load(open(p+'hotline.json'));h['power']=json.load(open(p+'power.json'));json.dump(h,open(p+'hotline.json','w'),indent=1)"
python3 tools/ettelem/build_energy_manual.py --out docs/reports/data/2026-09-23-energy-manual/manual.json
python3 scripts/build-report.py energy-manual docs/reports/data/2026-09-23-energy-manual/manual.json docs/reports/2026-09-23-energy-manual.html
```
Check that the rendered text is unchanged (render_text.sh before and after; the repro run already showed this for enercat). Tell the hot-line group, because hotline.json is also their page's input.


Verifier note: Reproduced in scratch. Regenerating enercat.json changes exactly 672 rails_idle/rails_busy leaves (up to 13.6 W; a2 row 0 minion_w 24.64 committed vs 11.05). Regenerating power.json gives idle minion 10.77 vs 24.55, sram 1.94 vs 3.63 and noc 3.58 vs 5.45, with nj_per_op and over_idle_w identical. The proposed python one-liner changes only the 18 rail lines of hotline.json and keeps 'context'. build_energy_manual.py run in a symlinked tree with the patched inputs changes only /enercat/cards (672) and /sync/atomics (18). build-report.py on that manual.json renders text byte-identical to today's page. The baseline rebuild is byte-identical to the committed manual.json and HTML. Proposal is safe.


#### em-c1 — MODIFIED [consistency/medium] et-soc1-energy-manual

Where: §4.3, the paragraph after the DRAM-row table (script.js line 401, rowtext); docs/findings/03-experiments.md E28 lines 601–602

Files: docs/reports/sources/energy-manual.script.js, docs/findings/03-experiments.md

Problem: The page offers 'Either the controller closes pages after each access, so the baseline already includes an activation, or the activation is small next to the transfer; the instruments cannot tell which'. Anatomy of a memory access §6 read the controller's registers and found an open-page policy with no idle-close timer, and measured row hits on about two thirds of back-to-back same-row loads. So the first alternative is excluded by another page of the set. A real alternative is missing: with 32 interleaved streams, the harts may close each other's rows. The page also never says why these rows cost 147–156 pJ/B on random data against §4.1's 129.


APPLY (CORRECTED): rowtext: after the bold first sentence, replace the 'Either the controller closes pages…' sentence with: 'The controller runs an open-page policy, but <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-memory-anatomy#how-long-a-row-stays-open">Anatomy of a memory access, §6</a> found that rows left idle for 1,000–2,000 cycles mostly close anyway. Each hart here comes back to its row only every 1,200–1,400 cycles or so (32 harts at 14–17 GB/s), with 31 other streams in between. So either every pattern paid an activation, or an activation is small next to the transfer (one of 20 pJ/B would have shown); for a programmer it makes no difference. These 32-hart loads cost 14–21% more per byte than section 4.1's tensor loads at 76 GB/s (26–30% more on zeros): use them to compare patterns, and section 4.1 to price DRAM.' Make the same change in 03-experiments E28 (lines 600–602), in render_catalogue.py line 189 (then re-render 04a) and in 05-claims line 410 ('Whether rows closed between a hart's visits or the activation is merely small; E28 cannot tell').

Base PROPOSAL (for "as proposed" references): In rowtext, replace 'Either the controller closes pages after each access, so the baseline already includes an activation, or the activation is small next to the transfer; the instruments cannot tell which, and for a programmer it makes no difference.' with: 'The controller runs an open-page policy (<a href="https://spacesheep.dev/@yaroslavvb/et-soc1-memory-anatomy#how-long-a-row-stays-open">Anatomy of a memory access, §6</a>), so it does not close a row after every access. Either an activation is small next to the transfer (one of 20 pJ/B would have shown), or the 32 interleaved streams closed each other's rows so that every pattern paid one. These 32-hart loads run at 14–17 GB/s and cost 15–20% more per byte than section 4.1's tensor loads at 76 GB/s: use them to compare patterns and section 4.1 to price DRAM.' Make the same change in 03-experiments.md E28: 'Either the controller closes pages after each access, so every access already includes an activation, or …' becomes 'The controller runs an open-page policy (E-anatomy, §6), so either the activation is small (<20 pJ/B) or the interleaved streams closed each other's rows'.


Verifier note: The problem is real. Anatomy §6 says the controller is open-page with no idle-close timer, and back-to-back same-row loads hit two thirds of the time, so 'closes pages after each access' is excluded. The reviewer's replacement, though, implies rows stay open, and Anatomy says the opposite. Rows left idle for 1,000–2,000 cycles mostly close anyway, by a mechanism it could not identify: 23% hits after 1,000 cycles, almost none after 1,500–2,000. Here each of the 32 harts moves 14–17 GB/s ÷ 32, so it returns to its row only every ~1,160–1,410 cycles, and Anatomy's own §7 already says interleaved streams probably re-activate on almost every access. The premium figure is also slightly off. Against 4.1's 129.1 pJ/B, random-data rows cost 14% (seq 147.1), 21% (rowhit 155.7) and 19% (rowmiss 153.4) more, and 26–30% more on zeros. The same sentence is mirrored in render_catalogue.py line 189 (04a-fine-grain.md line 60) and in 05-claims.md line 410, which the reviewer did not list.


#### em-c2 — CONFIRMED [claim/medium] et-soc1-energy-manual

Where: §4.3 'Where the current flows' text (script.js line 434, railstext): 'A DRAM byte is mostly off-chip: 70% of its energy is on no metered rail at all — the DDR PHY and the memory itself.'; 03-experiments E28 line 602

Files: docs/reports/sources/energy-manual.script.js, docs/findings/03-experiments.md

Problem: The sentence attributes the whole 70% unmetered share to the DDR PHY and the DRAM. The page's own attribution (unmetered_fit.json), and the hub that quotes it, put about 73 of the 129 pJ/B (57%) there. About 6% is regulator loss on the metered rails, and the rest is the fit's residual. The hub says: 'about 70 pJ per byte in the DDR PHY, the I/O rail and the DRAM chips, on top of the 50–60 pJ the mesh, the SRAM and the delivery losses take'.


APPLY (CORRECTED): As proposed. If em-d1 is also applied, fold em-d1's closing pointer into this sentence rather than linking hub §4.2 twice in consecutive sentences.

Base PROPOSAL (for "as proposed" references): Replace with: '<b>A DRAM byte is mostly off-chip</b>: 70% of its energy is on no metered rail. The fit in <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-limits-of-observability#the-unmetered-remainder-attributed">Limits of observability, §4.2</a> puts 73 of its 129 pJ/B in the DDR PHY, the I/O rail and the DRAM chips; the rest of the unmetered share is the regulators' delivery loss and the fit's residual.' In 03-experiments E28, 'Rails: 68–70% of a DRAM read is on no metered rail (the DDR PHY and the chips)' becomes 'Rails: on random data 67–71% of a DRAM row read is on no metered rail (73–75% on zeros)'.


Verifier note: Recomputed from manual.json. On a2, tload/dram/random is 9.84 W over idle, of which 6.86 W (70%) is unmetered. The fit's loss term is 0.58 W (6%), the DRAM term 72.9 pJ/B × 76.0 GB/s = 5.54 W (56%), and the residual 0.74 W. Unmetered minus the fitted loss is 83 pJ/B. For E28's dramrow2 rows, random is 67/71/68% and zeros 74/75/73%, so '67–71% (73–75% on zeros)' is right. The markdown mirror, 04a line 160, already says '73 pJ per byte in the DDR PHY, the I/O rail and the DRAM chips', so the page would come into line with it and with the hub.


#### em-c3 — MODIFIED [claim/low] et-soc1-energy-manual

Where: §1 first paragraph (body.html line 45): 'The fixed part — PCIe, the DDR PHY, the IO shire and the regulators at rest — does not change with temperature.'

Files: docs/reports/sources/energy-manual.body.html

Problem: The sentence equates the idle law's 12.6 W constant with the blocks that have no rail sensor. The table directly below shows those blocks drawing 15.10 W at 73 °C, more than the whole constant. In the data, the unsensed part is indeed nearly flat with temperature and the metered rails carry the leakage. The 12.6/23.3 split, though, comes from a fit with an imposed 36 °C shape (the SRAM rail's fit needs a negative constant for the same reason); it is not a block-by-block account.


APPLY (CORRECTED): Replace the sentence with: 'The fixed part is the law's constant, 12.6 W. The blocks with no rail sensor (PCIe, the DDR PHY, the IO shire, the regulators) draw about 15 W at idle and barely move with temperature: 0.03 W per °C over 71–83 °C in the catalogue's idle gaps. The three metered rails carry the leakage, 0.55 W per °C between them at about 75 °C. The split into 12.6 W and leakage is a fit with the 36 °C shape imposed, not a block-by-block account.'

Base PROPOSAL (for "as proposed" references): Replace that sentence with: 'The fixed part is the law's constant, 12.6 W. The blocks with no rail sensor (PCIe, the DDR PHY, the IO shire, the regulators) draw about 15 W at idle and barely move with temperature (0.03 W per °C over 71–81 °C in the catalogue's idle gaps); the three metered rails carry the leakage, 0.55 W per °C between them. The split into 12.6 W and leakage is a fit with the 36 °C shape imposed, not a block-by-block account.'


Verifier note: Reproduced from the catalogue telemetry: idle samples at least 1.5 s before and 2.5 s after any burst, n = 9,781. Fitted against die temperature: unsensed 0.033 W/°C (14.9 W at 73 °C), minion 0.361, SRAM 0.073, NoC 0.114 (0.55 together), board 0.581 W/°C. rails_73c.unsensed is 15.10 W, more than P_fix 12.63 W, so the sentence does equate the law's constant with blocks that draw more than it. Two corrections. The idle gaps span 71–83 °C, not 71–81. And 0.55 W/°C holds at about 75 °C, where the law's own slope is 0.56, next to the paragraph's '0.65 W per °C at 80 °C'.


#### em-c4 — MODIFIED [claim/low] et-soc1-energy-manual

Where: §4.3 SRAM chart caption (script.js line 452, sramcap); docs/energy-manual/04a-fine-grain.md line 83 (render_catalogue.py line 223); docs/findings/03-experiments.md line 583

Files: docs/reports/sources/energy-manual.script.js, tools/ettelem/render_catalogue.py, docs/energy-manual/04a-fine-grain.md, docs/findings/03-experiments.md

Problem: 'aifoundry3's rail, fitted the same way, gives 27 mW/MB' is the fitted exponential term A/128. The aifoundry2 figure it sits next to (19.4 mW/MB) is the whole rail measured at 80 °C. The aifoundry3 figure is also an extrapolation of 25 °C from a 4 °C span (51–55 °C), and the same caption already gives the meaningful aifoundry3 fact: 1.90 W at 51 °C against 0.93 W from the aifoundry2 fit. 'a byte held in scratchpad for one second leaks about 19 nJ' presents as fact what the caption itself calls an upper bound. E27 quotes the aifoundry2 fitted term (22 mW/MB) instead of the page's 19.4.


APPLY (CORRECTED): In sramcap, delete the aifoundry3 fitted clause and change 'leaks about 19 nJ' to 'leaks at most about 19 nJ'. Keep the fitted-formula sentence, because the chart draws that curve. Replace it with 'It e-folds every 31 °C over 67–82 °C' only if the drawn line is also changed to the free exponential fit. Apply the render_catalogue.py line 223 and 03-experiments line 583 changes as proposed, and re-render 04a.

Base PROPOSAL (for "as proposed" references): In sramcap, delete '; aifoundry3's rail, fitted the same way, gives 27 mW/MB, an extrapolation from its idle at 51–55 °C'. Change 'leaks about 19 nJ' to 'leaks at most about 19 nJ'. Optionally replace 'Fitted with the idle law's 36 °C e-folding imposed: −0.32 W + 2.81 W·e^((T−80)/36); the negative constant says the rail rises faster than that shape.' with 'It e-folds every 30 °C over 67–82 °C, faster than the board's 36 °C.' In render_catalogue.py line 223, drop the '; fitted the same way it gives … mW/MB at 80 °C, an extrapolation from …' clause (04a line 83 follows). In 03-experiments line 583, change '(78 mW/°C at 80 °C, 22 mW/MB)' to '(78 mW/°C at 80 °C; the whole rail 19.4 mW/MB at 80 °C)'.


Verifier note: The numbers check out. For a2 the fit's A/128 is 21.9 mW/MB and the whole rail at 80 °C is 2.483 W, or 19.4 mW/MB. For a3, A/128 is 27.4, fitted from a 51–55 °C span (5 bins) and extrapolated 25 °C. So the caption sets a fitted term for one card beside a whole-rail figure for the other. 'leaks about 19 nJ' comes from the upper bound. E27's '22 mW/MB' is the fitted term. The optional part of the proposal is harmful as written: the SRAM chart draws exactly the imposed-36 °C fitted curve, so removing the formula from the caption leaves the drawn line unexplained. (A weighted free exponential gives an e-fold of about 31 °C.)


#### em-c5 — MODIFIED [consistency/low] et-soc1-energy-manual

Where: §2 awake table row 4 and awaketext (script.js lines 94, 100); §6 barrier row (line 233, hard-coded 1.4e-3); docs/energy-manual/README.md row 2

Files: tools/ettelem/analyze_reruns.py, docs/reports/data/2026-09-23-energy-manual/reruns.json, docs/reports/sources/energy-manual.script.js, docs/energy-manual/README.md

Problem: The hot-line row in §2 prints the first session only ('a2 only, 22 September', 1.41 W, 1.4 mW), and the prose says '1.4 mW against 2.1'. §6 on the same page says the pooled reruns draw 'about 1.2 W over idle (1.4 W in the first session)'. The page code already looks for RR.hotline_over_idle_w, but analyze_reruns.py never writes it, so the page falls back to the single session. The §6 barrier energy is derived from a hard-coded 1.4 mW.


APPLY (CORRECTED): Do the analyze_reruns.py change as proposed. In script.js, for the §2 row 4 cells under the '(a2)' headers, use hot.per_card.aifoundry2.mean (1.25 W, 1.22 mW) and keep the pooled bar in the per-card column. Alternatively, relabel those two cells 'both cards'. Make §6's barrier use the pooled mean (≈ 10 µJ), and template the note 'stalled at ${…} mW'. Apply the same in render_energy_manual.py lines 145, 335 and 338, then re-render. Change README row 2 to 1.2 mW. If em-d4 is applied, the awaketext edit is moot.

Base PROPOSAL (for "as proposed" references): In tools/ettelem/analyze_reruns.py:
- Add a `hotw` dict next to `hot`.
- In the hot-line loop, append `b["over_idle_w"]` to `hotw[lab][host]`.
- In the first-session block, append `r["over_idle_w"]`.
- Output `"hotline_over_idle_w": {l: stats(v) for l, v in hotw.items()}`.
Regenerate reruns.json and manual.json. In script.js:
- awaketext: use `hot?hot.mean:hw` for the stalled figure, so it reads '1.2 mW against 2.1'.
- §6: replace `1.4e-3` with `(RR.hotline_over_idle_w?RR.hotline_over_idle_w.contended.mean:1.41)/1024`, so it reads '≈ 10 µJ of waiting … stalled at 1.2 mW'.
In README.md row 2, change 'draws 1.4 mW' to 'draws 1.2 mW'.


Verifier note: Verified by running the reviewer's patched analyze_reruns. hotline_nj_per_op and every other block come out byte-identical, and hotline_over_idle_w.contended is 1.190 [1.015–1.413] W, n = 7 (a2 1.248 ± 0.057, a3 1.114 ± 0.064). That is 1.16 mW per minion and a barrier of 9.9 µJ against 11.9 today. The page and render_energy_manual.py (line 141) both already have a code path for it. Three gaps. First, render_energy_manual.py hard-codes the first session at line 145 ('1.4 against 2.1 mW', from at0), at line 335 (1.4e-3 and 'stalled at 1.4 mW') and at line 338 ('about 1.4 mW'), so 02-awake.md and 06-synchronisation.md would still say 1.4 mW and 12 µJ. Second, the §2 row's pooled value would land under the columns headed 'W over idle, 1,024 minions (a2)' and 'per minion (a2)'. Third, em-d4 deletes the awaketext sentence this edits.


#### em-c6 — CONFIRMED [claim/low] et-soc1-energy-manual

Where: §3 text after the instruction table (script.js lines 134–136, instrtext)

Files: docs/reports/sources/energy-manual.script.js

Problem: The text says 'the datapath energy is close, and what the tensor unit mostly saves is instruction issue'. The page's own numbers make issue about half of the saving, not most of it. The comparison also sets uniform [0.5, 2) operands (vector unit) against normal ones (TensorFMA randn), which toggle differently, without saying so. Separately, 'idle lanes are free' is inaccurate: on zeros the lanes are not idle, they compute zeros.


APPLY (CORRECTED): As proposed. Also apply it in render_energy_manual.py lines 183–184 and 03-experiments line 532, then re-render.

Base PROPOSAL (for "as proposed" references): Replace 'the datapath energy is close, and what the tensor unit mostly saves is instruction issue.' with 'of the 1.2 pJ per multiply-add the tensor unit saves, about half is instruction issue and half datapath (the operands differ as well: uniform in [0.5, 2) here, normal for the tensor unit).' Replace 'idle lanes are free' with 'lanes computing on zeros add nothing'.


Verifier note: fmadd.ps random is 55.86/8 = 6.98 pJ per lane and the tensor unit 5.78, a gap of 1.20. Issue per lane is 4.5–5.3/8 = 0.56–0.66 pJ, 47–55% of the gap, so 'mostly' is wrong and 'about half' is right. The operand sets do differ: [0.5, 2) uniform for the vector unit, randn for TensorFMA. The zeros lanes compute zeros, so 'idle' is inaccurate. The same wording is mirrored in render_energy_manual.py lines 183–184 (03-instructions.md lines 30–31) and 03-experiments line 532, which should get the same edit.


#### em-c7 — MODIFIED [consistency/low] et-soc1-energy-manual

Where: §4.1 memtext (script.js line 173): 'because every store allocates a line and the line goes down through L2 and L3'

Files: docs/reports/sources/energy-manual.script.js

Problem: The page gives an on-chip cause for why a byte written through the L1 costs 2.4× a tensor store. The hub (§4.2) and the page's own attribution put the extra off-rail: 'a byte written through the L1 costs twice that off-rail, because the line is read from DRAM before it is written'. The two pages explain the same measurement differently.


APPLY (CORRECTED): Replace ', because every store allocates a line and the line goes down through L2 and L3.' with ': each store allocates its line, so the line is read from DRAM before it is written back and the byte pays for a read and a write. Off-rail it costs 174 pJ against a tensor store's 81 (<a href="https://spacesheep.dev/@yaroslavvb/et-soc1-limits-of-observability#the-unmetered-remainder-attributed">Limits of observability, §4.2</a>), and a tensor load plus a tensor store come to 265 of its 333 pJ/B.' Template 265/333 from cb(); apply the same in render_energy_manual.py line 263.

Base PROPOSAL (for "as proposed" references): Replace ', because every store allocates a line and the line goes down through L2 and L3.' with ': off-rail such a byte costs about 174 pJ, twice a tensor store's 81, because each store allocates its line and the line is read from DRAM before it is written (<a href="https://spacesheep.dev/@yaroslavvb/et-soc1-limits-of-observability#the-unmetered-remainder-attributed">Limits of observability, §4.2</a>).'


Verifier note: The data support the hub's cause, but the proposed text gives only the off-rail half. On a2, st_stream random is 342 pJ/B: 140 on the metered rails (minion 32, SRAM 39, mesh 70), 28 delivery loss and 174 off-rail. tstore/dram is 50 metered and 81 off-rail. tload/dram is 39 metered and 83 off-rail. So the off-rail 174 ≈ 83 + 81 (a read plus a write), and pooled a tensor load plus a tensor store is 129.1 + 136.2 = 265 of st_stream's 333 pJ/B. A byte through the L1 pays for a DRAM read and a DRAM write, on and off the rails. The old on-chip cause is not simply wrong, but it is incomplete. The mirror sentence in render_energy_manual.py line 263 (04-bytes-memory.md line 36) needs the same fix.


#### em-c8 — MODIFIED [consistency/low] et-soc1-energy-manual

Where: docs/energy-manual/README.md row 3.1; page §3.1 caption (allcap) and §9

Files: docs/energy-manual/README.md, docs/reports/sources/energy-manual.script.js

Problem: Two populations are used for the catalogue's scatter statistics. The page's §3.1 caption uses the 161 instructions on random data on aifoundry2 (SE 1.8%/5.4%, half-whisker ±5.9%/±11.7%). The README's §3.1 row pairs 'all 161 instructions' with 1.9%, which is the figure over every configuration (1.9%/6.1% and ±5.6%/±11.5%, as in 03a, 09-method and E27/E29).


APPLY (CORRECTED): README row 3.1: 'pass-to-pass standard error 1.8% in the median' (the 161 instructions, matching the page). Leave allcap unchanged.

Base PROPOSAL (for "as proposed" references): In README.md row 3.1, change 'pass-to-pass standard error 1.9% in the median' to 'pass-to-pass standard error 1.8% in the median over the 161 instructions (1.9% over every configuration)'. On the page, append ' (over every configuration: 1.9% and ±5.6%)' to the end of allcap so both populations are named once.


Verifier note: Confirmed: a2 over all 392 configurations gives a median SE of 1.88% and a 90th percentile of 6.12%; the 161 instructions give 1.8% and 5.4%, and the combined half-range is 5.55% / 11.51%. The README row that says 'all 161 instructions' quotes 1.9%. The fix belongs in the README. Adding the every-configuration figures to the §3.1 caption puts two more numbers on a page this review is trying to thin, and the caption is about the 161.


#### em-c9 — CONFIRMED [claim/low] et-soc1-energy-manual

Where: docs/findings/05-claims.md lines 268 and 310; docs/findings/19-observability-and-the-unmetered.md line 83; docs/findings/03-experiments.md E28 line 603

Files: docs/findings/05-claims.md, docs/findings/19-observability-and-the-unmetered.md, docs/findings/03-experiments.md

Problem: Small numeric slips in claims that feed the page's provenance. 's ↔ s+16 … energy read 45% low': that is true of one pass only; the mean is 39%. st_stream 'at 26.6 GB/s': the data say 26.9. E28 'the signal is 2–2.6 W over idle': that holds for random data only (zeros 1.6–1.9 W).


APPLY (PROPOSAL): 05-claims line 310 and findings/19 line 83: 'energy read 45% low' → 'energy read about 40% low (33–45% by pass)'. 05-claims line 268: '26.6 GB/s' → '26.9 GB/s'. 03-experiments line 603: 'so the signal is 2–2.6 W over idle' → 'so the signal is 2.2–2.6 W over idle on random data (1.6–1.9 W on zeros)'.


Verifier note: Recomputed with analyze_reruns.reduce_dir. The dropped a2 xshire16 passes read 7.29, 8.19 and 8.86 pJ/B (mean 8.11) against a3's 13.27, which is 45%, 38% and 33% low by pass and 39% on the mean. In E26 enercat, st_stream is 26.91 GB/s on the device clock (both cards) and 140.02e9/5.226 s = 26.8 on the wall clock; nothing gives 26.6. On dramrow2, over idle is 2.16–2.58 W on random data and 1.63–1.93 W on zeros.


#### em-r2 — MODIFIED [reproducibility/low] et-soc1-energy-manual

Where: docs/reports/data/2026-09-23-energy-manual/unmetered_fit.json (ddr_droop); page §4.3 droop text and §9 paragraph; hub §4.3; PLAN D10

Files: docs/reports/data/2026-09-23-energy-manual/unmetered_fit.json, tools/ettelem/fit_unmetered.py, docs/reports/sources/energy-manual.body.html, docs/reports/sources/energy-manual.script.js

Problem: No committed script regenerates the committed droop numbers, which were computed inline. The gap is disclosed three times on this page alone (§4.3 attribution 'reproduces this fit exactly', §4.3 droop '(… reproduces the coefficient to within 3%, 0.87 against 0.84 mV/W)', and the §9 paragraph), plus in the hub, the README and the script's docstring.


APPLY (CORRECTED): For the energy manual: apply em-d1 and em-d5, which remove all three of this page's copies of the droop numbers and the disclosure. Whether to regenerate unmetered_fit.json is the hub group's call. If they do, update every example-derived value in the hub prose and table, and render_catalogue.py lines 148, 178 and 309 (drop the hard-coded '0.87 against 0.84' and the reproduction clauses, then re-render 04a). Also update 03-experiments E30, findings/19, 05-claims and README, and the fit_unmetered.py docstring. Record the change in a note beside PLAN.md rather than editing D10.

Base PROPOSAL (for "as proposed" references): Run `python3 tools/ettelem/fit_unmetered.py --out docs/reports/data/2026-09-23-energy-manual/unmetered_fit.json --overwrite`. Then update the quoted values: 0.84 → 0.87 mV/W and rms 0.36 → 0.38 mV in the hub drooptext, PLAN D10, 05-claims and README, and refresh the hub's droop table from ddr_droop.examples. Replace the 'Reproducibility against …' paragraph of the fit_unmetered.py docstring with 'Writes unmetered_fit.json.' and delete every '(… reproduces … within 3% …)' clause. If the owner prefers to keep the inline numbers, keep only the §9 disclosure on this page (and see em-d1, which removes the §4.3 copies anyway).


Verifier note: The numbers reproduce: fit_unmetered.py gives 0.865 mV/W, rms 0.375 and common term 0.0286 against 0.841, 0.355 and 0.0250 committed; the attribution is exact; 1/0.865 = 1.16. The proposal is incomplete, and most of it is the hub's business. Regenerating also changes the ddr_droop.examples the hub and the markdown quote: tload/scp/random goes 1.74 → 1.90 mV and wire/hop6/random 1.05 → 1.16. That moves the hub's prose 'mesh traffic adds up to about 1.7 mV', 'about +1 to +1.7 mV', '1–1.7 mV', '0.6–1.5 mV more … 0.8–1.8 W', not just its table. render_catalogue.py hard-codes '0.87 against 0.84 mV/W' (line 309) and the reproduction clauses (lines 148 and 178), which would turn wrong or meaningless. The same applies to E30 (03-experiments line 676) and findings/19. PLAN.md is a dated record of the review and should not be rewritten.


#### em-r3 — CONFIRMED [reproducibility/low] et-soc1-energy-manual

Where: docs/energy-manual/README.md 'Regenerating' block; page §9 <pre><code> block (body.html line 182)

Files: docs/energy-manual/README.md, scripts/build-report.py, docs/reports/sources/energy-manual.body.html

Problem: Neither command list rebuilds the page from raw data in a fresh checkout. The README block starts at build_energy_manual.py and omits the three reductions it depends on (analyze_enercat.py, analyze_catalogue.py, analyze_reruns.py). The page's block omits analyze_enercat.py and the build-report step. build-report.py needs mathjax-full, which is only in an untracked node_modules; the version is unpinned, and the byte-identical SVG depends on it.


APPLY (CORRECTED): As proposed, applied after em-r1.

Base PROPOSAL (for "as proposed" references): Prepend to the README's Regenerating block:
```
npm install --no-save mathjax-full@3.2.1   # once, for build-report.py's TeX
python3 workloads/enercat/analyze_enercat.py docs/reports/data/2026-09-23-enercat-aifoundry2 docs/reports/data/2026-09-23-enercat-aifoundry3 --out docs/reports/data/2026-09-23-energy-manual/enercat.json
python3 workloads/enercat/analyze_catalogue.py docs/reports/data/2026-09-23-catalogue-aifoundry2 docs/reports/data/2026-09-23-catalogue-aifoundry3 docs/reports/data/2026-09-23-catalogue-aifoundry2-rows --out docs/reports/data/2026-09-23-energy-manual/catalogue.json
python3 tools/ettelem/analyze_reruns.py docs/reports/data/2026-09-23-reruns-aifoundry2-warm docs/reports/data/2026-09-23-reruns-aifoundry3 --out docs/reports/data/2026-09-23-energy-manual/reruns.json
```
Add the line '(the card-side runners, run_enercat.sh, run_catalogue.py, run_reruns_warm.sh, run_rl_warm_a2.sh and run_rings_levels_power.sh, are in docs/findings/03-experiments.md, E26–E29)'. Pin @3.2.1 in build-report.py's docstring and error message. On the page, replace the whole <pre><code> block with one sentence (see em-d5).


Verifier note: Checked. The README block starts at build_energy_manual.py, and the page's block omits analyze_enercat.py and build-report.py. The proposed analyze_catalogue.py and analyze_reruns.py commands reproduce catalogue.json and reruns.json byte for byte. analyze_enercat.py reproduces enercat.json only after em-r1 (672 rail leaves differ today), so em-r3 depends on em-r1. node_modules is gitignored with no package.json, the installed mathjax-full is 3.2.1, and build-report.py's docstring and error message give no version.


#### em-d1 — CONFIRMED [redundancy/medium] et-soc1-energy-manual

Where: §4.3, the two paragraphs after the rail-split chart: 'Attributed: over the whole catalogue …' and 'A droop meter for DRAM: …' (script.js lines 180–188 unmetText/droopText/dramRms, used at line 434); §1 link 'section 4.3 attributes it'

Files: docs/reports/sources/energy-manual.script.js, docs/reports/sources/energy-manual.body.html

Problem: About 230 words repeat the hub's canonical treatment: Limits of observability §4.2 (#the-unmetered-remainder-attributed: the same coefficients with SEs, rms, the DRAM residual) and §4.3 (the droop meter with its table, the 0.84 mV/W, and the mesh caveat). The hub's E30 row names 'This page, §4' as the home. The manual's copy is the only place carrying the '(… 0.87 against 0.84 mV/W)' disclosure twice.


APPLY (CORRECTED): As proposed. Two notes. Merge the new pointer with em-c2's DRAM sentence so hub §4.2 is not linked twice in a row. And decide explicitly whether the markdown mirror keeps its fuller section (render_catalogue.py lines 276–315, 04a '## What is on no metered rail'). Keeping it is fine, but README row 4.3 should then point to the hub for the canonical version.

Base PROPOSAL (for "as proposed" references): Delete unmetText, droopText and dramRms. End railstext after the three bold sentences, followed by one paragraph: '<p>What the unmetered part is made of (18–20% of the minion rail's watts lost in delivery, about 70 pJ per DRAM byte off-rail) and a free DRAM meter hidden in the DDR rail's voltage (1 mV ≈ 1.2 W) are fitted over this catalogue in <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-limits-of-observability#the-unmetered-remainder-attributed">Limits of observability, §4.2–4.3</a>.</p>'. In body.html §1, change '<a href="#finer-grain-wires-lines-rows-and-the-leakage-of-the-arrays">section 4.3</a> attributes it' to '<a href="https://spacesheep.dev/@yaroslavvb/et-soc1-limits-of-observability#the-unmetered-remainder-attributed">Limits of observability, §4.2</a> attributes it'. Delete the §9 paragraph 'The attribution of the unmetered power and the DDR droop meter in section 4.3 are in …', or keep it only if em-r2 is not done.


Verifier note: The hub text carries every number in the two paragraphs: 0.196/0.177, 0.050/0.064, 0.286/0.264, 72.9/68.1 pJ/B, rms 0.35 W, 1.1–1.3 W on DRAM, 767 mV, 0.84 mV/W, rms 0.36 mV, 1 mV ≈ 1.2 W, 1.74 mV. The hub's E30 row names itself as the home. The replacement paragraph keeps the reader-facing numbers: 18–20% delivery loss matches a2 20% and a3 18%, about 70 pJ/B matches 72.9/68.1, and 1 mV ≈ 1.2 W is correct.


#### em-d2 — MODIFIED [redundancy/medium] et-soc1-energy-manual

Where: §4.3 wiretext (script.js line 376, about 200 words) and wirecap; §5 commtext clause '; Heat per millimetre measures 1.5 pJ/B per hop on the mesh rail and 2.2 on board power directly'

Files: docs/reports/sources/energy-manual.script.js

Problem: Per D9, Heat per millimetre is the canonical home for energy per hop. The wire paragraph re-derives fJ per random bit, explains flips against ones carried, then recommends a different fit and ends 'use its figures for wires'. §5 repeats the Heat-per-millimetre comparison. The chart draws only the 1–8-hop fit, which the text itself calls pulled low.


APPLY (CORRECTED): Use the proposed wiretext, changed to '… <b>and 0.6–0.9 on zeros</b> (0.64–0.75 over 1–8 hops, 0.84–0.89 over 1–6)' and 'the intercept of the 1–8-hop fit is ${intercept} pJ/B on random data against ${local} for the shire's own scratchpad'. Alternatively, template both slope and intercept from whichever fit the toggle selects. The toggle and the wirecap change go in as proposed, and the §5 deletion as proposed.

Base PROPOSAL (for "as proposed" references): Replace wiretext with (keeping the templated numbers): '<b>One mesh hop costs about 2 pJ per byte on random data</b> (${dr} on aifoundry2 and ${dr2} on aifoundry3 fitted over 1–8 hops; ${r6} and ${r6b} over 1–6, leaving out d = 8, which only 16 shires reach and which sits level with d = 6) <b>and 0.6–0.75 on zeros</b>. Leaving the shire costs more than any hop: the intercept is ${intercept} pJ/B on random data against ${local} for the shire's own scratchpad. For wires, use <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-heat-per-mm">Heat per millimetre</a>: 2.17 pJ/B per hop on board power, split into bits that differ between flits and ones carried.' In the wire chart, add a two-button toggle ('fit over 1–8 hops' / '1–6 hops', aria-pressed) that redraws the dashed lines with lfit over the chosen points; wirecap 'Dashed: straight-line fits over 1–8 hops.' becomes 'Dashed: straight-line fit over the hops chosen above.' In §5 commtext, delete '; <a …heat-per-mm>Heat per millimetre</a> measures 1.5 pJ/B per hop on the mesh rail and 2.2 on board power directly'.


Verifier note: The redundancy is real: the rendered §4.3 carries both fits and the fJ-per-bit conversions, and D9 makes Heat per millimetre the home for energy per hop. The proposed text mixes fits, though. 'About 2 pJ/B on random data' spans the 1–8 fit (1.81/1.67) and the 1–6 fit (2.29/2.09), but '0.6–0.75 on zeros' is the 1–8 fit only; over 1–6 the zeros slope is 0.89 (a2) and 0.84 (a3). The ${intercept} 7.90 is the 1–8 fit's intercept (6.55 over 1–6), which a toggle that redraws the fit would contradict. Keeping a one-clause Heat-per-mm link in §5 is harmless; deleting it loses nothing essential.


#### em-d3 — MODIFIED [redundancy/low] et-soc1-energy-manual

Where: Lede paragraph 3 (body.html line 12); instrcap; memcap; linetab last row; §9 'Confidence bars.' first sentence

Files: docs/reports/sources/energy-manual.body.html, docs/reports/sources/energy-manual.script.js

Problem: The bar definition, 'mean over every pass on every card and the range those passes spanned', is written out six times: the lede, the §2 note ('Bars from here on'), the instrcap, the memcap, the line-table footer and §9. The in-chart legends say it a seventh time.


APPLY (CORRECTED): Replace lede paragraph 3 with one sentence: 'Brackets are the range over every pass on both cards; section 9 says how each bar was made, and rows measured once or derived say so.' Leave the §2 note as it is and make the remaining deletions (instrcap, memcap, the linetab footer row, the first sentence of §9's Confidence-bars bullet) as proposed.

Base PROPOSAL (for "as proposed" references): Delete lede paragraph 3, '<p>Every repeated measurement carries a confidence bar — … Rows measured once, or derived, say so.</p>'. Append 'Rows measured once, or derived, say so; how each bar was made is in section 9.' to the §2 note 'Bars from here on: …'. In instrcap, delete ' Each bar is the mean over three shuffled passes on each of two cards; the whisker is the range those six passes spanned.' In memcap, delete ' Whiskers: the range over three shuffled passes on each of two cards.' Delete linetab's last row '<tr><td colspan="4" class="small">Each entry: mean over three passes on each of two cards, and the range those six passes spanned.</td></tr>'. In §9, delete the first sentence of the Confidence-bars bullet ('Every repeated entry is the mean over every pass on every card, with the full range those passes spanned in brackets.'). Keep the in-chart legends.


Verifier note: The definition does appear at rendered lines 9, 71, 114, 384, 460 and 623. But the KPI tiles show '56 pJ [54–58]' and '31× [29–33]' before the §2 note. With lede paragraph 3 deleted, and more so with em-o1 moving the KPIs up, those brackets would appear with no definition.


#### em-d4 — CONFIRMED [redundancy/low] et-soc1-energy-manual

Where: §2 awaketext (script.js lines 99–100); §10 Related reports, Sections 2 and 3.2 item

Files: docs/reports/sources/energy-manual.script.js, docs/reports/sources/energy-manual.body.html

Problem: The prose under the awake table repeats two table rows word for word: the ablation (1.46 W, 1.4 mW, 8.1 pJ) and the stalled minion (1.4 mW against 2.1). Related reports repeats the ablation a third time ('an earlier, slower integer loop (half the addi loop's instruction rate, 1.4 mW per minion)').


APPLY (CORRECTED): As proposed. Optionally end row 4's label with '(less than a spinning minion)' to keep the takeaway. This makes em-c5's awaketext edit moot.

Base PROPOSAL (for "as proposed" references): In awaketext, keep only the first sentence (the nop/fence floor) and delete 'The ablation in <a …>Why is the ET-SoC-1 low power?</a>, whose loop issued at half the one-hart addi loop's rate on hart 0, measured … A minion stalled on a contended atomic draws less than one spinning: … against ….' Move the rate fact into the table: row 3's label becomes 'The 21 September ablation's integer loop (four adds and a branch, half the addi loop's issue rate), hart 0, 80 °C, <a …why-low-power>Why is the ET-SoC-1 low power?</a>'. In Related reports, delete '; the source of the activity-term row of section 2, and of an earlier, slower integer loop (half the addi loop's instruction rate, 1.4 mW per minion)'.


Verifier note: The awaketext's second and third sentences restate rows 3 and 4 (1.46 W, 1.4 mW, 8.1 pJ; 1.4 against 2.1 mW), and Related reports repeats the ablation. The half-rate fact checks: 1.46 W/8.1 pJ over 1,024 minions is 0.29 instructions per cycle, against the addi loop's 2.19 W/5.8 pJ = 0.61, a ratio of 0.48. Moving it into the row label loses nothing.


#### em-d5 — MODIFIED [redundancy/low] et-soc1-energy-manual

Where: §9 end (body.html lines 182–197): the command block, the unmetered_fit paragraph and the Versions paragraph

Files: docs/reports/sources/energy-manual.body.html

Problem: These are leftovers that belong in the repo. The eight-line command block duplicates the README's Regenerating section, and at 1280 px its comments run past the box. The unmetered_fit paragraph is the third copy of the droop disclosure (em-r2). The Versions paragraph is internal history ('first edition 23 September; the second … the third … Corrected on 24 September after a review: …').


APPLY (CORRECTED): Replace the <pre> block with the proposed one-sentence link, and delete the unmetered_fit paragraph. Keep a shortened Versions line: '<p class="small">Versions: three editions on 23 September (the first; every instruction on two cards and section 4.3; confidence bars and the reruns); corrected 24 September after a review.</p>'

Base PROPOSAL (for "as proposed" references): Replace the <pre><code>…</code></pre> block with: '<p class="small">Every table is rebuilt from the committed data by the commands in <a href="https://github.com/yaroslavvb/et-soc1-prototyping/tree/main/docs/energy-manual#regenerating">docs/energy-manual/README.md</a>; the measurement runs are docs/findings/03-experiments.md, E26–E30.</p>'. Delete '<p class="small">The attribution of the unmetered power and the DDR droop meter in section 4.3 are in … and the file keeps the original numbers.</p>' (after em-d1 there is nothing in 4.3 to disclose). Delete '<p class="small">Versions: first edition 23 September; … and the related reports.</p>'. The history stays in git.


Verifier note: The command block does duplicate the README and is clipped at 1280 (screenshot s1280-12 confirms). The unmetered_fit paragraph has no referent after em-d1. Deleting the Versions paragraph, however, breaks convention C2 set in today's PLAN ('Version history goes on a Versions line at the end of Method'), which other pages follow (memory anatomy: 'Versions: published 19 September … Revised 24 September …'). Readers of an earlier edition also need to know the page was corrected.


#### em-d6 — CONFIRMED [redundancy/low] et-soc1-energy-manual

Where: §3 13-instruction table (#instrtab, class 'table-wrap wide'); layout at 1280 px

Files: docs/reports/sources/energy-manual.body.html, docs/reports/sources/energy-manual.script.js

Problem: The §3 table repeats the §3 chart's 39 values, and all 13 rows are again in §3.1's full table. At 1280 px it is also wider than the 908-px column: the 'issue per hart per cycle' header is cut to 'issue per hart per cycl', every rate shows as '0.3' instead of 0.37/0.36, and the per-card column is off-screen unless the reader scrolls.


APPLY (CORRECTED): As proposed. Dropping the per-card column may be enough on its own to fit 908 px, so check before also adding the details wrapper.

Base PROPOSAL (for "as proposed" references): Wrap #instrtab in '<details><summary>The 13 as a table: constant operand, per lane, issue rate</summary>…</details>'. Drop its 'per card, random' column (per-card values are in the chart's hover and in §3.1's table) and shorten the header to 'issue / hart / cycle'. The table then fits 908 px and the chart carries the section.


Verifier note: Screenshot s1280-2 shows the header clipped to 'issue per hart per cycl' and the rates to '0.3'. §3.1's table (in its details element) holds all 13 instructions with zeros, random, per lane, issue rate and a2/a3 ± se. The only thing unique to the §3 table is the constant-operand column, and the §3 chart carries that with bars and hover, so collapsing the table loses nothing.


#### em-d7 — MODIFIED [redundancy/low] et-soc1-energy-manual

Where: §7 relaytext (script.js line 278) and the §5 relay rows

Files: docs/reports/sources/energy-manual.script.js

Problem: The relay's three measured values (105.7 / 3.99 / 8.59 pJ/B with bars) appear in both the §5 table and the §7 check table. relaytext restates the relay's mechanics twice within itself ('reads with 32 B vector loads through the L1 and writes with tensor stores' and again 'The own-scratchpad read uses the 32 B loads through the L1 …'), and repeats '(shire s − 1 by ID)' from the §5 note.


APPLY (CORRECTED): relaytext: 'No row of section 4 was derived from the relay, so this is an out-of-sample check. Each byte is read once and written once, so each bracket is the mean of a read row and a write row of section 4, from zeros to random data (the relay's data is one constant per slab). The relay reads with 32 B loads through the L1 and writes with tensor stores. It is priced with the 32 B L1 row of section 4.3 for its own scratchpad, the wire read of section 4.3 at ${hh} hops for the next shire, and, for DRAM, section 4.1's tensor-load row, the nearest the catalogue has. DRAM and the next shire fall inside their brackets and the own scratchpad reads ${x}% below; the adds and barriers the relay also runs are in no table.' Keep the verdicts templated.

Base PROPOSAL (for "as proposed" references): Keep the §7 table, since the check needs the measured column, but replace relaytext with: 'No row of section 4 was derived from the relay, so this is an out-of-sample check. Each bracket is the mean of the matching read and write rows of section 4, from zeros to random data, because the relay's data is one constant per slab. Reads are 32 B loads through the L1 (section 4.3) for the own scratchpad, the wire read at 3.5 hops for the next shire and tensor loads (section 4.1) for DRAM; writes are tensor stores. DRAM and the next shire fall inside their brackets and the own scratchpad reads 8% below; the adds and barriers the relay also runs are in no table.' (keep the computed values templated).


Verifier note: The redundancy is real. The proposed text, however, drops two things a reader needs to trust the check. It drops the reason for averaging read and write rows ('each byte is read once and written once'). It also drops the caveat that the relay reads DRAM with 32 B loads through the L1 but is priced with the tensor-load row, the nearest the catalogue has. As written, 'Reads are … tensor loads (section 4.1) for DRAM' reads as a description of what the relay does, which is wrong.


#### em-d8 — CONFIRMED [redundancy/low] et-soc1-energy-manual

Where: §10 Related reports (body.html lines 199–213)

Files: docs/reports/sources/energy-manual.body.html

Problem: There are 16 report links in 8 items, about 400 words. They repeat the idle-law formula (its fourth appearance on the page), the ablation (em-d4) and the hub's full contents, and one item says its own measurement is elsewhere. X1 asks for '<link> — why read it'.


APPLY (PROPOSAL): Trim, keeping every link the plan asked for:
- Hub item: replace the text after the link with '— the hub: what each instrument can and cannot see, the unmetered remainder attributed, and the glossary.'
- Section 1 item: delete 'the idle law P = 12.6 W + 23.3 W·e^((T−80)/36), '.
- Section 6 item: 'L2 mainline starvation — a same-day brief about the shire that hosts a hot line; the measurement that section 6 uses is in One hot line stops a shire' becomes 'L2 mainline starvation — a same-day argument about the same shire (its measurement is One hot line stops a shire)'.
- Spatial temperature item: cut it to '— where the 35 temperature sensors sit and why the card reports one number', or drop it (no section of the manual uses it).


Verifier note: There are 8 items (the X1 maximum) with about 400 words. The idle-law formula and the ablation repeat what the page already says. Nothing in PLAN X4 requires the spatial-temperature link from this page. Every link the plan requires is kept.


#### em-o1 — CONFIRMED [reorganize/medium] et-soc1-energy-manual

Where: Whole page; §4.3 in particular

Files: docs/reports/sources/energy-manual.body.html, docs/reports/sources/energy-manual.script.js, tools/ettelem/render_catalogue.py, tools/ettelem/render_energy_manual.py

Problem: §4.3 is a grab-bag. It holds wires, L1 lines, strides, DRAM rows, the rail split, the unmetered attribution, the droop meter, SRAM leakage at rest and neighbourhoods. The SRAM leakage is an idle-power fact that belongs with §1's rail table. The rail split answers 'which meter sees this', not 'what does a byte cost'. The KPI tiles, the page's headline, sit below a 13-line Terms box, on the third phone screen. §7 mixes a worked example with an out-of-sample check.


APPLY (CORRECTED): As proposed, with two dependencies. Moving the KPIs above the Terms box needs em-d3's one-sentence bracket definition placed before them. The new 4.4 id (#where-the-current-flows) should be added to PLAN's list of anchors. The markdown mirror move is optional and can follow later.

Base PROPOSAL (for "as proposed" references): New order, with every existing id kept:
- h1, byline.
- Lede paragraphs 1–2.
- The equation.
- KPIs.
- Contents.
- Terms, as <details open><summary>Terms: minion, hart, shire, scratchpad, SP, PMIC</summary>.
- 1. The card at rest (#the-card-at-rest): idle chart, rail table, then new h3 '1.1 The SRAM arrays at rest' (#the-sram-arrays-at-rest), with the SRAM chart and caption moved from 4.3.
- 2. A core that is awake (#a-core-that-is-awake).
- 3. Instructions (#instructions), with 3.1 (#every-instruction-the-core-executes) and 3.2 (#the-tensor-unit-per-multiply-add).
- 4. Bytes through the memory hierarchy (#bytes-through-the-memory-hierarchy), with the new energy-against-bandwidth map (em-v2) first, then:
  - 4.1 (#reads-and-writes-measured-together);
  - 4.2 (#reads-by-level);
  - 4.3 'Finer grain: wires, lines and rows', keeping id #finer-grain-wires-lines-rows-and-the-leakage-of-the-arrays: wires (shortened, em-d2), the line table, the row table and neighbourhoods;
  - new 4.4 'Where the current flows, by meter' (#where-the-current-flows): the rail-split chart, its three bold sentences and the one-sentence hub link (em-d1).
- 5. Bytes between cores and shires (#bytes-between-cores-and-shires).
- 6. Synchronisation (#synchronisation).
- 7. Composition (#composition-where-a-workload-s-joules-go):
  - 7.1 'Build a workload's energy' (#build-a-workload-s-energy): the calculator (em-v1), whose default preset is the old matmul bar;
  - 7.2 'The relay, priced from section 4' (#the-relay-priced-from-section-4).
- 8. Two cards (#two-cards).
- 9. Method (#method-and-what-the-manual-cannot-tell-you).
- 10. Related reports (#related-reports).
Update the §9 bullet's section list ('sections 2, 3, 4.1, 4.3, 8') to '2, 3, 4.1, 4.3, 4.4, 8'. Mirror the change in docs/energy-manual (move the SRAM block of 04a-fine-grain.md into 01-at-rest.md through render_catalogue.py/render_energy_manual.py).


Verifier note: The structure problems are real. §4.3 mixes wires, lines, rows, rails, attribution, droop, SRAM idle leakage and neighbourhoods, and at 390 px the KPIs start around 1,790 px (s390-1). Every id that is used today is kept, and the inbound #finer-grain… links (Heat per millimetre, Memory anatomy) mean the wires, which stay in 4.3. SRAM leakage at idle belongs with §1's rail table.


#### em-l1 — MODIFIED [layout/medium] et-soc1-energy-manual

Where: All charts use class 'chart scroll' (template: .chart.scroll svg {min-width:640px}); #relaycheck table

Files: docs/reports/sources/energy-manual.script.js, docs/reports/sources/energy-manual.body.html

Problem: At 390 px every 700-wide chart shows only its left 55% until the reader scrolls sideways, and on several charts that hides the result:
- The idle chart stops near 62 °C, so all of aifoundry2's fitted bins (64–88 °C) are hidden.
- The rail-split bars show only the minion and SRAM segments; the mesh segment and the grey 'no sensor' segment the text is about are hidden.
- The composition bar shows fixed + leakage only, and its title 'predicted 63.1 W … measured 63.9 W' is cut.
- The SRAM chart stops at 75 °C.
- The relay-check table hides both the 'priced' and 'measured' columns.
Scaling the same 700-unit viewBox down to fit would make the 12 px labels 6 px, so the fix must re-lay-out rather than just drop the scroll class.


APPLY (CORRECTED): As proposed, plus two changes. First, in the rail split below 480 px, put each row's label on its own line above its bar (row pitch ~40) and use the full width for the bar. Second, in the wire chart (and any chart with a right-hand legend) below 480 px, move the legend to a row above the plot and set the right margin to ~16.

Base PROPOSAL (for "as proposed" references): In script.js host(): read `const cw=document.getElementById(id).clientWidth` and pass `W=Math.max(340,Math.min(700,cw))` to the idle, SRAM, wire, rail-split, composition and cards charts. Each already computes its scales from W. Re-render on a debounced resize. In the rail split, set `L=Math.min(220,Math.round(0.36*W))` and font-size 10 below 480 px. In the composition bar at W<480, stack the labels under the bar in a legend row. In body.html, change class="chart scroll" to class="chart" for #idle, #sram, #wire, #railsplit, #comp and #cards, and keep 'scroll' only for #allinstr and #instr. For #relaycheck, move the parentheticals '(tensor load and tensor store)', '(32 B loads through the L1, tensor store)' and '(the wire read at 3.5 hops, tensor store)' out of the first column into relaytext (em-d7 already names them), so the three columns fit 358 px.


Verifier note: The screenshots confirm clipping at 390 px: the rail-split bars lose most of the grey 'no sensor' segment on the DRAM rows, the SRAM chart stops at ~75 °C, the comp title is cut, and the relay-check columns sit off-screen. One detail is off: the idle chart shows up to ~69 °C, so a2's 64–68 °C bins are visible and the rest hidden. The width-aware re-layout is the right fix, but the proposal misses two things. The rail-split labels run up to 31 characters ('DRAM via the L1 write-back path', ~150 px at 10 px), which does not fit in L = 0.36·W = 129 px, so the text would run off the left edge. And the wire chart has a fixed 140-unit right-hand legend (R3=140), which would leave a 160-px plot at W=358.


#### em-l2 — MODIFIED [readability/low] et-soc1-energy-manual

Where: §8 chart #cards (script.js lines 285–298)

Files: docs/reports/sources/energy-manual.script.js

Problem: The chart is a log–log equality scatter over four decades, so the ±5% card effect the section exists to show is invisible. All 386 points sit on the dashed line, and the '± standard error' crosses the caption mentions are sub-pixel. A reader cannot see the 0.95 median or the 0.75–1.08 outliers.


APPLY (CORRECTED): As proposed, except for the reruns. Either convert the hot-line entries to pJ and widen x to 0.5–30,000, or, better, draw the 24 reruns as a separate labelled strip beside the plot (their x is not comparable anyway), with the ratio on the same y axis.

Base PROPOSAL (for "as proposed" references): Plot the ratio instead:
- y = aifoundry3 / aifoundry2, linear, 0.70–1.20; x = the aifoundry2 value, log, 1–2000 pJ.
- Draw a solid line at the median 0.950 and shade the 10–90% band 0.906–0.987 in var(--grid) (D.catalogue.cross_card.{median,p10,p90}).
- Colour points var(--c1) per instruction and var(--c2) per byte, using D.catalogue.cards.aifoundry2.summary[k].bytes_per_s.mean>0.
- Add the 24 rerun ratios as hollow var(--c7) points (D.reruns.*.per_card), and the tensor-transfer scale 0.924 as a dotted line (D.cards.scale).
- Keep the hover (entry, both values ± se, ratio). Add a focusable list of the five lowest and highest ratios under the chart, so outliers are reachable by keyboard.
The caption stays; drop its 'the cross on each point …' clause.


Verifier note: The log–log equality plot does hide the ±5% effect. Catalogue a2 values run 2.0–1,486 pJ and ratios 0.753–1.078, so the proposed axes fit the catalogue points. The 24 rerun points do not. Five are hot-line entries in nJ (0.57–22.4 nJ, i.e. 570–22,400 pJ). Others sit below 1 (pair ring 0.63 pJ/B, L1 level 0.86 pJ/B). Their ratios, 0.733–1.157, fit the y range. Plotted on the proposed 1–2000 pJ x axis, those points would be clipped or placed with the wrong unit.


#### em-v1 — MODIFIED [visualization/high] et-soc1-energy-manual

Where: New 7.1 'Build a workload's energy' at the top of §7; replaces the static composition bar #comp (keeps compcap/comptext as the default preset)

Files: docs/reports/sources/energy-manual.body.html, docs/reports/sources/energy-manual.script.js

Problem: The page's main claim is its equation: energy = the time integral of P_idle(T) plus Σ N_i·e_i. Yet no chart lets a reader apply it. The only composition shown is one fixed case (a random fp32 matmul at 80 °C). Temperature, data and the mix of events are the three levers the text names ('the data decides the dynamic energy and the temperature decides the rest'), and none of them can be moved.


APPLY (CORRECTED): Build as proposed, with these changes. Price the relay presets from the section-4 rows that §7.2 uses (tensor load + tensor store for DRAM, 32 B L1 row + tensor store for own scratchpad, the wire row at 3.5 hops + tensor store for the next shire), and show the relay's measured pJ/B×GB/s as the tick. Show each measured tick only while the slider is at the temperature it was measured at (±2 °C), and otherwise grey it out with 'measured at 80 °C'. Cap the summed % of instruction-issue rows at 100%, while byte-stream rows may add. Add a duration input (default 7 s) and report joules as well as watts. Any explanatory text should say that at 80 °C the static 36 W exceeds the dynamic power of every measured kernel, the dense random matmul (27.6 W) included.

Base PROPOSAL (for "as proposed" references): An inline SVG plus vanilla JS widget.

Controls:
- A range input 'die temperature' (45–95 °C, step 1, default 80).
- Preset buttons (aria-pressed): 'fp32 matmul, random', 'fp32 matmul, zeros', 'fp16 random', 'int8 random', 'stream from DRAM (tensor load, random)', 'relay: next shire', 'relay: through DRAM'.
- Up to three event rows. Each has a <select> of every catalogue entry plus the tensor rows, and a range input 'rate, % of what the card reached' (0–100%). The absolute rate is shown beside it, capped at the measured maximum.

Chart: one horizontal stacked bar in W, with these segments:
- fixed, var(--ref);
- leakage at T, var(--c4);
- the event terms, var(--c1), var(--c2), var(--c3).
A whisker at the bar's end spans Σ lo to Σ hi.

Readouts: total W, the static share, and pJ per useful op (per FLOP, per byte or per instruction). Where the preset has a measurement, add a tick 'measured 63.9 W (21 Sep ablation)' or the relay's measured value. Note under the chart: 'per-instruction costs include the awake core (section 2); two instruction streams on the same harts count it twice'.

Make the bar full container width with no min-width and let the controls wrap in the template's .controls; all inputs are native, so it is keyboard-usable. Colours come only from tokens.

What the reader learns: at 80 °C the static 36 W outweighs every kernel but a dense random matmul; cooling to 60 °C saves about 10 W; zeros against random moves only the dynamic slice. The page's closing sentence becomes something the reader can test.


Verifier note: The data do exist and the arithmetic checks: 12.63 + 23.26 + 4.59e12 × 5.779 pJ = 62.4 W; the idle law gives 25.98 W at 60 °C; 6.80 → 5.72 pJ/FLOP. Four problems with the proposal as written. (1) The relay presets would take the relay's own measured pJ/B, so the 'measured' tick would equal the prediction by construction. (2) The measured ticks (63.9 W, the relay's W) belong to a launch temperature, 80 °C for the ablation, and are meaningless once the slider moves. (3) Instruction streams share the same harts' issue slots, so two instruction rows at 100% each are impossible; the note covers only double-counting the awake core. (4) The design rationale is wrong: no kernel's dynamic power reaches the static 36 W at 80 °C, and the dense random matmul is 27.6 W, so the page must not say static 'outweighs every kernel but a dense random matmul'. The section title promises joules, but the current bar (titled '7 seconds') and the widget are in watts.


#### em-v2 — CONFIRMED [visualization/medium] et-soc1-energy-manual

Where: Top of §4, replacing the §4.1 log-scale bar chart #mem (the #memtab table stays)

Files: docs/reports/sources/energy-manual.body.html, docs/reports/sources/energy-manual.script.js

Problem: The reader's question in §4–5 is 'where should my bytes live, and what does moving them cost at the speed I need?'. The answer is spread over seven tables and two charts, each in its own units. The §4.1 chart draws bars on a log axis, whose lengths mean nothing, and it omits bandwidth, which the text leans on ('a third of the bandwidth', '12× the bandwidth at a twelfth of the energy').


APPLY (PROPOSAL): Draw a log–log scatter: x = aggregate GB/s (10–20,000), y = pJ/B (0.3–500).
- Every path is a point with a vertical lo–hi whisker. Colour by family: reads var(--c1), writes var(--c2), core-to-core messages var(--c7), relay var(--c3). The wire points hop1–8 are joined by a thin line labelled 'hops'.
- Diagonal iso-power lines, W = pJ/B × GB/s / 1000, at 1, 3, 10 and 30 W in var(--grid), labelled at the right edge.
- Controls: buttons 'zeros / random' and family toggles. A range input 'power over idle, 1–30 W' highlights one diagonal in var(--ink) and fills a readout: 'within X W: DRAM up to its 76 GB/s, own scratchpad N TB/s, …' (min of the measured GB/s and X/pJ).
- Hover and focus: points are tabbable, and arrow keys step along a family. The tooltip gives path, pJ/B [lo–hi], GB/s, W over idle, and a2/a3.
- viewBox 360×320, scaling with the container, so it fits 390 px with 11 px ticks.
What the reader learns: the 31× headline becomes a picture (DRAM and the scratchpad draw the same 10 W at a 32× bandwidth difference), and the reader sees that the relay's two media cost the same power while one moves 12× more.


Verifier note: The data are embedded and the numbers check. DRAM: 129.1 pJ/B × 76 GB/s = 9.8 W. Own scratchpad: 4.21 × 2,458 = 10.3 W. Relay through DRAM: 105.7 × 50 = 5.3 W. Relay to the next shire: 8.6 × 594 = 5.1 W. Rings: 1.5–2.0 W (xshire2 17.8 × 87, pair 0.67 × 2,992). All points fall inside x 10–20,000 GB/s (dramrow2 14 GB/s; L1 via ops_per_s × 32 ≈ 14 TB/s) and y 0.3–500 pJ/B (L1 zeros 0.39, st_stream 333). A 360×320 viewBox that scales with the container works on a phone. The #memtab table keeps the per-path numbers.


#### em-v3 — MODIFIED [visualization/medium] et-soc1-energy-manual

Where: §3.1, replacing #allinstr (161 bars in an SVG with min-width 1,851 px) and its 14-colour legend; the table stays in <details>

Files: docs/reports/sources/energy-manual.script.js, docs/reports/sources/energy-manual.body.html

Problem: §3.1 asks what each instruction costs and how much the data matters. The chart that should answer it fails on several counts:
- The 161 bars are 11 px wide on a log axis, sorted by aifoundry2 alone while the whiskers and the text use the pooled mean.
- Most bars sit in the bottom fifth: the axis runs to 1,393 pJ for one atomic.
- The zeros figure is a 1-px tick.
- The 14 class colours include two identical pairs, so class cannot be read. var(--c4) and var(--warn) are both #eda100 ('Vector integer' and 'Loads and stores that bypass the L1'); var(--muted) #898781 and var(--ref) #8c8b85 ('Masks and broadcasts' and 'Atomics').
The text's claims (28 one-cycle ints span 5.3–6.4 on zeros and 5.4–10.2 on random; a divide 5× mulw; amoaddg 4× amoaddl) cannot be seen in it.


APPLY (CORRECTED): Draw one row per class with the class label on its own line above the row (full width, no left gutter). Draw the random-data value of each instruction as a dot in a beeswarm, dodged vertically within a ~36–44 px row so dots do not overlap. Show the zeros value and the zeros→random segment only for the hovered, focused or searched instruction, plus a toggle 'show zeros for all'. Keep the fence–nop floor band (hide it in per-lane mode), the find box, keyboard navigation and the tooltip as proposed.

Base PROPOSAL (for "as proposed" references): A dumbbell strip plot with one row per class (the 14 CLASSES already in script.js).
- Axis: log x in pJ per instruction, 3–2000.
- Marks: each instruction is a hollow var(--c3) dot at its zeros mean and a filled var(--c2) dot at its random mean (D.catalogue.combined[`${n}/{zeros,random}/h2`].mean), joined by a var(--axis) segment. A shaded vertical band at the awake-core floor spans fence to nop, 4.5–5.3 pJ (combined fence/zeros/h2 and nop/zeros/h2). The class is the row label, so no colour legend is needed.
- Controls: buttons (aria-pressed) 'per instruction / per lane' (÷8 for the LANES set) and 'both cards / aifoundry2 / aifoundry3' (D.catalogue.cards.*.summary[..].pj_per_op.mean); a labelled text input 'find an instruction' highlights a mnemonic and opens its tooltip.
- Keyboard: dots are tabbable, and arrow keys move within and between rows.
- Tooltip: mnemonic, class, zeros and random with [lo–hi], random/zeros, issue per hart per cycle (summary ops_per_cycle_per_hart), and a2/a3 with their ratio.
- Size: 14 rows × 30 px, full container width, no min-width.
If this is not adopted, at least recolour the existing chart by 7 super-groups using only var(--c1)…var(--c7) and draw the bars at the pooled mean.
What the reader learns: the within-class spread and the data dependence the text asserts become visible at a glance, on a phone.


Verifier note: The problems are real. The chart sorts by a2 but draws pooled whiskers. Zeros is a 1-px tick. --c4 and --warn are both #eda100 (#c98500 in dark), and --muted #898781 is nearly --ref #8c8b85 in light. All 161 zeros and random combined entries exist. The proposed dumbbell per class overplots badly, though. The 28 one-cycle integer ops sit at 5.3–6.4 pJ on zeros (0.08 decade) and 5.4–10.2 pJ on random. On a 3–2000 pJ log axis in the ~240 px left at phone width after row labels, that is 28 dumbbells in about 7–24 px. Individual dots and segments become an unreadable smear, and hovering over overlapped dots is unreliable. Left-hand labels such as 'Compressed against full-width, in-place forms' will not fit at 358 px.


### Missed by the reviewers (found by the verifiers)


#### M-em-1 [layout] et-soc1-energy-manual

Problem: At 390 px the page's central equation is clipped. The display-math SVG is 46.12ex wide, wider than the 358-px column, and the template sets .math-display svg{max-width:none} inside an overflow-x:auto span, so the Σ N_i e_i term is off-screen with no cue to scroll (screenshot s390-0 shows 'E(workload) = ∫…dτ + Σ_i .').

APPLY: Add a page-level style in body.html (or the template): '@media (max-width:480px){.math-display svg{max-width:100%;height:auto}}' (a scale of about 0.88, still readable). Alternatively, write the TeX as two lines with \begin{aligned}E(\text{workload}) &= \int_0^t P_\text{idle}(T(\tau))\,d\tau \\ &\quad+ \sum_i N_i e_i\end{aligned}.


#### M-em-2 [consistency] et-soc1-energy-manual

Problem: The claim fixes em-c1, em-c5, em-c6 and em-c7 edit only script.js (and 03-experiments). The markdown manual ('the same manual as markdown', linked from the byline) is rendered from render_energy_manual.py and render_catalogue.py, which hard-code the same sentences. Examples: render_catalogue.py line 189 (04a line 60, 'closes pages after each access'); render_energy_manual.py lines 183–184 ('idle lanes are free', 'mostly saves is instruction issue'), line 263 ('the line goes down through L2 and L3'), and lines 145, 335 and 338 (1.4 mW and 1.4e-3 for the stalled minion and the barrier). There are also 05-claims line 410 and 03-experiments line 532. After the page fixes, the page and the markdown would disagree.

APPLY: For each claim fix, make the same edit in the renderer line named above and re-run render_energy_manual.py and render_catalogue.py (both regenerate from manual.json and catalogue.json, so a sentence there is never typed in the .md). Update 05-claims line 410 and 03-experiments line 532 by hand.


#### M-em-3 [layout] et-soc1-energy-manual

Problem: At 390 px several wide tables put their value columns off-screen behind long descriptive first columns or headers. In §5 (#comm) only 'Ring | What moves | Mesh hops' show and the pJ/B column is hidden (m390-12). In §3.2 (#tensor) the first header cell is a 30-word sentence ('Tensor unit, one instruction per tile (fp32 16×16×16 = 4,096 MACs; …), all 1,024 minions, 80 °C'), so the loaded-pJ, W and MAC/s columns are hidden (m390-4). In §2 (#awake), row labels run 6–10 lines, pushing the W and mW columns off-screen. em-l1 fixes only #relaycheck.

APPLY: Move the §3.2 header's description into tensornote and shorten the header to 'Tensor unit, 1,024 minions, 80 °C'. Below 480 px, hide the §5 'What moves' column (the ring name and the small code already identify the ring; the description can go into a title/tooltip on the ring cell). Put the long §2 row descriptions in a <span class="small"> second line so the first column wraps narrower. Keep table-wrap scrolling as the fallback.


#### M-em-4 [readability] et-soc1-energy-manual

Problem: The §7 chart is titled 'A dense fp32 matmul at 80 °C, 7 seconds, by component' and sits under the heading 'where a workload's joules go', but it plots watts. The 7 s is never used or explained.

APPLY: If em-v1 is not adopted, retitle it 'A dense fp32 matmul launched at 80 °C: board power by component', or multiply the segments by 7 s and label them in joules (predicted 442 J against measured 447 J). With em-v1, add the duration input described there.



## Group heat-per-mm


### Reproduction problems


#### R-heat-1 [medium] docs/reports/sources/heat-per-mm.body.html

Problem: A hand-written §10 sentence claims more than the data support. 'Even if all of the one-hop zeros energy were cost per second, it would explain at most a quarter of the link-disjoint fixed part and a fifth of the loaded one' holds only on the mesh rail. On board power the same bound covers nearly all of the free-link fixed part (14.0 fJ/mm) and 58% of the loaded one (26.8), and the page quotes both. 'At most a quarter' also rounds 27% down.

Evidence: Let E0(1) be the one-hop zeros energy (from wire.json configs wsep|wu/p0/hop1). The per-second model is E0(1)·BW(1)/BW(d), with BW the per-reader bandwidth from checks.per_reader_gb_s, and its slope over d = 1–4 is compared with the measured zeros slope. Results: mesh rail 0.092/0.347 = 0.27 (wsep) and 0.111/0.611 = 0.18 (wu); board 0.409/0.416 = 0.98 and 0.477/0.824 = 0.58. The review's physics skeptic got the same 27%/18% for the mesh rail only (review/workflow-result.json).

Fix: Say 'on the mesh rail, at most about a quarter (27%) of the link-disjoint fixed part and a fifth (18%) of the loaded one; on board power it could be most of it'. Better, compute it in heat-per-mm.script.js from W_.configs and W_.checks.per_reader_gb_s as the other sentences are.


#### R-heat-2 [low] docs/reports/sources/heat-per-mm.script.js

Problem: The die figure's tooltip gives the memory-shire and PHY strip as '≈1.61 mm wide'. It is computed as (die_w − 6·pitch_x)/2 = (25.6 − 22.38)/2, but the research measures 1.74–1.80 mm. For the same reason the drawn grid spans 22.4 mm (87% of the die), while the text says 86% (22.2 mm). The review's arithmetic skeptic flagged this under 'other issues', and it was not applied.

Evidence: script.js §1: mw=gx0=(dw-6*px)/2 with dw 25.6 and px 3.73 gives 1.61. research/geometry/pitch.json scale_from_570mm2.B_symmetric_bottom.memshire_col_w_mm = 1.755. SYNTHESIS.md line 52: 'strips 1.74 and 1.80 mm', '6 columns ≈ 22.2 mm (86% of width)'. The workflow-result.json arith lens says: "The mesh figure's tooltip gives the memory-shire strip as '≈1.61 mm wide'…"

Fix: Put the strip width (about 1.76 mm) and the grid span (22.2 mm) in report.json inputs from pitch.json, and draw the tiles from those; or drop the width from the tooltip.


#### R-heat-3 [low] docs/reports/data/2026-09-24-wire-energy/review/indep/fits.txt

Problem: The committed fits.txt was made with `fits.py --keep-bad`, but the committed fits_leak.txt was made with the default, which drops the starved bursts. The two review outputs therefore use different burst sets. fits.txt's C4 axis block includes the six starved aifoundry2 bursts and prints nonsense for aifoundry2's y axis (rand −309.9, nan, n=9). With the script's own health filter (max latency over 300 ms), aifoundry3's y-only 1–3-hop data part is 111.6 fJ against x at 122.2 (9% below). The page instead says y is '4% above over one to three hops on aifoundry3': 127.6 from the pipeline, which keeps those slow-read bursts because their median latency is 22 ms.

Evidence: Default `python3 fits.py` changes 4 lines (C4). `python3 fits.py --keep-bad` reproduces the committed fits.txt byte for byte. `fits.py --leak` reproduces fits_leak.txt byte for byte. bursts.py marks the aifoundry3 waxis/y/hop3 bursts BAD (max latency 399–549 ms).

Fix: Regenerate fits.txt with the default flags, or record the flag in review/README.md. Optionally hedge §10's axis sentence: the sign of the three-hop y−x difference on aifoundry3 depends on keeping bursts with 0.2–0.55 s readings.


#### R-heat-4 [low] tools/ettelem/build_wire_report.py

Problem: manual.json is opened by a path relative to the working directory, and any exception is swallowed. Run from anywhere but the repo root, the script exits 0 and writes report.json with context={'error': ...}. The page's §9 paragraph (the DRAM, scratchpad and fadd comparisons) then silently disappears, because script.js guards it with if(X.tload_dram_random_pj_per_byte).

Evidence: Running it from the validate2 scratch directory with absolute --wire and --out gives rc=0 and context = {'error': "[Errno 2] No such file or directory: 'docs/reports/data/2026-09-23-energy-manual/manual.json'"}.

Fix: Resolve the path from os.path.dirname(__file__) (repo root = ../..) and fail loudly if it is missing.


#### R-heat-5 [low] docs/findings/03-experiments.md

Problem: The exact command that produces wire.json is not documented. E31 and E32 name analyze_wire.py but give no command line. Reproducing the committed file byte for byte needs the four directories and `--pitch-x-mm 3.73 --pitch-y-mm 3.70`, which I inferred from wire.json per_mm.hop_mm.

Evidence: 03-experiments.md E31/E32 have no command block, unlike E27. 04-artifacts.md A18 describes the script but gives no invocation. The analyze_wire.py docstring shows only placeholders.

Fix: Add to E32 (or A18): `python3 workloads/enercat/analyze_wire.py docs/reports/data/2026-09-24-wire{,2}-aifoundry{2,3} --out docs/reports/data/2026-09-24-wire-energy/wire.json --pitch-x-mm 3.73 --pitch-y-mm 3.70`, followed by the build_wire_report.py and build-report.py commands, all run from the repo root.


#### R-heat-6 [low] docs/reports/data/2026-09-24-wire-energy/wire.json

Problem: The two committed data files use different hop lengths. wire.json's per_mm block uses sqrt(3.73·3.70) = 3.715 mm; report.json and the page use 3.72 mm, the mean of pitch.json readings A and B (3.735, 3.711). Separately, build_wire_report.py's INPUTS source text says '254.8 px tile period', while pitch.json has 254.7 px.

Evidence: wire.json per_mm.hop_mm = 3.714969717; report.json inputs.hop_mm.value = 3.72. Example: v1 noc per-transition is 25.7 fJ/mm in wire.json per_mm but 25.6 in the report headline, a difference of at most 0.14%. pitch.json micro22_fig7.pitch_x_px = 254.7.

Fix: Pass the hop length (3.72) to analyze_wire.py, or drop its per_mm block, and correct the pixel figure in the INPUTS text. Cosmetic; no page number changes.


#### R-heat-7 [low] docs/reports/data/2026-09-24-wire-energy/research/critique/railfit.py

Problem: Several research and review scripts are not portable, and one superseded script is not marked. critique/railfit.py, critique/confounds.py and every review/ script hard-code /home/yaroslavvb/claude/et-soc1-prototyping, and the review scripts also need uncompressed telemetry.jsonl and runs.jsonl. research/README.md does not mention this for the critique scripts. research/synthesis/convert.py hard-codes E27 inputs and a hop range of 3.64–3.76 (the final range is 3.64–3.74) without saying it is superseded.

Evidence: grep finds the absolute path in railfit.py:6, confounds.py:5, indep/bursts.py:14, methodB/load.py:8, artifacts/extract.py:4, combine/checks.py:3 and others. convert.py line 4: P_C, P_LO, P_HI = 3.72, 3.64, 3.76.

Fix: Use paths relative to __file__, and read .gz files directly as analyze_wire.jl() does. Add a one-line 'superseded by wire.json; E27 inputs' header to convert.py and to wire_calc.py's E27 section.


#### R-heat-8 [low] docs/reports/sources/heat-per-mm.body.html

Problem: The §10 sentence 'Three independent reductions … agree within 3% on the mesh rail and within about 7% on board power' is not true for every quantity. Rerun, Method B gives the free-link (wsep) mesh-rail fixed part as 45.6 against the pipeline's 43.1 fJ/bit/hop (+6%). Board v1 a is +16% raw and +6.7% with Method B's own leakage correction.

Evidence: methodB/keys.py on the regenerated summary_b_1.0_0.0.json: 'noc wsep d1-5 zeros 45.557' against wire.json disjoint_flows.noc_pj_per_byte.wsep.zeros 43.1; 'v1 board a 161.485', board_tc 147.770, against model.v1.board 138.5. The other mesh-rail terms agree within 1–3%.

Fix: Soften to 'within 1–3% on the mesh rail's coefficients (6% on the free-link fixed part) and about 7% on board power with a leakage correction'.


### Review findings


#### heat-claim-1 — MODIFIED [claim/medium] et-soc1-heat-per-mm

Where: docs/reports/sources/heat-per-mm.body.html, §10 (#limits), bullet 'Fixed per-hop cost'

Files: docs/reports/sources/heat-per-mm.body.html, docs/reports/sources/heat-per-mm.script.js, docs/reports/data/2026-09-24-wire-energy/wire.json

Problem: 'Even if all of the one-hop zeros energy were cost per second, it would explain at most a quarter of the link-disjoint fixed part and a fifth of the loaded one.' This holds on the mesh rail only (27% and 18%, and 'at most a quarter' rounds 27% down). On board power the same bound is 98% and 58%, and the page quotes board fixed parts: 14.0 and 26.8 fJ/mm in the §5 table, and both appear in the 47 and 73 fJ totals of the lede and §8.


APPLY (CORRECTED): Apply the proposed psb() helper and the <span id="persectext"></span> replacement, with this text: `Even if all of the one-hop zeros energy were cost per second, on the mesh rail it would explain at most ${pc(psb('wsep',NK))} of the link-disjoint fixed part and ${pc(psb('wu',NK))} of the loaded one. On board power, whose one-hop energy also includes the scratchpad read and the cores, the same bound is ${pc(psb('wsep',BK))} and ${pc(psb('wu',BK))}, so it cannot rule out that most of the board's fixed part is per second.` This renders 27%/18% and 98%/58%.

Base PROPOSAL (for "as proposed" references): In body.html replace that sentence with <span id="persectext"></span>. In script.js, in the '10. limits' block, add: const psb=(fam,k)=>{const ds=[1,2,3,4],z=ds.map(d=>v(`${fam}/p0/hop${d}`,k)),bw=ds.map(d=>CK.per_reader_gb_s[`${fam}/p0.5/hop${d}`]);return line(ds,ds.map((d,i)=>z[0]*bw[0]/bw[i])).slope/line(ds,z).slope;}; setText('persectext',`Even if all of the one-hop zeros energy were cost per second, on the mesh rail it would explain at most ${pc(psb('wsep',NK))} of the link-disjoint fixed part and ${pc(psb('wu',NK))} of the loaded one. On board power it could explain ${pc(psb('wsep',BK))} and ${pc(psb('wu',BK))}, so the board-power fixed parts per hop are upper bounds.`); This renders 27%/18% and 98%/58%.


Verifier note: Reproduced from wire.json: the per-second bound over 1–4 hops is 0.266 (wsep) and 0.181 (wu) on the mesh rail, and 0.984 and 0.579 on board power. The page's sentence names no meter, but it only holds on the rail, and the 14.0 and 26.8 fJ/mm board fixed parts are quoted in the lede totals, §5 and §8. The proposed code is correct: line, v, CK, pc, NK and BK are all in scope in the '10. limits' block, and per_reader_gb_s has both the p0 and p0.5 keys, which are identical. The closing clause 'so the board-power fixed parts per hop are upper bounds' is loose, since both meters' fixed parts are upper bounds under this confound. It also does not say why the board bound is so weak: board one-hop energy includes the scratchpad read and the cores' own per-byte work.


#### heat-claim-2 — MODIFIED [claim/low] et-soc1-heat-per-mm

Where: script.js setText('onestext') in §5 (#ones): 'Two terms fit every pattern — a, … and b, … — on both cards and both meters'

Files: docs/reports/sources/heat-per-mm.script.js

Problem: Overstated. The fit covers the bit densities and the frozen line only (the table footnote says 'five bit densities and the frozen line'). §7 shows that the 256-byte block pattern pays only 54–69% of what the same model predicts.


APPLY (CORRECTED): In onestext: 'Two terms fit every bit density and the frozen line — <i>a</i>, … and <i>b</i>, … — on both cards and both meters, to … on board power (the block patterns of <a href="#lanes">§7</a> were not fitted and come in below it: slightly for 16–128 B blocks, far below for 256 B):'. Renumber the §7 reference if heat-reorg-1 is adopted.

Base PROPOSAL (for "as proposed" references): In onestext replace 'Two terms fit every pattern — ' with 'Two terms fit every bit density and the frozen line — '. After '…on board power' insert ' (the 256-byte blocks of <a href="#lanes">§7</a> are the exception)' before the colon.


Verifier note: The fit covers only the v2 wu/p* points and wfrz, and v1 covers only the wbern densities, so 'every pattern' is overstated. However, the proposed parenthetical implies that the 16–128 B blocks do fit. They do not quite. Against the v1 model's no-transition prediction (s0 + b/2) they sit 2.5–5.7% below on the mesh rail (1.056–1.091 against 1.115 pJ/B/hop, 3–7× the fit's 0.008 rms) and 4.8–9.7% below on board power (1.457–1.536 against 1.616). The §7 chart shows those bars under their dashed lines. The 256 B blocks are far below.


#### heat-claim-3 — CONFIRMED [claim/low] et-soc1-heat-per-mm

Where: script.js §1 die figure (#mesh) tooltip for the amber tiles: 'memory shire + LPDDR4x PHY strip, ≈1.61 mm wide'

Files: docs/reports/sources/heat-per-mm.script.js, tools/ettelem/build_wire_report.py

Problem: 1.61 mm is (25.6 − 6·3.73)/2, an artefact of drawing the grid as 6 tile periods (22.4 mm, 87% of the die). The research measures the strip at 1.74–1.80 mm, and the text's 86% is the measured outline span. The tooltip contradicts the research.


APPLY (PROPOSAL): Replace the tooltip string with 'memory shire + LPDDR4x PHY strip, about 1.74–1.80 mm wide on the die plot'. Better: add "memshire_w_mm": {"value": 1.76, "range": [1.74, 1.80], "source": "research/geometry/pitch.json scale_from_570mm2.B_symmetric_bottom.memshire_col_w_mm"} to INPUTS in tools/ettelem/build_wire_report.py, and print `about ${f2(IN.memshire_w_mm.range[0])}–${f2(IN.memshire_w_mm.range[1])} mm`. Leave the drawing as is, but add to the #meshcap caption: 'tiles are drawn at the 3.73 mm period, so the grid looks slightly wider than the 86% its outlines span'.


Verifier note: The script's mw = (25.6 − 6·3.73)/2 = 1.61 mm. In pitch.py, memshire_col_w_mm = (140 − 20) px × scale = 1.755 mm (reading B), and SYNTHESIS gives strips of 1.74 and 1.80 mm to the tile outlines (vlines at 137–143 and 1646–1654 px, die edges 20 and 1772 px, which measure.py reproduces). The 86% in the text is the span of the outlines (22.1 mm), while the drawing uses 6 full periods (22.4 mm, 87%). The INPUTS variant is preferable because the page computes its numbers from D. The caption note is accurate. This is cosmetic only.


#### heat-claim-4 — MODIFIED [claim/low] et-soc1-heat-per-mm

Where: script.js setText('senstext') in §10 'Board against rail': 'Three independent reductions of the same bursts, made for this page's review, agree within 3% on the mesh rail and within about 7% on board power.' The same claim is in docs/findings/03-experiments.md E32 ('reproduced within 1–3% on the rail and about 7% on board power').

Files: docs/reports/sources/heat-per-mm.script.js, docs/findings/03-experiments.md

Problem: Not true for every quantity. Rerun, Method B gives the free-link mesh-rail fixed part as 45.6 against the pipeline's 43.1 fJ/bit/hop (+6%). Board v1 a is +16% raw, and +6.7% only after Method B's own leakage correction.


APPLY (CORRECTED): senstext: 'Three independent reductions of the same bursts, made for this page's review, agree within 3% on the mesh rail's coefficients (6% on the free-link fixed part) and within about 7% on board power, comparing like with like for the leakage correction.' Apply the same parenthetical to 03-experiments.md E32 'Review' and to review/README.md's 'Verdict' paragraph ('within 1–3% on the mesh rail').

Base PROPOSAL (for "as proposed" references): In senstext replace the sentence with: 'Three independent reductions of the same bursts, made for this page's review, agree within 3% on the mesh rail's coefficients (6% on the free-link fixed part) and within about 7% on board power when the same leakage correction is applied.' In 03-experiments.md E32 'Review', change 'within 1–3% on the rail' to 'within 1–3% on the rail's coefficients (6% on the free-link fixed part)'.


Verifier note: Method B reproduces: free-link mesh-rail zeros over 1–5 hops 45.56 against the pipeline's wsep 43.07 (+5.8%); v1 board a 161.5 raw against 138.5 (+16.6%), and 147.8 with its own leakage correction (+6.7%). Like for like, the board agreement is about 7% either way: Method B raw against the pipeline without leakage correction (150.7) is +7.2%, and the independent reduction's raw v2 a 161.8 against 160.0 is about 1%. So the '7%' is fine. Only the rail's 'within 3%' needs the free-link fixed-part exception; every other rail quantity is within 0.8–2.7%. Method B used its own leakage correction, not 'the same' one. The reviewer also missed that review/README.md carries the same 'within 1–3% on the mesh rail' sentence.


#### heat-claim-5 — MODIFIED [claim/low] et-soc1-heat-per-mm

Where: script.js setText('axistext') in §10 'Router against wire': '(The x-only and y-only sets agree only to about 10% — y is 10–12% below x over one and two hops on both cards, and 4% above over one to three hops on aifoundry3, the only card with a usable three-hop y point — …)'

Files: docs/reports/sources/heat-per-mm.script.js

Problem: The '4% above' figure (127.6 against 122.2) depends on keeping aifoundry3's y-only three-hop bursts, whose readings were delayed up to 0.4–0.55 s. The review's own health filter (review/indep/bursts.py, max latency over 300 ms) marks them bad, and without them y is 9% below x (111.6). The detail is fragile, and the sentence itself says the x/y sets 'do not test this'.


APPLY (CORRECTED): Keep the xy12 computation, drop ya/yh/up3, and set axistext to `(The x-only and y-only pairs differ by ${pcs(hosts.map(xy12))} over one and two hops — y below x on both cards — but they also differ in link sharing, so they cannot separate the two.)`. In starvetext, end the aifoundry3 sentence at '…those bursts were kept.'

Base PROPOSAL (for "as proposed" references): Replace the whole axistext computation and its up3 branch with a fixed sentence: setText('axistext','(The x-only and y-only pairs differ by about 10%, but they also differ in link sharing, so they cannot separate the two.)'); This matches 03-experiments E31 ('x-only and y-only pairs agree to about 10%').


Verifier note: Confirmed from wire.json. axes y/noc…d1_3 has only aifoundry3 (127.6 against x 122.2, +4.4%). Its hop-3 configurations have took_ms_max 496 ms. With the review's health filter (reading over 300 ms), y keeps only 1–2 hops (n=6) and gives 111.6, 9% below x, so the sign flips on one kept set. The review's VERDICT §8 itself called that point 'suspect'. Replacing it with a hard-coded 'about 10%' breaks the page's rule that sentence numbers are computed, and xy12 already gives a robust, computed 10–12% (10.3% on a2, 11.8% on a3) from hops 1–2. The reviewer also missed that dropping this figure leaves starvetext's 'and they give the only y-only three-hop point' pointing at nothing on the page.


#### heat-claim-6 — MODIFIED [claim/low] et-soc1-heat-per-mm

Where: script.js §8 chart (#comparechart), row 'ET-SoC-1 mesh rail, everything, loaded mesh, at 0.9 V' (174)

Files: docs/reports/sources/heat-per-mm.script.js

Problem: This is the only bar above Dally's and Keckler's figures, and no sentence mentions it. It scales the fixed part as CV², which the tooltip admits is an assumption, and its free-link counterpart (36.2 × 3.44 = 125) is missing. A reader scanning the chart sees 'ET-SoC-1 = 174 > 100' against a lede that says the rule of thumb holds.


APPLY (CORRECTED): Replace the 174 row with two rows: 'ET-SoC-1 mesh rail, everything, free links, at 0.9 V (if the fixed part is also CV²)' (UN.random_bit_total × s09 = 125) and the same for the loaded mesh (174). Add to comparetext: `Counting the data-independent part too, and assuming it also scales as CV², the figure at 0.9 V is ${f0(UN.random_bit_total.mean*s09)}–${f0(HN.random_bit_total.mean*s09)} fJ, above Dally's 100.` heat-viz-v1 supersedes this if adopted.

Base PROPOSAL (for "as proposed" references): Delete that row from the rows array. If the all-in figure at 0.9 V is wanted, add both all-in rows (free links 125, loaded 174), labelled '…, everything, at 0.9 V (if the fixed part is also CV²)', and add to comparetext: 'Counting the data-independent part too, and assuming it also scales as CV², the figure at 0.9 V is 125–174 fJ.' Heat-viz-v1 supersedes this if adopted.


Verifier note: Confirmed: row 8 = 50.42 × 3.4435 = 173.6 → 174, with a whisker to 182.9. It is the only bar above Dally's line, no sentence mentions it, and the free-link counterpart (36.22 × 3.44 = 124.7) is missing. Deleting it alone would be harmful: it hides the fact that the verdict 'the rule of thumb holds' depends on counting only the data-dependent part. A reader should see that everything included at 0.9 V comes to 125–174 fJ, given the stated CV² assumption. The reviewer's second option is the right one.


#### heat-cons-1 — MODIFIED [consistency/low] et-soc1-heat-per-mm

Where: tools/ettelem/build_wire_report.py INPUTS (pitch_x_mm, hop_mm sources); wire.json per_mm.hop_mm

Files: tools/ettelem/build_wire_report.py, workloads/enercat/analyze_wire.py, docs/reports/data/2026-09-24-wire-energy/wire.json

Problem: The two data files use different hop lengths. wire.json per_mm uses sqrt(3.73·3.70) = 3.715 mm; report.json and the page use 3.72, which is the mean of pitch.json readings A and B (3.735, 3.711). The hop_mm source text nevertheless says 'sqrt(px*py) …'. pitch_x_mm's source says '254.8 px' where pitch.json has 254.7 px. Page numbers move by at most 0.14%.


APPLY (CORRECTED): Only reword the hop_mm source in build_wire_report.py INPUTS: 'about the mean of the two readings of the 570 mm² (A 3.735, B 3.711 mm; √(px·py) under each; research/SYNTHESIS.md 1a); 3.637 if the area includes the drawn frame'. Leave pitch_x_mm's '254.8 px' and leave wire.json as it is. Optionally note in the analyze_wire.py docstring that per_mm uses √(px·py) and that the report uses 3.72.

Base PROPOSAL (for "as proposed" references): In build_wire_report.py set the hop_mm source to 'mean of the two readings of the 570 mm² (3.735 and 3.711 mm; research/SYNTHESIS.md 1a); range down to 3.637 if the area includes the drawn frame', and change '254.8 px' to '254.7 px'. In analyze_wire.py add a --hop-mm argument (default sqrt(px*py)) used for per_mm. Regenerate with --hop-mm 3.72, or delete the per_mm block, since the page does not read it.


Verifier note: The finding is real but trivial. wire.json per_mm.hop_mm = √(3.73·3.70) = 3.71497, while report.json and the page use 3.72, which is closer to the mean of readings A and B (3.723). The difference is 0.13%. per_mm is only printed by analyze_wire.py; nothing on the page or in other scripts reads it. The '254.8 px' is not wrong: SYNTHESIS gives 254.7–254.8 px and 'Micro22 outlines and autocorrelation 254.78', so changing it to 254.7 is unwarranted. Adding --hop-mm and regenerating wire.json changes a byte-for-byte-reproducible artefact to fix an unused block.


#### heat-repro-1 — CONFIRMED [reproducibility/low] et-soc1-heat-per-mm

Where: tools/ettelem/build_wire_report.py lines 70–81 (context from the energy manual)

Files: tools/ettelem/build_wire_report.py, docs/reports/sources/heat-per-mm.script.js

Problem: manual.json is opened as 'docs/reports/data/2026-09-23-energy-manual/manual.json', relative to the working directory, and every exception is swallowed. Run from anywhere but the repo root, the script exits 0 and writes context={'error': …}. The page's whole §9 (#meaning) then silently disappears, because script.js guards it with if(X.tload_dram_random_pj_per_byte).


APPLY (PROPOSAL): Replace the open() with ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','..')); man=json.load(open(os.path.join(ROOT,'docs/reports/data/2026-09-23-energy-manual/manual.json'))). Remove the broad except, or re-raise with SystemExit('build_wire_report: cannot read the energy manual context: …'). In script.js add an else branch that writes 'energy-manual context missing from report.json' into #practice, so a bad build is visible.


Verifier note: Reproduced. Running build_wire_report.py from the scratch directory with absolute --wire and --out exits 0 and writes context = {'error': "[Errno 2] No such file … manual.json"}, and §9 is guarded by if(X.tload_dram_random_pj_per_byte), so it silently empties. From the repo root the output is byte-identical to the committed report.json. ROOT = dirname(__file__)/../.. is the correct repo root for tools/ettelem/. Making the build fail (SystemExit) is the important part; the script.js else branch is only a secondary guard and should not be the way a published page shows the failure.


#### heat-repro-2 — CONFIRMED [reproducibility/low] et-soc1-heat-per-mm

Where: docs/findings/03-experiments.md E31/E32 (no command block); docs/findings/04-artifacts.md A18; analyze_wire.py docstring

Files: docs/findings/03-experiments.md, docs/findings/04-artifacts.md, workloads/enercat/analyze_wire.py

Problem: The command that produces the committed wire.json is not written anywhere. Reproducing it byte for byte needs all four raw directories and `--pitch-x-mm 3.73 --pitch-y-mm 3.70`, which the reproduction had to infer from per_mm.hop_mm. build-report.py also needs `npm install --no-save mathjax-full`, which only its docstring mentions.


APPLY (PROPOSAL): Add to E32 in 03-experiments.md, under 'Raw data', a block run from the repo root: `python3 workloads/enercat/analyze_wire.py docs/reports/data/2026-09-24-wire{,2}-aifoundry{2,3} --out docs/reports/data/2026-09-24-wire-energy/wire.json --pitch-x-mm 3.73 --pitch-y-mm 3.70` then `python3 tools/ettelem/build_wire_report.py --wire docs/reports/data/2026-09-24-wire-energy/wire.json --out docs/reports/data/2026-09-24-wire-energy/report.json` then `npm install --no-save mathjax-full && python3 scripts/build-report.py heat-per-mm docs/reports/data/2026-09-24-wire-energy/report.json docs/reports/2026-09-24-heat-per-mm.html`. Copy the same three lines into the analyze_wire.py docstring in place of the placeholder usage.


Verifier note: No doc gives the exact commands: E31 and E32 describe the reduction in prose, A18 lists the tools, and the analyze_wire docstring gives a placeholder. I ran exactly `python3 workloads/enercat/analyze_wire.py docs/reports/data/2026-09-24-wire{,2}-aifoundry{2,3} --out … --pitch-x-mm 3.73 --pitch-y-mm 3.70` to scratch: md5 b59112fc… is identical to the committed wire.json. build_wire_report from the repo root gives a byte-identical report.json, and build-report.py gives a byte-identical HTML (286,091 bytes). mathjax-full is present in node_modules here but would be needed on a fresh clone. It would read better with only the analyze_wire command in its own docstring and the full three-step chain in E32 and A18, but the proposal is harmless as written.


#### heat-repro-3 — CONFIRMED [reproducibility/low] et-soc1-heat-per-mm

Where: docs/reports/data/2026-09-24-wire-energy/review/indep/fits.txt

Files: docs/reports/data/2026-09-24-wire-energy/review/indep/fits.txt, docs/reports/data/2026-09-24-wire-energy/review/README.md

Problem: The committed fits.txt was made with `fits.py --keep-bad`, and its sibling fits_leak.txt with the default, so the two review outputs use different burst sets. fits.txt's C4 axis block includes the six starved aifoundry2 bursts and prints 'rand -309.9', 'nan', n=9.


APPLY (PROPOSAL): Regenerate with the default flags (cd review/indep && python3 fits.py > fits.txt) and commit. Add a line to review/README.md: 'fits.txt and fits_leak.txt use bursts.py's health filter (bursts with a reading over 300 ms dropped); --keep-bad keeps them for comparison.'


Verifier note: fits.py sets DROP_BAD = '--keep-bad' not in sys.argv. The committed fits.txt's C4 block has aifoundry2 y 'rand -309.9', 'nan', n=9, which only the kept starved bursts produce. fits_leak.txt's C4 has n=6, which is the default filter. The earlier default rerun differs from the committed file in exactly those 4 C4 lines. VERDICT.md already says 'every reduction drops those six bursts' and 'dropping these bursts gives y = 112', which matches the default output, so regenerating fits.txt makes the record consistent. Nothing else in VERDICT or README quotes the changed lines.


#### heat-repro-4 — MODIFIED [reproducibility/low] et-soc1-heat-per-mm

Where: research/critique/railfit.py:6, confounds.py:5, review/indep/bursts.py:14, review/methodB/load.py:8, review/artifacts/extract.py:4, review/combine/checks.py:3 and others; research/synthesis/convert.py; research/lit/wire_calc.py (last section); research/geometry/pitch.py

Files: docs/reports/data/2026-09-24-wire-energy/research/critique/railfit.py, docs/reports/data/2026-09-24-wire-energy/research/synthesis/convert.py, docs/reports/data/2026-09-24-wire-energy/research/lit/wire_calc.py, docs/reports/data/2026-09-24-wire-energy/research/README.md, docs/reports/data/2026-09-24-wire-energy/review/README.md

Problem: Research and review scripts hard-code /home/yaroslavvb/claude/et-soc1-prototyping and need uncompressed telemetry.jsonl and runs.jsonl. research/README.md does not say so for the critique scripts. convert.py (E27 inputs typed in, hop range 3.64–3.76) and wire_calc.py's last section (E27's 131 fJ and 1.29 pJ/B) are superseded but not marked. pitch.py's bottom_inner/bottom_outer constants are manual readings, because measure.py's bottom-edge detection returns -1 on two of the three images.


APPLY (CORRECTED): Do (2) and (3) as proposed. Add to research/README.md the note review/README.md already has: 'critique/railfit.py and confounds.py read the repo by absolute path; edit the path at the top to run from another checkout'. Make the path and .gz changes of (1) only if each edited script is rerun afterwards and its committed output (fits*.txt, railfit.json, …) reproduces unchanged.

Base PROPOSAL (for "as proposed" references): (1) Replace each absolute path with REPO=os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../../../..')) (depth per file) and open the .gz files directly, as analyze_wire.jl() does, e.g. `(gzip.open if p.endswith('.gz') else open)(p,'rt')`. (2) Put the first line of convert.py and the heading of wire_calc.py's last section as '# Superseded by wire.json (E31/E32): this uses the E27 inputs and the provisional 3.64–3.76 mm pitch range.' (3) In research/geometry/README.md add: 'bottom edges in pitch.py are read by hand (measure.py's bottom detection fails on micro22 and hc33).'


Verifier note: The problem is real. 12+ research and review scripts hard-code /home/yaroslavvb/claude/et-soc1-prototyping, and review scripts need runs/telemetry .jsonl uncompressed. I confirmed measure.py returns bottom -1.0 for micro22 and hc33 (mpr works), so pitch.py's die boxes are hand readings, which its comment does not say. convert.py uses E27 inputs and a 3.64–3.76 range, and wire_calc.py's last block uses E27's 131 fJ and 1.29 pJ/B. However, review/README.md already documents the gunzip-and-edit-paths requirement. research/README.md is the one that lacks it. Rewriting ~12 archived scripts is optional and risky unless each edited script is rerun and its committed output compared.


#### heat-red-1 — MODIFIED [redundancy/low] et-soc1-heat-per-mm

Where: script.js setText('comparetext2') in §8 (#compare), first sentence

Files: docs/reports/sources/heat-per-mm.script.js

Problem: This repeats the previous paragraph. comparetext ends '…which brackets Dally's 100 and is 0.7–0.9 of Keckler's 121 (40 nm, 0.9 V)', and comparetext2 opens 'At equal voltage the mesh rail's data-dependent cost per random bit·mm, routers included, is 0.7–0.9 of Keckler's 40 nm repeated-wire figure (35 fJ at 0.485 V).' This is the same ratio, since both sides are scaled by the same 3.44.


APPLY (CORRECTED): Start comparetext2 with: `Being ${f1(n09[0]/KEK)}–${f1(n09[1]/KEK)} of Keckler's wire figure with the routers included is roughly what one would expect: wire capacitance per mm barely changes between process nodes (Dally 2018: "about 200fF/mm and independent of scaling"), and <b>the mesh's advantage over the 0.9 V literature is mostly V²</b>. ` Then continue unchanged from 'A plain repeated wire…'. kek485 then goes unused and can be removed.

Base PROPOSAL (for "as proposed" references): In comparetext2 cut 'At equal voltage the mesh rail's data-dependent cost per random bit·mm, routers included, is ${…}–${…} of Keckler's 40 nm repeated-wire figure (${f0(kek485)} fJ at 0.485 V). Wire capacitance' and start instead: 'That ratio, routers included, is roughly what one would expect: wire capacitance per mm barely changes between process nodes (Dally 2018: "about 200fF/mm and independent of scaling"), and <b>the mesh's advantage over the 0.9 V literature is mostly V²</b>.' Then continue unchanged from 'A plain repeated wire…'.


Verifier note: Confirmed redundant: comparetext's n09/KEK and comparetext2's UN/(KEK/s09) are the same ratio (0.70–0.87 → '0.7–0.9'). But the proposed opener 'That ratio, routers included, …' starts a new paragraph right after comparetext's last sentence, which is about board power's 159 and the regulator's loss, so 'That ratio' would point at the wrong thing.


#### heat-red-2 — CONFIRMED [redundancy/low] et-soc1-heat-per-mm

Where: body.html §10 (#limits), bullet 'Router against wire', after <span id="axistext"></span>

Files: docs/reports/sources/heat-per-mm.body.html

Problem: The bullet ends by repeating two things said at their canonical places: '"Per mm" here is per mm of mesh travel.' (stated in §2, last sentences) and 'A plain repeated 7 nm wire at 0.485 V would be about 12–24 fJ per random bit·mm from first principles (§8).' (stated in §8, comparetext2).


APPLY (PROPOSAL): Delete both sentences: '"Per mm" here is per mm of mesh travel. A plain repeated 7 nm wire at 0.485 V would be about 12–24 fJ per random bit·mm from first principles (<a href="#compare">§8</a>).' The bullet then ends with the axistext sentence (see heat-claim-5).


Verifier note: Both sentences repeat their canonical statements: §2 on per mm of mesh travel (with the consequence that per mm of wire would be lower), and §8's comparetext2, which also says 'these data cannot say how much the routers add'. The body.html copy also hard-codes '12–24', while §8 computes it from D.first_principles. Deleting them loses nothing. It also removes the in-text '(§8)' reference that heat-reorg-1 would otherwise have to renumber.


#### heat-red-3 — MODIFIED [redundancy/medium] et-soc1-heat-per-mm

Where: body.html §10 (#limits): bullets 'The meter can be stopped' and 'A stray write is invisible', and the last sentence of 'The meter can be starved'

Files: docs/reports/sources/heat-per-mm.body.html

Problem: These repeat at length what the observability hub (§4.1, #the-chain) already records as its own findings. The hub has the poisoned management queue and dev_mngt_service drain, the 'about a second of stray tensor stores to physical address 0 … no error counter, telemetry field or clock moved', and the s ↔ s+16 rings at 150 ms instead of 22. On this page they are lab history, not limits of the per-mm measurement.


APPLY (CORRECTED): Delete the two bullets as proposed. Replace the s/s+16 sentence in the 'starved' bullet with: 'Other workloads that starve the meter, a sampler crash that stopped it between the two runs, and a stray write the card never reported (no measurement here comes from those launches) are in the <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-limits-of-observability#the-chain">observability report, §4.1</a>.' If §10 then holds only limits, retitle it 'What this cannot tell' (see heat-reorg-1).

Base PROPOSAL (for "as proposed" references): Delete the two bullets starting '<li><b>The meter can be stopped.</b> Between the two runs a sampler killed…' and '<li><b>A stray write is invisible.</b> While the store mode…'. In the 'starved' bullet, replace 'Rings between shires <i>s</i> and <i>s</i>+16, measured for the energy manual and not part of this run, also starve it: about 150 ms per reading, with the board reading frozen for seconds.' with 'Other workloads that starve the meter, a sampler crash that stopped it between the two runs, and a stray write the card never reported are in the <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-limits-of-observability#the-chain">observability report, §4.1</a>.' Retitle that bullet 'The meter can be starved.' (unchanged) and keep starvetext.


Verifier note: Confirmed: hub §4.1 (#the-chain exists) has the s ↔ s+16 150 ms rings, the poisoned management queue and one-command drain, and the stray tensor stores to physical address 0 with 'no error counter, telemetry field or clock moved'. The findings files also record the stray write (14-card-behaviour, 19-observability, 20-heat-per-mm). The two bullets are lab history, not limits of this measurement. One clause should survive, though: 'no measurement here comes from those launches' is a provenance statement about this page's data, and the proposed pointer drops it.


#### heat-red-4 — MODIFIED [redundancy/low] et-soc1-heat-per-mm

Where: script.js setText('disttext') §4, last sentence; lede paragraph 2; onestext §5

Files: docs/reports/sources/heat-per-mm.script.js

Problem: The ones result is stated three times with the same numbers. Lede: 'costs as much per hop as random data (7–9% more), though at one hop it costs 36–37% less in all'. §4: 'The lines fan out with the density of ones; the all-ones line (P = 1) starts 36–37% below the random one at one hop and climbs 7–9% faster.' §5: 'all-ones costs about as much per hop as random data (7–9% more)'. Nearby in §5, modeltext2's unrelated '36% of its present per-hop cost' invites confusion with the 36–37%.


APPLY (CORRECTED): In disttext change the last sentence to `The lines fan out with the density of ones; the all-ones line (<i>P</i> = 1) starts ${pcs(onesLess1)} below the random one at one hop but climbs faster (<a href="#ones">§5</a>).` That drops only the repeated 7–9%. Apply the modeltext2 change as proposed ('…cost what zeros cost per hop, ${pc(1-onesToZeros)} less').

Base PROPOSAL (for "as proposed" references): In disttext replace the last sentence with 'The lines fan out with the density of ones (<a href="#ones">§5</a>).' In modeltext2 change 'all-ones data would then cost what zeros cost, ${pc(onesToZeros)} of its present per-hop cost' to 'all-ones data would then cost what zeros cost per hop, ${pc(1-onesToZeros)} less'. This renders '64% less' and removes the second 36%.


Verifier note: The 7–9% does appear three times. But cutting disttext's last sentence would leave the lede's '36–37% less at one hop' with no statement in the body: only disttext gives it, and it describes what the §4 chart shows. That cut is harmful. The modeltext2 change is correct: onesToZeros = 73.8/(73.8+129.4) = 0.363, so '36% of its present cost' becomes '64% less', which removes the clash with 36–37%.


#### heat-red-5 — CONFIRMED [redundancy/low] et-soc1-heat-per-mm

Where: body.html lede paragraph 3 ('Dally states no voltage. …')

Files: docs/reports/sources/heat-per-mm.body.html

Problem: The Keckler-lineage inference and its caveat appear in both the lede ('— the voltage of Keckler 2011's 40 nm wire figure, from which his number most likely descends (an inference; no source says so) —') and §1 ('The likeliest lineage — an inference; no source states it — runs through Keckler…'). The lede is already three paragraphs, a Terms block and four KPIs before the contents.


APPLY (PROPOSAL): In the lede replace ' — the voltage of Keckler 2011's 40 nm wire figure, from which his number most likely descends (an inference; no source says so) — ' with ' (the voltage of Keckler 2011's 40 nm wire figure, his likeliest source; <a href="#question">§1</a>) '. Keep §1 as the canonical statement.


Verifier note: The lede and §1 both carry the lineage inference with its hedge. The replacement keeps a hedge ('his likeliest source') and links to §1, where the full caveat stays, so the review's requirement that the inference is flagged still holds on the page.


#### heat-red-6 — CONFIRMED [redundancy/low] et-soc1-heat-per-mm

Where: body.html §3 (#method), bullet 'Two meters'

Files: docs/reports/sources/heat-per-mm.body.html

Problem: This re-defines both meters in the words the Terms paragraph already uses. Terms: 'Both meters are in the board's power-management controller (PMIC): board power is its reading of the card's 12 V input, the mesh rail its reading of the regulator that feeds the mesh; the service processor (SP) … reports them.' §3: 'Board power (the PMIC's 12 V input, in 10 mW steps, one reading per 133 ms) and the PMIC's reading of the mesh (NoC) rail, as the service processor reports it; that rail feeds…'.


APPLY (PROPOSAL): In §3 replace 'Board power (the PMIC's 12 V input, in 10 mW steps, one reading per 133 ms) and the PMIC's reading of the mesh (NoC) rail, as the service processor reports it; that rail feeds the routers and links at 0.485 V and 400 MHz.' with 'Board power (10 mW steps, one reading per 133 ms) and the mesh rail, which feeds the routers and links at 0.485 V and 400 MHz.'


Verifier note: The Terms paragraph defines both meters (PMIC, 12 V input, the regulator feeding the mesh, the SP reports them). The §3 bullet repeats this in nearly the same words. The trimmed version keeps what §3 uniquely needs (10 mW steps, 133 ms, 0.485 V and 400 MHz), and §10 restates '12 V input power' where it matters.


#### heat-red-7 — MODIFIED [redundancy/low] et-soc1-heat-per-mm

Where: body.html §11 (#data), bullets 3 and 4

Files: docs/reports/sources/heat-per-mm.body.html

Problem: Internal process history on a results page. Bullet 3: '…was gathered by seven AI agents (Claude subagents run by the author)'. Bullet 4: 'Before publication, six more such agents reviewed this page adversarially: two re-analysed the raw data independently, three looked for faults in the measurement, the physics and the arithmetic, and one combined their findings. The measurements reproduced; the review's corrections to the interpretation are applied on this page, and its report is …VERDICT.md'. 04-artifacts.md A17 and 03-experiments.md E32 already record this.


APPLY (CORRECTED): One bullet: '<li>Research notes behind the conversion to millimetres (die geometry, the NoC, the literature), gathered by AI agents run by the author: <code>…/research/SYNTHESIS.md</code>. An independent re-analysis and adversarial review of this page, also by AI agents: <code>…/review/VERDICT.md</code>; the measurements reproduced, and its corrections are applied here.</li>' Keep the GitHub links.

Base PROPOSAL (for "as proposed" references): Replace both bullets with one: '<li>Research notes behind the conversion to millimetres (die geometry, the NoC, the literature): <code>…/research/SYNTHESIS.md</code>. An independent re-analysis and review of this page by AI agents run by the author: <code>…/review/VERDICT.md</code>.</li>' Keep the same GitHub links.


Verifier note: Merging the two bullets is fine. But the proposed text drops the disclosure that the research notes (the literature quotes and die geometry the page relies on) were gathered by AI agents, and the project decided such work must be disclosed (PLAN.md §1 item 5, hub-11, open question 3). It also drops 'the measurements reproduced', which is useful to readers.


#### heat-reorg-1 — MODIFIED [reorganize/low] et-soc1-heat-per-mm

Where: body.html section order §6–§10

Files: docs/reports/sources/heat-per-mm.body.html, docs/reports/sources/heat-per-mm.script.js

Problem: The page's question is whether Dally's ~100 fJ/b-mm holds here. After the three results (distance §4, ones §5, sharing §6), the answer (§8 #compare) and its use (§9 #meaning) are delayed by §7 'Lanes and flits', a side result about lanes and flit width. §10's title promises 'what else it found', which after heat-red-3 is only limits.


APPLY (CORRECTED): Apply the proposed order and renumbering. Also update the link texts to 'Heat per millimetre, §7' in on-chip-communication (standalone HTML) and 'Heat per millimetre, §8' in on-chip-relay.body.html, then rebuild it. Add to the moved lanes section's first paragraph: 'These patterns test the model of <a href="#ones">§5</a>'. Retitle §10 'What this cannot tell' if heat-red-3 is applied.

Base PROPOSAL (for "as proposed" references): New order, keeping every id: 1. The number, and what it hides (#question); 2. How long is a hop? (#die); 3. The experiment (#method); 4. Energy grows nearly linearly with distance (#distance); 5. Ones cost energy, not just flips (#ones); 6. Sharing a link costs energy (#contention); 7. Against the rule of thumb (#compare); 8. What it means in practice (#meaning); 9. Lanes and flits (#lanes); 10. What this cannot tell (#limits); 11. Data and tools (#data); 12. Related reports (#related). Move the whole <h2 id="lanes"> block (heading, #alt chart, both paragraphs) after the <p id="practice"></p>. Update the hard-coded numbers in the h2 texts and the in-text references: Terms '(<a href="#lanes">§7</a>)' becomes '§9'; heat-claim-2's new '§7' becomes '§9'; the '(§8)' in §10 goes away with heat-red-2. 'section 6', '§5', '§10' and 'sections 4 and 5' stay correct.


Verifier note: Moving the side result on lanes after the payoff (§7 compare, §8 meaning) is reasonable, and all ids are kept. The reviewer missed two cross-page link texts that name section numbers and would become wrong: docs/reports/2026-09-18-et-soc1-on-chip-communication.html says '(Heat per millimetre, §8)' linking #compare, which becomes §7, and docs/reports/sources/on-chip-relay.body.html says '(Heat per millimetre, §9)' linking #meaning, which becomes §8. The hub's '§5' (#ones) and the '§2' (#die) links stay correct. Note that §7 on lanes is also the test of §5's model with patterns that break the P ↔ t link, so its intro should link back to §5 once it is separated.


#### heat-read-1 — CONFIRMED [readability/low] et-soc1-heat-per-mm

Where: script.js setText('practice'), §9 (#meaning)

Files: docs/reports/sources/heat-per-mm.script.js, docs/reports/sources/heat-per-mm.body.html

Problem: §9 is one paragraph of nine sentences with 17 numbers, mixing two separate comparisons: a line moved across the chip against DRAM and scratchpad, and a hop against an add in 'Dally's currency'.


APPLY (PROPOSAL): Split into two <p>s. Add <p id="practice2"></p> to body.html and move everything from 'In Dally's currency — …' to the end into setText('practice2', …). If heat-viz-v3's path explorer is adopted, the first paragraph's 10-hop example becomes its default state.


Verifier note: The rendered §9 is one 9-sentence paragraph mixing two comparisons (a line moved against DRAM and the scratchpad; a hop against an add). Splitting at 'In Dally's currency' is clean. The setText('practice2', …) call must stay inside the same if(X.tload_dram_random_pj_per_byte) guard.


#### heat-chart-1 — CONFIRMED [visualization/medium] et-soc1-heat-per-mm

Where: script.js §2 'energy against distance' (#dist, #distbtn) and §3 'ones and transitions' (#model, #modelbtn); §6 (#contbtn)

Files: docs/reports/sources/heat-per-mm.script.js

Problem: The §4 and §5 charts open on board power, but the text under them describes the mesh-rail view ('On the mesh rail the data-dependent energy is zero at d = 0…'). The page's headline numbers are also mesh rail. In the board view the lines do not meet at d = 0, so the reader cannot see what the text says without toggling. In the mesh-rail view all five lines start at 0 and fan out, which is the section's point. Button order and labels also differ: §4/§5 read 'board power | mesh rail only', §6 reads 'mesh rail only | board power'.


APPLY (PROPOSAL): In the §2 IIFE set let key='noc_pj_per_byte' and build the buttons from [['noc_pj_per_byte','mesh rail'],['pj_per_byte','board power']]. In the §3 IIFE set let src='noc_rail' and use buttons [['noc_rail','mesh rail'],['board','board power']]. In §6 rename 'mesh rail only' to 'mesh rail'. Every toggle then opens on the page's primary meter, with the same order and wording.


Verifier note: Screenshot at 1280 px: §4 opens on board power, where the d = 0 points spread from 2.0 to 4.4 pJ/B. Yet disttext opens 'On the mesh rail the data-dependent energy is zero at d = 0', which is visible only in the rail view (hop-0 noc 0.009–0.046). The headline numbers are mesh rail. §6 already opens on the rail, with the buttons in the opposite order. Harmonising the default and the labels is harmless: board power stays one click away, and §9's board-power comparisons do not depend on these charts.


#### heat-chart-2 — MODIFIED [visualization/medium] et-soc1-heat-per-mm

Where: script.js §8 'against the literature' chart (#comparechart)

Files: docs/reports/sources/heat-per-mm.script.js, docs/reports/sources/heat-per-mm.body.html

Problem: (1) Bars on a log axis that starts at an arbitrary 5 fJ: bar length means nothing, and 25 against 100 looks like 60% of the length. All values (18–174) fit a linear axis. (2) The four bar colours (measured, scaled to 0.9 V, literature, first principles) have no legend. (3) The value labels sit under the dashed 'Dally ~100' line for 73, 85 and 105. (4) At 390 px the 330-px label column fills the visible frame, and the bars and the Dally line are off-screen (s390 piece 10).


APPLY (CORRECTED): As proposed (dot + whisker, linear, group headers acting as the legend, labels right of the whisker, phone layout with the label above each dot and no min-width), but with a 0–200 fJ axis (ticks every 25 or 50), keeping both all-in 0.9 V rows per the modified heat-claim-6.

Base PROPOSAL (for "as proposed" references): If heat-viz-v1 is not adopted: plot dot + whisker (no bars) on a linear axis 0–180 fJ (ticks every 20). Group the rows under three bold row headers drawn in the SVG: 'ET-SoC-1 at 0.485 V (as run)', 'ET-SoC-1 scaled to 0.9 V (mesh rail, CV²)', 'Literature and a plain 7 nm wire'. Keep each group's colour (var(--c1), var(--c7), var(--c2)/var(--c3)) so the headers act as the legend. Put value labels right of the whisker, with the 'Dally ~100' label at the top of its line. When h.clientWidth < 560, draw with W=360, L=8, the row label on its own line above each dot (rh=38), and no min-width (add class 'noscroll' or skip 'scroll' on #comparechart). Drop the 174 row per heat-claim-6.


Verifier note: Confirmed at 1280 px: bars on a log axis from an arbitrary 5 fJ; the labels '73' and '85' collide with the dashed Dally line; there is no legend for the blue, purple and orange groups. At 390 px only the labels and the '5 10' ticks show. The proposed linear 0–180 axis would clip the 174 row's whisker (hi 182.9). heat-claim-6 as modified keeps that row plus a 125 row. The board-power free-link total hi is 58.8, and the first-principles 0.9 V band 41–81, both fine. This proposal is moot if heat-viz-v1 replaces the chart.


#### heat-chart-3 — MODIFIED [visualization/low] et-soc1-heat-per-mm

Where: script.js §3 chart (#model): the dashed 'differences only' curve, and onestext

Files: docs/reports/sources/heat-per-mm.script.js

Problem: The text says a transitions-only mesh would give 'zero for all-zeros and for all-ones … (dashed)'. The dashed curve is instead a separate least-squares fit bT + aT·2P(1−P), whose intercept (about 1.55 pJ/B/hop on board, 1.1 on the mesh rail) sits far above the measured all-zeros point (0.82 and 0.59). The reader sees a curve that neither matches the words nor isolates the ones term.


APPLY (CORRECTED): Keep the least-squares dashed curve. Rename its legend entry to 'differences only (best fit)'. In onestext change '…would follow 2P(1−P): zero for all-zeros and for all-ones, highest at P = ½, symmetric about it (dashed)' to '…would rise and fall as 2P(1−P): the same for all-zeros and all-ones, highest at P = ½, symmetric about it (dashed: the best fit of that shape, which misses both ends)'.

Base PROPOSAL (for "as proposed" references): Replace the least-squares block (from 'const pp=pts.filter…' to 'tog.push([p,bT+aT*2*p*(1-p)])') with: for(let p=0;p<=1.0001;p+=0.02)tog.push([p,s0+a*2*p*(1-p)]); That is the same fit with its ones term removed (b = 0). Rename the legend entry to 'without the ones term (b = 0)'. In onestext change '…would follow 2P(1−P): zero for all-zeros and for all-ones, highest at P = ½, symmetric about it (dashed)' to '…would rise above the all-zeros level as 2P(1−P): nothing extra for all-ones, highest at P = ½, symmetric about it (dashed: the fit below with its ones term removed; the gap to the solid line is b·P)'.


Verifier note: The numbers are right: the transitions-only least-squares fit has intercept bT = 1.58 (board) and 1.11 (rail), against measured zeros of 0.83 and 0.60. The words 'zero for all-zeros and for all-ones' do not match the curve. But the current curve is the fair null model: the best any transitions-only curve can do, and it visibly misses both ends by about 0.5 (rail) and 0.75 (board) pJ/B. The proposed s0 + a·2P(1−P) is the two-term fit with b removed. That is a decomposition, not a test of the hypothesis the sentence states, and it would read as a strawman. Fix the words and keep the test.


#### heat-chart-4 — CONFIRMED [visualization/low] et-soc1-heat-per-mm

Where: script.js §4 'lanes and flit width' chart (#alt); body.html §7

Files: docs/reports/sources/heat-per-mm.script.js, docs/reports/sources/heat-per-mm.body.html

Problem: (1) The chart shows board power only, but alttext quotes both meters (69% on board, 54% on the mesh rail, and the 0.35/0.45 pJ/B increments on the mesh rail). (2) The dashed 256 B prediction (about 2.9 pJ/B) is drawn above the top tick of 2.5, with no gridline or label, because yt stops at 2.5 while mx is about 3.2.


APPLY (PROPOSAL): Add <div class="controls" id="altbtn"></div> above the #alt chart title. Wrap the IIFE in draw(key) with key ∈ {'pj_per_byte','noc_pj_per_byte'}, reading P[`alt:${n}`][key].slope and the model W_.model.v1[key==='pj_per_byte'?'board':'noc_rail']. Default to mesh rail (heat-chart-1), and set the y label to `${meter}: pJ per payload byte per hop`. Change yt to [0,0.5,1,1.5,2,2.5,3,3.5].filter(q=>q<=mx).


Verifier note: Screenshot: the 256 B dashed prediction (2.72 pJ/B on board) sits above the top gridline (2.5), with no tick. alttext quotes mesh-rail figures (54%, 0.35/0.45 pJ/B) that the board-only chart cannot show. patterns['alt:N'].noc_pj_per_byte.slope exists (1.091, 1.081, 1.080, 1.056, 1.489), and model.v1.noc_rail has a, b and s0. The toggle, the mesh-rail default and the extended yt are all sound.


#### heat-chart-5 — MODIFIED [visualization/low] et-soc1-heat-per-mm

Where: script.js §2 (#dist) colours; hover() helper

Files: docs/reports/sources/heat-per-mm.script.js

Problem: (1) Density of ones is an ordered variable, but the five lines use unordered categorical tokens (green, blue, purple, orange, pink for P = 0, ¼, ½, ¾, 1), so P cannot be read from the colour and P = ½ and ¾ look unrelated. (2) Every tooltip listens only to mousemove: keyboard users cannot reach any value, and the §5 table is the only non-hover access to the numbers.


APPLY (CORRECTED): (1) Use an ordered ramp with a visible floor, e.g. `color-mix(in srgb, var(--c7) ${Math.round(45+55*p)}%, var(--ink-2))`, or a validated sequential pair of tokens. Label each line at its right end ('P = 0' … 'P = 1'), then drop the side legend. (2) Add the focus/blur handlers as proposed, plus g.setAttribute('aria-label', <the tooltip text without HTML>) on each focusable group.

Base PROPOSAL (for "as proposed" references): (1) Replace cols with an ordered ramp from one token: const col=p=>`color-mix(in srgb, var(--c7) ${Math.round(25+75*p)}%, var(--grid))`. Label each line at its right end ('P = 0' … 'P = 1', class 'lab', fill the line colour) and drop the side legend (R2 150 → 60). (2) In hover(), add g.setAttribute('tabindex','0'); g.addEventListener('focus',()=>{const r=g.getBoundingClientRect(),b=h.getBoundingClientRect();tip.innerHTML=html();tip.style.display='block';tip.style.left=Math.min(r.right-b.left+8,b.width-290)+'px';tip.style.top=(r.top-b.top)+'px';}); g.addEventListener('blur',()=>tip.style.display='none'). All charts then work by Tab.


Verifier note: P is ordered and the categorical hues hide that, so the point is valid. But color-mix(var(--c7) 25%, var(--grid)) would make the P = 0 line, the zeros/fixed-part line the page leans on, nearly invisible against the background in both themes. The lines also cross: P = 1 crosses P = 0.25 near d = 3, and at d = 0 the order differs. A faint single-hue ramp makes crossings hard to follow unless the lines carry direct labels. Adding tabindex to every point group gives about 30 tab stops in §4 alone. That is workable, but each focusable group needs an aria-label.


#### heat-layout-1 — MODIFIED [layout/medium] et-soc1-heat-per-mm

Where: All SVG charts at 390 px (template .chart.scroll svg{min-width:640px}); §5 table #modeltab

Files: docs/reports/sources/heat-per-mm.script.js, docs/reports/sources/heat-per-mm.body.html

Problem: At phone width each chart is a 640-px canvas scrolled inside a 358-px frame. The legends, drawn in the right margin (R2 = 150–190 px), are off-screen in §4, §5 and §6, so the coloured lines cannot be identified without scrolling sideways. In §8 only the labels are visible. The §5 table's first column is squeezed to about 90 px, so each row label wraps to 5–7 lines.


APPLY (CORRECTED): As proposed, plus: move #cont's summary lines into the HTML legend row or a caption under the chart before cutting R2. Render line-style legend entries as small inline SVGs (solid, and dashed '4 3'), not background swatches. Shorten the #modeltab row labels as proposed.

Base PROPOSAL (for "as proposed" references): Move each chart's legend out of the SVG into an HTML row above the chart: <div class="legend" id="dist-leg"></div>, flex-wrap, swatches as <span style="background:var(--cN)">, so it wraps at 390 px. Then cut R2 to 20 in #dist, #model and #cont. For #comparechart see heat-chart-2. In #modeltab shorten the row labels ('a: per flit-to-flit difference', 'b: per one carried', 'random bit, data part (½a + ½b)', 'per bit, data-independent') and move the definitions into the equation's caption, which already defines both terms.


Verifier note: Confirmed at 390 px: §4's legend is off-screen, the §8 chart shows only labels and the '5 10' ticks, and the table's first column is squeezed so each label wraps to many lines. Two omissions in the proposal. First, #cont draws its 'per bit per hop, 1–4 hops, fJ: data 91 own links, 119 loaded; fixed 43 / 76' summary in the same right margin (at T+100..136), so cutting R2 to 20 would clip it. Second, #model's legend has solid and dashed line entries, so an HTML legend of background swatches cannot represent them.


#### heat-viz-v1 — MODIFIED [visualization/medium] et-soc1-heat-per-mm

Where: §8 'Against the rule of thumb' (#compare), replacing #comparechart

Files: docs/reports/sources/heat-per-mm.script.js, docs/reports/sources/heat-per-mm.body.html, docs/reports/data/2026-09-24-wire-energy/report.json

Problem: The page's central question, whether Dally's voltage-less 100 fJ/b-mm holds here, turns on the supply voltage and on what one counts: data-dependent only, or everything. The current log-bar chart shows two fixed voltages as separate bars, so the reader cannot see that the page's argument ('the advantage over the 0.9 V literature is mostly V²') is a family of CV² curves crossing Dally's line.


APPLY (CORRECTED): As proposed, with a y axis of 0–240 fJ (or clip at 200 with an arrow marker). Legend and readout wording for the 'everything' curves: 'everything (assumes the fixed part also scales as CV²)'. Replace #comparechart only when this ships; heat-chart-2 applies otherwise.

Base PROPOSAL (for "as proposed" references): A 'voltage explorer' line chart in inline SVG. Question: at what voltage would this mesh cost Dally's 100, and where does the literature sit at its own voltage? Data (report.json):
- the mesh-rail curves: headline['uncontended/noc_rail'] and headline['v2/noc_rail'] .random_bit_data and .random_bit_total {mean, lo, hi};
- board power: headline['uncontended/board'] and headline['v2/board'] .random_bit_total, plotted only at 0.485 V as hollow points labelled 'board power, includes regulator loss, not scaled';
- literature[] {who, fj_bit_mm, v, range, conditions}: v set gives points (Keckler 0.9 V 121; Dally 2014 0.7 V 68); v null gives horizontal reference lines (Dally 2023 and CACM 2020 at 100, VLSI 2018 band 20–40, CACM 2022 at 30); Ho 1.8 V excluded as now;
- first_principles.at_0485.per_random_bit_fj_mm [lo, mid, hi], and inputs.noc_v.value (0.485).
Encoding:
- x = supply voltage 0.40–1.00 V (linear); y = fJ per random bit·mm, linear 0–200.
- Four curves E(V) = E485·(V/0.485)² with lo–hi bands (fill-opacity 0.15): data on free links var(--c1) solid, data on the loaded mesh var(--c1) dashed, everything on free links var(--c7) solid, everything on the loaded mesh var(--c7) dashed.
- The plain 7 nm wire band in var(--c3); literature points in var(--c2) with whiskers; voltage-less lines in var(--ref), labelled at the left; a vertical marker at 0.485 V ('ET-SoC-1 runs here'); grid in var(--grid), text in var(--ink).
Interaction:
- A range input (0.40–1.00 V, step 0.005, default 0.9) moves a vertical cursor.
- A readout table under the chart gives each series at that voltage, its ratio to 100, and Keckler's 121 scaled to the same voltage.
- Snap buttons '0.485 V (as run)', '0.7 V (Dally 2014)' and '0.9 V (Keckler)'.
- Hover or focus on a point shows the literature entry's 'what' and 'conditions'.
- One computed sentence, e.g. 'the data-dependent part reaches 100 fJ at 0.88 V (loaded) to 0.98 V (free links); everything included, at 0.68–0.81 V; a plain 7 nm wire only at 1.0–1.4 V.'
Phone: draw with W=360 when the container is under 560 px; the readout table sits under the chart; no min-width. Keyboard: the range input and buttons. What changes for the reader: 'holds, to within its own vagueness' becomes visible. The verdict flips with the voltage one assumes and with whether the fixed part counts. At Dally's 2014 0.7 V this mesh's data cost is 51–64 fJ against his 68. It replaces the log-bar chart; comparetext stays.


Verifier note: All the numbers check: 100 fJ is reached at 0.979 V (free data), 0.877 V (loaded data), 0.806 V (free total) and 0.683 V (loaded total); at 0.7 V the data costs are 51.2 and 63.7; the wire reaches 100 at 1.0–1.41 V; the literature entries have who, what, conditions and v. This is the right chart for the page's question, and it keeps board power unscaled, consistent with the page. Two errors, though. First, the y range 0–200 clips the loaded-total curve, which reaches 214 at 1.0 V (band to 226). Second, the 'everything' curves scale the fixed part as CV², the same assumption heat-claim-6 flags, and the encoding does not say so. Voltage-less literature drawn as horizontal lines must be labelled as such; the proposal does this.


#### heat-viz-v2 — MODIFIED [visualization/medium] et-soc1-heat-per-mm

Where: §5 'Ones cost energy, not just flips' (#ones), new block after the model table (complements #model)

Files: docs/reports/sources/heat-per-mm.script.js, docs/reports/sources/heat-per-mm.body.html, docs/reports/data/2026-09-24-wire-energy/report.json

Problem: The page's surprising result is a two-term model, E = s0 + a·t + b·P. The static chart plots cost against P alone, so the patterns that break the P ↔ t link (the frozen line at t = 0, the 16–128 B blocks at t = 0, the 256 B blocks at t = 1) look like outliers. The encoding advice in modeltext2 (complement ones-dense data: −64%; per-flit inversion: about 1%) cannot be explored.


APPLY (CORRECTED): Draw the plane and contours from model.v2 only. Plot the v2 points (wu/p*, wfrz) as measured markers. Omit the v1 bern points, or draw them hollow with 't ≤ 2P(1−P) (repeated image)'. Place the alt:N blocks (first run) at P = 0.5 with t from the lane rule (0 for N ≤ 128, 1 for 256), labelled 'first run; t from the lane rule of §7', and read their predictions off the v2 plane. Shade or label everything off the measured points 'model extrapolation'. In the readout say the 16–128 B blocks come in slightly below the plane and 256 B far below. Keep the rest (complement button, meter toggle, phone layout).

Base PROPOSAL (for "as proposed" references): A 'what does a bit pattern cost' plane. Question: for any mix of ones P and flit-to-flit differences t, what does a hop cost, and why do all ones cost as much as random data?
Data (report.json):
- wire.model.v2.{noc_rail,board}: a = toggle_fj_per_bit_transition_hop, b = ones_fj_per_one_bit_hop, s0 = s0_pj_per_byte_hop × 125 fJ/bit.
- Measured markers: wire.model.v2.<meter>.per_pass[host][].points[] {pattern, toggle, ones, slope}, pooled by pattern into mean/lo/hi as the §5 chart does, plus the same from model.v1 for the first-run densities.
- wire.patterns['alt:16'…'alt:256'].{noc_pj_per_byte,pj_per_byte}.slope, placed at P = 0.5 with t = 0 for N ≤ 128 and t = 1 for 256 (the lane rule of §7) and predicted with model.v1.
- inputs.hop_mm.value.
Encoding:
- Main panel (SVG): x = density of ones P (0–1), y = fraction of bits differing from the previous flit t (0–1); the feasible region t ≤ 2·min(P, 1−P) shaded var(--grid).
- The independent-bits parabola t = 2P(1−P) dashed in var(--ref); iso-cost lines of the fitted plane every 0.25 pJ/B/hop in var(--ink-2), thin and labelled. They are straight and tilted, because more ones cost more than more differences (b = 129 > a = 98 fJ on the mesh rail).
- Markers: circles var(--c1) (first run), var(--c2) (second run); squares var(--c3) (frozen line, block patterns). The 256 B marker, measured well below its predicted contour, gets a hollow ring at the prediction.
- Readout panel: a stacked horizontal bar for the cursor point with segments s0 (var(--ref)), a·t (var(--c1)) and b·P (var(--c2)), labelled in fJ per bit per hop, fJ per bit·mm and pJ per 1 KB tensor load per hop; for a measured preset, a tick and bracket show the measured value.
Interaction:
- Range inputs P (0–1, step 0.01) and t (0–1, step 0.01, clamped to the feasible region); the cursor can also be dragged with pointer events.
- Preset buttons: all zeros, P = ¼, random, P = ¾, all ones, frozen line, 16–128 B blocks, 256 B blocks.
- A 'send complemented' button maps (P, t) → (1−P, t) and prints the saving; for all ones, 203 → 74 fJ per bit per hop on the mesh rail.
- A meter toggle (mesh rail | board power).
Phone: the plane is 340 px square and the readout stacks below. What changes for the reader: they see the all-ones corner (1, 0) on the same cost contour as random data (0.5, 0.5); the frozen line and the 16–128 B blocks sit on the model at t = 0; the 256 B blocks are the one pattern the model overpredicts. That links §5 to §7, and makes the encoding advice something to try.


Verifier note: The coefficients and examples check: v2 rail a 98.1, b 129.4, s0 0.590 pJ/B; all ones 203 against random 187.5 fJ; complemented all ones 74 fJ; the frozen line predicted 1.084 against measured 1.072. Three problems. (a) The 16–128 B blocks do not 'sit on the model at t = 0': they are 1.5–4.7% below the v2 rail plane and 2–7% below on board, 3–7× the fit rms. The markers will show this, but the narrative must not claim otherwise. (b) Putting first-run (v1) points at t = 2P(1−P) contradicts E31's caveat: the repeated 512 B image makes the true difference rate lower 'by an unknown factor'. Predicting the alt markers with model.v1 while the contours come from model.v2 (board a 138.5 against 151) puts two models on one plane. (c) Only the parabola, the frozen line and the block patterns are measured. The iso-cost lines over the rest of the feasible region are the model's extrapolation, not a map.


#### heat-viz-v3 — CONFIRMED [visualization/low] et-soc1-heat-per-mm

Where: §6 'Sharing a link costs energy' (#contention), beside the #cont chart (linked)

Files: tools/ettelem/build_wire_report.py, workloads/enercat/run_wire.py, docs/reports/sources/heat-per-mm.script.js, docs/reports/sources/heat-per-mm.body.html

Problem: The lede's second headline number (contention adds 40–45% per mm) rests on 'share of link-hops on shared links' (0, 22–32, 55, 72%). Readers get only these percentages, never the traffic pattern itself, so 'why does the loaded mesh cost more at 4 hops' stays abstract.


APPLY (PROPOSAL): A link-sharing mesh map.
Data: add to report.json via build_wire_report.py:
- inputs.mesh_xy, the runner's logical map (workloads/enercat/run_wire.py MESH: 32 shires → (x, y) on 6 × 6);
- wire.checks.link_sharing[cfg].target_map, copied from any run record's 'target_map' in docs/reports/data/2026-09-24-wire{,2}-aifoundry*/runs.jsonl.gz. The map is identical across passes and cards for every wu/p0.5 and wsep/p0.5 configuration, at most 181 characters each.
The page routes each flow target → reader with dimension-ordered XY, as analyze_wire.route() does.
Encoding (SVG):
- A 6 × 6 grid labelled 'logical map (the die turned a quarter)'. The 32 shires are dots in var(--ink); the four non-compute positions are grey rings.
- Each directed link is drawn as a short offset arrow, coloured and widened by the number of flows on it: 1 = var(--c1), 2 = var(--c4), 3–4 = var(--c2).
- Readout: flows, reader shires, shared link-hop fraction (checks.link_sharing[cfg].shared_link_hop_fraction) and the mesh-rail pJ/B for random data at that d (configs[cfg].noc_pj_per_byte.mean), for both sets side by side.
Interaction:
- Buttons d = 1, 2, 3, 4, 5, 6 (sets without that d are disabled: wsep has no 6, wu no 5) and a two-way toggle 'loaded mesh (all pairs) | own links'.
- Hover or focus on a reader dot lights its route; hover a link to list its flows.
- Brushing: choosing d outlines the matching points in the #cont chart.
Phone: a 340 px square map with the readout below. What changes for the reader: at d = 1 both maps are single disjoint links and the energies agree (2.40 against 2.33 pJ/B). At d = 4 the loaded map has links carrying three flows and 55% of link-hops shared, while the own-links map has every link carrying one; the gap (7.14 against 5.57 pJ/B) is then visibly tied to the sharing.


Verifier note: Verified from the raw runs.jsonl.gz: exactly one target_map per configuration across passes and cards, at most 181 characters, format 'reader>target[/r1]'. Routing with analyze_wire.route() gives loaded maps of 32/57/79/90/105 links with max load 1/2/3/3/4 at d = 1/2/3/4/6, and own-links maps of 31–72 links with max load 1. The mesh-rail pJ/B for random data matches the proposal (d1 2.40/2.33, d2 3.77/3.38, d3 5.20/4.46, d4 7.14/5.57), as does the shared fraction (0, 22%, 32%, 55%, 72%). The data is small and exists. One caution for the readout: the own-links set also has fewer flows (18 against 32 at d = 4) and only straight paths. The page hedges ('points to sharing rather than turns'), so the readout should show the flow counts side by side, as proposed, and not claim the gap is caused by sharing alone.


### Missed by the reviewers (found by the verifiers)


#### M-heat-1 [consistency] et-soc1-heat-per-mm

Problem: heat-reorg-1 renumbers #compare (§8 → §7) and #meaning (§9 → §8), but two sibling pages cite those numbers in their link text: the on-chip communication page's '(Heat per millimetre, §8)' → #compare and the on-chip relay page's '(Heat per millimetre, §9)' → #meaning (in docs/reports/sources/on-chip-relay.body.html). final_links.py checks anchors, not the numbers in link text, so it would not catch this.

APPLY: If the reorder is applied, change those two link texts to '§7' and '§8' in the same change and rebuild the relay page; or drop section numbers from cross-page link texts and link by name.


#### M-heat-2 [claim] et-soc1-heat-per-mm

Problem: §7 says 'Blocks of 16 to 128 bytes cost the same' and discusses only the 256 B shortfall. But the §7 chart visibly shows all four 16–128 B bars below their dashed no-transition predictions: 2.5–5.7% below on the mesh rail (1.056–1.091 against 1.115 pJ/B/hop) and 4.8–9.7% on board power (1.457–1.536 against 1.616). That is 3–7× the model's 0.008 pJ/B/hop residual. The text leaves this unexplained, and it bears on heat-claim-2 and heat-viz-v2.

APPLY: Add a computed clause to alttext: `The 16–128 B blocks also come in ${…}% below the model's no-transition prediction on the mesh rail (${…}% on board power), a first-run pattern the model was not fitted to.` Compute it from W_.patterns['alt:N'] and model.v1 (s0 + b/2).


#### M-heat-3 [consistency] et-soc1-heat-per-mm

Problem: docs/reports/data/2026-09-24-wire-energy/review/README.md ('three independent reductions agree with the pipeline within 1–3% on the mesh rail and about 7% on board power') repeats the claim heat-claim-4 corrects, but the finding's file list covers only script.js and 03-experiments.md.

APPLY: Apply the same wording to review/README.md: 'within 1–3% on the mesh rail's coefficients (6% on the free-link fixed part: Method B 45.6 against 43.1 fJ per bit per hop) and about 7% on board power, like for like on the leakage correction'.


#### M-heat-4 [claim] et-soc1-heat-per-mm

Problem: Once heat-claim-5 removes the only use of aifoundry3's y-only three-hop point, starvetext still says those bursts 'give the only y-only three-hop point', which then refers to nothing on the page. No other number on the page uses waxis/y/hop3.

APPLY: End starvetext's aifoundry3 sentence at 'those bursts were kept.'



## Group horace-lowpower


### Reproduction problems


#### R-hl-1 [medium] docs/reports/data/2026-09-22-horace-aifoundry3/transfer.json, docs/reports/data/2026-09-22-horace-aifoundry3/leakage_crosscard.json

Problem: No committed script (current or in git history) produces these two files, yet finish_horace.sh consumes them through build_cards_data.py. They feed Horace §10, DVFS §7, the energy manual, and E20/05-claims (0.924 scale, 0.36/1.53/0.27 W, +0.73 W).

Evidence: git log -S for loo_scale_rms and card2_law_W finds only the data commit 9df563e and the consumers. Both files were regenerated exactly by hand: transfer from cards.json (least-squares scale; per-pattern calibration; worst = max single abs error), and leakage from raw telemetry excluding 1 s before to 6 s after each launch, whole-degree bins, and the model.json law, with an unweighted mean and rms over 4 bins.

Fix: Commit a small tools/ettelem script (for example transfer_cards.py) that writes both from cards.json, the aifoundry3 telemetry and runs, and model.json, using the rule above. Call it in finish_horace.sh before build_cards_data.py, and cite it in E20 and 05-claims.


#### R-hl-2 [low] docs/reports/data/2026-09-21-horace-aifoundry2/vf.json

Problem: Hand-entered file with no producer script; its window definitions are not recorded. It feeds the low-power page's 800 MHz chart points and the 3.9/1.9, 20.6/10.3, 53/27 W and 35.0 vs 28.1 W claims.

Evidence: Only build_lowpower_report_data.py reads it. From cold1/cold2 telemetry: zeros800 38.91, ones800 55.64, randn peak 87.55, idle800 34.97 (12 settled post-run idle samples at 800 MHz), idle600 28.02 at 65 °C; ones600 and randn600 are about 0.1–0.2 W off simple window means. 05-claims gives the 800 MHz random peak as 87.8 W (cold2), vf.json 87.6.

Fix: Add a --vf option to analyze_horace_cold.py (or a small script) that writes vf.json with the windows stated, and align the peak figure (87.6 or 87.8 W) between vf.json, 05-claims and both pages.


#### R-hl-3 [low] docs/reports/sources/horace-experiment.body.html

Problem: Section 10 says "Calibrating that number on a single aifoundry3 run and predicting the other seven gives 0.36 W rms in the median and 1.53 W at worst". Calibration is on one pattern's mean (3 runs for 6 of the 8 patterns), and 1.53 W is the worst single-pattern absolute error, not a worst rms. The same wording is in E20, 05-claims and the DVFS page §7.

Evidence: transfer.json: median_rms is the median of the 8 per-pattern rms values (0.356); the worst rms is 0.93 W (zeros calibration); worst = 1.527 is |error| on randn when calibrated on zeros. Per-run calibration gives median 0.38 W rms and worst 1.28 W rms.

Fix: Reword to "calibrating it on one pattern and predicting the other seven gives 0.36 W rms in the median (0.93 W at worst, 1.53 W the largest single error)", or switch to per-run numbers.


#### R-hl-4 [low] docs/reports/sources/horace-experiment.body.html

Problem: Section 4's "the 20 September session … put a further 0.11 °C per W at 60 s and beyond" is hard-coded (since f2b8776), and no committed output or script reproduces it.

Evidence: analyze_horace_strict.py (unchanged since f2b8776) on the 20 September v2 session gives R = 0.06 at 60 s + 0.026 at 1,000 s = 0.086 °C/W (0.164 counting the 25 s stage); on v1 it gives 1.0 °C/W at 400 s.

Fix: Recompute from a committed command and cite it, or drop the parenthetical; section 8's long-run network already shows the slow stages.


#### R-hl-5 [low] docs/reports/sources/horace-experiment.body.html

Problem: "For the eleven patterns that heat the die by more than a degree, this thermal estimate agrees with the electrical one to 1.0 W rms, with a slope of 0.97" mixes two populations.

Evidence: rms over the 11 hot patterns is 1.02 W with slope 0.983; the 0.975 slope in report.json thermal.inferred_vs_electrical is over all 14 patterns, whose rms is 1.72 W.

Fix: Say "slope 0.98", or compute both over the 11 patterns in analyze_horace_strict.py and fill the sentence from D.thermal.


#### R-hl-6 [low] tools/ettelem/finish_horace.sh, tools/ettelem/build_horace_report_data.py

Problem: Redundant output. finish_horace.sh runs flip_thermal_model.py --evaluate on long2 (model2.json/.txt) and merges it into report.json as structured_long, but no page or script reads it. Its non-causal predictions compete with the causal validation_afternoon.json the page shows (negzero 102.3 vs 113.5 s, relu 59.0 vs 62.6, DFT 106.3 vs 116.2). report.json also carries predictions_before twice (top-level before and power_model.before).

Evidence: grep for structured_long and model2 finds no consumer in docs/reports/sources/*.js; the data README still lists model2.json as "the model evaluated on them".

Fix: Drop the model2 step and --long2/--model2, or mark model2.json as superseded by validation_afternoon.json in the README; keep one copy of before.


#### R-hl-7 [low] docs/reports/sources/horace-experiment.body.html

Problem: The Method section's long-run command, "run_horace_long.sh build/horace_long tools/ettelem/horace_long.sched 80 84 90", omits the "900 18000 600" that E12 records. The script's defaults (max_wait 900, deadline 18600, final_idle 900) then reproduce a different session end.

Evidence: 03-experiments E12: `... 80 84 90 900 18000 600`; run_horace_long.sh usage: [max_wait_s=900] [deadline_s=18600] [final_idle_s=900].

Fix: Append "900 18000 600" to the command on the page.


#### R-hl-8 [low] docs/reports/sources/why-low-power.body.html

Problem: "this card's minion rail alone reads 22 W under int8 random data at the end of a 7 s run (about 82 °C)": the end reading was 83 °C.

Evidence: ablation.json runs for int8_randn: t_end 83.0 and 83.0 (launch about 81 + rise 2.1).

Fix: Change to "about 83 °C".


#### R-hl-9 [low] docs/reports/data/2026-09-22-horace-aifoundry3/leakage_crosscard.json

Problem: The cross-card idle curve uses a different idle rule from the model it tests. Its 50 °C bin, which sets the "7 to 14 °C below" range, is 22 samples from the first 2.2 s of the session.

Evidence: Under flip_thermal_model.py's own rule (±4.5 s, 600 MHz, skip 20 s, 3 s smoothing, n≥30) the bins are 55–57 °C with offsets +0.71/+0.73/+0.65 W, a mean of +0.69 W, and 7–9 °C below the fitted range.

Fix: Use the model's own idle rule in the script proposed above, or say on the page that the 50 °C point is 2 s of pre-session idle.


### Review findings


#### H-layout-1 — CONFIRMED [layout/medium] et-soc1-horace-experiment

Where: Tables #tbl (§1), #act (§3), #long-tbl (§7), #perflip (§8), #struct-tbl (§9); template rule th.num{white-space:nowrap}

Files: docs/reports/sources/horace-experiment.body.html, docs/reports/sources/report.template.html

Problem: At 1280 px five tables are wider than the 908 px column and scroll sideways inside their frame, so a desktop reader never sees the last columns: #tbl 1340 px (both pJ-per-FLOP columns hidden, although the note under it explains them), #act 1201 px (measured W, model W, error), #long-tbl 1203 px (end °C measured, end °C fitted), #perflip 1023 px (°C after 1 min), #struct-tbl 1268 px (error, end reading − launch). The cause is the template's th.num{white-space:nowrap} with long numeric headers. check_page.sh does not flag it because the page itself does not overflow.


APPLY (PROPOSAL): In docs/reports/sources/horace-experiment.body.html line 1, append to the existing <style>: `#tbl th.num,#act th.num,#long-tbl th.num,#perflip th.num,#struct-tbl th.num,#val-tbl th.num{white-space:normal;min-width:3.5em}`. Tested on a copy of the built page: every table-wrap then measures 908/908 at 1280 px. The column cuts in H-red-1 and H-red-2 shorten #tbl and #act further. Rebuild and redeploy with the GIFs.


Verifier note: I measured scrollWidth/clientWidth at 1280 px on the committed page and got #tbl 1340/908, #act 1201/908, #long-tbl 1203/908, #perflip 1023/908 and #struct-tbl 1268/908. With the proposed CSS injected, every table-wrap measures 908/908. At 390 px the page still does not overflow (375/390), and the tables get narrower (for example #tbl goes from 1340 to 798), so the fix also helps phones. The cause is the template rule th.num{white-space:nowrap} (report.template.html L93).


#### H-repro-1 — CONFIRMED [reproducibility/medium] et-soc1-horace-experiment

Where: §10 (#scaletext, #leaktab) and Method raw-data note; tools/ettelem/finish_horace.sh line 60 (build_cards_data.py step)

Files: tools/ettelem/finish_horace.sh, tools/ettelem/build_cards_data.py, docs/reports/data/2026-09-22-horace-aifoundry3/transfer.json, docs/reports/data/2026-09-22-horace-aifoundry3/leakage_crosscard.json, docs/findings/03-experiments.md, docs/findings/05-claims.md

Problem: No committed script, current or in git history, produces docs/reports/data/2026-09-22-horace-aifoundry3/transfer.json or leakage_crosscard.json. finish_horace.sh consumes both through build_cards_data.py. They carry the 0.924 scale, the 0.36/1.53/0.27 W calibration figures and the +0.73 W idle offset shown in Horace §10, DVFS §7, the energy manual, 03-experiments E20 and 05-claims. finish_horace.sh also does not regenerate aifoundry3's horace3.json or cards.json.


APPLY (PROPOSAL): Add tools/ettelem/transfer_cards.py (--cards, --session, --model, --transfer, --leak) that writes both files.

transfer.json, with m = cards.patterns[].model and a = [].a3:
- scale = (a·m)/(m·m).
- For each pattern i, s_i = a_i/m_i and loo_scale_rms[i] = rms over j≠i of (a_j − s_i·m_j).
- median_rms = the median of those; worst_rms = their max.
- worst_single = max over i≠j of |a_j − s_i·m_j| (today's field 'worst').

leakage_crosscard.json:
- Take the session's telemetry.jsonl.gz and runs.jsonl, and apply flip_thermal_model.py's own idle rule: samples at least 4.5 s from any launch, 600 MHz, skip the first 20 s, 3 s smoothing, bins on the whole-degree minshire reading with n ≥ 30.
- Law = P_fix + A_leak_at_80·e^((T−80)/T_L) from model.json.
- Report mean_offset_W and rms_W.
- To keep today's file byte-exact instead, use the rule that regenerated it: drop samples from 1 s before to 6 s after each launch, then take an unweighted mean over the 4 bins.

In finish_horace.sh, before the build_cards_data.py line, add (with A3=docs/reports/data/2026-09-22-horace-aifoundry3):
- `python3 tools/ettelem/analyze_horace_strict.py "$A3" --toggles "$D/toggles.json" --out "$A3/horace3.json"`
- `python3 tools/ettelem/compare_cards.py --card aifoundry2="$D/horace3.json" --card aifoundry3="$A3/horace3.json" --model "$D/model.json" --toggles "$D/toggles.json" --out "$A3/cards.json"`
- `python3 tools/ettelem/transfer_cards.py --cards "$A3/cards.json" --session "$A3" --model "$D/model.json" --transfer "$A3/transfer.json" --leak "$A3/leakage_crosscard.json"`

Cite the script in the Horace Method raw-data note, E20 and 05-claims rows 198 and 200.


Verifier note: No script, current or in history, writes transfer.json or leakage_crosscard.json. The only matches are the consumers (build_cards_data.py, finish_horace.sh, the two script.js files). I recomputed transfer.json exactly: scale 0.923596, per-pattern LOO rms values, median 0.35638, worst single error 1.52668. The reviewer's 'byte-exact' rule for leakage_crosscard also checks out: drop samples from 1 s before to 6 s after each launch, bin on the raw whole degree, take the unweighted mean of the 4 bins. That gives 50/55/56/57 °C with n 22/207/2963/404, mean +0.7321 and rms 0.7399. Under flip_thermal_model.py's own idle rule I get 55/56/57 °C with n 205/2283/681 and a mean of +0.694 W. The proposed finish_horace.sh lines are safe: I ran analyze_horace_strict.py on the aifoundry3 session and compare_cards.py locally, and both reproduce the committed horace3.json and cards.json identically.


#### H-claim-1 — CONFIRMED [claim/medium] et-soc1-horace-experiment

Where: §10, generated paragraph #scaletext (horace-experiment.script.js L310–317); same wording in dvfs-leakage.script.js L162–169, 03-experiments E20 result, 05-claims row 198

Files: docs/reports/sources/horace-experiment.script.js, docs/reports/sources/dvfs-leakage.script.js, docs/findings/03-experiments.md, docs/findings/05-claims.md

Problem: 'Calibrating that number on a single aifoundry3 run and predicting the other seven gives 0.36 W rms in the median and 1.53 W at worst.' The calibration is on one pattern's mean (3 runs for 6 of the 8 patterns), not a single run. 1.53 W is the largest single-pattern absolute error, not a worst rms; the worst rms is 0.93 W (calibrated on zeros). 'A consistent 8% overestimate' is 3–10% by pattern (a3/model 0.904–0.971); 8% is the least-squares value.


APPLY (PROPOSAL): Replace the tail of the #scaletext template with:

`…and it overestimates every pattern, by ${Math.round(100*(1-Math.max(...P.map(p=>p.a3/p.model))))} to ${Math.round(100*(1-Math.min(...P.map(p=>p.a3/p.model))))}%. Multiply every flip energy by one number, <b>${f(C.scale)}</b>, and the residual falls to <b>${f(C.rms_scaled)} W rms</b> over a 1.9 to 25 W range, which is as good as the in-sample fit on the card the coefficients came from. Calibrating that number on one pattern's runs and predicting the other seven patterns gives ${f(C.loo.median_rms)} W rms in the median and ${f(Math.max(...Object.values(C.loo.per_pattern)))} W rms at worst (calibrated on zeros), with ${f(C.loo.worst)} W the largest single-pattern error; calibrated on random normal it is ${f(C.loo.per_pattern.randn)} W rms.`

This renders as '…by 3 to 10% … 0.36 W rms in the median and 0.93 W rms at worst (calibrated on zeros), with 1.53 W the largest single-pattern error; calibrated on random normal it is 0.27 W rms.'

Mirror the change in dvfs-leakage.script.js L165–169 ('a consistent … overestimate' and 'at worst'), in E20 and in 05-claims row 198.


Verifier note: Recomputed from cards.patterns. Each calibration uses one pattern's mean (horace3.json on aifoundry3 has n=3 for 6 patterns and n=1 for signs and mant), not a single run. Per-pattern LOO rms runs from 0.218 to 0.929 (worst: zeros). 1.527 is the largest single absolute error (normal, calibrated on zeros), not an rms. a3/model is 0.904–0.971, i.e. 3–10%; 8% is the least-squares figure. The proposed template renders 'by 3 to 10%' (rounding 2.9 and 9.6) and 0.93 W rms at worst. The DVFS page has the same 'consistent … overestimate' and 'at worst' wording (dvfs-leakage.script.js L165–169); its 'single operand pattern' is already correct there.


#### H-claim-2 — MODIFIED [claim/low] et-soc1-horace-experiment

Where: §4 'From watts to degrees', paragraph after the #foster table (body L192–193)

Files: docs/reports/sources/horace-experiment.body.html, docs/reports/data/2026-09-21-horace-aifoundry2/model.json

Problem: 'the 20 September session, which did not, put a further 0.11 °C per W at 60 s and beyond' is hard-coded (since f2b8776), and no committed output or script reproduces it.


APPLY (CORRECTED): Replace the clause with: 'the model of <a href="#a-model-from-flips-to-temperature">section 8</a>, fitted to the long runs of section 7, which do not, puts 1.31 °C per W in stages of 60 s and longer (1.47 °C per W in all).'

Base PROPOSAL (for "as proposed" references): Replace that clause with: 'the long runs of <a href="#a-model-from-flips-to-temperature">section 8</a>, which do not, put a further 1.3 °C per W in stages of 60 s and longer.' This is the page's own §8 table: 0.234 + 0.136 + 0.860 + 0.081.


Verifier note: I refitted analyze_horace_strict's Foster chain on the 20 Sep telemetry. The v2 session (624 s) gives R 0.06 at 60 s and 0.026 at 1,000 s: 0.086 °C/W for τ ≥ 60 s, 0.164 including the 25 s stage. The v1 session gives 1.006 at 400 s. Neither gives 0.11, so the clause cannot be reproduced. The replacement is right in substance, but the long runs are section 7, not 8 (section 8 is the model fitted to them). The model's fast stages also differ from §4's: 1.5 s 0.106, 4 s 0.050, no 10 s stage. So 'a further' is 1.25 relative to §4's 0.22, or 1.31 counting the model's stages of 60 s and longer.


#### H-claim-3 — CONFIRMED [claim/low] et-soc1-horace-experiment

Where: §4, paragraph under the 'three ways' chart (body L210–211)

Files: docs/reports/sources/horace-experiment.body.html, tools/ettelem/analyze_horace_strict.py

Problem: 'For the eleven patterns that heat the die by more than a degree, this thermal estimate agrees with the electrical one to 1.0 W rms, with a slope of 0.97' mixes two populations. The 1.0 W rms is over the 11 hot patterns (1.02); the 0.97 slope is thermal.inferred_vs_electrical over all 14, whose rms is 1.72 W. Over the 11 patterns the slope is 0.98.


APPLY (PROPOSAL): Change 'with a slope of 0.97 between them' to 'with a slope of 0.98 between them'. Better: have analyze_horace_strict.py also write thermal.inferred_vs_electrical_hot = {slope, rms, n} over patterns with rise_fit > 1 °C, and fill the sentence from D via a <span id>.


Verifier note: Recomputed from report.json patterns with the script's own formulas (slope through the origin; rms of a_thermal − a_electrical). All 14 patterns: slope 0.975, rms 1.72 W. The 11 with rise_fit > 1 °C: slope 0.983, rms 1.016 W. The sentence therefore mixes the two populations, and 0.98 is the right slope for the 11.


#### H-claim-4 — CONFIRMED [claim/low] et-soc1-horace-experiment

Where: §8 'How well it fits' (body L370–371) and 'How well it predicts' second bullet (L381–382)

Files: docs/reports/sources/horace-experiment.body.html

Problem: The text presents the ten-minute hot bias as an out-of-sample effect ('At ten minutes it runs hot … 3.8 °C rms against 2.5 °C in the fit, and it wrongly has two of the five ten-minute runs reaching 90 °C'). The fit itself is also hot: its seven ten-minute runs average +1.8 °C, and the same two runs are fitted to reach 90 °C, at 580 s (ones, 512 minions) and 507 s (75%-zero matrix), although they ended at 88 and 87 °C. The long-runs table shows 580 and 507, but no text explains them.


APPLY (PROPOSAL): Replace L370–371 'For the seven ten-minute runs the end temperature is off by 2.5 °C rms.' with: 'For the seven ten-minute runs the end temperature is off by 2.5 °C rms and 1.8 °C hot on average; two of them (ones on 512 minions and the 75%-zero matrix) are fitted to reach 90 °C, at 580 and 507 s, though they ended at 88 and 87 °C.'

In the held-out bullet, replace 'and it wrongly has two of the five ten-minute runs reaching 90 °C, at 437 and 469 s, when they ended at 87 and 88 °C' with: 'and, as in the fit, it has the same two runs reaching 90 °C, now earlier (437 and 469 s), when they ended at 87 and 88 °C.'


Verifier note: model.per_run for the long session has 7 uncapped runs, with end errors of +3.04, −1.3, +1.71, +3.37, +0.53, +1.82 and +3.75 °C: mean +1.85, rms 2.474. The fit's t_cap_pred is 580.1 s for ones on 512 minions (ended at 88) and 506.9 s for the 75%-zero matrix (ended at 87). In the held-out rows the same two runs are 469.0 s (ones/512, 88 °C) and 437.4 s (sparse75, 87 °C). The pairings in the proposed text are correct.


#### H-claim-5 — MODIFIED [claim/low] et-soc1-horace-experiment

Where: §5 item 4 'Leakage feeds back' (body L230–231)

Files: docs/reports/sources/horace-experiment.body.html

Problem: 'Random normal reads 65.8 W in seconds 1 to 3 and 68.0 W in the last two seconds of the same run: +2.2 W from its own 5 °C.' Between those two windows the die warms by about 2 °C, not 5 °C. 5 °C is the rise from launch to the end. Read literally, the sentence implies 0.44 W/°C, which contradicts the 0.81 W/°C used in the next sentence.


APPLY (CORRECTED): 'Random normal reads 65.8 W in seconds 1 to 3 and 68.0 W in the last two seconds of the same run: +2.2 W as its own heating lifts the reading another 2.4 °C between those windows (5 °C over the whole run).'

Base PROPOSAL (for "as proposed" references): Replace with: 'Random normal reads 65.8 W in seconds 1 to 3 and 68.0 W in the last two seconds of the same run: +2.2 W as its own heating raises the die by another 2 °C between those windows (5 °C over the whole run).'


Verifier note: The problem is real: for random normal, p_early is 65.80 and p_late 67.97, yet between those windows the die warms about 2 °C, not 5. But the replacement '+2.2 W … another 2 °C' implies 1.1 W/°C, which again clashes with the 0.81 W/°C in the next sentence. The 2 °C is from the recovered temperature: mean curve_fit is 83.89 in s 1–3 and 85.77 in the last 2 s. The 0.81 is fitted against the whole-degree sensor reading, which rises 2.68 → 5.05 (+2.36 °C) between the same windows. On that scale the ratio is 0.92 W/°C, close to random normal's own per-run slopes (0.85–0.89) and the pooled 0.81. Quote the sensor-scale rise.


#### H-claim-6 — CONFIRMED [claim/low] et-soc1-horace-experiment

Where: §10 leakage paragraph (body L495–498) and #leaktab (script L318–320)

Files: docs/reports/sources/horace-experiment.body.html, docs/reports/data/2026-09-22-horace-aifoundry3/leakage_crosscard.json

Problem: The cross-card idle table's 50 °C row, which sets the '7 to 14 °C below' range and 'idled at 50 to 57 °C', is 22 samples from the first 2.2 s of the aifoundry3 session, before any launch. It was also binned with an idle rule different from the one the model it tests was fitted with. Under the model's rule only 55–57 °C remain and the offset is +0.69 W.


APPLY (PROPOSAL): Add under #leaktab: <p class="small">The 50 °C row is 22 samples from the first 2.2 s of the session, before any launch. With the idle rule the model was fitted with (samples at least 4.5 s from any launch, 600 MHz, 3 s smoothing, bins of 30 samples or more) only 55–57 °C remain and the mean offset is +0.69 W.</p>

When transfer_cards.py (H-repro-1) adopts that rule, change the prose to 'extrapolated 7 to 9 °C below that onto the other card, which idled at 55 to 57 °C, … to +0.69 W'.


Verifier note: The first launch of the aifoundry3 session (a pre-heat, block −9) is at 3.2 s. The 50 °C bin is the 22 samples before it, and every sample in the first 3 s reads 50. Under flip_thermal_model.py's rule (±4.5 s from any launch, 600 MHz, first 20 s skipped, 3 s smoothing, n ≥ 30) only 55–57 °C remain: offsets +0.710, +0.726 and +0.646 W, mean +0.694 W. The note under #leaktab is accurate. When the prose changes to '7 to 9 °C below … 55 to 57 °C … +0.69 W', mirror it in DVFS §7, E20 and 05-claims, which quote +0.73 and 50–57 °C.


#### HL-consistency-1 — CONFIRMED [consistency/low] et-soc1-horace-experiment and et-soc1-why-low-power

Where: Horace §8 'Leakage is two thirds…' paragraph (body L359–363); why-low-power §3 'Leakage and temperature' third bullet (body L135–136)

Files: docs/reports/sources/horace-experiment.body.html, docs/reports/sources/why-low-power.body.html

Problem: Horace says 'each watt, given ten minutes, adds 1.2 °C' and then 'that loop has a gain of 0.95'. A reader multiplying 0.65 × 1.2 gets 0.78; the gain uses the settled 1.47 °C/W. Why-low-power says 'each sustained watt adds about 1.5 °C'. Both are the same network at different horizons, and neither page says which.


APPLY (PROPOSAL): Horace L359: 'and each watt, given ten minutes, adds 1.2 °C through the network' → 'and each watt adds 1.2 °C through the network after ten minutes, 1.47 °C once settled'. L362–363: 'that loop has a gain of 0.95 at 80 °C' → 'that loop has a gain of 0.65 × 1.47 = 0.95 at 80 °C'.

Why-low-power L135–136: 'on this card's cooling each sustained watt adds about 1.5 °C, a loop gain near one (0.95) at 80 °C' → 'on this card's cooling each watt held for hours adds 1.47 °C (1.2 °C after ten minutes), a loop gain of 0.65 × 1.47 = 0.95 at 80 °C'.


Verifier note: model.json: step_open[600] = 1.209, R_total = 1.467, lambda_at_80 = 0.646, loop_gain_at_80 = 0.948 (= 0.646 × 1.467), and the gain reaches 1 at 82.0 °C. Horace's '1.2 °C … loop gain 0.95' mixes the two horizons, as the reviewer says. Why-low-power's 'about 1.5 °C' is already the settled value but does not say so. The proposed wordings are correct.


#### H-red-1 — CONFIRMED [redundancy/medium] et-soc1-horace-experiment

Where: §1: #perflip bar chart (script L47–57) and #tbl (script L58–59)

Files: docs/reports/sources/horace-experiment.script.js

Problem: The bar chart's labels already print each pattern's m°C per 10¹² FLOPs and its de-quantised rise ('76 (+5.1 °C)'), and the table repeats both. The table also has a TFLOPS column that reads 9.18–9.19 in all 14 rows (the text already says every run does 9.18 × 10¹² FLOPs/s) and an 'onset, °C/s' column that the text never mentions. The table has 11 columns and is the widest on the page (1,340 px).


APPLY (PROPOSAL): In script.js L58–59, drop the header cells 'TFLOPS', 'rise in 7 s, °C', 'onset, °C/s' and 'm°C per 10¹² FLOPs' together with their <td>s (${f2(v.tflops)}, the bold rise_fit cell, ${f2(v.slope)}, the mC_per_tflop_fit cell). Rename 'as read' to 'rise as read, °C (whole degrees)'. The table keeps Operands, runs, board W at 80 °C, ± sd, rise as read, pJ per FLOP (run average), pJ per FLOP over idle. The chart's hover keeps the onset and TFLOPS for anyone who wants them.


Verifier note: TFLOPS is 9.18 or 9.19 in all 14 rows. 'onset' appears nowhere in body.html. The bars' labels print mC_per_tflop_fit (0 decimals) and rise_fit (1 decimal), so the table's m°C column exactly repeats the chart and its rise_fit column nearly does. The kept columns hold what is not on the chart (runs, W, sd, the whole-degree rise, which is otherwise only in the hover, and both pJ columns). With H-layout-1 applied this is a declutter, not a layout fix. Keep the note under the table and rename 'as read' as proposed so it is not taken for the de-quantised rise.


#### H-red-2 — MODIFIED [redundancy/medium] et-soc1-horace-experiment

Where: §3 #act table (script L70–73), §3 #strip chart, §3 #stack chart, §4 'Step 1. Activity to power' scatter #pm (body L202, script L75–84)

Files: docs/reports/sources/horace-experiment.body.html, docs/reports/sources/horace-experiment.script.js

Problem: The leave-one-out power prediction against measurement is shown four times within two screens: #strip (dots and black LOO ticks), the #act table's 'measured W / model W / error' columns, the #pm scatter in §4, and #stack's black 'measured' line. The text says #act 'gives the counts per op', yet its last three columns repeat #strip. #pm also carries a dead variable (`bef`, L80).


APPLY (CORRECTED): Delete the #pm block (body L202) and its IIFE (script L75–84, including `bef`), and retitle #chain-sc 'Activity to temperature rise (RTL alone)'. Keep #act's 'measured W', 'model W' and 'error' columns, renamed 'measured W', 'predicted W (fit without it)' and 'error, W', since they are the numeric form of #strip's black ticks.

Base PROPOSAL (for "as proposed" references): Delete the #pm block in body L202 (`<div style="flex:1 1 380px;max-width:460px"><div class="chart-title">Step 1. Activity to power, all patterns</div><div class="chart" id="pm"></div></div>`) and its IIFE in script L75–84, and retitle #chain-sc 'Activity to temperature rise (RTL alone)'. In script L71–73, drop the 'measured W', 'model W' and 'error' header cells and the `${f1(me)}`, `${f1(pr)}` and error cells, so #act holds only event counts. Update the §3 bullet: '(the black ticks above)' stays, and it now refers to the only LOO view.


Verifier note: #pm repeats #strip (the same prim.loo against p80) and carries a dead variable `bef` at L80, so deleting it and its IIFE is right. Dropping #act's measured W / model W / error columns loses the only record of each pattern's LOO prediction and error outside a hover tooltip, and the text cites per-pattern errors ('zeros and random exponents (+0.9 W), ternary (−0.8 W)'). Hover on touch screens is unreliable. With H-layout-1's CSS, #act already fits 908/908 at 1280 px.


#### H-red-3 — CONFIRMED [redundancy/low] et-soc1-horace-experiment

Where: §4 paragraph under the 'three ways' chart (body L208–210)

Files: docs/reports/sources/horace-experiment.body.html

Problem: The paragraph re-explains §2's de-quantisation almost word for word: 'The sensor's whole degrees hide the size of the rise, but the instants at which it steps are sharp. So for each run one number was fitted: the added power which, put through the network from the launch state and rounded like the sensor, reproduces that run's readings.' Compare §2, L114–117: 'for each run, one number (the heating power) is fitted so that the thermal network … started from the launch state and rounded like the sensor, reproduces the run's readings. The times at which the reading steps … carry the information.'


APPLY (PROPOSAL): Replace 'The ring in the last chart uses no electrical measurement at all. The sensor's whole degrees hide the size of the rise, but the instants at which it steps are sharp. So for each run one number was fitted: the added power which, put through the network from the launch state and rounded like the sensor, reproduces that run's readings.' with 'The ring uses no electrical measurement at all: it is the heating power recovered from the whole-degree steps alone (<a href="#strict-temperature-control">section 2</a>).'


Verifier note: Body L208–210 restates §2's L114–117 almost word for word (one fitted heating power per run, network from the launch state, rounded like the sensor, step instants carry the information). The replacement keeps the point that the rings use no electrical measurement and links to #strict-temperature-control, which exists.


#### H-red-4 — MODIFIED [redundancy/low] et-soc1-horace-experiment

Where: §11 Method command block (body L535–556) and raw-data note (L557–563); §7 opening (L278); §10 opening (L473–475)

Files: docs/reports/sources/horace-experiment.body.html, docs/findings/03-experiments.md

Problem: The 22-line command block copies the acquisition commands already recorded in docs/findings/03-experiments.md (E9–E20). Two of its lines have already drifted from what produced the data (see H-repro-2). The raw-data note says 'their statement that the clock is fixed is corrected in section 6', and the Versions line directly below says the same. Internal lab history repeats: '(the lab's 10-second rule was waived for this)' in §7 duplicates the Method bullet. §10's three-line aifoundry1 driver story ('because its kernel module is built from different sources than the other two while carrying the same management library, and the library's compatibility check refuses them') belongs to the DVFS report §6, its canonical home.


APPLY (CORRECTED): Apply the three cuts as proposed. If the <pre> is replaced, use: `tools/ettelem/finish_horace.sh   # every analysis, the model, the GIFs and both pages from the committed data; no card; needs node and npm install --no-save mathjax-full` and the predict_heat --pattern randn line, followed by the sentence linking the experiment register, sessions E9–E20. If the block is kept instead, apply H-repro-2's three fixes.

Base PROPOSAL (for "as proposed" references): Replace the <pre> block with three lines:
```
tools/ettelem/finish_horace.sh   # every analysis, the model, the GIFs and both pages from the committed data; no card needed
python3 tools/ettelem/predict_heat.py --model docs/reports/data/2026-09-21-horace-aifoundry2/model.json \
    --toggles docs/reports/data/2026-09-21-horace-aifoundry2/toggles_all.json --pattern randn
```
Follow it with: <p class="small">The commands that acquired each session on the card (strict runs, cool starts, long runs, ablations, the second card) are in the <a href="https://github.com/yaroslavvb/et-soc1-prototyping/blob/main/docs/findings/03-experiments.md">experiment register</a>, sessions E9–E20.</p>

Other cuts:
- In the raw-data note, cut ', and their statement that the clock is fixed is corrected in <a href="#the-speed-effect-appears-on-a-cool-die">section 6</a>'.
- In §7, cut ' (the lab's 10-second rule was waived for this)'.
- In §10, replace 'AI Foundry has three machines; aifoundry1's two cards could not be opened at all, because its kernel module is built from different sources than the other two while carrying the same management library, and the library's compatibility check refuses them. aifoundry3's card works' with 'Of AI Foundry's other two machines, aifoundry1's cards cannot be opened (<a href="https://spacesheep.dev/@yaroslavvb/et-soc1-dvfs-leakage#the-same-firmware-on-three-cards">the DVFS report, §6</a>); aifoundry3's card works'.


Verifier note: The three small cuts are right. Raw-data note L560–561 and Versions L564–565 both say the 20 September runs' fixed-clock claim is corrected in section 6. §7's 'lab's 10-second rule was waived' repeats the Method bullet. The aifoundry1 driver story is covered in DVFS §6 (#the-same-firmware-on-three-cards, whose first paragraph is 'aifoundry1 could not be measured'). Replacing the command block with a link to 03-experiments.md is acceptable: E9, E10, E12, E15 and E20 hold the acquisition commands, and other pages already link that GitHub file. But the proposed 3-line block drops what a local rebuild needs. I rebuilt both pages byte-identically here with build-report.py, and it needs node plus mathjax-full.


#### H-red-5 — MODIFIED [redundancy/low] et-soc1-horace-experiment

Where: Top <figure> with horace-heating.gif (body L33–40); §7 <figure> with horace-long.gif (L282–286)

Files: docs/reports/sources/horace-experiment.body.html

Problem: The heating GIF shows five runs each of zeros, ones and random normal. The interactive #cl-temp chart a screen below shows every run of six patterns, with toggles and hover. The long-run GIF shows a subset of what #long-curves shows, and #long-curves adds the model's dashed curves. The two GIFs make the page about 1,000 px longer and duplicate interactive charts. They are repost assets, and their first frame is an empty plot.


APPLY (CORRECTED): Remove only the §7 <figure> (L282–286). Append to the #long-curves title ' To repost: <a href="horace-long.gif">horace-long.gif</a> (0.3 MB).' In L305 change 'in the animation' to 'in the chart below' (the default view shows ones on 1,024 and random normal on 384 minions). Keep the top heating GIF and its caption. Keep publishing all GIF files with every redeploy.

Base PROPOSAL (for "as proposed" references): Remove both <figure> elements. Append to the #cl-temp chart title: ' Animated versions to repost: <a href="horace-heating.gif">horace-heating.gif</a> (three kinds, 0.5 MB), <a href="horace-heating-6.gif">horace-heating-6.gif</a> (six kinds, 0.9 MB).' Append to the #long-curves title: ' To repost: <a href="horace-long.gif">horace-long.gif</a> (0.3 MB).' Keep publishing the GIF files with every redeploy, as PLAN requires.


Verifier note: The evidence overstates the defect. All three GIFs loop forever (loop=0), and the empty first frame lasts 70 ms (630 ms for the long GIF), so readers see the animation, not empty axes. Only a static screenshot catches frame 0. The §7 long GIF sits directly above #long-curves, an interactive superset of it with the model's dashed curves, so removing it is justified. Two things the reviewer missed. First, the §7 bullet at L305 refers to that GIF ('with curves that lie on top of each other in the animation'). Second, the top GIF is the page's only lead image, the first visual after the lede, in a run whose owner asked for more compelling visuals. It is redundant with #cl-temp but not harmful.


#### H-reorg-1 — MODIFIED [reorganize/low] et-soc1-horace-experiment

Where: §2 'Strict temperature control' (body L89–117); §8 two-column block with 'A predictor for custom workloads' (L395–402)

Files: docs/reports/sources/horace-experiment.body.html

Problem: The section order follows the lede, but §2 is a 30-line method interlude (burn-in, shuffled blocks, three control checks, de-quantisation) between the result (§1) and its explanation (§3). The predictor paragraph in §8 introduces the tool that §9 then demonstrates. Renumbering sections is not an option: at least 20 inbound references on other pages and in docs/findings cite 'Horace §4/§6/§8/§10' by number.


APPLY (CORRECTED): (a) As proposed, with the summary sentence reading '…and random normal repeated across the hour's five blocks to 0.08 W and 0.03 °C (standard deviations).' Move 'Heating and cooling to the launch point took 12 to 120 s (median 63 s)' into the Method 'Protocol and checks' bullet along with the burn-in and check bullets. (b) As proposed, but replace the last sentence of the moved paragraph with 'The matrices below test it.'

Base PROPOSAL (for "as proposed" references): Keep every h2 text, id and number.

(a) Cut §2 to its first paragraph, the three-step <ol>, and one summary sentence: 'The control held: every sample read 600 MHz and 516–518 mV; at the 46 launches the die was at 80.96 ± 0.11 °C in the sensor's units with 36.29 ± 0.06 W idle, and random normal repeated to 0.1 W and 0.07 °C across the hour's five blocks.' Keep the de-quantisation paragraph (L114–117), which §1 and §4 reference. Move 'Four burn-in cycles come first … in 58 minutes.' and the three 'checks' bullets into §11 Method as a bullet 'Protocol and checks: …'.

(b) Move the 'A predictor for custom workloads' <p> from the §8 flex block to the top of §9, before 'The point of the model is to price a workload…', and let #cap-sc take the full row.


Verifier note: The idea is sound, and keeping every h2 id and number is right. But the proposed summary sentence mixes statistics: 'random normal repeated to 0.1 W and 0.07 °C' combines a rounded sd for power (block values 63.38–63.49 W, sd 0.084) with the range for the rise (5.10–5.17 °C, range 0.07, sd 0.025). §1 quotes the sd form (0.08 W, 0.03 °C). The summary also drops the approach-time fact (12–120 s, median 63 s); move it to Method with the rest. In (b), the predictor paragraph ends 'Section 9 tests it on matrices it had never seen', which becomes self-referential once the paragraph is moved into §9.


#### H-repro-2 — MODIFIED [reproducibility/low] et-soc1-horace-experiment

Where: §11 Method command block (body L542, L544, L547) and §9 predict_heat example (L460–470)

Files: docs/reports/sources/horace-experiment.body.html, tools/ettelem/run_horace_long.sh, tools/ettelem/make_heating_gif.py, tools/ettelem/predict_heat.py

Problem: Three commands on the page do not reproduce what the page shows.
- 'run_horace_long.sh build/horace_long tools/ettelem/horace_long.sched 80 84 90' omits '900 18000 600' (E12); the script's defaults (max_wait 900, deadline 18600, final_idle 900) end the session differently.
- 'make_heating_gif.py horace3.json horace-heating.gif' omits --steps, so it draws dots, while the published GIF and its caption use staircases (finish_horace.sh passes --steps --poster).
- The predict_heat example uses --tiles, which replays through the RTL bench and needs Verilator; the --toggles/--pattern path runs anywhere but prints slightly different numbers.

finish_horace.sh also needs `npm install --no-save mathjax-full`, which the page never mentions.


APPLY (CORRECTED): Apply the L544, L542 and L547 fixes as proposed (or put the mathjax note in H-red-4's replacement block). In §9 add the --pattern line with its note, worded: '--tiles replays the tiles through the RTL bench in rtl-sim/fma_toggle, which must first be built with Verilator (make -C rtl-sim/fma_toggle); --pattern reads the committed counts and prints 74.4 M tree toggles, 141 k operand-word toggles, 2.5 W and 26 s instead (the mean of both seeds).'

Base PROPOSAL (for "as proposed" references): If the block is kept (see H-red-4):
- L544: append ' 900 18000 600' after '80 84 90'.
- L542: change to 'python3 tools/ettelem/make_heating_gif.py horace3.json horace-heating.gif --poster horace-heating.png --steps'.
- L547 comment: '# analyses, model, GIFs, both reports; no card; needs npm install --no-save mathjax-full; the RTL replays need Verilator and are skipped while toggles.json exists'.

In §9, after the --tiles line of the <pre>, add:
```
$ python3 tools/ettelem/predict_heat.py --model …/model.json --toggles …/toggles_all.json --pattern kaleidoscope   # no Verilator: the committed counts
```
Add to the small note: '--tiles replays the tiles through rtl-sim/fma_toggle (Verilator); --pattern reads the committed counts and prints 74.4 M tree toggles, 141 k operand-word toggles, 2.5 W and 26 s instead (mean of both seeds).'


Verifier note: The first two points are right. E12's command has '900 18000 600', while the script's defaults are 900/18600/900. make_heating_gif.py draws dots unless --steps is given, and finish_horace.sh passes --steps --poster. build-report.py does need mathjax-full. The third point is only partly right. I ran make_tiles.py kaleidoscope and predict_heat.py --tiles on this machine and it reproduced the page's transcript exactly (74.3 M, 13.27 M, 140 k, 2.4 W, 27 s), because rtl-sim/fma_toggle/obj_dir is already built here. On a fresh clone obj_dir is gitignored, so --tiles needs Verilator to build the bench, not to run it. predict_heat.py --pattern kaleidoscope prints 74.4 M, 141 k, 2.5 W and 26 s, as the reviewer says.


#### H-repro-3 — CONFIRMED [reproducibility/low] et-soc1-horace-experiment

Where: tools/ettelem/finish_horace.sh L45 and L49; tools/ettelem/build_horace_report_data.py L101–109; tools/ettelem/analyze_horace_strict.py L316; data README row 'long2/, long2.json, model2.json'

Files: tools/ettelem/finish_horace.sh, tools/ettelem/build_horace_report_data.py, tools/ettelem/analyze_horace_strict.py, docs/reports/data/2026-09-21-horace-aifoundry2/README.md

Problem: finish_horace.sh runs flip_thermal_model.py --evaluate on long2 (model2.json/.txt) and merges it into report.json as structured_long, but no page or script reads it. Its non-causal predictions compete with the causal validation_afternoon.json that §9 shows (negzero 102.3 against 113.5 s, relu 59.0 against 62.6, DFT 106.3 against 116.2). The README still calls model2.json 'the model evaluated on them'. report.json also stores the pre-registered predictions twice: top-level 'before' (used by the page) and power_model.before (set by analyze_horace_strict.py L316).


APPLY (PROPOSAL): Delete finish_horace.sh L45 (the `flip_thermal_model.py "$D/long2" --evaluate … model2.json` line) and drop `--long2 "$D/long2.json" --model2 "$D/model2.json"` from L49. Remove the structured_long block (build_horace_report_data.py L101–109) and add `out["power_model"].pop("before", None)` after the power_model copy. Change the README row to '`long2/`, `long2.json`: long validation runs of the structured matrices (tested causally in `validation_afternoon*.json`; `model2.json` is a superseded non-causal evaluation)', or delete model2.*. Rebuild; the page output does not change.


Verifier note: No file in docs/reports/sources reads structured_long, and no findings page mentions model2. Only the data README does. In report.json, 'before' equals power_model.before (1,018 bytes each), and the page reads only D.before. Removing the model2 step and the structured_long block, and popping power_model.before, leaves the page unchanged. The README row should stop calling model2.json 'the model evaluated on them', since validation_afternoon.json is the causal test the page shows.


#### H-viz-1 — MODIFIED [visualization/medium] et-soc1-horace-experiment

Where: New panel in §9 after the #struct-long discussion, replacing the static predict_heat output transcript (keep the command lines); linked to §8's #budget chart

Files: docs/reports/sources/horace-experiment.body.html, docs/reports/sources/horace-experiment.script.js, tools/ettelem/predict_heat.py, docs/reports/data/2026-09-21-horace-aifoundry2/report.json

Problem: The page's stated point, 'price a workload before running it' (§8, §9), is shown only as a static terminal transcript for one matrix. The reader cannot ask what 512 minions of the DFT pair, or ones in a 26 °C room, would do, although every coefficient needed is embedded in the page.


APPLY (CORRECTED): Build the pricer as proposed, below the §9 transcript rather than replacing it. Add a fixed accuracy line under the readout: 'On held-out runs: time to 90 °C 9% median error, 23% worst; ten-minute end temperatures 3–5 °C too hot near the budget; from a generic idle start it runs slow when the heatsink was left hot by the run before (§7).' For structured kinds, overlay the afternoon session's measured time to 90 °C as a marker (no trace exists). Label the ambient slider 'room and airflow (model ambient)'.

Base PROPOSAL (for "as proposed" references): 'Price a workload: flips → watts → degrees'. It answers 'what will this workload draw, and how long until 90 °C?'.

Data, all in the page's D (report.json):
- D.model.power {P_fix, A_leak_at_80, T_L, e_fJ{ffclk,mult,rest,bus}, p_sm_full_chip}, D.model.taus[9], D.model.R[9], D.model.T_amb.
- Flip counts per op and minion: D.power_model.rows[] (14 patterns, in millions) and D.structured.before.patterns[k].flips (17 structured kinds).
- Overlays: D.long[] (values, minions, sec[], T[]), D.model.per_run[] (long-session curve_pred every 2 s, t_cap_pred), D.validation.afternoon.rows, D.patterns[p].p80, D.structured.measured[k].p80.

Controls, all keyboard-operable:
- <select> of the 31 workloads, grouped 'measured patterns' / 'structured matrices'.
- Range 'active minions' 128–1,024, step 128.
- Range 'launch temperature' 76–84 °C (default 80.9, the protocol's launch state; a tick at 80.0 for predict_heat.py's default).
- Range 'room (model ambient)' 20–28 °C (default 22.8; a tick at 26.3 labelled '22 September').

Encoding:
- Left: a horizontal stacked bar of switching watts by kind of flip plus the state machines, in #stack's colours (var(--c4) clocking, var(--c5) tree, var(--bad) rest, var(--c7) operand words, var(--ref) state machines), with the board total at the launch temperature.
- Right: die temperature against time since launch on a log axis (1–600 s, 76–92 °C), with a 90 °C cap line (var(--bad), dashed) and the predicted curve (var(--ink)).
- When a measured long run exists for that pattern × minion count, its sensor trace (var(--c1), thin staircase) and the fitted-with-history curve (dashed) are drawn too, so the reader sees why the same pattern varies (ones: 107 against 162–167 s).
- Readout: switching W, board W, °C at 10 s, 1 min and 10 min, time to 90 °C or 'settles at X °C', and the duty cycle that holds the start temperature.

Computation: a 20-line port of tools/ettelem/predict_heat.py predict() (dt 0.1 s, fast stages settled at idle, slow stages share the rest). The ambient value also redraws #budget with the page's own pd(t) = (t−Ta)/R_total − P_fix − A·e^((t−80)/T_L).

Layout and reach: panels stack vertically at 390 px, each SVG sits in a .chart.scroll frame, and the markup is inline SVG with vanilla JS.

What changes for the reader: they can test the flip budget, the minion-count effect of §7 and the room dependence of §8 themselves.


Verifier note: The data exists and the port is faithful. I ran the reviewer's pricer_proto.js against report.json: p_switching matches all 17 pre-registered kinds to 0.003 W. From 80.9 °C: kaleidoscope 21.8 s, random normal 22/40/86/148/345 s on 1,024/768/512/384/256 minions. Budget 3.10 W at 22.8 °C ambient and 0.71 W at 26.3 °C. D.power_model.rows, D.structured.before.patterns[k].flips, D.model.{power,taus,R,T_amb,per_run} and D.long[].sec/T are all present. Two changes are needed. First, the generic-history start overestimates slow runs (384 minions: 148 s against 119; 256: 345 against 276–315), and the model runs 3–5 °C hot at ten minutes, so the readout must show the model's measured accuracy or readers will over-trust it. Second, the proposal replaces the predict_heat transcript, but H-repro-2 builds on that transcript, and it is the only record of the CLI's output. For the structured kinds, D.validation.afternoon.rows has no traces, so their overlay is a measured-time marker only.


#### H-viz-2 — MODIFIED [visualization/low] et-soc1-horace-experiment

Where: §3 #stack chart (script L162–172) and §9 #struct chart; replaces #stack and the model columns of #act (H-red-2)

Files: docs/reports/sources/horace-experiment.script.js, docs/reports/sources/horace-experiment.body.html

Problem: §3 splits each strict-session pattern's watts by kind of flip, but §9's 14 structured matrices appear only as predicted-against-measured totals. §9's two central claims, 'structure in the values buys nothing' and 'structure in the zeros buys a lot', therefore cannot be seen term by term. Comparing two patterns ('A ones, B random' draws 3.6 W more than 'A random, B ones' despite fewer tree toggles) means reading numbers off the #act table.


APPLY (CORRECTED): As proposed, with the example computed live and correctly: 'A ones, B random − A random, B ones: +3.6 W measured, +4.1 W modelled (tree −0.7, rest of the unit +3.8, operand words +1.0 W)'. State in the chart title that the bars use section 8's energies (so the strict-session bars differ slightly from #strip's leave-one-out ticks).

Base PROPOSAL (for "as proposed" references): 'Where the watts go, all 31 patterns'. It answers 'which kind of flip makes one operand pattern cost more than another?'.

Data:
- The 14 strict patterns: D.power_model.rows[] (ffclk, mult, rest, bus in M per op) times D.model.power.e_fJ, converted with 1,024·600e6/546 ops/s.
- The 17 structured kinds: D.structured.before.patterns[k].flips with the same energies.
- Measured ticks: D.patterns[p].p80 and D.structured.measured[k].p80.
- Constant: P_fix + leakage at the launch temperature + p_sm_full_chip.

Encoding: horizontal stacked bars sorted by measured W, in #stack's colours, with a black measured tick. Toggle buttons: 'strict-session patterns (fitted)', 'structured matrices (priced before they ran)', 'both'. Clicking a row, or Enter on a focused row, pins it. With two rows pinned, a difference bar underneath gives the per-kind deltas, for example 'A ones, B random − A random, B ones: +3.6 W measured; tree −0.2, rest +2.9, operand words +0.9 W'. Hover gives the raw counts.

What it replaces: #stack. It lets #act drop its model columns and complements §9's #struct. The reader sees Hadamard ≈ random signs (rest-of-unit toggles only), −0.0 ≈ ones (pure clocking) and butterfly ≈ zeros (gated), term by term. Layout: .chart.scroll at 390 px, template tokens only.


Verifier note: The data and the concept hold up: power_model.rows has ffclk/mult/rest/bus for 14 patterns and structured.before.patterns has flips for 17. But the proposal's worked example is wrong. With section 8's energies, 'A ones, B random' minus 'A random, B ones' is tree −0.69 W, rest +3.78 W and operand words +0.96 W, for +4.05 W modelled against +3.64 W measured. §3's fit gives −0.86, +3.71 and +0.78, for +3.63 W. It is not 'tree −0.2, rest +2.9, operand words +0.9'. The equivalences hold: Hadamard is clocking 8.83 plus rest 2.76 W against random signs' 8.83 plus 4.15 W (50.1 against 51.4 W measured). −0.0 matches ones (8.83 W of clocking only). Butterfly is near zeros (39.3 against 38.3 W).


#### H-viz-3 — CONFIRMED [visualization/low] et-soc1-horace-experiment

Where: §10 #cardsw chart (script L290–304) and #scaletext

Files: docs/reports/sources/horace-experiment.script.js

Problem: §10's claim, 'multiply every flip energy by one number … calibrating on one pattern predicts the others', is stated only as text whose statistic is misdescribed (H-claim-1). The chart shows a fixed dashed model rule, so the reader cannot see how the fit depends on the scale or on the calibration pattern.


APPLY (PROPOSAL): Add controls under #cardsw:
- A range input 'scale on every flip energy', 0.85–1.05, step 0.001, default 1.000.
- Buttons 'calibrate on: zeros / 50% zeroed / ones / π / random sign / random mantissa / uniform / normal', each setting the scale to a3_i/model_i.
- A button 'least squares' that sets 0.924.

The dashed rule on each pair becomes scale × model. A residual strip below the bars shows a3 − scale·model per pattern in W, with var(--c2) bars and a var(--grid) zero line. A live readout gives 'rms over all 8: x W; over the other 7: y W; largest single error: z W'.

Data: D.cards.patterns[] (values, model, a2, a3), D.cards.scale, D.cards.loo.per_pattern (as a check).

What the reader gains: pressing 'zeros' shows 0.93 W rms and a 1.53 W miss on normal, and 'normal' shows 0.27 W. That teaches why one random-data run is the right calibration. Keyboard: buttons and range. 390 px: the chart already scrolls in its frame.


Verifier note: Recomputed from cards.patterns. Calibrating on zeros (scale 0.971) gives 0.929 W rms over the other seven, and the largest miss is 1.527 W on normal. Calibrating on normal (0.915) gives 0.275 W. Least squares gives 0.9236 with 0.202 W rms. The controls follow directly from existing data, need no new files, and turn H-claim-1's corrected statistic into something the reader can check. One addition: the best single calibration patterns are uniform and random mantissa (0.218 W), both random data, which supports the 'one random-data run' advice.


#### H-viz-4 — MODIFIED [visualization/low] et-soc1-horace-experiment

Where: #budget (script L255–264), #cap-sc (L211–220), #step (L235–240)

Files: docs/reports/sources/horace-experiment.script.js

Problem: Three existing charts have labelling gaps.
- #budget has no y-axis label (its values are die temperature, 50–100 °C).
- #cap-sc colours its dots by group (red, purple, green, orange, grey) with no legend; the title explains only dots against rings.
- #step's closed-loop curve stops silently at 10 min because later values (7.2 °C/W at 30 min, 11.7 at 1 h) exceed the 4 °C/W axis, so a reader may take the line's end as a plateau.


APPLY (CORRECTED): #budget: add yl:'die temperature, °C'. #cap-sc: add the swatch legend as proposed. #step: txt(svg, W-R, y(ymax)+12, `off scale: ${M.step_closed[1800].toFixed(1)} °C/W at 30 min`, 'lab', 'end'), which takes the value from the data and anchors the label inside the frame.

Base PROPOSAL (for "as proposed" references): - #budget: add yl:'die temperature, °C' to its axes() call.
- #cap-sc: add under its title the same swatch legend that #long-leg builds (reuse LC and the GROUPS labels), plus 'filled: fitted; ring: held out'.
- #step: after the closed-loop path, add txt(svg, x(600)+4, y(ymax)+12, 'off scale: 7.2 °C/W at 30 min', 'lab').


Verifier note: All three gaps are real. The #budget axes() call (L258) has no yl. #cap-sc colours by LC() groups with no legend. In #step, ymax = min(4, …) filters out step_closed 1800 (7.22) and 3600 (11.69), so the red line stops at 600 s (3.12). But the proposed #step label is hard-coded, and placed at x(600)+4 ≈ 342 in a 440-wide viewBox a label about 170 px long would be clipped at the right edge.


#### L-claim-1 — CONFIRMED [claim/low] et-soc1-why-low-power

Where: §2, second bullet (body L62)

Files: docs/reports/sources/why-low-power.body.html

Problem: 'this card's minion rail alone reads 22 W under int8 random data at the end of a 7 s run (about 82 °C)'. Both int8 random runs ended at 83 °C.


APPLY (PROPOSAL): Change '(about 82 °C)' to '(about 83 °C)'.


Verifier note: In ablation.json both int8_randn runs have t_end = 83.0 (mean of the last 0.5 s) and t_early 81.95. rails_late (the last 1 s) gives the minion rail as 22.28 and 22.23 W, so 'about 83 °C' is the right label.


#### L-repro-1 — MODIFIED [reproducibility/medium] et-soc1-why-low-power

Where: §3 'Voltage and clock' bullets 1–2 (body L110–118), the #volt chart's 800 MHz points, Method data bullet (L219–222); docs/reports/data/2026-09-21-horace-aifoundry2/vf.json

Files: docs/reports/data/2026-09-21-horace-aifoundry2/vf.json, tools/ettelem/analyze_horace_cold.py, tools/ettelem/finish_horace.sh, docs/reports/sources/why-low-power.body.html, docs/findings/05-claims.md, docs/findings/14-card-behaviour.md

Problem: vf.json is entered by hand, with no producer script and no recorded windows. It feeds the #volt chart's 800 MHz points and the 3.9/1.9, 20.6/10.3, 53/27 W, 2.0× and 35.0 against 28.1 W claims. The 800 MHz loads are the single highest readings before the governor stepped down, while the 600 MHz values are window means. 'idle800' 35.0 W is the 0.6–1 s after the zeros runs' last launch, while the governor still held 800 MHz, not a settled idle. The random-data peak is 87.6 W here (cold1 run 1) but 87.8 W in 05-claims and 14-card-behaviour (cold2 run 0).


APPLY (CORRECTED): Add tools/ettelem/build_vf.py --cold cold1 cold2 --ablation ablation.json --out vf.json and call it in finish_horace.sh before build_lowpower_report_data.py. Its rules:
- X800 = max board_w from the first 800 MHz sample of run X to 0.3 s after the last one (board power lags the clock field), max over both sessions, which gives 87.8 W for random data.
- idle800 = mean board_w over the samples after a zeros run's last launch while mhz == 800, skipping the first 0.1 s.
- idle600 = mean over 0.5–2.5 s after each run's last launch at 600 MHz.
- X600 = mean over seconds 2–7 at 600 MHz.
- zeros600_dyn = ablation fp32_zeros dyn, labelled as the 80 °C value.
Use 87.8 W on every page. Use the proposed Method text, plus: 'the 600 MHz zeros figure is from the 80 °C runs, since from a cool die zeros stayed at 800 MHz'.

Base PROPOSAL (for "as proposed" references): Add `--vf OUT` to tools/ettelem/analyze_horace_cold.py, writing vf.json from cold1 and cold2 with the windows stated in its 'note':
- idle600: mean board_w 0.5–2.5 s after each run's last launch at 600 MHz, 64–66 °C.
- idle800: mean board_w after the last launch while mhz == 800.
- X800: max board_w while mhz == 800 during run X (max over both sessions).
- X600: mean board_w over seconds 2–7 at 600 MHz.

Call it in finish_horace.sh before build_lowpower_report_data.py. Use one peak value on every page (87.8 W, the max over both sessions; 'about 53 W' is unchanged).

On the page, replace the Method text '<code>vf.json</code> (the 600 against 800 MHz runs)' with '<code>vf.json</code> (the 600 against 800 MHz operating points from the cool-start telemetry in <code>cold1/</code> and <code>cold2/</code>: the 800 MHz loads are the highest single readings before the governor stepped down, and idle at 800 MHz is the second after the zeros runs' last launch, while the governor still held 800 MHz)'.


Verifier note: vf.json has no producer; only finish_horace.sh and build_lowpower_report_data.py read it. It was added by hand in 07f7d04. The peaks disagree across pages: 87.55 W (cold1) here, 87.82 W (cold2) in 05-claims and 14-card-behaviour. But the proposed rule 'X800: max board_w while mhz == 800' fails for random data. Board power refreshes every 133 ms and lags the clock field: while the samples read 800 MHz, board_w still shows the stale 53.35/53.6 W, and 87.55/87.82 appear only in the next samples, which already read 600/700 MHz. The rule would give randn800 = 53.6 W. Also, zeros600_dyn (1.9 W) cannot come from the cool starts, because zeros held 800 MHz for almost the whole run. It is the 80 °C ablation's fp32_zeros dyn (1.912). A separate script also fits better than a flag on analyze_horace_cold.py, which takes one session.


#### L-consistency-1 — CONFIRMED [consistency/low] et-soc1-why-low-power

Where: §3 'Gating follows the data' (body L92) and Caveats bullet 2 (L191), against Horace §1 (horace body L74–75, L84)

Files: docs/reports/sources/why-low-power.body.html

Problem: The two pages report the same quantities from different 21 September sessions and neither says so. Over idle at 80 °C: 1.9/10.6/27.6 W here (ablation, 63.9 W random fp32) against 2.0/10.5/27.1 W in Horace (strict session, 63.4 W). Random-data watts late in the run: 29.5 W here, 29.6 W in Horace. A reader who checks one page against the other finds half-watt disagreements with no explanation (D4 records both).


APPLY (PROPOSAL): Append to why-low-power Method bullet 1 ('Every configuration ran twice…'): ' These are the ablation session's values (random fp32 63.9 W at the launch temperature); the Horace experiment's strict session the same day read 0.5 W lower (63.4 W, +27.1 W over idle), and the pages each quote their own session.'


Verifier note: lowpower-report ablation.configs gives fp32 zeros/ones/randn dyn of 1.912/10.562/27.625 W and randn p80 63.93 W. Horace's strict session gives randn p80 63.40 W; the page quotes 2.0/10.5/27.1 W at the launch temperature and 29.6 W against 29.5 W late in the run. Both are correct for their own session. A one-sentence note in Method removes the apparent disagreement.


#### L-red-1 — MODIFIED [redundancy/medium] et-soc1-why-low-power

Where: §1 comparison table (script L71–73, L77) and prose (body L37–45); §4 table Clock row (body L168) and last paragraph (L179–180); Caveats bullet 1 (L188–190)

Files: docs/reports/sources/why-low-power.script.js, docs/reports/sources/why-low-power.body.html

Problem: The per-FLOP verdict (5.4× against fp32, 2.6× against fp16, 2.9× against the CUDA cores) appears in the lede, KPI 5, the 'Energy per FLOP, board' note, both §1 paragraphs, the §4 table and the §4 closing paragraph. The A100 clock reasoning (1,410 MHz boost, at least 1,160, probably near 1,230) is written out in the §1 table note, again in the §4 Clock row, and a third time in Caveats. The last §4 paragraph restates the one directly above it. 'Dense matmul, 16-bit' repeats the A100 cell '257 TFLOPS bf16 at 330 W' of the row above.


APPLY (CORRECTED): Apply (a), (b) and (c) as proposed. In (d), cut 'Against the A100 it switches a comparable amount of capacitance every cycle. It does so at a third of the V² and at 43–52% of the clock, which is the 5–6× of the headline,' but keep one sentence: 'Everything idle is clock-gated to nearly no switching power.' Then continue with 'What it does not have is efficiency per FLOP…'.

Base PROPOSAL (for "as proposed" references): (a) In script L73, replace the 'Energy per FLOP, board' note template with: 'A100 bf16 tensor cores against fp32 and fp16 here; the fp32 CUDA-core comparison follows the table'.

(b) Merge L71–72 into one row: row('Dense matmul, measured', `${A.tflops} TFLOPS bf16 at ${A.watts} W`, `${f2(E.tflops)} TFLOPS fp32 at ${f1(E.watts)} W<br>${f1(tf16)} TFLOPS fp16 at ${f1(h16.p80)} W`, 'A100: Horace He’s 8192³ bf16 run on random data at a 330 W limit. ET: TensorFMA on random data, board power at 80 °C; fp16 and bf16 are different formats').

(c) In body L168, replace the Clock note with: 'cycle counter against wall clock here, 546 cycles per op for every data pattern; the A100's range is explained in section 1's table; the per-FLOP rows below do not depend on the clock'.

(d) In L179–180, cut 'Against the A100 it switches a comparable amount of capacitance every cycle. It does so at a third of the V² and at 43–52% of the clock, which is the 5–6× of the headline, and everything idle is clock-gated to nearly no switching power.' and start the paragraph at 'What it does not have is efficiency per FLOP…'.


Verifier note: The repetition is real. 5.4×, 2.6× and 2.9× appear in the §1 table note and again in both §1 paragraphs. The A100 clock reasoning is written out in the §1 table, in the §4 Clock row and in Caveats. L179–180 restates L176–178 (V² 2.7×, clock 43–52% / 2.35×, 5–6×). Merging the 16-bit row is fine. But cut (d) also removes 'everything idle is clock-gated to nearly no switching power', which is one of the three parts of the lede's answer and the only place the synthesis section states it.


#### L-red-2 — CONFIRMED [redundancy/low] et-soc1-why-low-power

Where: §3 'Memory' bullets 1–3 (body L144–154)

Files: docs/reports/sources/why-low-power.body.html

Problem: Energy per byte is not a term of P = C·V²·f + leakage, and its canonical home is the energy manual §4 (D7). Three bullets restate the energy manual's 122 / 91–129 / 2.5 pJ/B at length, and bullet 3 ('The figures in this section come from two 7 s strict-start runs … the energy manual, section 4, has the later measurements…') repeats bullet 1's pointer to the same page.


APPLY (PROPOSAL): Replace bullets 1–3 with one bullet: 'Moving data costs power too: a TensorLoad stream from LPDDR4x at 75.5 GB/s (63% of the 119 GB/s these cards' DDR clock allows) adds 10.7 W, 142 pJ per byte on a never-written buffer, and from the shire's own L2 at 2.45 TB/s 6.2 W, 2.6 pJ per byte (two 7 s runs each at 80 °C). The <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-energy-manual#bytes-through-the-memory-hierarchy">energy manual, §4</a> has the per-level values with bars on two cards (DRAM 122 pJ/B at a pinned 600 MHz; 91–129 pJ/B on known data).' Keep the A100 bandwidth bullet.


Verifier note: I checked the numbers against ablation.json and the energy manual. tload_dram: 75.5 GB/s, +10.71 W, 141.8 pJ/B. tload_l2: 2.45 TB/s, +6.24 W, 2.55 pJ/B. The energy manual §4.2 has DRAM 122.0 [116.8–129.0] pJ/B and states 'Three passes on each card at a pinned 600 MHz'. §4.1 has zeros 91 and random 129 pJ/B. The #bytes-through-the-memory-hierarchy anchor exists. The merged bullet keeps every number a reader needs. Optionally keep '(end to end: DRAM, PHY, controller, mesh and cache fills)' after 142 pJ per byte, since it says what the figure includes.


#### L-red-3 — MODIFIED [redundancy/low] et-soc1-why-low-power

Where: §3 'Voltage and clock' flex block: #leak chart (body L107, script L41–48)

Files: docs/reports/sources/why-low-power.body.html, docs/reports/sources/why-low-power.script.js

Problem: The chart 'Leakage: idle board power against die temperature, with the fitted exponential' plots the same model.power.idle_curve points and the same law as the Horace experiment's §8 #leak chart, which is the canonical home (energy manual §1 tabulates it). It also sits under the 'Voltage and clock' heading, away from 'Leakage and temperature'.


APPLY (CORRECTED): Move the #leak chart from the 'Voltage and clock' flex block to the top of the 'Leakage and temperature' subsection, and let #volt take the full row. Delete it only if L-viz-2 is built and plots PW.idle_curve points (n ≥ 30) against its temperature slider. Add the Horace §8 link in either case.

Base PROPOSAL (for "as proposed" references): Delete the #leak div and its IIFE. In the first 'Leakage and temperature' bullet, after '(the idle law)', add ' (data and fit plotted in <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-horace-experiment#a-model-from-flips-to-temperature">the Horace experiment, §8</a>)'. The temperature slider of L-viz-2 takes over the job of showing how leakage moves with temperature. The #volt chart then takes the full row.


Verifier note: The chart is the same data and law as Horace §8's #leak, and it is misplaced under 'Voltage and clock'. But leakage is a headline claim of this page (the lede and KPI 3: 23 W at 80 °C, 'the largest single item'), and this is the only chart on the page that shows the measured idle points behind it. Deleting it leaves that claim to a link, unless L-viz-2 ships with the measured idle curve on its temperature axis.


#### L-reorg-1 — CONFIRMED [reorganize/medium] et-soc1-why-low-power

Where: h2 order: 1 The comparison, 2 Esperanto's equation measured, 3 Taking the terms away (#ablations), 4 Putting the terms together, 5 Caveats, 6 Method, 7 Related

Files: docs/reports/sources/why-low-power.body.html

Problem: The page asks 'why is it low power?', and the comparison table poses the puzzle: a fifth of the power, yet worse per FLOP. The answer, the factor split 8.8× = V² 2.7 × clock 1.9–2.35 × capacitance 1.4–1.7, only arrives in §4, after about four screens of per-term evidence. No other page cites this page's section numbers; the only inbound anchor is #ablations.


APPLY (PROPOSAL): Reorder the h2s, keeping their texts so the auto-ids stay: 1. The comparison (#the-comparison); 2. Putting the terms together (#putting-the-terms-together); 3. Esperanto's equation, measured (#esperanto-s-equation-measured); 4. Taking the terms away one at a time (#ablations); 5. Caveats; 6. Method and sources; 7. Related reports.

In the moved section's first paragraph, link the measured inputs forward: '27.6 W at 0.52 V and 600 MHz' → '27.6 W (<a href="#ablations">section 4</a>)'. In its table, the 'linear in active cores' and 'the 0.62 V point costs 1.5× per op' notes get '(section 4)'. Renumber the h2 prefixes.


Verifier note: The h2 ids come from the template's slug(), which strips the leading number. Reordering and renumbering therefore keeps #the-comparison, #putting-the-terms-together, #esperanto-s-equation-measured and #ablations. No page or findings file cites this page by section number. The answer-first order suits a page titled as a question. Besides the proposed forward links, the moved section's second paragraph needs one more: 'the arithmetic is 19 times cheaper than fp32' → '… (<a href="#ablations">section 4</a>)'.


#### L-viz-1 — CONFIRMED [visualization/medium] et-soc1-why-low-power

Where: New chart at the top of 'Putting the terms together' (moved to §2 by L-reorg-1), above the static table; complements the table and KPI 1

Files: docs/reports/sources/why-low-power.body.html, docs/reports/sources/why-low-power.script.js, docs/reports/data/2026-09-21-horace-aifoundry2/lowpower-report.json

Problem: The page's main result, how the 8.8× lower switching power splits into voltage, clock and capacitance, rests on two A100 inputs nobody has measured: core voltage (assumed 0.85 V; 0.75–0.95 gives V² 2.1–3.3×) and clock under the 330 W cap (1,160–1,410 MHz). The static table can show only the endpoints, so the reader cannot see that the capacitance factor absorbs whatever V and f do not explain.


APPLY (PROPOSAL): 'From 242 W to 27.6 W: the factors'. It answers 'how much of the lower power is operating point and how much is doing less?'.

Data:
- D.facts.a100 {watts 330, idle 88, tflops 257, volts 0.85, mhz 1410}.
- D.facts.et {tflops, watts, volts 0.52, mhz 600}.
- D.ablation.configs.fp32_randn {dyn 27.6, per_s} and fp16_randn {dyn 24.8, per_s}.
- The script's V = 0.517 and F = 600e6.

Controls:
- Range 'A100 core voltage' 0.75–0.95 V, step 0.01, default 0.85.
- Range 'A100 clock under the 330 W cap' 1,160–1,410 MHz, default 1,230, with labelled ticks at 1,160 ('257/312 of peak') and 1,410 ('max boost').
- Buttons 'this card: fp32 / fp16'.

Encoding: a horizontal log-scale waterfall from the A100's 242 W of switching through '÷ V² ratio', '÷ clock ratio' and '÷ capacitance ratio' down to this card's 27.6 W (24.8 W in fp16). Segments are var(--c1), var(--c2), var(--c3), and the endpoints are var(--ink) bars. Because both endpoints are measured, the capacitance segment is computed as the remainder. A second, per-FLOP row below shows switching pJ per FLOP (0.94 against 3.0 / 1.35), then the idle floor added, then board pJ per FLOP (1.28 against 7.0 / 3.3).

The live readout is the table's rows, so text and chart cannot drift. It is inline SVG with range inputs, in a .chart.scroll frame at 390 px.

What the reader gains: the headline's '5–6×' and the caveat 'A100 voltage is an assumption' become visible, and the capacitance factor moves from 1.27 to 2.03 across plausible V and f.


Verifier note: I recomputed the arithmetic. 242/(0.85²·1.41e9) = 237.6 nF, and 27.6/(0.517²·6e8) = 172.1 nF, a ratio of 1.38. At 1,160 MHz: 288.8 nF (1.68). At 0.75 V and 1,230 MHz: V² ratio 2.10, C 349.8 nF (2.03). At 0.95 V and 1,230 MHz: 3.38 and 218 nF (1.27). The per-FLOP values check out: 0.94 against 3.0/1.35 pJ switching, 1.28 against 7.0/3.3 pJ at the board. Every input is in lowpower-report.json (facts.a100, facts.et, ablation.configs fp32_randn/fp16_randn). Computing capacitance as the remainder between two measured endpoints is honest, provided it is labelled that way. Note that facts.et.volts is 0.52 while the script uses V = 0.517. Use 0.517 throughout so the chart matches the table's 0.27 V².


#### L-viz-2 — MODIFIED [visualization/medium] et-soc1-why-low-power

Where: §3 'Taking the terms away one at a time': replaces the static five-state #stack chart (script L10–20) and the #leak chart (L-red-3); complements #cdyn and #volt

Files: docs/reports/sources/why-low-power.body.html, docs/reports/sources/why-low-power.script.js, docs/reports/data/2026-09-21-horace-aifoundry2/lowpower-report.json, docs/reports/data/2026-09-21-horace-aifoundry2/vf.json

Problem: The page measures each term of P = C·V²·f + leakage, but presents it as five fixed bars at 80 °C and 0.52 V, 600 MHz. Its most instructive checks are only prose: V²f predicting the 800 MHz points, 'idle pays for voltage too', and 175 W at a GPU's operating point.


APPLY (CORRECTED): Build it as proposed, with these changes.
- Between 0.517 and 0.618 V, show the board total, with leakage from the idle law plus the measured 0.62 V idle offset, interpolated.
- Outside that range, show switching only. Draw leakage as a hatched 'not measured at this voltage' segment of unknown length and replace the board-W readout with 'switching W (leakage not measured here)'. The 175 W preset then reads correctly as 'before leakage'.
- For the TensorFMA workloads, split the switching segment into state machines, register clocking and data toggles from D.flips and PW.e_fJ (scaled by V²f), in #stack's colours, so the viz fully replaces #stack.
- If #leak is removed (L-red-3), plot the idle_curve points against the temperature slider.

Base PROPOSAL (for "as proposed" references): 'Esperanto's equation on this card'. It answers 'what does each term contribute at a given voltage, clock and temperature?'.

Data:
- D.ablation.configs[*] {dyn, per_s, unit, minions}, giving C_dyn per minion = dyn/(1,024·V²·F) as the script's cd() already computes.
- D.model.power {P_fix, A_leak_at_80, T_L}.
- D.vf {points at 0.618 V/800 MHz, idle600, idle800}.

Controls:
- Workload buttons: idle, integer loop, fp32 zeros/ones/random, fp16 random, int8 random, TensorLoad L2, TensorLoad DRAM.
- Range 'core voltage' 0.40–0.90 V, with labelled ticks at 0.425 (Esperanto's target), 0.517/0.568/0.618 (this card's points) and 0.85 (A100).
- Range 'clock' 400–1,410 MHz.
- Range 'die temperature' 50–90 °C.
- Range 'active minions' 0–1,024.
- A toggle 'idle at 0.62 V as measured (35.0 W at 65 °C)'.

Encoding: one stacked bar: fixed 12.6 W in var(--ref); leakage from the idle law at T in var(--c2), hatched when V ≠ 0.517 V because leakage's voltage dependence was measured at one point only; switching = C_dyn·(active/1,024)·V²·f in var(--bad). Measured markers sit on the same axis: the ablation p80 at 0.517 V/600 MHz, and vf.json's 38.9/55.6/87.6 W at 0.618 V/800 MHz. Readouts: board W, mW per minion against Esperanto's 10 mW, pJ per operation.

It is keyboard-operable (buttons and ranges), fits 390 px by stacking, uses template tokens only, and needs no library.

What the reader gains: at 0.618 V and 800 MHz, the reader sees switching scale 1.905× as V²f predicts. With leakage held at the 0.52 V law the totals fall 7 W short. The toggle closes the gap, which is exactly the page's 'idle pays for voltage too'. Presets reproduce the 175 W extrapolation and the 10 mW target.


Verifier note: The anchor numbers reproduce. Idle at 65 °C by the 0.52 V law is 27.97 W. V²f scales by 1.905, giving 3.6/20.1/52.6 W of switching and totals of 31.6/48.1/80.6 W against the measured 38.9/55.6/87.6. With the measured 35.0 W idle the totals become 38.6/55.1/87.6. Two parts would mislead or lose information. First, a 0.40–0.90 V, up-to-1,410 MHz slider that shows a board total with leakage from the 0.52 V law understates the total far outside the one measured voltage step (0.52 → 0.62 V). Hatching alone does not stop readers reading off the total. Second, a single switching segment drops the clocking / data-toggle / state-machine split that the current #stack shows. The 'Activity' bullets ('a constant clocks registers but toggles no data') rely on that split.


#### L-viz-3 — CONFIRMED [visualization/low] et-soc1-why-low-power

Where: §3 #volt chart (script L50–59)

Files: docs/reports/sources/why-low-power.script.js

Problem: The chart overlays Esperanto's modelled chip power (at its own clock and workload) with this card's board power, at 0.517 V/600 MHz/80 °C and at 0.618 V/800 MHz/64–66 °C. The same colours are used at both voltages, and the only legend text is 'this card, measured'. The 87.6 W point is a single reading taken as the governor stepped down, not a sustained value.


APPLY (PROPOSAL): Draw the 0.517 V points filled and the 0.618 V points as rings (stroke = colour, fill var(--surface)). Add a legend row under the chart title with swatches: 'zeros (var(--c1)), ones (var(--c4)), random fp32 (var(--bad)); filled: 600 MHz, 80 °C; ring: 800 MHz, 64–66 °C, highest reading before the governor stepped down; dashed grey: Esperanto's model of one chip (Hot Chips 33)'. Label the 87.6 W ring 'peak, ≤0.3 s'.


Verifier note: The #volt chart concatenates the three 0.517 V points with D.vf.points and colours them identically, with only 'this card, measured' as legend. The raw telemetry confirms the random-data peak is one board-power refresh: 87.55 W in cold1 and 87.82 W in cold2, each in the samples right after the clock field left 800 MHz, and it lasts under 0.3 s. Rings for 800 MHz, a swatch legend, and a 'peak, ≤0.3 s' label fix this. If L-repro-1 changes the value, draw the ring at 87.8 W.


### Missed by the reviewers (found by the verifiers)


#### M-hl-1 [consistency] et-soc1-horace-experiment

Problem: The §7 bullet 'Equal flip power, equal curve' (body L305) ends 'with curves that lie on top of each other in the animation'. That refers to horace-long.gif, so it breaks if H-red-5 removes the §7 figure.

APPLY: Change 'in the animation' to 'in the chart below'. The #long-curves default view (groups 'main' and 'fewer') shows ones on 1,024 minions and random normal on 384 together.


#### M-hl-2 [claim] et-soc1-why-low-power

Problem: §3 'Voltage and clock', bullet 1: 'The same kernels at nearly the same temperature (64 to 68 °C) draw, over idle: zeros 3.9 against 1.9 W…'. The 1.9 W (vf.json zeros600_dyn) is the 80 °C ablation's fp32_zeros value (1.912 W). From a cool die, zeros held 800 MHz for almost the whole run, so no 600 MHz zeros window exists at 64–68 °C.

APPLY: Change to '…draw, over idle: zeros 3.9 against 1.9 W (the 600 MHz zeros figure from the 80 °C runs, since from a cool die zeros never left 800 MHz for long), ones 20.6 against 10.3 W, random fp32 about 53 against 27 W.'


#### M-hl-3 [claim] et-soc1-horace-experiment

Problem: The lede says 'at ten minutes it runs 3 to 5 °C hot'. On the held-out ten-minute runs the error is +3.7, +4.1, +3.6 and +5.2 °C for the runs near the flip budget, but +0.7 °C for zeros. The body (L381) qualifies this with 'on the low-power runs'; the lede does not.

APPLY: Change the lede to 'at ten minutes it runs 3 to 5 °C hot on workloads near the card's flip budget'.


#### M-hl-4 [reproducibility] et-soc1-horace-experiment

Problem: This is a positive result of the local run, for the record. Several pipelines regenerate the committed files exactly. build-report.py rebuilds both committed pages byte-identically. build_lowpower_report_data.py reproduces lowpower-report.json, and analyze_ablation.py reproduces ablation.json. analyze_horace_strict.py and compare_cards.py reproduce aifoundry3's horace3.json and cards.json. make_tiles.py plus predict_heat.py --tiles reproduce §9's transcript. So the pipeline behind these two pages is sound; the only producers missing are transfer_cards.py and vf.json's (H-repro-1, L-repro-1).

APPLY: No page change. After adding transfer_cards.py and build_vf.py, run finish_horace.sh once and confirm that report.json and lowpower-report.json are unchanged, apart from the values deliberately changed (+0.69 W and 87.8 W).



## Group dvfs


### Reproduction problems


#### R-dvfs-1 [medium] tools/ettelem/analyze_dvfs.py

Problem: wakeup() applies the hpmcounter3 late-carry correction to results the kernel has already corrected, so 7 of 800 latencies get a spurious +128 cycles.

Evidence: workloads/memprobe/kernel/memprobe.c tload() stores fixcyc(t1) − fixcyc(t0) (lines 31–33, 53–57; present since 76085a3 on 20 Sep, before the 22 Sep data), and gen_ops.py wakeup uses p.tload (OP_TLOAD). analyze_dvfs.py line 119 then applies `fix = lambda x: x + 128 if (x & 0x7F) < 11 else x` to those differences. DRAM rep 14 raw [313, 251, 262, 262, 262, 262, 263, 262] becomes [313, 251, 390, 390, 390, 390, 391, 390]; DRAM rep 11's no-idle 265 becomes 393. Paired medians are unchanged (DRAM +10.5, L2 −11, others 0), but DRAM median_cycles in dvfs.json change from [311, 312.5, 312, 311, 311.5, 312, 311, 313] to [307, 312.5, 311.5, 310.5, 310.5, 310.5, 310.5, 312]. The paired DRAM differences become 13 at +9 to +14, six within 6 cycles and one outlier (−51), not '12 … and two are outliers' as §3 says (body.html line 156). The '−114' and '+77' outliers are artefacts of the double correction. memprobe/analyze.py applies the same fix only to raw counter pairs, which is correct.

Fix: In wakeup(), drop the host-side fix (use the values as stored) and regenerate dvfs.json with the page's reproduce block. Change body.html line 156 to '13 of the 20 paired differences are +9 to +14 cycles, six are within 6 cycles of zero and one is an outlier', and mirror that in docs/findings/16-dvfs-and-leakage.md if it gives the counts. Rebuild the page; no chart changes, because it plots paired_median_by_idle.


#### R-dvfs-2 [medium] docs/reports/sources/dvfs-leakage.body.html

Problem: The idle leakage share at 80 °C is 65% on the page but 64% in the data field and knowledge-base rows that are cited for it. Round 2 switched the page to the idle law's value but did not change analyze_dvfs.py or the findings.

Evidence: body.html lines 11 and 190 say '65% of an idle one/card at 80 °C'. script.js line 122 computes A_at_80/(P_fix+A_at_80) = 0.648 itself instead of reading the data. dvfs.json leak_fraction.idle_80c = 0.6404 (A over the measured 36.32 W ablation idle). docs/findings/05-claims.md line 177 gives '64%' with source 'DATA2/dvfs.json → leak_fraction'; 16-dvfs-and-leakage.md lines 24 and 145 say 64%; PLAN.md D3 says 64%. round2-results.json.gz asked to set idle_80c = 0.648 in dvfs.json, and that was never done.

Fix: In analyze_dvfs.py set leak_fraction.idle_80c = pw['A_leak_at_80']/(pw['P_fix']+pw['A_leak_at_80']) and regenerate. Make script.js line 122 print D.leak_fraction.idle_80c. Change 05-claims.md line 177 and 16-dvfs-and-leakage.md lines 24 and 145 to '65% (of the idle law's 35.9 W)'.


#### R-dvfs-3 [medium] docs/getting-started.md

Problem: The DVFS rebuild recipe leaves out the build_cards_data.py --merge step, so following it gives a page whose §6–§7 are silently empty.

Evidence: The DVFS row (line ~319) says: analyze_dvfs.py … --out dvfs.json, then scripts/build-report.py dvfs-leakage dvfs.json HTML. Building from the pre-merge dvfs.json gives a 175,680-byte page on which check_page.sh reports PROBLEMS empty=['spcount', 'cardswcap', 'scaletext'] at 1280 and 390 px, with no JS error. The cards table and chart are missing too. The page's own reproduce block has the correct three-step chain.

Fix: Replace the row's command with the page's chain: analyze_dvfs.py (full arguments), then build_cards_data.py … --merge dvfs.json, then build-report.py. Optionally make analyze_dvfs.py keep an existing 'cards' key when it rewrites dvfs.json, or have build-report.py refuse to build dvfs-leakage without D.cards.


#### R-dvfs-4 [low] docs/reports/data/2026-09-22-horace-aifoundry3/leakage_crosscard.json

Problem: No committed script produces this file or transfer.json. Its '+0.73 W mean' is an unweighted mean over four temperature bins, one of which holds only 22 samples.

Evidence: A grep finds no producer, only 9df563e which added the files. I reconstructed both exactly (transfer.json from cards.json; leakage_crosscard.json with idle = 600 MHz samples outside [start−1 s, end+6 s]). mean_offset_W 0.732 = mean of the per-bin offsets +0.908/+0.712/+0.690/+0.618; over samples it is +0.684 W (rms 0.692). The page's leak table row 'mean +0.73', 03-experiments E20 and 05-claims line 200 call it the mean error.

Fix: Commit the derivation (for example --transfer-out/--leak-out in compare_cards.py, using the −1 s/+6 s idle window) so that finish_horace.sh regenerates both files. Label the figure 'mean over the four temperature bins', or switch to the sample-weighted +0.68 W.


#### R-dvfs-5 [low] docs/reports/data/2026-09-21-horace-aifoundry2/vf.json

Problem: vf.json is hand-entered, and no script regenerates it; §5's V²f ratios (2.0 for ones, 2.05 for zeros) rest on it.

Evidence: There is no producer in tools/ or scripts/. Its values match hand readings of cold1 telemetry: idle800 35.0 = the post-run 800 MHz plateaus of 34.5–35.3 W; zeros800 38.9 ≈ 38.91; ones800 55.6 ≈ 55.64. ones600 38.4 against in-run 600 MHz means of 38.23/38.09; idle600 28.1 against 27.61/28.24.

Fix: Add a short script that derives vf.json from cold1/cold2 with explicit sample selections, and call it from finish_horace.sh.


#### R-dvfs-6 [low] docs/reports/sources/dvfs-leakage.script.js

Problem: '0.36 W rms in the median and 1.53 W at worst' reads as a worst-case rms. 1.53 W is actually the largest single held-out error (calibrate on zeros, predict randn); the worst rms is 0.93 W.

Evidence: transfer.json worst = max |error| = 1.5267 (zeros → randn). loo_scale_rms max = 0.9294 (zeros). The same wording is in scaletext (lines 168–169), in horace-experiment.script.js line 316 and in 05-claims line 198.

Fix: Write '0.36 W rms in the median and 0.93 W rms at worst (calibrating on zeros, whose largest single error is 1.53 W)', here and in the Horace page.


#### R-dvfs-7 [low] docs/reports/sources/dvfs-leakage.body.html

Problem: 'random data draws up to 88 W at 800 MHz and 69 W at 700' contradicts the down-step table, which shows a 700→600 step at 87.8 W.

Evidence: dvfs.json transitions: cold2 randn at 1.05 s, 700→600, P 87.8 (the PMIC average still carrying the 800 MHz burst); the 68.9 W is cold1 randn at 1.59 s.

Fix: Write 'up to 88 W at 800 MHz (and still 88 W on the reading taken at 700 MHz, 0.1 s later)', or drop the 700 MHz figure.


#### R-dvfs-8 [low] docs/reports/sources/dvfs-leakage.script.js

Problem: Some values on the page have no committed raw record: the firmware/PMIC versions 1.3.1 / 1.5.0 in the cards table, and the '23 W' at which aifoundry3 reports max_power.

Evidence: config.json holds only TDP, threshold, power state, MHz and mV. The sptrace buffers contain only the request string 'dm_svc_get_firmware_version'. The values appear only in script.js line 130, body.html line 265 and the findings prose.

Fix: Commit the ettelem config/version output (and the board power at that read) into docs/reports/data/2026-09-22-cards/, and have script.js read it.


#### R-dvfs-9 [low] scripts/build-report.py

Problem: The rebuild depends on an unpinned, uncommitted mathjax-full. Byte-identical output was reproduced only with the 3.2.1 copy in the main checkout's untracked node_modules.

Evidence: The repo has no package.json. build-report.py's docstring says `npm install --no-save mathjax-full` (latest version). The page embeds 9 SVG equations whose markup depends on the MathJax version.

Fix: Add a package.json pinning mathjax-full 3.2.1, or record the version in build-report.py's docstring.


#### R-dvfs-10 [low] docs/findings/16-dvfs-and-leakage.md

Problem: It still says 'about 96 I2C reads' per pass, which the page's review dropped as unverified.

Evidence: Line 33. fix-results.json.gz for dvfs-2 lists it as skipped: 'I could not verify the count myself'.

Fix: Drop the count, or verify it against thermal_pwr_mgmt.c / dm_task.c and cite that.


### Review findings


#### dvfs-viz-1 — MODIFIED [visualization/high] et-soc1-dvfs-leakage

Where: §2 'The loop as measured': #cycle (body.html lines 79–81, script.js lines 15–49), #trans (body.html line 111, script.js lines 107–110), #attrib (script.js lines 51–65); tools/ettelem/analyze_dvfs.py transitions()/traces()/main()

Files: docs/reports/sources/dvfs-leakage.body.html, docs/reports/sources/dvfs-leakage.script.js, tools/ettelem/analyze_dvfs.py, docs/reports/data/2026-09-22-dvfs-aifoundry2/dvfs.json

Problem: §2's main claim is that a rule with no dead band makes the clock hunt, and that each down-step comes from one of two tests. Today the reader gets one static run (ones) and an 18-row table, and must cross-read both against the §1 pseudo-code. The attribution is never shown acting on the data. dvfs.json already embeds three runs' 10 Hz traces (traces[0] zeros, [1] randn, [2] ones), but script.js draws only the ones run, so the other two are dead data. The chart has no keyboard access. At 390 px its power axis and TDP label sit in the scrolled-off right margin.


APPLY (CORRECTED): Build 'Watch the governor decide' as proposed: the data export, seven run buttons, play/pause with prefers-reduced-motion, a keyboard scrubber, cause-coloured ticks, and #trans moved into <details>. Change these points. (a) Code panel lines follow the 353f20e source: `if T > 65: { if f > 600: step DOWN (thermal) else HOLD (thermal blocks the power tests) } elif P > 65 and f > 600: step DOWN (power) elif P < 65 and f < 800: step UP else hold`, plus 'master minion idle → boot point'. Fix §1's pseudo-code the same way (see missed). (b) At a clock change, evaluate the rule on the last sample before the step and show the at-step sample as secondary. When neither sample predicts the move, say so: 'clock moved; on our 10 Hz samples the rule says hold/other — the SP read between our samples (§8)'. This covers 7 of 36 changes, including one up-step read at 66 °C. (c) Render at the container's pixel width, redrawing on resize, or use a narrow layout (viewBox width ≤ 440, bands stacked, code panel below) under 600 px, so labels stay at 10 px or larger. (d) Drop 'the clock follows a pass later'. Say instead that the step comes zero to a few samples after the reading crosses.

Base PROPOSAL (for "as proposed" references): Replace #cycle and its title with 'Watch the governor decide'. Move #trans into <details><summary>All 18 down-steps as a table</summary>.

DATA
- dvfs.json traces[] (t, mhz, T, P, dur), transitions[] (session, values, t, dir, f0, f1, mv0, mv1, T, P, why), thresholds.temp_c / tdp_w.
- Export all seven runs. In analyze_dvfs.py transitions(), write `for k, proc in enumerate(procs):` and add "proc": k to each osc entry. In main(), write `"traces": traces(a.cold, {(o["session"], o["values"], o["proc"]) for o in osc})`. In traces(), add "mv": [int(x) for x in mv[sel]] (read die_mv as transitions() does). This adds about 12 KB.
- Until the data is regenerated, the chart works on the 3 embedded runs (runs 1–3).

CONTROLS
- 7 buttons in a role=radiogroup: '1 zeros', '2 randn', '3 ones', '4 randn', '5 zeros', '6 ones', '7 randn'. Default 3. Numbering as in script.js line 108.
- Play/Pause. Respect prefers-reduced-motion.
- An <input type=range> scrubber over the sample index: ←/→ = one 100 ms sample; PageUp/PageDown = previous/next clock change.

CHART (SVG viewBox 700×400; drop the 'scroll' class so it fits 390 px)
- The same three bands:
  - clock: stairs in var(--c1);
  - die temperature (whole degrees): stairs in var(--c7), with the 65 °C line dashed in var(--bad);
  - board power: var(--c2), with the 65 W line dashed in var(--bad).
- Put all three bands' tick labels on the left.
- Shade the spans where the reading is above 65 °C (var(--c7), opacity 0.10) and where P > 65 W (var(--bad), 0.10). These are the spans where each test fires.
- Draw a tick for every transition in the run, coloured by cause: thermal var(--c7), thermal+power var(--bad), unattributed var(--ref), up-steps var(--c3).

CODE PANEL (beside the chart, below it under 600 px)
- The §1 pseudo-code as five lines.
- At the scrubbed sample, highlight (background var(--grid), 3 px left border var(--c1)) the line the rule selects from the sampled T, P and f:
  - T > 65 and f > 600 → 'step DOWN (thermal)';
  - else P > 65 and f > 600 → 'step DOWN (power)';
  - else P < 65 and f < 800 → 'step UP';
  - else 'hold';
  - t < 0 or t > dur → 'idle: back to the boot point'.
- Readout example: 't 1.11 s · die 66 °C · board 55.9 W · 800→700 MHz (617→579 mV) · the thermal test fires'.
- On an unattributed step: 'clock stepped down, but on this sample neither test fires — the service processor read between our 10 Hz samples (§8)'.

LINKED VIEW
- Clicking or pressing Enter on a dot in the fixed #attrib scatter (see dvfs-viz-scatter) selects its run and moves the scrubber to that step.

WHAT THE READER GAINS
- They watch the missing dead band work: each 65↔66 tick of the reading flips the highlighted line, and the clock follows a pass later.
- The power band reaches 65 W only in the randn runs.
- The seven unattributed steps show visibly as 'clock moved, no test lit'.

Keep the 'It hunts…' paragraph. It turns §1's rules and §2's table into one thing the reader can explore.


Verifier note: The problem is real. script.js line 16 draws only the ones trace, so traces[0] and traces[1] are unused. At 390 px the power labels and the TDP label sit off-screen and the run is cut at about 4.3 s (screenshot checked). The chart has no keyboard access. The design has four flaws. (1) The code panel copies §1's flattened pseudo-code. At et-platform 353f20e (/usr/src/et-platform, thermal_pwr_mgmt.c lines 884–896) the f > f_min check is nested inside the thermal test. Above 65 °C at the floor the loop therefore holds. The reviewer's chain would light 'step UP' at 600 MHz and 66 °C. (2) With the nested rule, the rule applied to the sample at the step matches 25 of the 36 changes; applied to the sample before the step it matches 29. Seven match neither: the six unattributed down-steps other than 5.5 s, plus the cold1 randn up-step at 0.99 s, which reads 66 °C on both samples. The panel's only special case covers unattributed down-steps, so it would show 'step DOWN' or 'hold' while the clock visibly steps up. (3) A 700-wide viewBox scaled to the roughly 358 px content width draws the 12 px labels at about 6 px, which cannot be read on a phone. (4) 'The clock follows a pass later' is not supported, because the lag varies from zero to more than one sample.


#### dvfs-claim-wakeup — CONFIRMED [claim/medium] et-soc1-dvfs-leakage

Where: §3 DRAM bullet, body.html lines 156–157; tools/ettelem/analyze_dvfs.py wakeup() line 119; dvfs.json wakeup.levels[DRAM].median_cycles

Files: tools/ettelem/analyze_dvfs.py, docs/reports/sources/dvfs-leakage.body.html, docs/reports/data/2026-09-22-dvfs-aifoundry2/dvfs.json, workloads/memprobe/kernel/memprobe.c

Problem: analyze_dvfs.py applies the hpmcounter3 late-carry fix (x+128 when the low 7 bits are below 11) to latencies that memprobe.c tload() has already corrected (*dt = fixcyc(t1) − fixcyc(t0)). Seven of 800 results gain a spurious 128 cycles. The paired medians do not change, so no headline number moves. But the page's count is an artefact: '12 of the 20 paired differences are +9 to +14 cycles, six are within 6 cycles of zero and two are outliers'. The −114 and +77 'outliers' come from the double correction. DRAM median_cycles in dvfs.json are also wrong.


APPLY (PROPOSAL): In tools/ettelem/analyze_dvfs.py wakeup(), delete line 119 (`fix = lambda x: x + 128 if (x & 0x7F) < 11 else x`). Use the stored value in lines 123–124 (`by[(l[1], l[2])].append(x)`, `per[(l[1], l[3])][l[2]] = x`) and add a comment: '# memprobe.c tload() already stores fixcyc(t1) − fixcyc(t0); do not correct again'.

Regenerate with the page's §8 chain (analyze_dvfs.py, then build_cards_data.py --merge), then rebuild.

In body.html lines 156–157, replace 'Here 12 of the 20 paired differences are +9 to +14 cycles, six are within 6 cycles of zero and two are outliers.' with 'Here 13 of the 20 paired differences are +9 to +14 cycles, six are within 6 cycles of zero and one is an outlier (−51 cycles).'

The #wake chart is unchanged, because it plots paired_median_by_idle.


Verifier note: Reproduced from wakeup.u32 and wakeup.json. The host fix changes 7 of 800 values, all DRAM: repeat 11's no-idle load goes 265→393, and repeat 14's six idle loads go 262–263→390–391. memprobe.c already applied fixcyc inside tload at 76085a3 (20 Sep), before the 22 Sep run, and memprobe/analyze.py applies the fix only to raw t_raw counters. Without the host fix, the 27 ms DRAM paired differences are 13 at +9..+14, six within 6 cycles and one at −51. Paired medians are unchanged (DRAM +10.5, L2 −11). DRAM median_cycles become [307, 312.5, 311.5, 310.5, 310.5, 310.5, 310.5, 312], as the reviewer stated. The '12 of the 20' count appears only on this page. One note: L1 repeat 8's no-idle load reads 145 (17+128), a misfire of the kernel's own fixcyc that is unaffected by this fix. 'L1: zero' holds as a median (19 of 20 repeats are exactly 0).


#### dvfs-cons-idle65 — MODIFIED [consistency/medium] et-soc1-dvfs-leakage

Where: Lede (body.html line 11), §4 (line 190), verdict row 5 (script.js line 122); analyze_dvfs.py leak_fraction.idle_80c; docs/findings/05-claims.md line 177; docs/findings/16-dvfs-and-leakage.md lines 24 and 145

Files: tools/ettelem/analyze_dvfs.py, docs/reports/sources/dvfs-leakage.script.js, docs/reports/sources/dvfs-leakage.body.html, docs/findings/05-claims.md, docs/findings/16-dvfs-and-leakage.md

Problem: The page says idle leakage at 80 °C is 65%, computed in script.js from the idle law (23.26/35.89 = 0.648). The data field and the knowledge-base rows cited for it say 64%: dvfs.json leak_fraction.idle_80c = 0.640 (A over the measured 36.32 W ablation idle), and 05-claims and 16-dvfs both give 64%. Round 2 asked for idle_80c = 0.648 in dvfs.json, and that was never applied. A reader who follows the page's claim to its cited source finds a different number.


APPLY (CORRECTED): Keep leak_fraction.idle_80c (measured denominator) and add `"idle_80c_law": A/(P_fix+A)` (0.648) in analyze_dvfs.py. Point script.js line 122 at D.leak_fraction.idle_80c_law. Change 05-claims:177 to '**65%** (23.3 of the idle law's 35.9 W) — `leak_fraction.idle_80c_law`' and 16-dvfs lines 24 and 145 to 65%. Regenerate dvfs.json with the full chain, then rerun build_energy_manual.py and confirm the energy-manual page is byte-identical. The body.html line 190 parenthetical is fine. Record in PLAN D3 that the DVFS page and the knowledge base now use 65%.

Base PROPOSAL (for "as proposed" references): Take the law's value everywhere, as the energy manual does.
- analyze_dvfs.py: set `"idle_80c": pw["A_leak_at_80"] / (pw["P_fix"] + pw["A_leak_at_80"])`, then regenerate.
- script.js line 122: replace `${Math.round(100*D.leak_model.A_at_80/(D.leak_model.P_fix+D.leak_model.A_at_80))}%` with `${Math.round(100*D.leak_fraction.idle_80c)}%`.
- body.html line 190: '65% of an idle card at 80 °C' → '65% of an idle card at 80 °C (23.3 of the idle law's 35.9 W)'.
- 05-claims.md line 177: '**64%**' → '**65%** (23.3 of the idle law's 35.9 W)'.
- 16-dvfs-and-leakage.md lines 24 and 145: '64%' → '65%'.
- Note in PLAN D3 that 65% is now the value used.


Verifier note: The mismatch is real but low severity. PLAN D3 explicitly allows either figure ('The energy manual's 65% (of the law's 35.9 W) is also fine'), and the energy manual already uses 65%. The knowledge-base rows (05-claims:177, 16-dvfs:24,145) and dvfs.json leak_fraction.idle_80c (0.640 = 23.26/36.32) say 64%. The proposal misses a consumer: tools/ettelem/build_energy_manual.py line 71 copies dv['leak_fraction'] into the energy manual's data. Redefining idle_80c silently changes that data unless it is rebuilt. It also makes idle_80c use the law as denominator while busy_randn_80c keeps a measured one.


#### dvfs-repro-recipe — MODIFIED [reproducibility/medium] et-soc1-dvfs-leakage

Where: docs/getting-started.md line 319 (DVFS row); analyze_dvfs.py main() output; docs/findings/03-experiments.md E18/E19 Method

Files: docs/getting-started.md, docs/reports/sources/dvfs-leakage.script.js, tools/ettelem/analyze_dvfs.py, docs/findings/03-experiments.md

Problem: The documented rebuild is 'analyze_dvfs.py … --out dvfs.json, then scripts/build-report.py dvfs-leakage'. It leaves out build_cards_data.py --merge. Following it builds a page whose §6–§7 are silently empty: check_page flags spcount, cardswcap and scaletext as empty, there is no JS error, and the cards table and chart are missing. analyze_dvfs.py also rewrites dvfs.json without the 'cards' key, so running it after finish_horace.sh silently undoes the merge. The only complete command set is the page's own §8 block, and 03-experiments E18–E19 name only `analyze_dvfs.py --since`.


APPLY (CORRECTED): 1. Replace the getting-started.md line 319 cell with the three-step chain, as proposed. Also list the raw data it reads: 2026-09-21-horace-aifoundry2 (cold1, cold2, long2, model.json, ablation.json) and 2026-09-22-horace-aifoundry3 (cards.json, transfer.json, leakage_crosscard.json). 2. Make the primary fix step 3: analyze_dvfs.py carries over an existing 'cards' block when --out already exists. Alternatively, make build-report.py dvfs-leakage exit with an error when the data has no 'cards' key, so the failure shows at build time. Drop the in-page throw, because the page already throws. 3. Fix check_page.sh to inject its error listener immediately after <head> (see missed). 4. Paste the analyze_dvfs.py command into E18 and E19 under Method, as proposed.

Base PROPOSAL (for "as proposed" references): 1. getting-started.md line 319: replace the last cell with the page's three-step chain:
`D=docs/reports/data; H=$D/2026-09-21-horace-aifoundry2; A3=$D/2026-09-22-horace-aifoundry3; C=$D/2026-09-22-cards`
`python3 tools/ettelem/analyze_dvfs.py --cold $H/cold1 $H/cold2 --wakeup $D/2026-09-22-dvfs-aifoundry2/wakeup --idle $D/2026-09-22-dvfs-aifoundry2/idle_20h.jsonl.gz --since $H/long2/runs.jsonl.gz --model $H/model.json --ablation $H/ablation.json --sptrace $C/sptrace-aifoundry3.bin --out $D/2026-09-22-dvfs-aifoundry2/dvfs.json`
then `python3 tools/ettelem/build_cards_data.py --cards $A3/cards.json --transfer $A3/transfer.json --leak $A3/leakage_crosscard.json --config $C/config.json --driver $C/driver_config.json --sptrace $C/sptrace-aifoundry3.bin --out $C/cards-report.json --merge $D/2026-09-22-dvfs-aifoundry2/dvfs.json` (required: without it §6–§7 render empty)
then `python3 scripts/build-report.py dvfs-leakage $D/2026-09-22-dvfs-aifoundry2/dvfs.json docs/reports/2026-09-22-dvfs-leakage.html`.
2. Make the failure loud. At the top of the §6–§7 block in dvfs-leakage.script.js (line 129), add `if(!D.cards) throw new Error('dvfs.json has no cards block: run build_cards_data.py --merge');`. check_page.sh then reports a JS error.
3. Optionally, in analyze_dvfs.py main(), keep an existing block: `if os.path.exists(a.out): out.setdefault("cards", json.load(open(a.out)).get("cards"))`. Drop the key if it is None.
4. Paste the analyze_dvfs.py command into 03-experiments E18 and E19 under Method.


Verifier note: The recipe gap is real. I re-ran the page's §8 chain: dvfs.json and the page (178,461 chars) come out byte-identical to the committed files. Building from the pre-merge dvfs.json gives 175,680 chars, and check_page reports spcount, cardswcap and scaletext as empty. The claim that 'there is no JS error' is wrong. With an error listener injected in <head>, the pre-merge page throws `Uncaught TypeError: Cannot read properties of undefined (reading 'config')` at the start of the §6–§7 block (`const C=D.cards,cf=C.config`), and #cardcfg, #cardsw and #leaktab are also empty. check_page.sh misses it because it installs its listener just before </body>, after the page's script has run. Step 2 (add a throw) therefore changes nothing that check_page can see.


#### dvfs-red-s7 — CONFIRMED [redundancy/medium] et-soc1-dvfs-leakage

Where: §7 'What the second card says about the model' (body.html lines 286–316; script.js lines 146–174); §8 bullet 'aifoundry3's session is the same strict protocol…' (lines 354–359)

Files: docs/reports/sources/dvfs-leakage.body.html, docs/reports/sources/dvfs-leakage.script.js, docs/reports/sources/horace-experiment.body.html

Problem: §7 repeats Horace §10 ('A second card, and what transfers') almost word for word, built from the same merged cards block: the same #cardsw chart and title, #cardswcap, #scaletext paragraph, operating-point paragraph, leakage paragraph, #leaktab table and 'consequence for anyone with a shelf of these cards' paragraph. §7 even says 'The same comparison, with the transfer test in full, is §10 of the Horace experiment'. The flip-counting model is Horace's subject, so Horace §10 is the canonical home. At 390 px the duplicated chart's legend is off-screen. The §8 bullet on aifoundry3's protocol repeats Horace's method.


APPLY (PROPOSAL): Keep the h2 and its id: why-low-power line 203 links it. Replace everything from '<p>A card pinned at its lowest operating point is still a card…' through '…One random-data matmul on a new card calibrates the scale, and idle readings give the offset.</p>' with:

'<p>aifoundry3, held at 600 MHz, ran the same strict protocol at a 55.8 °C launch. The flip-counting model fitted on aifoundry2 carries over with one per-card scale factor. Unchanged, it overestimates by 8% (1.38 W rms). Multiplied by <b>0.92</b>, it is within <b>0.20 W rms</b> over 1.9–25 W. The operating point cannot explain the 8%: aifoundry3's 523 mV against 518 mV would predict 2% <em>more</em> switching power. The chart and the leave-one-out calibration are in <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-horace-experiment#a-second-card-and-what-transfers">§10 of the Horace experiment</a>. How the idle law transfers to this card is in <a href="#what-that-costs">What that costs</a>.</p>'

Fill the numbers from D.cards.scale, rms_raw, rms_scaled and voltage if preferred.

Then:
- Move the 'Leakage transfers too…' sentence and #leaktab into §4 (or into dvfs-viz-2), where the idle law is.
- Delete from script.js lines 146–169: #cardsw, #cardswcap, #scaletext.
- Delete the operand-pattern list (body.html lines 296–299).
- Cut the §8 bullet to: '<li>aifoundry3's session is the Horace experiment's strict protocol, launched at 55.77 ± 0.18 °C (20 runs); raw data in docs/reports/data/2026-09-22-horace-aifoundry3/.</li>'


Verifier note: Verified. Horace body.html lines 472–508 and script.js lines 293–320 use the same ids (cardsw, cardswcap, scaletext, leaktab) with near-identical prose and code, and the DVFS §7 itself defers to Horace §10. The replacement numbers check out: rms_raw 1.38, scale 0.924, rms_scaled 0.20, and 523 against 518 mV gives cv2f 1.019. why-low-power's link to #what-the-second-card-says-about-the-model and its '8% less' claim remain supported by the one paragraph. Filling the numbers from D.cards keeps them data-driven. Cutting the leave-one-out sentence from §8 is correct, because that figure leaves the page.


#### dvfs-reorg — MODIFIED [reorganize/medium] et-soc1-dvfs-leakage

Where: Section order (h2s); cross-references in script.js line 122, body.html lines 179, 327–328; why-low-power.body.html line 203; limits-of-observability.data.json line 1102; docs/findings/03-experiments.md line 345

Files: docs/reports/sources/dvfs-leakage.body.html, docs/reports/sources/dvfs-leakage.script.js, docs/reports/sources/why-low-power.body.html, docs/reports/sources/limits-of-observability.data.json, docs/findings/03-experiments.md

Problem: The governor story is split. §1–§2 cover the loop on aifoundry2, but whether the power branch works at all is only settled in §6 (aifoundry3's TDP of 0 W, 'This also settles what section 2 could not'), after three sections on leakage. The wake-up chart, which is §3's evidence, sits in §2. §7's leakage transfer belongs with the idle law in §4. §5's implications for measuring power come before §6–§7 contribute to them.


APPLY (CORRECTED): Apply the proposed order and reference updates, and also: sparsity.html line 290 '§6' → '§3' (then republish that standalone page); body.html line 383 '(§6–§7)' → '(§3 and §6)'. §8's '§2–§7' still covers everything. Run final_links.py afterwards. If dvfs-layout-wake is applied first, the wake chart move is already done.

Base PROPOSAL (for "as proposed" references): New order. Every id is kept, and Method stays §8, so the byline's and body's '§8' references still hold.
1. The loop as built (#the-loop-as-built)
2. The loop as measured (#the-loop-as-measured): the aifoundry2 cool starts, with no wake-up chart
3. The same firmware on three cards (#the-same-firmware-on-three-cards): moved up from §6; the TDP-0 power branch completes the loop story
4. The leakage-suppression transistors (#the-leakage-suppression-transistors): the old §3, with the wake-up chart placed after the probe description. Optionally retitle 'Leakage suppression: in the open design, tied off'.
5. What that costs (#what-that-costs): the old §4, plus the second card's idle-law check (#leaktab, or dvfs-viz-2)
6. What the second card says about the model (#what-the-second-card-says-about-the-model): cut to one paragraph (dvfs-red-s7)
7. What this means for the equation, and for measuring power (#what-this-means-for-the-equation-and-for-measuring-power): the old §5, now the conclusion
8. Method, and what is not established (#method-and-what-is-not-established)
Then Related reports.

Update these references:
- script.js line 122: '(the idle law, <a href="#what-that-costs">§4</a>)' → '§5'.
- body.html line 179: 'the 4.9 s wake-up probe of §3' → '§4'.
- body.html line 328: 'the explanations drawn from the source in §1 and §5 may not' → '§1 and §7'.
- In the moved §6 (new §3): 'Everything above is one card.' → 'Everything so far is one card.'
- why-low-power.body.html line 203: 'the DVFS report, section 7' → 'section 6'.
- limits-of-observability.data.json line 1102: 'The DVFS loop and its leakage, §6' → '§3'.
- 03-experiments.md line 345: '(A11), section 7' → 'section 6'.
- The private Kanter brief's 'DVFS report §5' links become §7, if it is ever published.


Verifier note: The diagnosis is right. Line 130 says 'below' but the chart is above, in §2. 'This also settles what section 2 could not' comes after three leakage sections. All incoming anchors survive, because the ids are kept. The reviewer's reference list is incomplete. The standalone sparsity page (docs/reports/2026-09-18-et-soc1-sparsity.html line 290) links #the-same-firmware-on-three-cards with the text 'The DVFS loop and its leakage, §6'. The Versions note (body.html line 383) says 'the three-machine comparison and the second card (§6–§7)'.


#### dvfs-claim-shipsoff — CONFIRMED [claim/medium] et-soc1-dvfs-leakage

Where: §3 closing paragraph, body.html lines 161–164; docs/findings/16-dvfs-and-leakage.md verdict row 4 and intro

Files: docs/reports/sources/dvfs-leakage.body.html, docs/findings/16-dvfs-and-leakage.md

Problem: 'So on this card, in this firmware, leakage suppression is a capability that ships switched off.' This asserts that the ET-SoC-1 silicon has the capability. The page itself says the RTL is the Erbium configuration, not the taped-out chip, and lists 'whether the taped-out ET-SoC-1 drives its sleep transistors' as not established (§8). 'which the same RTL does use aggressively' has the same problem. The findings file's verdict 'Built, not used' contradicts the page's corrected 'tied off in the open RTL'.


APPLY (PROPOSAL): Replace body.html lines 161–164 with:

'<p>So on this card, in this firmware, no leakage suppression is in use. The open design has the ports and ties them off, no firmware line drives them, and the card shows no wake-up. Whether the taped-out chip could gate its arrays is not established (§8). The gating that demonstrably works is clock gating, which the open RTL uses aggressively (per lane, per functional unit, with a seven-cycle tail). That is why an idle-but-powered core costs so little <i>dynamic</i> power and still leaks.</p>'

In 16-dvfs-and-leakage.md:
- verdict row 4: '**Built, not used**' → '**Tied off in the open RTL**';
- intro: 'and one is a capability that ships switched off' → 'and one is in the open design but tied off'.


Verifier note: Lines 161–164 say 'a capability that ships switched off'. That asserts something about the silicon, which §8 (lines 329–333, 360) explicitly leaves not established. The RTL is Erbium, not the taped-out chip. The replacement keeps every fact and removes the unsupported one. The 16-dvfs verdict row 4 ('Built, not used') and the intro ('a capability that ships switched off') are as quoted and should change as proposed.


#### dvfs-viz-2 — MODIFIED [visualization/medium] et-soc1-dvfs-leakage

Where: §4 'What that costs': replaces #leakfrac (body.html lines 167–171, script.js lines 86–104) and #leaktab (from §7, script.js lines 171–174)

Files: docs/reports/sources/dvfs-leakage.body.html, docs/reports/sources/dvfs-leakage.script.js, tools/ettelem/analyze_dvfs.py, docs/reports/data/2026-09-21-horace-aifoundry2/model.json, docs/reports/data/2026-09-22-dvfs-aifoundry2/dvfs.json

Problem: The page's leakage claims are one fitted law checked twice: on the same card after 20.6 h at 73 °C, and on a second card 7–14 °C below the fit range. Today the reader sees a share-of-power chart that hides the watts, the fit range and both checks. Its only data point is not independent: the law's leakage divided by measured power, so it sits on the curve by construction. The second card's check is a table two sections away.


APPLY (CORRECTED): Build the chart as proposed, with these changes: render at container width, or use viewBox width ≤ 440 under 600 px. Make the points focusable and tappable, with the readout updating on tap, not hover only. Add the 62 °C, 26.7 W overnight point, labelled 'overnight rest, 21 Sep'. Use a distinct marker and the legend label 'a different card (aifoundry3)' for the aifoundry3 bins. For the offset toggle, use whichever convention dvfs-claim-mean073 settles on, labelled either '+0.73 W, mean of the four bins' or '+0.68 W, by sample'. Keep the display equation and a two-sentence version of the out-of-sample paragraph.

Base PROPOSAL (for "as proposed" references): Title: 'One law, three checks: idle power against die temperature'.

DATA
- dvfs.json leak_model {P_fix 12.63, A_at_80 23.26, T_L 36}.
- aifoundry2's fit bins: model.json power.idle_curve (T 64–67 and 81–88 °C, P, n). Copy it into dvfs.json in analyze_dvfs.py: `"leak_model": {…, "idle_curve": pw["idle_curve"]}`.
- dvfs.json idle_check (73.0 °C, 31.79 W, sd 0.04, hours_idle 20.6).
- dvfs.json cards.leakage.idle_curve (aifoundry3: 50/55/56/57 °C, W, card2_law_W, n).
- busy_randn_80c 63.93; leak_fraction.kanter_range.

ENCODING (SVG viewBox 640×380, fits 390 px)
- x: die temperature, 45–95 °C. y: board power, 0–70 W.
- Stacked bands: fixed 12.6 W (var(--ref), 0.25); leakage A·e^((T−80)/36) (var(--c1), 0.35). A toggle button 'under a random-data matmul' adds switching 28.0 W (= 63.93 − the law's 35.89 at 80 °C) in var(--c2) at 0.35, so the busy share at 80 °C is the quoted 36%.
- The law as a line in var(--ink).
- Points:
  - aifoundry2 fit bins: hollow var(--c1), radius ∝ √n;
  - the 20.6-h check: filled var(--c3), labelled '22 Sep, 20.6 h idle';
  - aifoundry3 bins: filled var(--c7).
- Toggle 'shift the law by aifoundry3's offset' (+0.73 W, or +0.68 sample-weighted; see dvfs-claim-mean073).

INTERACTION
- A range slider for die temperature: 45–95, step 1, default 80. It moves a vertical cursor.
- The readout recomputes from the law: 'At 80 °C: idle 35.9 W = 12.6 fixed + 23.3 leakage → leakage is 65% of idle, 36% of a random-data matmul; slope 0.65 W/°C'. Show a 0–100% bar with Kanter's 5–30% band shaded (var(--c3), 0.16).
- Hover or focus a point (tabindex=0): bin °C, measured W, law W, difference, n samples.

REPLACES
- #leakfrac and #leaktab.
- The 'A free out-of-sample check' paragraph shrinks to two sentences.
- Keep the display equation.

WHAT THE READER GAINS
- In watts, they see where the law was fitted (two clusters, with nothing from 68 to 80 °C), that the 73 °C check lands in the gap at +0.01 W, and that a different card 7–14 °C below the range sits 0.6–0.9 W above it.
- They can read the leakage share at any temperature, not just the two quoted figures.


Verifier note: The data checks out. The model.json idle_curve residuals against the law are within ±0.11 W (−0.074 to +0.053 over 64–67 °C, −0.112 to +0.023 over 81–88 °C). The 73 °C check is 31.790 measured against 31.782 predicted. The aifoundry3 bins are +0.908/+0.712/+0.690/+0.618 W. Switching of 63.93 − 35.89 = 28.04 W gives 36.4% at 80 °C. The current chart's 73 °C dot is on the curve by construction: 19.147/31.790 against 19.147/31.782. The design has two flaws. A 640-wide viewBox at the roughly 358 px phone content width draws the 12 px labels at about 6.7 px. Hover does not work on phones. The proposal also omits the 62 °C overnight point (26.7 W) that the text says the law passes through.


#### dvfs-viz-scatter — CONFIRMED [visualization/medium] et-soc1-dvfs-leakage

Where: #attrib down-step scatter, script.js lines 51–65; chart title body.html line 92

Files: docs/reports/sources/dvfs-leakage.script.js, docs/reports/sources/dvfs-leakage.body.html

Problem: 'Every down-step, placed against the two thresholds it could have tripped' draws 18 steps as 11 visible marks. Whole-degree temperatures make points coincide: 7 thermal steps show as 4 dots, 7 unattributed as 5 and 4 thermal+power as 3. A reader counting dots cannot reproduce 7/4/7. The x range 60–72 °C puts every point in 64–67, so about two thirds of the width is empty. Thermal (var(--c2), orange) and thermal+power (var(--bad), red) are near-identical hues in both themes. Unattributed uses var(--c1), the clock's colour in the chart above. The dots are hover-only, with no keyboard access.


APPLY (PROPOSAL): In script.js:
- Change the x scale to 62.5–68.5 °C (ticks 63–68).
- Separate coincident points. Group rows by `r.T+'|'+Math.round(r.P/2)`, and offset each point's cx by `(i-(n-1)/2)*0.22` °C within its group.
- Colours: `COL={'thermal':'var(--c7)','thermal+power':'var(--bad)','power':'var(--c4)',[UN]:'var(--ref)'}`. Thermal takes the temperature colour; unknown is neutral grey.
- Legend counts: `${k} (${rows.filter(r=>r.why===k).length})`.
- Give each dot group `tabindex=0`, `role=img` and an aria-label with its tooltip text. Show and hide the tooltip on focus/blur as on mousemove.

In body.html line 92, the title becomes 'All 18 down-steps, placed against the two thresholds they could have tripped'.

If dvfs-viz-1 is built, make each dot select its run and step in the replay.


Verifier note: Verified with one small count error. Eighteen down-steps show as 11 visible dots, but the 7 thermal steps show as 3 dots, not 4: (66, 55.9/56.0) ×3, (66, 45.6/45.7) ×3 and (67, 53.7). The 4 thermal+power steps show as 3 and the 7 unattributed as 5, as stated. With x at 62.5–68.5 °C, 0.22 °C is about 14 px, more than the 12 px dot diameter, so the jitter separates the groups. The groups keyed on T|round(P/2) are correct. The colour change removes the clash of orange against red and of blue against the clock trace. Add a caption note that points within one whole degree are spread sideways so each is visible.


#### dvfs-layout-verdict — CONFIRMED [layout/medium] et-soc1-dvfs-leakage

Where: #verdict table (body.html line 35; template td.lvl {white-space:nowrap}); also #trans (line 111)

Files: docs/reports/sources/dvfs-leakage.body.html, docs/reports/sources/dvfs-leakage.script.js

Problem: At 390 px the verdict table, the page's summary, shows only the claim column and a clipped verdict ('confirmed, and thermal h', 'consistent, weakly testec'). The Evidence column is entirely off-screen, leaving tall blank cells, because td.lvl is nowrap and the table scrolls sideways. The 18-row #trans table likewise hides its Cause column on phones.


APPLY (PROPOSAL): Add a style block at the top of dvfs-leakage.body.html:
<style>@media (max-width:640px){#verdict thead{display:none}#verdict tr{display:block;padding:10px 0;border-bottom:1px solid var(--grid)}#verdict td{display:block;border:0;padding:2px 0}#verdict td.lvl{white-space:normal}#verdict td.lvl::before{content:'Verdict: ';font-weight:400;color:var(--ink-2)}#trans th:nth-child(4),#trans td:nth-child(4){display:none}}</style>

This stacks each Kanter statement, its verdict and its evidence, and drops #trans's mV column on phones so Cause fits. In script.js line 110, render the cause 'unattributed (reading ≤65 °C)' as 'unattributed', with the full label explained in the legend.


Verifier note: The 390 px screenshot confirms that the Evidence column is off-screen, that 'confirmed, and thermal h' and 'consistent, weakly testec' are clipped, and that the rows show tall blank cells. check_page shows no overflow because .table-wrap scrolls. #trans at 390 px shows only Run, t, MHz and mV. Other report bodies already use a <style> block (Horace, why-low-power, heat-per-mm, hub). One addition: with thead hidden, prefix the first cell too (for example `#verdict td:first-child::before{content:'Kanter: '}`), so each stacked block reads claim / verdict / evidence.


#### dvfs-layout-wake — CONFIRMED [layout/low] et-soc1-dvfs-leakage

Where: body.html lines 90–100 (flex block in §2) and line 130

Files: docs/reports/sources/dvfs-leakage.body.html

Problem: The wake-up probe chart sits in §2, beside the down-step scatter, before any text about the probe. §3 then says 'for those, the wake-up probe below is the only evidence', but the chart is above, in another section.


APPLY (PROPOSAL): Move `<div style="flex:1 1 380px;max-width:460px"><div class="chart-title">Wake-up probe: …</div><div class="chart" id="wake"></div></div>` (lines 96–99) into §3, right after the paragraph ending '…only the idle time varying, 20 repeats.' (line 144), as a plain block with max-width 560px. Leave #attrib as the only child of the §2 block, or remove that flex wrapper.


Verifier note: Line 130 says 'the wake-up probe below', but #wake sits in §2's flex block (lines 96–99). The move fixes the reference and puts the chart next to its description. It is subsumed by dvfs-reorg if that is applied.


#### dvfs-claim-chassis — CONFIRMED [claim/low] et-soc1-dvfs-leakage

Where: §4 last paragraph, body.html line 191

Files: docs/reports/sources/dvfs-leakage.body.html

Problem: '(2) a desktop chassis idles it at 73–80 °C rather than in server airflow'. The card at rest settled at 62 °C after a cool night and 73 °C on a warmer day. 80 °C is the strict protocol's preheat, not an idle temperature. why-low-power says 'left alone it settled at 62 °C one night and at 73 °C on a warmer day, and every run here launched at 80 °C'.


APPLY (PROPOSAL): Replace with '(2) it sits in a desktop chassis, where it rests at 62–73 °C, and these shares are taken at 80 °C, where every strict run launched, rather than in server airflow'.


Verifier note: idle_check gives 73.0 °C and the overnight anchor is 62 °C at 26.7 W. 80 °C is the strict protocol's launch temperature, not a resting temperature. why-low-power line 200 states it correctly. A cleaner wording: '(2) its desktop chassis rests it at 62–73 °C, and these shares are quoted at 80 °C, where every strict run launched; server airflow would keep it cooler'.


#### dvfs-claim-v2f — MODIFIED [claim/low] et-soc1-dvfs-leakage

Where: §5 bullet 1, body.html lines 204–207; docs/reports/data/2026-09-21-horace-aifoundry2/vf.json

Files: docs/reports/sources/dvfs-leakage.body.html, docs/reports/data/2026-09-21-horace-aifoundry2/vf.json, tools/ettelem/finish_horace.sh

Problem: 'the cool-start runs give 2.0 for ones (20.6 against 10.3 W over idle) and 2.05 for zeros (3.9 against 1.9 W), 5% and 8% above it'. This is more precise than the inputs allow.
- vf.json is hand-entered, with no script.
- Its values are rounded to 0.1 W, so 3.9/1.9 could be anything from 1.97 to 2.14.
- The 800 MHz idle (35.0 W) comes from the second after a run ends, before the clock resets. Of the 16 such samples in cold1, 11 read 34.7–35.3 W and 5 read 27.8–28.1 W (the 600 MHz idle level), so the value depends on which samples were picked.


APPLY (CORRECTED): Replace the sentence with: 'the cool-start runs give about 2.0 for ones (20.6 against 10.3 W over idle), within the roughly 5% that these hand-read idle levels allow (the 600 MHz idle alone moves about 0.4 W per degree at 64–66 °C), so consistent with it; zeros (3.9 against 1.9 W) are too small to test it.' Keep the note that this comes from seven short, uncontrolled runs. Adding tools/ettelem/derive_vf.py with explicit sample selection is worthwhile: in-run means by clock, and post-run idle windows that skip samples within about 0.3 s of a clock change, called from finish_horace.sh.

Base PROPOSAL (for "as proposed" references): Replace the sentence from 'the cool-start runs give 2.0…' to '…from seven short, uncontrolled runs.' with 'the cool-start runs give 2.0 for ones (20.6 against 10.3 W over idle), consistent with it; zeros (3.9 against 1.9 W) are too small to resolve, anywhere from 2.0 to 2.1 at the 0.1 W these are recorded to. Both rest on hand-read idle levels from seven short, uncontrolled runs.'

Add tools/ettelem/derive_vf.py. It should write vf.json from cold1/cold2 with explicit selections: in-run means by clock, and idle windows at each clock, listing the samples used. Call it from finish_horace.sh.


Verifier note: The problem is real: 5% and 8% are more precise than hand-entered, 0.1-W-rounded inputs allow, and vf.json has no producer. Two corrections. First, the 800 MHz idle ambiguity is smaller than claimed. Of the 16 samples, the 5 at 27.8–28.1 W are lagged 600 MHz meter readings. The other 11 average 35.01 W, which is exactly vf.json's 35.0, but they span 34.66–35.31 W. Second, the 600 MHz idle depends on temperature: medians of 27.45, 28.02 and 28.38 W at 64, 65 and 66 °C, and vf.json takes 28.1. The reviewer's replacement ('zeros anywhere from 2.0 to 2.1') is itself too precise and wrongly excludes 1.91. With these spreads, zeros' 3.9/1.9 W is anywhere from about 1.7 to 2.5, and ones' 20.6/10.3 is 2.0 ± about 5%.


#### dvfs-claim-worst — CONFIRMED [claim/low] et-soc1-dvfs-leakage

Where: #scaletext, script.js lines 168–169; horace-experiment.script.js line 316; docs/findings/05-claims.md line 198

Files: docs/reports/sources/dvfs-leakage.script.js, docs/reports/sources/horace-experiment.script.js, docs/findings/05-claims.md

Problem: '…gives 0.36 W rms in the median and 1.53 W at worst' reads as a worst-case rms. 1.53 W is the largest single held-out error (calibrate on zeros, predict randn). The worst per-calibration rms is 0.93 W (zeros).


APPLY (PROPOSAL): If dvfs-red-s7 is not applied, write in script.js: `${f2(C.loo.median_rms)} W rms in the median and ${f2(Math.max(...Object.values(C.loo.per_pattern)))} W rms at worst (calibrating on zeros, whose largest single error is ${f2(C.loo.worst)} W)`. Make the same change in horace-experiment.script.js line 316. In 05-claims line 198, write '0.36 W rms median, 0.93 W rms worst (largest single error 1.53 W)'.


Verifier note: Reconstructed from cards.patterns. Calibrating on zeros gives scale 1.8872/1.9437 = 0.971, which predicts randn at 26.39 W against 24.86 measured, an error of 1.527 W = loo.worst. The largest per-calibration rms is zeros at 0.929. 'X W at worst' next to 'W rms in the median' does read as a worst rms. If dvfs-red-s7 is applied, only Horace script.js line 316 and 05-claims line 198 need the change.


#### dvfs-claim-mean073 — CONFIRMED [reproducibility/low] et-soc1-dvfs-leakage

Where: #leaktab 'mean' row (script.js line 174); docs/reports/data/2026-09-22-horace-aifoundry3/leakage_crosscard.json and transfer.json; 03-experiments E20 (line 340 and command block); 05-claims line 200

Files: tools/ettelem/compare_cards.py, tools/ettelem/finish_horace.sh, docs/reports/sources/dvfs-leakage.script.js, docs/findings/03-experiments.md, docs/findings/05-claims.md

Problem: The table's 'mean +0.73' is the unweighted mean of four per-bin offsets. The 50 °C bin holds only 22 of 3,596 samples; weighted by samples the offset is +0.68 W (rms 0.69). No committed script produces leakage_crosscard.json or transfer.json, only commit 9df563e. The idle window (600 MHz samples outside [launch start − 1 s, launch end + 6 s]) is documented nowhere. E20's command block writes '--card aifoundry2=... --card aifoundry3=...' and '--toggles ...'.


APPLY (PROPOSAL): 1. Add `--transfer-out` and `--leak-out` to tools/ettelem/compare_cards.py. transfer: per-pattern scale a3_i/model_i, rms over the other seven, median and worst. leak: 10 Hz samples at 600 MHz outside [start − 1 s, end + 6 s] of every launch in runs.jsonl, binned by the whole-degree temp_c.minshire[0], bins with n ≥ 20, and the law from model.json. Write mean_offset_W sample-weighted and keep bin_mean_offset_W for the old figure. Call it from finish_horace.sh before build_cards_data.py.
2. In script.js line 174 (and Horace's leaktab), label the row 'mean (by sample)' and show +0.68. Or keep +0.73 and label it 'mean of the four bins'.
3. In 03-experiments E20, write the commands in full: `--card aifoundry2=docs/reports/data/2026-09-21-horace-aifoundry2/horace3.json --card aifoundry3=docs/reports/data/2026-09-22-horace-aifoundry3/horace3.json --toggles docs/reports/data/2026-09-21-horace-aifoundry2/toggles.json --out docs/reports/data/2026-09-22-horace-aifoundry3/cards.json`.
4. Change 'Calibrating that factor on a single run' → 'on a single operand pattern'.


Verifier note: Reproduced leakage_crosscard.json exactly: aifoundry3 samples at 600 MHz outside [launch start − 1 s, end + 6 s], binned by whole-degree temp_c.minshire[0], bins with n ≥ 20. The unweighted mean is 0.7321 and the sample-weighted mean is 0.6843. No script in tools/ or scripts/ writes leakage_crosscard.json or transfer.json, and compare_cards.py has only --card, --model, --toggles and --out. Prefer option 2b: keep +0.73 and label it 'mean of the four bins'. That avoids editing PLAN D11, E20, Horace's #leakoff, 05-claims:200 and the '0.7 W' prose. Adding the producer script and writing out the E20 commands in full are both worth doing, as is the 'single operand pattern' wording fix.


#### dvfs-repro-provenance — MODIFIED [reproducibility/low] et-soc1-dvfs-leakage

Where: #cardcfg row 1 (script.js line 130); §6 'max_power while sitting at 23 W' (body.html line 265); §4 'apart from the 4.9 s wake-up probe of §3, five minutes before' (line 179)

Files: docs/reports/sources/dvfs-leakage.script.js, docs/reports/sources/dvfs-leakage.body.html, docs/reports/data/2026-09-22-cards/config.json

Problem: Three of the page's facts have no committed raw record:
- the firmware/PMIC release 1.3.1 / 1.5.0 (hard-coded in script.js);
- the 23 W at which aifoundry3 reports max_power (config.json has no power field);
- the probe's 4.9 s duration and its timing five minutes before the idle sample (wakeup.json meta has only delays and reps).
The sptrace buffers contain only the request string dm_svc_get_firmware_version.


APPLY (CORRECTED): Commit the ettelem version/config output together with the board power at the moment of the read. Add firmware, pmic_fw and board_w_at_read to config.json, and read them in script.js and the body. Compute the probe duration in analyze_dvfs.py wakeup() from meta (delays × reps × levels ÷ 600 MHz) and print it. Until the records are committed, add to §8: 'The release numbers, the 23 W reading and the 72–73 °C during the thirteen-minute watch were read by hand and are not in the stored data.'

Base PROPOSAL (for "as proposed" references): Commit the `ettelem config`/version output with the board power at that read, and the memprobe_host run log (start/end timestamps), into docs/reports/data/2026-09-22-cards/ and …/2026-09-22-dvfs-aifoundry2/wakeup/. Add `firmware`, `pmic_fw` and `board_w_at_read` to config.json. Have script.js read `cf.aifoundry2.firmware` and the body read the 23 W from data. Until then, add to §8: 'The release numbers and the 23 W reading were read by hand from ettelem's output and are not in the stored data.'


Verifier note: The firmware/PMIC release (1.3.1 / 1.5.0, hard-coded at script.js line 130) and aifoundry3's 'max_power at 23 W' have no stored record. config.json has no power field, and no data file contains '1.3.1'. The probe's 4.9 s can be derived from stored data. wakeup.json meta gives delays summing to 29.111 M cycles per line; × 20 reps × 5 levels = 2.91e9 cycles = 4.85 s at 600 MHz. Only 'five minutes before' rests on E18/E19's logged clock times (11:39 against 11:44:19). A related gap the reviewer missed: cool2.log, the 13-minute aifoundry2 watch, polls config every 20 s and has no temperature field, so the '72–73 °C' in §6 has no stored record either.


#### dvfs-repro-mathjax — MODIFIED [reproducibility/low] et-soc1-dvfs-leakage

Where: scripts/build-report.py docstring; repo root (no package.json)

Files: scripts/build-report.py

Problem: The page embeds 9 MathJax SVG equations. A byte-identical rebuild needed mathjax-full 3.2.1 from the main checkout's untracked node_modules. The docstring says `npm install --no-save mathjax-full`, which installs whatever version is latest.


APPLY (CORRECTED): Optional, repo-wide: add package.json with mathjax-full pinned (3.2.1 or 3.2.2 both work) and a lockfile, and change the docstring to 'npm ci'. Do not state that other versions change the SVGs: 3.2.2 does not.

Base PROPOSAL (for "as proposed" references): Add a package.json at the repo root with "devDependencies": {"mathjax-full": "3.2.1"} and commit package-lock.json. Change the docstring to 'npm ci (pins mathjax-full 3.2.1; other versions change the equation SVGs)'.


Verifier note: The premise does not hold. I built the page with mathjax-full 3.2.2, the current npm latest, installed in the scratchpad, and got byte-identical output (178,461 chars, 9 equations), the same as with 3.2.1. An unpinned install reproduces the page today. Pinning is still reasonable hygiene against future releases, but it is low priority, not page-specific, and not needed for reproducibility now.


#### dvfs-repro-volts — MODIFIED [reproducibility/low] et-soc1-dvfs-leakage

Where: tools/ettelem/analyze_dvfs.py line 29 (VOLTS); §2 and §5's (0.618/0.517)

Files: tools/ettelem/analyze_dvfs.py

Problem: The operating-point voltages are hard-coded constants commented 'measured on-die, die_mv.minion', not computed. In the cool-start telemetry, steady 600 MHz reads 517–519 mV (median 519), 700 reads 566–568 and 800 reads 616–619. The idle check and config.json read 518. 0.517 is the lowest reading, not a typical one; the V²f factor changes only from 1.905 to 1.890.


APPLY (CORRECTED): In analyze_dvfs.py, compute VOLTS as the median die_mv.minion over samples inside a launch window whose clock equals the previous sample's, per clock. This reproduces 0.517/0.568/0.618 exactly. Write the result into operating_points and change the comment to 'median on-die reading while a kernel runs (cold1+cold2)'. Keep D1's rounded prose.

Base PROPOSAL (for "as proposed" references): In analyze_dvfs.py, compute VOLTS as the median die_mv.minion over samples whose clock equals the previous sample's, per clock, rounded to 1 mV, and write them into operating_points. Keep D1's rounded 0.52/0.57/0.62 V in prose. If 0.517 is kept as canonical, change the comment to say it is the minimum steady reading.


Verifier note: The hard-coded constant is real, but '0.517 is the lowest reading, not a typical one' is wrong. 517 mV is the typical reading at 600 MHz while a kernel runs. In-run samples in cold1+cold2 read 517 in 201 of 331, 518 in 115 and 519 in 15. Idle samples read 518–519. At 700 and 800 MHz the in-run medians are 568 and 618. The proposed median over all steady samples mixes mostly-idle 600 MHz samples (median 519) with mostly-busy 800 MHz ones, which is inconsistent for a switching-power ratio.


#### dvfs-cons-findings16 — CONFIRMED [consistency/low] et-soc1-dvfs-leakage

Where: docs/findings/16-dvfs-and-leakage.md lines 33, 60, verdict row 4

Files: docs/findings/16-dvfs-and-leakage.md

Problem: The findings file behind the page's Related link still has three items the page review corrected or dropped:
- 'about 96 I2C reads' per pass, which the review skipped as unverified;
- 'twelve and thirteen' launches (see dvfs-claim-13);
- the verdict 'Built, not used' (see dvfs-claim-shipsoff).


APPLY (PROPOSAL): Line 33: '(about 96 I2C reads, each followed by a 1 ms wait, then a DM_TASK_DELAY_MS = 10 ms sleep)' → '(each I2C sensor read waits 1 ms, then the pass sleeps DM_TASK_DELAY_MS = 10 ms)', matching the page. If the count is wanted, verify it against thermal_pwr_mgmt.c and dm_task.c at 353f20e and cite the lines. Apply the line-60 and verdict changes from dvfs-claim-13 and dvfs-claim-shipsoff.


Verifier note: 16-dvfs line 33 has '(about 96 I2C reads, each followed by a 1 ms wait…)'. fix-results.json.gz records that dvfs-2 skipped the count because it could not be verified, and the page (body.html line 43) has no count. Verdict row 4 'Built, not used' and the intro line match dvfs-claim-shipsoff. Of the three sub-items, apply the line 33 and verdict/intro changes. Leave line 60's 'twelve and thirteen': it is correct (see dvfs-claim-13).


#### dvfs-red-hysteresis — CONFIRMED [redundancy/low] et-soc1-dvfs-leakage

Where: §5 fourth bullet, body.html lines 219–221 (repeats §1 bullet 3, lines 62–65)

Files: docs/reports/sources/dvfs-leakage.body.html

Problem: '<b>The hunting measured here is at the thermal threshold</b>, which has no dead band in either version of the source. The two power-guardband macros that the 353f20e source leaves unused (the older governor uses one of them) would not damp it; damping it needs a temperature dead band.' This restates §1's 'There is no hysteresis' bullet and §2's hunting paragraph.


APPLY (PROPOSAL): Delete the §5 bullet. Append to §1's 'There is no hysteresis' bullet (after '…and stops firing at 65 °C.'): ' The older governor the cards run uses one of the two power guardbands, but neither would damp hunting at the thermal threshold (§2); that needs a temperature dead band.'


Verifier note: §5 bullet 4 (lines 219–221) restates §1 bullet 3 and §2's hunting paragraph. Its only new facts are that the older governor uses one guardband and that damping needs a temperature dead band, and the proposed sentence appended to §1 keeps both. It fits §1, and §5 stays focused on measuring power.


#### dvfs-red-contrast — MODIFIED [redundancy/low] et-soc1-dvfs-leakage

Where: §6 'The contrast is not that aifoundry2 is always faster' paragraph, body.html lines 275–279

Files: docs/reports/sources/dvfs-leakage.body.html

Problem: It repeats §1 bullet 2 ('This card usually idles above 65 °C (at 73 °C on 22 September…), and there it sits at its lowest operating point however little power it draws').


APPLY (CORRECTED): Replace lines 275–279 with: '<p><b>The contrast is not that aifoundry2 is always faster.</b> Launched warm, it too runs at 600 MHz: the thermal branch holds it at the floor, and every one of the strict protocol's launches at 80 °C ran at 600 MHz (§1). The difference is the remedy. aifoundry2 reaches 700 and 800 MHz when it starts cool (§2). aifoundry3 cannot at any temperature, because the branch that would raise it is unreachable.</p>'

Base PROPOSAL (for "as proposed" references): Replace lines 275–279 with: '<p><b>The contrast is not that aifoundry2 is always faster.</b> A warm aifoundry2 also sits at 600 MHz (§1; it read 600 MHz throughout a thirteen-minute watch at 72–73 °C on 22 September). The difference is the remedy. aifoundry2 reaches 700 and 800 MHz when it starts cool (§2). aifoundry3 cannot at any temperature, because the branch that would raise it is unreachable.</p>'


Verifier note: The redundancy with §1 bullet 2 is real, but the evidence the replacement keeps does not support its point. The 'thirteen-minute watch' is cool2.log: 41 config polls 20 s apart on an idle card, with no temperature field. An idle card sits at the boot point (600 MHz) whatever its temperature: aifoundry2 idles at 600 MHz at 62–64 °C in cold1/cold2, and aifoundry3 at 51–57 °C. So a 600 MHz reading while idle says nothing about the thermal branch. The evidence that a warm aifoundry2 runs work at 600 MHz is the strict session: all 1,112 launches in 2026-09-21-horace-aifoundry2/strict/runs.jsonl, launched at about 81 °C, ran at 0.58–0.60 GHz.


#### dvfs-red-kanter — CONFIRMED [redundancy/low] et-soc1-dvfs-leakage

Where: Intro paragraph (body.html lines 19–21), verdict row 2 (script.js line 116), §3 first paragraph (body.html lines 121–123)

Files: docs/reports/sources/dvfs-leakage.body.html, docs/reports/sources/dvfs-leakage.script.js

Problem: Kanter's claims are told three times before §3's evidence: in the intro, in the verdict table, and again in §3's opening ('Kanter's description was specific: cache data arrays sit behind leakage-suppression transistors, a lookup checks the tags first…'). The hedge is stated twice: in the intro ('He hedged… The hedge was right.') and in verdict row 2 ('He hedged that Esperanto might not have one; that hedge was right.').


APPLY (PROPOSAL): script.js line 116: delete ' He hedged that Esperanto might not have one; that hedge was right.' In §3, replace the first paragraph with one sentence: '<p>Kanter's mechanism is a tag check that wakes only the part of an array a lookup needs, at a small wake-up latency; the same trick applies to whole cores and execution units.</p>'


Verifier note: Kanter's mechanism and the hedge appear in the intro (lines 15–22), verdict row 2 (script.js line 116) and §3's opening (lines 121–123). The one-sentence §3 opener keeps the tag-check and wake-up-latency details the probe needs, and the intro keeps the ~10% figure. Deleting the hedge sentence from verdict row 2 loses nothing.


#### dvfs-red-formula — CONFIRMED [redundancy/low] et-soc1-dvfs-leakage

Where: §4, body.html lines 173–174 and 187

Files: docs/reports/sources/dvfs-leakage.body.html

Problem: The idle law is written out twice within a few lines: inline ('The leakage curve in this chart, \(P_\text{idle}(T)=12.6\,\mathrm{W}+23.3\,\mathrm{W}\,e^{(T-80)/36}\), was fitted on 21 September') and as the display equation with underbraces directly below the chart block.


APPLY (PROPOSAL): Move the display equation (line 187) to the start of §4, before the chart. Change the inline sentence to 'The idle law above was fitted on 21 September (…links unchanged…)'.


Verifier note: The law appears inline at lines 173–174 and again as the display equation at line 187, a few lines apart. Putting the display equation first and referring back to it is right. The point is moot if dvfs-viz-2 replaces the chart block and keeps the display equation.


#### dvfs-red-launchnote — CONFIRMED [redundancy/low] et-soc1-dvfs-leakage

Where: §2 note under the table, body.html lines 112–113

Files: docs/reports/sources/dvfs-leakage.body.html

Problem: 'Launches run back to back every 0.37–0.49 s, so every step is within a quarter of a second of some kernel boundary; the distance to the nearest one explains nothing and is not shown.' This is left over from a removed table column the reader never saw ('is not shown'). The same caveat is in analyze_dvfs.py's docstring.


APPLY (PROPOSAL): Delete the <p class="small">. In the attribution paragraph, after '…171 ms after a launch boundary) looks like the boot-point reset.', add ' (Launches run back to back every 0.37–0.49 s, so nearness to a boundary alone explains nothing.)'.


Verifier note: The note at lines 112–113 refers to a column the reader never sees ('is not shown'); PLAN dvfs-5 dropped it. The folded-in parenthetical keeps the one useful point, that nearness to a launch boundary explains nothing, next to the boot-point-reset sentence where it matters.


#### dvfs-viz-leakfrac — CONFIRMED [visualization/low] et-soc1-dvfs-leakage

Where: #leakfrac, script.js lines 97 and 102–104

Files: docs/reports/sources/dvfs-leakage.script.js

Problem: This applies only if dvfs-viz-2 is not built. The 73 °C dot is the law's leakage divided by measured power, so it lies on the idle curve by construction. Its tooltip says 'measured on 22 September … 60% temperature-dependent', which suggests the share was measured. The busy curve uses switching = busy − measured idle (27.6 W), so it reads 36.6% at 80 °C, while the text says 36%.


APPLY (PROPOSAL): Tooltip: `measured on 22 September after about ${ic.hours_idle} h: ${f2(ic.board_w)} W at ${f1(ic.die_c)} °C (law: ${f2(ic.model_pred_w)} W). The law puts ${f1(ic.temp_dependent_w)} W of it in leakage, ${Math.round(100*ic.temp_dependent_frac)}%.` In line 97, use `(D.busy_randn_80c-(m.P_fix+m.A_at_80))` as the switching term, so the busy curve passes through 36.4% at 80 °C.


Verifier note: This is the fallback if dvfs-viz-2 is not built. The 73 °C dot is 19.147/31.790 against the curve's 19.147/31.782, so it sits on the curve by construction, and 'temperature-dependent' comes from the law, not a measurement. Line 97's busy curve uses busy − measured idle (27.62 W) and reads 36.6% at 80 °C. The law-consistent 28.04 W gives 36.4%, matching leak_fraction.busy_randn_80c 0.364 and the text's 36%.


#### dvfs-layout-cycle — CONFIRMED [layout/low] et-soc1-dvfs-leakage

Where: #cycle, script.js lines 25, 29, 33 (chart.scroll min-width 640 px)

Files: docs/reports/sources/dvfs-leakage.script.js

Problem: This applies only if dvfs-viz-1 is not built. At 390 px the chart scrolls sideways. The board-power tick labels (30–90 W), the 'board W' label and 'TDP 65 W' are all in the right margin, off-screen. The visible orange trace has no scale, and the run is cut at about 4.3 s.


APPLY (PROPOSAL): Put the power band's labels on the left like the other two bands. Line 25: `txt(svg,L-6,yp(v)+4,v+' W','tick','end')`. Line 29: `txt(svg,4,yp(95)-4,'board power, W','lab')`. Line 33: `txt(svg,L+4,yp(TH.tdp_w)-5,'TDP '+TH.tdp_w+' W','lab')`. Then R can shrink from 58 to 16.


Verifier note: This is the fallback if dvfs-viz-1 is not built. The 390 px screenshot shows the chart scrolled, the power tick labels, 'board W' and 'TDP 65 W' off-screen, and the run cut at about 4.3 s. Moving the labels to the left and shrinking R fixes the axis. The chart still keeps its 640 px minimum width, so the run end stays off-screen unless 'scroll' is also dropped.


#### dvfs-viz-3 — MODIFIED [visualization/low] et-soc1-dvfs-leakage

Where: §3 wake-up probe: replaces #wake (script.js lines 67–84); analyze_dvfs.py wakeup()

Files: docs/reports/sources/dvfs-leakage.script.js, tools/ettelem/analyze_dvfs.py, docs/reports/data/2026-09-22-dvfs-aifoundry2/wakeup/wakeup.u32

Problem: The wake-up chart plots only medians. L1 (line left in place), L1 and L3 lie on top of each other at 0. Each dot's tooltip shows the level's overall summary, not the hovered value. The reader cannot see the page's key argument: the DRAM shift is a step already present at 1.7 µs in most repeats, not a ramp growing with idle, as a wake-up would. Nor can they check the '13 of 20 … one outlier' count.


APPLY (CORRECTED): Build after the dvfs-claim-wakeup fix, as proposed: per-repeat polylines, the median line, the +11 tRCD guide, edge arrows for clipped values, and a live count. Add a labelled arrow for L1 repeat 8 ('−128: a cycle-counter carry misfire in the no-idle read, not a wake-up'), and mention it in §8's probe bullet. Render at container width or viewBox width ≤ 440 under 600 px. Make the repeat lines focusable and tappable, not hover only. Default to DRAM.

Base PROPOSAL (for "as proposed" references): Title: 'Every repeat of the wake-up probe'.

DATA
- Raw: docs/reports/data/2026-09-22-dvfs-aifoundry2/wakeup/wakeup.u32 and wakeup.json labels.
- Export after the dvfs-claim-wakeup fix: in wakeup(), add `"paired_by_repeat": [[per[k][d_] - per[k][delays[0]] for d_ in delays] for k in sorted(per) if k[0] == lev]` to each level. That is 5 × 20 × 8 ints, about 2 KB.

CONTROLS
- Level buttons: 'L1 left in place', 'L1', 'L2', 'L3', 'DRAM'. Default DRAM.

ENCODING (viewBox 640×360)
- x: the existing log idle axis with the '0' break.
- y: latency minus the same line's no-idle latency, in cycles. Clip at ±40 and draw clipped values as small arrows at the edge (−51, +54 etc.) with their value.
- 20 thin polylines in var(--ref), one per repeat (the pairing).
- The median as a thick line in the level's colour (DRAM var(--bad), L2 var(--c4), L3 var(--c7), L1 var(--c1)/var(--c3)).
- Dashed guides at 0 and, for DRAM, at +11 (tRCD).

INTERACTION
- Hover or focus a repeat's line (tabindex=0): 'repeat 14: 0, −62, … cycles'.
- A live count under the chart: 'at 27 ms: 13 of 20 at +9 to +14, 6 within 6, 1 outlier', recomputed per level.

WHAT THE READER GAINS
- About 12–13 of 20 DRAM repeats jump by about 11 cycles at 1.7 µs and stay flat to 27 ms: a row closing, not a wake-up.
- All 20 L2 repeats show the same slow first load (61 → 49.5).
- L1 and L3 are flat.


Verifier note: The data exist and support the story once the host fix is removed. Twelve DRAM repeats (1, 5, 6, 7, 9, 10, 11, 12, 13, 15, 17, 19) sit at +8..+14 at every idle from 1.7 µs to 27 ms. Repeat 3 reaches +9 only at 27 ms. Six stay within 6 cycles of zero and repeat 14 sits at −50..−62. All 20 L2 repeats show −12..−10. The proposal misses two things. L1 repeat 8 reads 145 with no idle (17 + 128, a misfire of the kernel's own fixcyc), so the per-repeat L1 view shows one line at −128 at every idle, and 'L1 and L3 are flat' is true for 19 of 20. The 640-wide viewBox would also draw labels at about 6.7 px on a phone. The current tooltip does show only the level summary, as the reviewer says.


### Missed by the reviewers (found by the verifiers)


#### M-dvfs-1 [claim] et-soc1-dvfs-leakage

Problem: The §1 pseudo-code (body.html lines 47–49, 'Reduced to its logic') and 16-dvfs-and-leakage.md lines 40–42 merge the frequency check into the thermal test: `if T > 65 °C and f > f_min: step DOWN / elif P > 65 W and f > f_min: step DOWN / elif P < 65 W and f < f_max: step UP`. In the 353f20e source (/usr/src/et-platform, git show 353f20e:device-bootloaders/src/ServiceProcessorBL2/services/thermal_pwr_mgmt.c lines 884–896) the check is nested: `if (temperature_updated && T > thr) { if (f > f_min) step down }`, and the else-if chain is skipped whenever T > 65. The page's version would step the clock UP at 600 MHz on a hot die whenever P < 65 W. That contradicts the page's own bullet ('when the die reads above 65 °C the power branch is never reached') and every hot strict run, all at 600 MHz. dvfs-viz-1's proposed code panel copies the error.

APPLY: Rewrite the pseudo-code on the page and in 16-dvfs as:
`if T > 65 °C:
    if f > f_min: step DOWN one VMIN-LUT point   // at the floor: hold; the power tests are not reached
elif P > 65 W and f > f_min: step DOWN one VMIN-LUT point
elif P < 65 W and f < f_max: step UP one VMIN-LUT point`
Optionally note that each test fires only on a freshly updated reading (temperature_updated / pwr_updated). Use this form in the dvfs-viz-1 code panel.


#### M-dvfs-2 [claim] et-soc1-dvfs-leakage

Problem: §1 bullet 2 (lines 58–61, 'This card usually idles above 65 °C … and there it sits at its lowest operating point however little power it draws') and §6 lines 275–277 use idle observations (73 °C after 20.6 h; the 13-minute watch at 72–73 °C) as evidence of thermal priority. The governor acts only while the master minion is busy. An idle card sits at the boot point, 600 MHz, at any temperature: aifoundry2 idles at 600 MHz at 62–64 °C in cold1/cold2, and aifoundry3 at 51–57 °C. The evidence is misattributed, and the 72–73 °C of the watch is not in cool2.log, which has no temperature field.

APPLY: §1 bullet 2: '…This card usually rests above 65 °C (73 °C on 22 September, even after about 20.6 hours with no work), so a kernel launched on it starts above the threshold and runs at the lowest operating point however little power it draws: every launch of the strict protocol, at 80 °C, ran at 600 MHz.' Apply the matching §6 rewrite given in the dvfs-red-contrast verdict. Make the same change to 16-dvfs line ~55.


#### M-dvfs-3 [tooling] et-soc1-dvfs-leakage

Problem: The validation helper check_page.sh injects its window 'error' listener just before </body>, after the page's own inline script has run. It therefore cannot see exceptions thrown while the page loads, and its errs=[] result is not evidence that a page is error-free. Demonstrated here: the dvfs page built from pre-merge data throws 'Uncaught TypeError: Cannot read properties of undefined (reading 'config')', and check_page still reports errs=[] with only three empty fields. The same blind spot applies to every page checked in this validation run.

APPLY: In /tmp/claude-1019/-home-yaroslavvb-claude/ed6d06d5-de26-4323-94f1-0dc808eafbda/scratchpad/validate2/check_page.sh, insert the listener script immediately after '<head>' (fall back to the start of the document), leave the probe that dumps the results at the end of the body, and re-run check_page on all 18 pages.


#### M-dvfs-4 [claim] et-soc1-dvfs-leakage

Problem: The 7 thermal / 4 thermal+power / 7 unattributed split reads T and P on the first 10 Hz sample after each clock change. Using the last sample before the change gives 10 / 2 / 6. Run 5 zeros at 5.5 s (previous sample 66 °C) becomes thermal. The 800→ steps of run 2 at 0.79 s and run 7 at 0.95 s become thermal-only: their previous samples read 53.4 and 53.6 W, and the 87–88 W readings appear only after the step. Neither choice is clearly right, since the governor's pass can refresh P and T in the same pass that moves the clock. §8 discusses the sampling uncertainty for temperature only, and the page states 'four were both at once' without qualification.

APPLY: In §8's attribution bullet add: 'The split depends on which sample is read. Taking the sample just before each step instead of just after gives 10 thermal, 2 thermal+power and 6 unattributed, because the board meter lags the clock by 0.1–0.3 s. Either way the power branch never fired alone.' In §2 soften 'four were both at once' to 'four read above both thresholds on the sample after the step'. Optionally add a `why_prev` field in analyze_dvfs.py transitions() and show it in the #attrib tooltip.


### Refuted — do not apply


- dvfs-claim-700 (et-soc1-dvfs-leakage): '69 W at 700' is a sustained reading at 700 MHz, not a stray sample. In run 4 (cold1 randn) the clock held 700 MHz from 1.09 to 1.49 s. After the meter lag, the board read 68.5, 68.5 and 68.9 W, then 54.4 W once the clock was at 600. The 87.8 W at run 7's 700→600 step is the lagged reading of that run's 800 MHz burst: 800 MHz at 0.75–0.85 s, 87.8 W read at 0.95–1.15 s. The page's parenthetical is correct, and the replacement would drop a true figure. Optionally add a note under #trans: 'board W is the reading on the first sample that shows the new clock; the meter lags the clock by 0.1–0.3 s, so a 700→600 step can still show the 800 MHz burst.'


- dvfs-claim-13 (et-soc1-dvfs-leakage): From runs.jsonl ghz per launch: run 1 (cold1 zeros) reads [..., 0.788, 0.799 ×12, 0.697, ...]. The 0.788 launch contains the 600→800 up-step at 0.94 s, so it did not run wholly at 800 MHz. Run 5 has 13 launches at 0.799. Counting launches held at 800 MHz gives twelve and thirteen, as the findings file says. The reviewer's 13/13 uses a ghz ≥ 0.78 threshold that counts the partial launch. The page's 'twelve or more' is correct, and so is 16-dvfs line 60.



## Group power-temperature


### Reproduction problems


#### R-pt-1 [medium] docs/reports/data/2026-09-20-power-aifoundry2/summary.json

Problem: No committed script produces summary.json. Its thermal section carries the page's headline 0.80 W/°C. Its horace and horace2 sections come from an uncommitted reducer too.

Evidence: Commits df89c94 and 04746a3 add summary.json but no analysis script. No file in tools/ or scripts/ writes die_mnn, die_ddr, board_early or start_temp; the only matches are data files and make_heating_gif.py, which reads start_temp. 03-experiments E5 says the raw data is 'reduced to summary.json' without naming a tool. My independent rebuild of thermal matches to within 0.001 W.

Fix: Commit a reducer, e.g. tools/ettelem/summarize_power_session.py, that implements the rule reproduced here (1 s bins from the idle0 mark, field means rounded to 3 decimals, series cut at t=175). The thermal part of scratchpad/validate2/pt/check_pt.py can serve as a start. Then name it in 03-experiments E5 and in 04-artifacts.


#### R-pt-2 [medium] docs/reports/data/2026-09-20-power-aifoundry2/per-shire-voltage-idle.json

Problem: The E6 voltage map cannot be regenerated: the SP trace it was parsed from (sp.bin) and the parser are both missing from the repo.

Evidence: There is no sptrace binary in 2026-09-20-power-aifoundry2/, and no script in the repo parses 'MS %2d Voltage [mV]' lines. The JSON is internally consistent and equals summary.shires.

Fix: Commit the raw sptrace dump if it still exists, plus a small parser. Otherwise, say in 03-experiments E6 that the JSON is the rawest surviving record.


#### R-pt-3 [low] docs/reports/data/2026-09-20-power-aifoundry2/horace-telemetry.jsonl

Problem: The E7 and E8 telemetry was committed thinned 5× to 2 Hz, but the rows in summary.json and horace*-rows.json were computed from the 10 Hz stream (n=30 per row). The rows can only be approximated from the repo.

Evidence: run_horace.sh at df89c94 samples with --every-ms 100. The committed files have 586 and 1,247 samples at a 500 ms median spacing. Rebuilding from them gives a median |Δboard| of 0.02–0.04 W and a max of about 1.0 W.

Fix: State the thinning in 03-experiments E7/E8 (and 04-artifacts), or commit the full 10 Hz logs gzipped with compact_telemetry.py.


#### R-pt-4 [low] tools/ettelem/run_horace.sh

Problem: The pattern rotation (k·(2r+1)+3r) mod 10 is degenerate for round 2. The multiplier 5 is not coprime to 10, so E7's third round alternated onebit and ones five times each, and the summary kept only the last of each: 22 rows from 30 runs.

Evidence: horace-runs.jsonl splits into 30 runs; round 2 is onebit, ones, onebit, ones and so on. The (2, onebit) and (2, ones) rows match the fifth repeat (Δ ≈ 0.01 W) and not the first (Δ ≈ 2 W). run_horace.sh still uses the formula; the current default of rounds=2 avoids the bug.

Fix: Note in E7 that the '22 runs' are 22 rows out of 30 runs, with a degenerate third round. Use a coprime multiplier, or refuse rounds > 2.


#### R-pt-5 [low] docs/reports/sources/power-temperature.body.html

Problem: The '58 s of fp32 matmul' is really eight back-to-back ~7.2 s launches. Between launches, board power drops to 34–39 W for 0.1–0.3 s. The chart's seven dips go unexplained, the dips put 7 of the 52 fit bins below trend, and they drag the remainder to 14.6 W in those bins.

Evidence: Board samples under 45 W sit at 27.3, 34.6, 41.9, 49.2, 56.3, 63.6 and 70.9 s. Dropping those bins gives a slope of 0.79 board and 0.39 minion (against 0.80 and 0.40), and the remainder range becomes 19.6–22.1 W. Both stay within the page's 'about 0.8' and '20–22 W'.

Fix: Add one clause to §2: 'the matmul is eight 7 s launches back to back; the dips are the gaps between them'. Optionally have the JS fit skip bins that contain a gap.


#### R-pt-6 [low] docs/reports/sources/power-temperature.body.html

Problem: 'Same kernel, same clock, same rate: the extra 9 W is leakage' says more than the page's own idle law supports. The Later measurements box also says busy power climbs faster per degree than the idle law.

Evidence: The idle law gives 23.26·(e^(7/36) − e^(−4.4/36)) ≈ 7.7 W for the die going 75.6→87.0 °C, against the observed 8.9 W.

Fix: Reword as 'most of the extra 9 W is leakage (the idle law accounts for about 7.7 W of it)', or tie it to the Later box.


#### R-pt-7 [low] tools/ettelem/ettelem.cpp

Problem: The header comment says the SP rail figures are [avg, min, max] 'SINCE THEIR LAST RESET'. That contradicts E27 and canonical D2, which the page uses: avg is the PMIC's running average (τ ≈ 1 s), and only min and max run since reset. The usage string also leaves out `config` and `--reset-ms`.

Evidence: ettelem.cpp lines 6–8 and 178; 05-claims row 295 ('first-order, τ ≈ 1 s; min and max are since reset').

Fix: Correct the comment and the usage line.


#### R-pt-8 [low] docs/findings/05-claims.md

Problem: The claims register has no rows for several numbers these two pages state: the voltage-map ranges (517–521 mV, lows 513, highs 522), pmic_sys = minshire mean in 3,679 of 3,681 samples, the low stuck at 62 °C, and the 0.81 W/°C busy drift (report.json leak_w_per_c 0.807).

Evidence: grep for 517, 3,679 and 0.81 in 05-claims.md finds none of these rows.

Fix: Add rows pointing to per-shire-voltage-idle.json, the three *-telemetry.jsonl files (temp_c.pmic and temp_c.minshire) and 2026-09-21-horace-aifoundry2/report.json → leak_w_per_c.


### Review findings


#### sp-c1 — MODIFIED [claim/medium] et-soc1-spatial-temperature-brief

Where: §2 'The firmware reduction bottleneck', the paragraph after the code excerpt (repo HTML line 261: 'So the host never sees the current spread between shires: …')

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-22-et-soc1-spatial-temperature-brief.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-20-power-aifoundry2/thermal-telemetry.jsonl, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-20-power-aifoundry2/horace-telemetry.jsonl, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-20-power-aifoundry2/horace2-telemetry.jsonl

Problem: The brief says the host never sees the spread between shires and treats the two peak-hold extremes as useless. The 20 Sep telemetry shows the high carries one spatial number. It rises only when the 34-shire average sets a new maximum. After every rise it settles exactly 3 °C above the service processor's own maximum of the average (sp.minion_c[2]). So at those peaks the hottest shire read about 3 °C above the mean. The low sits 1 °C under the SP's minimum of the average. The brief's case is stronger than it says: there is a spread worth mapping, and the host sees its size but never its location.


APPLY (CORRECTED): Replace the paragraph with: '<p>So the host never sees the current spread between shires: the low and high are peak-hold values. The firmware resets them together with the service processor's own statistics, so both cover the same window. In the 20 Sep telemetry the low read 62 °C in all 3,681 samples, 1 °C under the service processor's minimum of the average (63 °C), while the average ran from 72 to 90 °C. The high only ratchets, but it leaks one number. Every rise followed a new record of the average and settled exactly 3 °C above the service processor's maximum of the average: 84/87 when the load step began, then 85/88, 86/89 and 87/90 during it (each 1.5–3 s after the record), and 88/91, 89/92 and 90/93 in the uncontrolled Horace session (the 92 came 27 s after its record). So at those peaks the hottest shire's sensor read about 3 °C above the 34-shire mean, in the firmware's whole degrees. The high is a single hardware sample, so sensor noise can add to it. Which shire it was, the host cannot tell.</p>'. KPI sub: 'Current mean + since-reset extremes, whole °C; the high gives the hottest shire's excess at a peak, not its place'. The 05-claims row (pt-p6) should read '2 °C for 1.5–3 s after each record in the load step, up to 27 s in Horace'.

Base PROPOSAL (for "as proposed" references): Replace the paragraph with: '<p>So the host never sees the current spread between shires: min and max are peak-hold values. In the 20 Sep telemetry the low read 62 °C in all 3,681 samples, 1 °C under the service processor's own minimum of the average (63 °C, set at the card's coolest moment since its stats were last reset), while the average ran from 72 to 90 °C. The high is a ratchet, but it leaks one number. Each time the average set a new maximum under the all-shire matmul, the high rose a few seconds later and settled 3 °C above the service processor's maximum of the average, every time: 84/87 at the start of the evening, then 85/88, 86/89, 87/90, 88/91, 89/92 and 90/93. So at those peaks the hottest shire read about 3 °C above the 34-shire mean (2–4 °C, in whole degrees). Which shire it was, the host cannot tell.</p>'. Keep the lede's 'one average at the host' framing, but change the KPI 'What the host sees today' sub to 'Current mean + since-reset extremes, truncated to 1 °C; the extremes give the hottest shire's excess at a peak, not its place'. Add the matching claim rows to 05-claims (see pt-p6).


Verifier note: The core finding is real. I recomputed it from the three telemetry files. temp_c.minshire[2] − sp.minion_c[2] is 3 after every rise: 1,789 + 531 + 1,247 samples at 3, and 59 + 55 at 2. The low is 62 against an SP minimum of 63 in all 3,681 samples. The firmware makes the comparison valid: Thermal_Pwr_Mgmt_Init_OP_Stats calls pvt_hilo_reset (thermal_pwr_mgmt.c ~2828), so the peak-hold registers and the SP's min/max cover the same window. The reviewer did not check this. Two parts of the proposal are wrong. (1) 'Rose a few seconds later … every time' is false. In the load step the high follows the record by 2.8, 1.5 and 1.6 s. In Horace the SP maximum reached 89 at 127.6 s, but the high reached 92 only at 154.2 s, 26.6 s later. The 55 Horace samples at 2 Hz are about 27 s, not 3 s. (2) 'Rises only when the average sets a new maximum' is loose. At 154.2 s the mean was 89, equal to its record. What holds is that every rise of the high followed a new record. Also, the high is one raw hardware sample taken at full rate, so noise can add to it, and the page should hedge the 'hottest shire' inference.


#### pt-r1 — MODIFIED [redundancy/medium] et-soc1-power-temperature

Where: 'Later measurements' box under the lede (power-temperature.body.html, the <div class="card" style="margin:18px 0 8px"> block)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/power-temperature.body.html

Problem: The box is about 170 words, most of it change history or text the page already has. Bullet 2 ('The rail readings are the PMIC's own running average … This page first called it a 2 s moving average') repeats §2 bullet 4, §1 rows 2–3 and the KPI, and adds internal history. Bullet 1's 'Its slope is 0.52 W/°C at 72 °C, 0.65 at 80 °C and 0.78 at 87 °C, and it reproduces this page's two idle readings to 0.1 W' repeats §2 bullet 2 ('Both sit on the idle law measured later (31.3 and 36.5 W …)'). 'The hub's improvement ladder supersedes §5' only serves a section that should go (pt-o1). X3 asks for a short box, not a changelog.


APPLY (CORRECTED): Use the reviewer's box, but end its second sentence '… attributed to delivery losses and DRAM traffic; the 15 W at idle is still not split (<a …#the-unmetered-remainder-attributed>Limits of observability, §4.2</a>).' Move the 0.81 W/°C sentence into §2 bullet 1 (pt-c1). In the Versions line, change '24 September: the rail averaging described from the firmware' to '24 September: the rail averaging described from the firmware (first described as a 2 s moving average)'. Drop 'supersedes §5' only if pt-o1 is applied.

Base PROPOSAL (for "as proposed" references): Replace the whole box with: '<div class="card" style="margin:18px 0 8px"><b>Later measurements.</b> Idle power is now a fitted law, P<sub>idle</sub> = 12.6 W + 23.3 W·e<sup>(T−80)/36</sup> with T the die temperature in °C. Its slope is 0.65 W/°C at 80 °C (<a href="https://spacesheep.dev/@yaroslavvb/et-soc1-dvfs-leakage">The DVFS loop and its leakage</a>; <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-energy-manual#the-card-at-rest">the energy manual, §1</a>); §2 compares this page's readings with it. What a workload adds to §2's unmetered remainder is now attributed to delivery losses and DRAM traffic (<a href="https://spacesheep.dev/@yaroslavvb/et-soc1-limits-of-observability#the-unmetered-remainder-attributed">Limits of observability, §4.2</a>).</div>'. Move the sentence 'Busy power climbs faster per degree … 0.81 W/°C for the drift within the Horace experiment's hot 7 s runs (80–86 °C)' into §2 bullet 1 (see pt-c1). The '2 s moving average' history belongs only in the Versions line, which already records it.


Verifier note: Real redundancy. The box repeats the τ ≈ 1 s averaging, which the KPI, §1 rows 2–3 and §2 bullet 4 already give, and the idle-law check that §2 bullet 2 gives. The proposed box is correct against D3, but it drops 'The 15 W at idle is still not split'. PLAN item 3 and D10 flag that as an overclaim guard, and without it a reader could assume the whole remainder is now attributed. The reviewer also says the Versions line 'already records' the 2 s moving-average history. It does not: it says only 'the rail averaging described from the firmware', never the old wording.


#### pt-o1 — MODIFIED [reorganize/medium] et-soc1-power-temperature

Where: Sections §4 'What a debug-interface client would and would not add', §5 'What would unlock more' and §6 'Reproduce'; the byline's '(…; see §6)'; script.js U table

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/power-temperature.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/power-temperature.script.js

Problem: §4 (about 90 words on the Minion Debug Interface) repeats the hub's §3 (#bits: 'The Minion Debug Interface reads state, not flips …') and its ladder row 'Halted-hart state'. §5 is a whole table the page itself calls superseded ('The table stands as it was on 20 September'); the hub's improvement ladder (#improve) is its canonical home. These two sections sit between the findings and Reproduce and make the page longer without new information.


APPLY (CORRECTED): Apply the reorder and the deletions as proposed (§4, §5, U table, byline '(see Reproduce)', MDI out of Terms, Versions note). Make the new end-of-§1 paragraph: '<p><b>Beyond these meters.</b> The Minion Debug Interface adds no power or temperature sensor: it reads the registers and memory of a halted hart (<a href="https://spacesheep.dev/@yaroslavvb/et-soc1-limits-of-observability#bits">Limits of observability, §3</a>). Its one use for energy work, writing the counter event selectors before a launch, is rung 17 of the hub's <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-limits-of-observability#improve">improvement ladder</a>, which also ranks what firmware changes or physical access would add and marks what has since been done.</p>'

Base PROPOSAL (for "as proposed" references): New order, keeping every surviving id and the §2/§3 numbers:
1. h1, byline, lede, short 'Later measurements' box (pt-r1), KPIs, Terms.
2. '1. Every way to measure, by granularity' (#every-way-to-measure-by-granularity), ending with a new paragraph: '<p><b>Beyond these meters.</b> The Minion Debug Interface adds no power or temperature sensor: it reads the registers and memory of a halted hart, and its use for energy work, writing counter event selectors, is covered in <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-limits-of-observability#bits">Limits of observability, §3</a>. What firmware changes or physical access would add, and what has since been done, is ranked in the hub's <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-limits-of-observability#improve">improvement ladder</a>.</p>'
3. '2. A load step, seen through every sensor' (#a-load-step-seen-through-every-sensor).
4. '3. The per-shire voltage map' (#the-per-shire-voltage-map).
5. '4. Reproduce' (#reproduce).
6. 'Related reports'.
Delete the §4 h2 and paragraph, and the §5 h2, its <p class="small"> note and <table id="unlock">. In script.js delete 'const U=[…];' and the 'document.getElementById('unlock').innerHTML=…' line. In the byline change '(the cards' own log strings point to an older build; see §6)' to '(…; see Reproduce)'. Drop the MDI sentence from Terms. Append to the Versions line: '24 September, second pass: §4 and §5 folded into §1; they pointed to the hub's fuller versions.'


Verifier note: Correct on redundancy and links. Nothing links §4, §5 or §6 (inbound anchors are only #a-load-step… ×3 and #the-per-shire-voltage-map ×6). The template's slugs drop the section numbers, so renumbering keeps the ids. Every row of the §5 table survives either in the hub's ladder (rungs 1, 5, 8, 12, 14, 16, 17) or in §1's 'Static against dynamic power' row. One error: the new paragraph says the debug interface's use for writing counter event selectors is covered in hub §3 (#bits). It is not. Hub §3's bullet says only that it 'reads state, not flips'. The mhpmevent writes are in rung 17 of the ladder. Side effect: with 5 h2s, the template no longer adds a contents list. That is acceptable for a page this short.


#### pt-v1 — MODIFIED [visualization/medium] et-soc1-power-temperature

Where: §2, new chart directly after the die-temperature chart and its caption, before the bullet list

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-20-power-aifoundry2/summary.json, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/power-temperature.script.js, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/power-temperature.body.html

Problem: The page's main result is that power depends on die temperature: busy power climbs about 0.8 W/°C, and idle after a load is 5 W higher. The existing charts only show power and temperature against time, so the reader must compare them by eye. Nothing shows that the idle readings lie on one curve, how much of the rise the idle law explains, or how much the fitted slope depends on where the fit starts.


APPLY (CORRECTED): Keep the chart, encoding and controls 1–2 as proposed. The reducer (pt-p1) writes thermal.gaps from the 10 Hz stream: [27.3, 34.6, 41.8, 49.2, 56.5, 63.6, 70.9] in the matmul and [126.6, 135.1, 143.8] in the DRAM phase. Control 3 rings the bins that contain those times. Add a checkbox 'Leave launch-gap bins out of the fit'; the readout then shows 0.79 against 0.80 at 5 s, and 0.84 against 0.89 at 20 s. Use expected medians of idle ≈ 0, DRAM ≈ +6.8 W and matmul ≈ +23.7 W. Merge control 4 with pt-v0's scrubber into one shared setCross scrubber, not two.

Base PROPOSAL (for "as proposed" references): Chart title: 'Board power against die temperature'. Question: how much of the rise under load is leakage, and is idle power a function of temperature alone?

Data: D.thermal.series[] (t, board, minion, temp) and D.thermal.phases[], already embedded.

Encoding: inline SVG drawn at the container's clientWidth (min 320 px; redraw on resize so labels stay at least 11 px). x = die temperature, 70–90 °C, titled 'die temperature (°C, 34-shire mean)'. y = board power, 25–70 W. One circle (r = 4) per bin: var(--ref) for idle0/cool1/cool2, var(--c7) for matmul, var(--c5) for DRAM. Bins within 3 s of a phase mark are drawn hollow. Idle law P(T) = 12.6 + 23.3·e^((T−80)/36) as a var(--ink) path, dashed 4 3, labelled 'idle law'. Matmul least-squares line in var(--c1) over the fitted bins. Grid lines var(--grid).

Controls, in a flex-wrap row, all native buttons or inputs:
(1) <input type=range> 'Fit starts N s after launch', 1–20, default 5. It recomputes the page's existing slope() for board and minion, moves the fit line, updates #slope-board/#slope-minion in bullet 1, and writes a readout: 'board 0.80 W/°C (minion 0.40) over 52 bins at 77–87 °C; the idle law's own slope there: 0.70 W/°C'. Expect 0.76 at 1 s, 0.80 at 5 s, 0.82 at 10 s and 0.89 at 20 s.
(2) Two aria-pressed buttons, 'Board power' and 'Above the idle law'. The second plots board − P(T) on a −5 to 30 W axis, draws the law as y = 0, and shows per-phase medians: idle ≈ 0, DRAM ≈ +6.9 W, matmul ≈ +23.8 W.
(3) Checkbox 'Mark launch gaps'. It rings the 7 matmul bins more than 3 W below the fit (t = 27, 34, 41, 49, 56, 63, 70 s) and the DRAM gap bins, with the tooltip 'gap between two ~7 s launches'.
(4) <input type=range> 'Step through time', 0–175, arrow-key usable. It highlights one bin, fills a readout (t, phase, T, board, minion, board − P(T)) and moves the crosshair on #power and #temp through a shared setCross(t), so the three charts are linked.
Pointermove on the SVG shows the nearest point's tooltip for mouse and touch.

Placement: it complements the time charts. Bullet 1's slope sentence reads its numbers from control (1). Bullet 2's 'Both sit on the idle law …' becomes something the reader can see.

What the reader gains: idle before (72 °C) and after (81 °C) the load lie on one curve, so the '5 W higher' is visibly temperature, not hysteresis. The matmul runs nearly parallel to the law, 23–24 W above it: 7.7 of the 8.9 W rise is the law's leakage. The quoted slope moves with the fit window, which is why 'about 0.8' is the right precision.


Verifier note: The main numbers reproduce from summary.json. Fit slopes are 0.759, 0.799, 0.821 and 0.890 for starts at 1, 5, 10 and 20 s. The minion slope is 0.395 over 52 bins at 77.1–87 °C. The idle law's mean slope is 0.69–0.72 W/°C. law(87) − law(75.6) = 7.68 W against 8.91 W observed. Idle readings are 31.23 against a law value of 31.26, and 36.5 against 36.56. The chart would add real understanding. Errors: (a) Control 3's rule, 'more than 3 W below the fit', catches only t = 34, 56, 63 and 70. Bins 27, 41 and 49 sit 1.65–1.89 W below the fit, and no rule on 1 s bins finds the 3 DRAM gaps (only 143 passes a 1.5 W rule). The gaps show clearly only in the 10 Hz stream, where board drops to 34–39 W. (b) The DRAM residual is 6.2–7.0 W outside gap bins (median 6.8), not 6.8–7.0. Matmul is 22.5–24.4 W (median 23.7), not 23.3–24.4. (c) Missed insight: part of the window sensitivity comes from the gap bins. Without them the slope is 0.77, 0.79, 0.80 and 0.84 for starts at 1, 5, 10 and 20 s. With them it is 0.76 to 0.89.


#### pt-v2 — MODIFIED [visualization/medium] et-soc1-power-temperature

Where: §2 bullet 4 'Why the remainder sometimes looks too small, or the rails seem to exceed the step'

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-20-power-aifoundry2/thermal-telemetry.jsonl, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/power-temperature.script.js, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/power-temperature.body.html

Problem: The bullet explains in about 150 words why board minus rails spikes to 39 W and dips to −3.5 W: the rails are the PMIC's τ ≈ 1 s averages while board power is instantaneous. The reader cannot see it. The remainder is not drawn on any chart (it appears only in the hover tooltip as 'rest'), and nothing lets the reader test the τ ≈ 1 s claim against this page's own data.


APPLY (CORRECTED): As proposed (thermal.fast written by the reducer; two panels; τ slider; 'PMIC's own board average' button), except: draw each panel's steady bands from that panel's data (start: 15.0 → about 20 W; stop: about 21 → 15.9 W). Use the caption 'At τ = 0 the remainder spikes to 39 W when the matmul starts, and drops below zero when it stops (−3.5 W) and at each gap between launches (to −4.3 W). Filter board power the way the PMIC filters the rails, with any τ from 1.0 to 1.4 s, and it steps cleanly between about 15 and 21 W.' Keep one sentence of mechanism in bullet 4 (see pt-r2).

Base PROPOSAL (for "as proposed" references): Chart title: 'The unmetered remainder at the load edges'. Question: is the 39 W spike and −3.5 W dip real, or an artefact of comparing an instant reading with 1 s averages?

Data: a new summary.json → thermal.fast = {t:[s], board:[W], board_avg:[W], rails:[W]}. It holds the 10 Hz samples for t = 15–35 s and 73–95 s (about 420 samples, about 20 KB; all 1,848 samples are about 80 KB): board_w, sp.board_avg_w and sp.minion_w[0]+sp.sram_w[0]+sp.noc_w[0], written by the reducer in pt-p1.

Encoding: two small-multiple SVG panels, 'Matmul starts (15–35 s)' and 'Matmul stops (73–95 s)', side by side above 600 px and stacked below. Shared y scale −5 to 42 W, with a y = 0 line in var(--ink). Remainder = board′ − rails as a 2 px var(--c5) line. Context: board′ in var(--c1) and rails in var(--c2), both at 35% opacity. Thin var(--grid) bands at the steady levels, 15 W idle and 21 W matmul.

Controls:
- <input type=range> 'Filter board power with τ = X s', 0–2, step 0.1, default 0. Board′ is y[i] = y[i−1] + (1 − e^(−(t[i]−t[i−1])/τ))·(x[i] − y[i−1]).
- Buttons 'Instant reading (τ = 0)', 'Filter like the rails (τ = 1 s)' and 'PMIC's own board average'. The last swaps board′ for board_avg and disables the slider.
- A live readout under each panel: 'remainder min … W, max … W'.
- Pointer and focus tooltip: t, board′, rails, remainder.

Placement: inside bullet 4. It replaces the bullet's sentences from 'So when the matmul starts …' to '… climbs back through 14 W over about 3 s' with the caption 'At τ = 0 the remainder spikes to 39 W and dips to −3.5 W; filter board power the way the PMIC filters the rails (τ ≈ 1 s) and it steps cleanly between 15 and 21 W.'

What the reader gains: the transients are shown to be a meter artefact, and the reader confirms the τ ≈ 1 s of canonical D2 from this page's own data.


Verifier note: The numbers reproduce exactly from thermal-telemetry.jsonl. Instant remainder: −4.2..38.8 W in 18–30 s and −3.5..21.7 W in 76–90 s. Filtered at τ = 1.0 s: 15.0..21.1 and 15.5..21.4. At τ = 0.5: 15.0..25.3 and 9.6..21.5. At τ = 1.2: 15.0..21.2 and 16.1..21.3. Using board_avg: 15.0..19.4 and 16.0..21.3. The chart is worth having. Three corrections. (1) The proposed caption says the remainder 'dips to −3.5 W', but the left panel will show −4.3 W at the 27.3 s launch gap, so the caption must mention the gaps. (2) Every τ from 1.0 to 1.4 s removes the transients, and 1.3–1.4 s is smoothest. The chart supports 'τ ≈ 1 s' only at that precision, so the text should not claim it confirms 1.0 exactly. (3) The fixed steady bands are wrong for the stop panel, where the idle remainder is 15.9 W at 81 °C, not 15.


#### sp-v1 — MODIFIED [visualization/medium] et-soc1-spatial-temperature-brief

Where: §2 'The firmware reduction bottleneck', right after the code excerpt (with sp-c1's corrected paragraph as its caption)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-22-et-soc1-spatial-temperature-brief.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-20-power-aifoundry2/thermal-telemetry.jsonl, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-20-power-aifoundry2/horace-telemetry.jsonl, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-20-power-aifoundry2/horace2-telemetry.jsonl

Problem: The brief's central claim, that the host gets one average plus peak-hold extremes, is only asserted. The page has no chart at all of the telemetry it cites (3,681 samples). A reader cannot see that the low never moves, that the high only ratchets, or that the high tracks the mean's record plus 3 °C.


APPLY (CORRECTED): As proposed, with these changes. The band between the SP maximum and the high is labelled with its live width, 2 or 3 °C. The scrubber readout shows t, mean, SP max, high and low, and adds '→ hottest shire ≈ mean + 3 °C at this peak' only in the first seconds after the high rises. Otherwise it says 'high held since t = X s; says nothing about now'. The caption notes that Horace samples are 2 Hz. Commit the extractor and name it in Sources, as proposed.

Base PROPOSAL (for "as proposed" references): Chart title: 'What the host's temperature fields did on 20 September'. Question: what exactly does the host receive, and does any of it say where the heat is?

Data: a const embedded in the page with change-point rows [t_s, mean, low, high, sp_max] per session, from {thermal,horace,horace2}-telemetry.jsonl: t_ms, temp_c.minshire[0..2] and sp.minion_c[2]. Commit the extractor, e.g. tools/ettelem/host_temp_fields.py (15 lines; it prints the const), and name it in Sources.

Encoding: inline SVG step lines (the values are whole degrees). x = seconds into the session; y = 60–95 °C.
- Mean: var(--c2).
- Peak-hold high: var(--c5).
- SP maximum of the mean: var(--ref), dashed.
- Peak-hold low: var(--c1).
- Direct end labels instead of a legend.
- A var(--grid) band between the SP maximum and the high, labelled '+3 °C'.
- A thin var(--ink) tick at each rise of the high.

Controls:
- Three aria-pressed buttons: 'Load step, 21:09 (185 s)', 'Horace, uncontrolled, 21:14 (293 s)' and 'Horace, 80 °C starts, 21:34 (624 s)'.
- <input type=range> time scrubber (arrow keys) with a readout, e.g. 't 76.3 s · mean 87 · SP max 87 · high 90 · low 62 → hottest shire ≈ mean + 3 °C'.
- A pointermove tooltip for mouse and touch.

It must fit 390 px: the SVG width is the container width.

What the reader gains: the low is pinned at 62 °C all evening, and the high moves only when the mean sets a record, always 3 °C above it. So the host learns how much hotter the hottest shire is at a peak, but never which shire, which is the brief's case for exporting the 35 readings.


Verifier note: The data exist and are small: 55, 97 and 117 change points, about 5.3 KB as JSON. The sessions are 185, 293 and 624 s long, starting at 21:09, 21:14 and 21:34. The chart shows the brief's central claim, and the brief has no chart. Two parts would mislead. (1) The scrubber readout '→ hottest shire ≈ mean + 3 °C' at any t is wrong. The high is held, so at t = 150 s in the load step the mean is 81 while the high is still 90, and nothing is known about the hottest shire then. (2) The fixed '+3 °C' band label is wrong for the 26.6 s in Horace (127.6–154.2 s) when the gap was 2 °C. Also, Horace's telemetry is thinned to 2 Hz, so step times there are only good to 0.5 s.


#### pt-p1 — CONFIRMED [reproducibility/medium] et-soc1-power-temperature

Where: docs/reports/data/2026-09-20-power-aifoundry2/summary.json (thermal, shires); the page's §6 Reproduce block; 03-experiments E5; 04-artifacts row A3

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-20-power-aifoundry2/summary.json, /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/03-experiments.md, /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/04-artifacts.md, /tmp/claude-1019/-home-yaroslavvb-claude/ed6d06d5-de26-4323-94f1-0dc808eafbda/scratchpad/validate2/pt/check_pt.py

Problem: No committed script produces summary.json, the only data the page's build reads. The Reproduce block goes from run_thermal.sh straight to a finished page. Nobody can rebuild the 0.80 W/°C headline from the raw telemetry with repo code.


APPLY (PROPOSAL): 1. Commit tools/ettelem/summarize_power_session.py <data-dir> --out <summary.json>. It should:
- read thermal-telemetry.jsonl and thermal-phases.jsonl;
- write thermal.phases = [{phase, t: round((t_ms − t_idle0)/1000, 3)}];
- write thermal.series from 1 s bins k = floor((t_ms − t_idle0)/1000), k ≤ 175 (say so in a comment, or emit all bins and change script.js's hard-coded 176 to S.at(-1).t + 1). Each bin holds means of board_w, sp.minion_w[0], sp.sram_w[0] and sp.noc_w[0] (3 decimals), and of temp_c.minshire[0], temp_c.pmic, die_mv.ddr and die_mv.minion (as check_pt.py does), with keys board, minion, sram, noc, temp, pmic, die_ddr, die_mnn;
- write thermal.fast for pt-v2;
- copy shires from per-shire-voltage-idle.json;
- merge into the existing summary.json without touching horace/horace2.
Start from part 1 of check_pt.py.

2. In the page's Reproduce block, after run_thermal.sh, add:
'python3 tools/ettelem/summarize_power_session.py docs/reports/data/2026-09-20-power-aifoundry2 --out docs/reports/data/2026-09-20-power-aifoundry2/summary.json'
'python3 scripts/build-report.py power-temperature docs/reports/data/2026-09-20-power-aifoundry2/summary.json docs/reports/2026-09-20-et-soc1-power-temperature.html'

3. In 03-experiments E5, change 'reduced to summary.json (thermal.series, one sample a second)' to 'reduced to summary.json (thermal.series, one sample a second) by tools/ettelem/summarize_power_session.py'. Add the same to 04-artifacts row A3.


Verifier note: No file in tools/ or scripts/ writes the thermal or shires parts of summary.json. build_horace_report_data.py only reads it through --earlier. I rebuilt the 1 s bins independently from thermal-telemetry.jsonl (k = floor((t_ms − t_idle0)/1000)). All 176 bins match board, minion, temp, pmic, die_ddr and die_mnn to within 0.0005. The raw data run to bin 184 (184.9 s), and the series stops at 175. The build-report.py usage in the proposed Reproduce line is correct, and E5's wording matches.


#### pt-p2 — MODIFIED [reproducibility/medium] et-soc1-power-temperature

Where: §3 voltage map data (per-shire-voltage-idle.json); last line of the Reproduce block ('strings -n 8 sp.bin | grep 'Voltage''); 03-experiments E6

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-20-power-aifoundry2/per-shire-voltage-idle.json, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/power-temperature.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/03-experiments.md

Problem: The E6 voltage map cannot be regenerated: neither the SP trace it came from (sp.bin) nor the parser that turned 'MS nn Voltage' lines into JSON is committed. The page's last Reproduce command stops at a grep, not at the JSON the page uses.


APPLY (CORRECTED): Commit tools/ettelem/parse_sptrace_voltage.py as proposed, with three changes. It takes the last pass in which all 34 shires printed, rather than the last record per shire, and falls back per shire with a warning. It ignores 'bad. skipping' and 'Sample fault' lines. It carries a --self-test that parses a line built from the firmware format string. The script's docstring and E6 say it was not run on the original 20 Sep trace. Replace the Reproduce line and add the E6 note as proposed.

Base PROPOSAL (for "as proposed" references): 1. Commit tools/ettelem/parse_sptrace_voltage.py sp.bin > per-shire-voltage-idle.json. It extracts printable strings of 8 or more characters, matches r'MS\s*(\d+) Voltage \[mV\]: VDD_MNN: (\d+) \[(\d+), (\d+)\] VDD_SRAM: (\d+) \[(\d+), (\d+)\] VDD_NOC: (\d+) \[(\d+), (\d+)\]', keeps the last complete record per shire, and writes {"<shire>": {"mnn": [now, low, high], "sram": […], "noc": […]}}.
2. Replace the page's line 'strings -n 8 sp.bin | grep 'Voltage'' with 'python3 tools/ettelem/parse_sptrace_voltage.py sp.bin > per-shire-voltage-idle.json'.
3. If the original sp.bin still exists in the lab build tree, commit it next to the JSON. Otherwise add to E6: 'The SP trace was not kept; per-shire-voltage-idle.json is the rawest surviving record.'


Verifier note: Confirmed: no sp.bin and no voltage parser exist in the repo or on this machine. The committed 2026-09-22-cards SP traces contain no 'Voltage' lines. The format string at pvt_controller.c lines 50–51 matches the proposed regex. The JSON order [now, low, high] matches the macro's argument order, and the JSON equals summary.shires. But the parser cannot be checked against the original trace. 'Last complete record per shire' can mix passes. The macro also prints 'MS nn bad. skipping.' and 'Sample fault' lines.


#### pt-c1 — CONFIRMED [claim/low] et-soc1-power-temperature

Where: §2 bullet 1 'Power climbs while the work stays constant'

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/power-temperature.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/tools/ettelem/run_thermal.sh, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-21-horace-aifoundry2/report.json

Problem: Four problems in one bullet.
(a) 'Same kernel, same clock, same rate: the extra 9 W is leakage' says more than the page's own idle law supports: the law accounts for 7.7 of the 8.9 W.
(b) 'Same rate' rests on run_thermal.sh's loads.log (the MMBENCH lines), which was not committed.
(c) '58 s of fp32 matmul' is eight back-to-back 7 s launches. The seven dips in the chart go unexplained.
(d) The corroborating sentence quotes the superseded first Horace session with '22 runs'. Those are 22 rows from 30 runs (a rotation bug repeated two patterns in round 2). Canonical D3 offers a better comparison: 0.81 W/°C within the strict hot runs.


APPLY (PROPOSAL): Replace the bullet with: '<li><b>Power climbs while the work stays constant.</b> The matmul, eight back-to-back launches of about 7 s each (the short dips in the chart are the gaps between them), draws 56 W two seconds after it starts and 65 W at its end, 56 s later, while the die warms from about 75 to 87 °C. It is the same kernel on the same 600 MHz clock. The idle law accounts for 7.7 W of the extra 9 W as leakage; the rest is why busy power climbs a little faster per degree than an idle card. A straight line through board power against die temperature, from 5 s after launch to the end, has a slope of <b id="slope-board"></b> W/°C, <span id="slope-minion"></span> W/°C of it on the minion rail. The idle law's slope over the same temperatures is 0.70 W/°C. The strict runs of <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-horace-experiment">the Horace experiment</a> found the same drift within their hot 7 s runs: 0.81 W/°C at 80–86 °C.</li>'. Also make the JS print one decimal less when the slider of pt-v1 is absent (toFixed(2) → 'about ' + toFixed(1)), or keep two decimals only together with pt-v1's window control. If loads.log survives in the lab build tree, commit it as thermal-loads.log so the rate claim can come back.


Verifier note: All four problems check out. (a) The law gives 7.68 of the observed 8.91 W (56.32 W at t = 22, 65.22 at t = 77). (b) loads.log is not committed. (c) The 10 Hz stream shows 7 dips at 27.3, 34.6, 41.8, 49.2, 56.5, 63.6 and 70.9 s, and run_thermal.sh loops 8 launches (58 s / 8 ≈ 7.25 s). (d) horace-runs.jsonl has 30 runs; round 2 alternates onebit and ones, and 22 rows remain. The clock is 600 MHz in all 1,848 samples. The idle law's slope over the fit bins is 0.70 (0.696). horace3.json and report.json give leak_w_per_c = 0.807. The replacement is D3-compliant and precise.


#### pt-p3 — MODIFIED [reproducibility/low] et-soc1-power-temperature

Where: tools/ettelem/run_thermal.sh; §6 Reproduce block

Files: /home/yaroslavvb/claude/et-soc1-prototyping/tools/ettelem/run_thermal.sh, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/power-temperature.body.html

Problem: run_thermal.sh hard-codes NEKKO=~/nekko/build, even though it cd's to the repo root, so it breaks in any other clone. It writes telemetry.jsonl, phases.jsonl and loads.log, but the committed files are thermal-telemetry.jsonl and thermal-phases.jsonl, and loads.log is missing. The page's Reproduce block does not list the builds the script needs: the mmbench launcher and kernel, the memprobe host, and dram_seq.tbl.


APPLY (CORRECTED): As proposed, and add 'mkdir -p "$NEKKO/run"' after the NEKKO assignment in run_thermal.sh. Also add 'set -o pipefail', or check that loads.log has 8 MMBENCH and 4 MEMPROBE lines at the end, so a failed launch is visible.

Base PROPOSAL (for "as proposed" references): 1. In run_thermal.sh, replace 'NEKKO=~/nekko/build' with 'NEKKO=${BUILD:-$PWD/build}' (after the existing cd). Write "$out/thermal-telemetry.jsonl", "$out/thermal-phases.jsonl" and "$out/thermal-loads.log", so the output names match the committed files.
2. Before the run_thermal.sh line in the Reproduce block, add:
'make all                                                     # build/launchers/mmbench_launcher, build/kernels/nekko/mmbench.elf'
'cmake -S workloads/memprobe -B build/memprobe -DCMAKE_PREFIX_PATH=/opt/et -Wno-dev && cmake --build build/memprobe'
'mkdir -p build/memprobe-data && python3 workloads/memprobe/gen_ops.py table --pattern dram_seq --out-file build/memprobe-data/dram_seq.tbl'
3. Change the run_thermal.sh comment to '# the load step, about 3 minutes; writes thermal-telemetry.jsonl, thermal-phases.jsonl, thermal-loads.log'.


Verifier note: Confirmed facts: line 9 is NEKKO=~/nekko/build. Outputs are telemetry.jsonl, phases.jsonl and loads.log, but the committed names are thermal-*, and loads.log is missing. The Makefile's 'all' builds launchers and kernels/nekko. The memprobe cmake line matches workloads/memprobe/README.md, and gen_ops.py takes 'table --pattern dram_seq --out-file'. The proposal has a gap. With NEKKO=$PWD/build, the script runs '(cd $NEKKO/run && …)', but build/run is created only by the Makefile's run targets (mkdir -p $(RUN_DIR)), not by 'make all'. In a fresh clone the cd fails silently inside the subshell, and the 'matmul' phase would record idle.


#### pt-r2 — MODIFIED [redundancy/low] et-soc1-power-temperature

Where: §2 bullet 4, last three sentences

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/power-temperature.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-19-et-soc1-memory-anatomy.html

Problem: The bullet repeats at length the memory-anatomy report's own explanation of its trace against host-log gap, which is canonical there (its §7 paragraph: 'Totals from the host's board-power log are 16–25% higher … Mid-run the two agree to within 0.3 W … starts to rise about 0.7 s before …'). It also keeps the history marker '(read later from the firmware: …)' and repeats the 61%/88% step figures that the KPI and §1 already give.


APPLY (CORRECTED): Make the first replacement as proposed (one sentence linking memory-anatomy #where-the-energy-goes). For the second, change '(read later from the firmware: <a …>Limits of observability, §4.1</a>). They behave like a first-order filter with τ ≈ 1 s: a step reaches 61% after 1 s and 88% after 2 s.' to ', roughly first-order with τ ≈ 1 s: a step reaches 61% after 1 s and 88% after 2 s (<a …#the-chain>Limits of observability, §4.1</a>).'

Base PROPOSAL (for "as proposed" references): Cut 'The same averaging, and how the trace was lined up in time, account for a gap in <a …>the memory-anatomy report</a>: there the rise above idle in the service processor's trace (the PMIC's board average) is 14–20% smaller than in the host log. Mid-run the two agree to within 0.3 W. As aligned, the trace starts to rise about 0.7 s before each load process starts and to fall before the run ends, so its baseline reads high and its run average low.' and replace it with 'The same averaging is behind the gap between the service-processor trace and the host log in <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-memory-anatomy#where-the-energy-goes">the memory-anatomy report</a>.' Change '(read later from the firmware: <a …>Limits of observability, §4.1</a>). They behave like a first-order filter with τ ≈ 1 s: a step reaches 61% after 1 s and 88% after 2 s.' to ', roughly first-order with τ ≈ 1 s (<a …#the-chain>Limits of observability, §4.1</a>).'


Verifier note: The first cut is right. The three sentences on the trace-versus-host-log gap (14–20%, 0.3 W, 0.7 s) repeat memory-anatomy's own paragraph almost word for word, and that paragraph is canonical there. The second cut goes too far. It deletes 'a step reaches 61% after 1 s and 88% after 2 s' from the bullet that explains the transients. pt-r3 and pt-c2 also strip '88%' from row 2 and the KPI, which leaves the D2 step figures in one table cell only. Memory-anatomy cites 'Power and temperature, §2' for the τ ≈ 1 s, so this bullet should keep the quantitative statement.


#### pt-r3 — MODIFIED [redundancy/low] et-soc1-power-temperature

Where: §1 row 2 (script.js M[1]); 'Finest power record' KPI; §6 'Firmware.' paragraph; §2 last bullet (clock); Terms

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/power-temperature.script.js, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/power-temperature.body.html

Problem: Remaining repeats and over-long method notes:
(a) '(τ ≈ 1 s; 88% of a step after 2 s)' appears verbatim in §1 rows 2 and 3 and in the KPI.
(b) The Reproduce 'Firmware.' paragraph (about 100 words) retells the firmware-build argument that the DVFS page owns (#the-same-firmware-on-three-cards) and that the byline and D16 already state in one sentence.
(c) The clock bullet (about 120 words) retells the governor that DVFS and Horace §6 cover.
(d) Once §4 is gone, Terms defines MDI for nothing.


APPLY (CORRECTED): Make (a), (c) and (d) as proposed. For (b): '<p class="small"><b>Firmware.</b> The service-processor code this page describes (the 133 ms pass, what each management command returns, the governor) was read at et-platform <code>353f20e</code>. The cards' own trace strings match an older build, from before et-platform commit <code>60b40c10f</code> (24 September 2024), which rewrote the governor, so the governor details may differ on the card (<a href="https://spacesheep.dev/@yaroslavvb/et-soc1-dvfs-leakage#the-same-firmware-on-three-cards">the DVFS report</a>). The measurements do not depend on it.</p>'

Base PROPOSAL (for "as proposed" references): (a) In script.js M[1][1], change 'whole card · the PMIC\'s running average (τ ≈ 1 s; 88% of a step after 2 s); min and max since the last stats reset' to 'whole card · the PMIC\'s running average, like the rails; min and max since the last stats reset'. For the KPI, see pt-c2.
(b) Replace the Firmware paragraph with '<p class="small"><b>Firmware.</b> The service-processor code this page describes (the 133 ms pass, what each management command returns, the governor) was read at et-platform <code>353f20e</code>; the cards' own trace strings match an older build, from before et-platform commit <code>60b40c10f</code> (24 September 2024; <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-dvfs-leakage#the-same-firmware-on-three-cards">the DVFS report</a>). The measurements do not depend on it.</p>'.
(c) Replace the clock bullet with '<li><b>The clock stayed at 600 MHz because the die was hot.</b> The governor steps down whenever the whole-degree die reading is above 65 °C or board power is above 65 W. Every run here had the die above 70 °C, so it held the lowest operating point (600 MHz at 0.52 V) even at 65 W. From a cool die it lifts the same kernel to 800 MHz within a second (<a href="https://spacesheep.dev/@yaroslavvb/et-soc1-horace-experiment#the-speed-effect-appears-on-a-cool-die">the Horace experiment, §6</a>; <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-dvfs-leakage">the DVFS report</a> reads the governor and classifies every clock change).</li>'.
(d) Delete 'MDI, the Minion Debug Interface, reads the registers and CSRs (control and status registers) of a halted hart.' from Terms.


Verifier note: (a), (c) and (d) are fine. (a) the 88% string repeats; board_avg shows the same τ ≈ 1 s, about 58% at 0.9 s. (c) the replacement uses D1's wording. (d) is fine if §4 goes. (b) drops the substance: the original says commit 60b40c10f 'rewrote the governor'. That is the one detail that says which part of this page may not match the running firmware: the clock bullet's thresholds. D16's short form is acceptable, but losing the governor caveat is not.


#### pt-c2 — CONFIRMED [claim/low] et-soc1-power-temperature

Where: Lede; KPI 'Finest power record'

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/power-temperature.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/research/power-telemetry.md

Problem: (a) 'up to 45 samples a second' is sold as a gain, but board power gets a new value only once per 133 ms pass (7.5 per second) and the rails are about 1 s averages. The real gain over et-powertop, which polls once a second, is a fresh reading every pass. The 45/s is only the command-latency ceiling.
(b) 'the die idles at 72 °C' is stated as a property. It is this session's starting point; the same card idled at 62 °C after a cool night and at 73 °C after 20.6 h on 22 Sep.
(c) The KPI '1 mW · 133 ms' pairs the rails' resolution with the board's refresh interval. The 1 mW rail figures are τ ≈ 1 s averages, so no 1 mW record exists at 133 ms.


APPLY (PROPOSAL): Lede: change 'the <b>per-rail snapshot the CLI refuses, up to 45 samples a second, and a 34-shire on-die voltage map</b>' to 'the <b>per-rail snapshot the CLI refuses, every 133 ms refresh instead of et-powertop's one poll a second, and a 34-shire on-die voltage map</b>'. Change 'the die idles at 72 °C' to 'the die idled at 72 °C here (62–73 °C on other days)'. KPI 'Finest power record': val '10 mW · 133 ms', sub 'board power, fresh each service-processor pass; the rails read to 1 mW but are the PMIC's running average (τ ≈ 1 s)'.


Verifier note: took_ms has a median of 22 ms, so 45/s is only the ceiling on command rate. Board and rail values change every 0.2 s in the 10 Hz stream (the 133 ms refresh sampled at 100 ms). et-powertop polls every 1000 ms (power-telemetry.md, kUpdateDelayMS). Board power has 10 mW steps (D2), and the 1 mW rail figures are τ ≈ 1 s averages, so '1 mW · 133 ms' pairs two different meters. The Horace page gives 62 °C after a cool night and 73 °C after 20.6 h idle. All three edits are correct.


#### pt-c3 — CONFIRMED [claim/low] et-soc1-power-temperature

Where: §2 bullet 'Voltage barely droops at the die'

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/power-temperature.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-20-power-aifoundry2/thermal-telemetry.jsonl

Problem: 'the regulator senses at the die' is an inference stated as fact. 'The DDR domain reads 768 mV … and sags 3 mV more under DRAM load' hides two things. The 3 mV is measured from the hot-idle 766 mV, not the 768 mV quoted, since the reading also moves with temperature. And the matmul, with little DRAM traffic, also takes it to 765 mV. That matters because the hub turns this droop into a DRAM power meter and warns that non-DRAM traffic moves it too (D10). The bullet does not link that meter.


APPLY (PROPOSAL): Replace the bullet with '<li><b>Voltage barely droops at the die.</b> The minion rail's on-die monitor reads 518 mV idle and 517 mV with 18 W more load (about 35 A more at 0.52 V), consistent with a regulator that senses at the die. The hub puts the sag at 0.068 mV per watt. The DDR domain reads 768 mV on die at 72 °C idle and 766 mV at 81 °C, against an 800 mV set-point. The DRAM-bound load takes it to 763 mV, and the matmul, with little DRAM traffic, to 765 mV. That droop is now used as a meter for DRAM power (<a href="https://spacesheep.dev/@yaroslavvb/et-soc1-limits-of-observability#what-the-moortec-sensors-can-and-cannot-do-for-power">Limits of observability, §4.3</a>).</li>'


Verifier note: Recomputed die_mv.ddr: idle0 768.0 at 72 °C, matmul (t = 60–78 s) 765.0, cool1 (t = 100–118 s) 766.1 at 81 °C, DRAM phase 763.1 (762–766), cool2 766.0. reg_mv.ddr is 800 throughout. The minion rail reads 518 → 517 with 18.1 W more on the minion rail (34.6 A at 0.52 V). The hub's minion_ir_drop_mv_per_w is 0.0684, and the anchor #what-the-moortec-sensors-can-and-cannot-do-for-power exists. The rewrite is accurate and adds the D10 link.


#### pt-c4 — MODIFIED [claim/low] et-soc1-power-temperature

Where: §3 caption under the map (<p class="small">Stronger colour = higher voltage …)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/power-temperature.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-20-power-aifoundry2/per-shire-voltage-idle.json

Problem: The caption does not say what the idle map shows, and the tile colours invite the reader to see hot spots. At idle the minion-rail readings span only 4 mV (517–521) in 1 mV steps, with no gradient across the mesh. The spread is most likely each monitor's own offset. The map's value is as a baseline for a map under load (the hub's rung 5), and the caption should say so.


APPLY (CORRECTED): After '… the lowest captured minimum is 513 mV (shires 0–2 and 18).' insert: 'The current readings differ by at most 4 mV, with no gradient across the grid (a plane fitted to them explains 9% of the spread). Idle currents of about 0.3 W per shire are far too small to cause that, so they are most likely each monitor's own offset: a baseline to subtract from a map taken under load (the hub's <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-limits-of-observability#improve">rung 5</a>). The lows are not idle values. They hold the deepest droop since the last stats reset, a window that included loads that evening.'

Base PROPOSAL (for "as proposed" references): After '… the lowest captured minimum is 513 mV (shires 0–2 and 18).' insert: 'At idle the shires differ by at most 4 mV, with no clear gradient across the grid: a plane fitted to it explains 9% of the minion-rail spread. So this map is most likely the monitors' own offsets, a baseline to subtract from a map taken under load (the hub's <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-limits-of-observability#improve">rung 5</a>).'


Verifier note: The R² values reproduce: minion now 0.091, lows 0.268, SRAM 0.378, mesh 0.011. The idle-current argument holds: 10.7 W ÷ 34 ≈ 0.31 W per shire, and at 0.068 mV/W the whole idle rail sags about 0.7 mV. So a 4 mV spread in the current readings is mostly monitor offset and 1 mV quantisation. By an F-test, the minion 'now' fit is not significant (p ≈ 0.25). But the lows do lean: R² 0.27 (p ≈ 0.01), about 0.5 mV per row, lower toward the top rows. The lows are also not idle quantities. They hold the deepest droop since the last stats reset, and the SP's board maximum read 79 W in that window at 21:09. The proposed caption applies 'offsets' to the whole map.


#### pt-v0 — MODIFIED [visualization/low] et-soc1-power-temperature

Where: §2 charts #power and #temp (script.js lines()); §3 #vmap

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/power-temperature.script.js, /tmp/claude-1019/-home-yaroslavvb-claude/ed6d06d5-de26-4323-94f1-0dc808eafbda/scratchpad/validate2/work/power-temperature/pt390-4.png, /tmp/claude-1019/-home-yaroslavvb-claude/ed6d06d5-de26-4323-94f1-0dc808eafbda/scratchpad/validate2/work/power-temperature/pt390-6.png

Problem: Assessment of the existing charts: clear, labelled (W and °C in the titles), honest scales (power from 0 W), useful phase shading. Weaknesses:
(1) The unmetered remainder, subject of two bullets, is not drawn; it exists only as 'rest' in the tooltip.
(2) Seven sharp dips in the matmul and three in the DRAM phase are unexplained.
(3) The tooltip works on mousemove only, with nothing for keyboard or touch.
(4) At 390 px the 900-unit SVG scrolls sideways: the y-axis labels scroll away, the DRAM phase starts off-screen, and nothing tells the reader to scroll.
(5) The voltage-map tile text renders at about 7–8 px on a phone, and colour is only explained in prose.


APPLY (CORRECTED): (1), (3) and (4) as proposed, with one scrubber shared with pt-v1. (2) Draw ticks at thermal.gaps from the reducer (10 Hz times: 27.3, 34.6, 41.8, 49.2, 56.5, 63.6, 70.9, 126.6, 135.1 and 143.8 s), not a threshold on 1 s bins. (5) Draw #vmap at the container width. Below 480 px, show only the mV value in each tile at 12 px or larger, move shire id and low into the tooltip or focus readout, and add the data-driven legend.

Base PROPOSAL (for "as proposed" references): (1) In lines('power', …), add a fifth series: remainder = board − minion − sram − noc, as a dashed path in var(--c5), with the legend entry 'unmetered (board − rails)'.
(2) Draw a short var(--ink-2) tick above the x-axis at each launch gap (board more than 3 W below its 1 s neighbours) and add to the caption: 'Dips: the gaps between successive ~7 s launches.'
(3) Replace 'mousemove' with 'pointermove' and add the shared keyboard scrubber from pt-v1 (<input type=range> 0–175 driving setCross(t) on both charts). Keep the tooltip visible while the input has focus.
(4) Drop the 'scroll' class. Draw the time charts at the container's clientWidth (as pt-v1), so the full 0–176 s is visible at 390 px with 5 ticks (0, 40, 80, 120, 160 s).
(5) For #vmap, see pt-v3; at minimum set the tile font to 14 viewBox units and add a 5-swatch legend (516–521 mV).


Verifier note: The assessment is accurate. pt390-4.png cuts the chart at about 97 s with the DRAM phase hidden and no scroll cue; .chart.scroll svg has min-width 640px. The tooltip listens for mousemove only. Map labels are about 7 px at 390 (pt390-6.png). Two fixes are flawed. (2) '3 W below its 1 s neighbours' on 1 s bins finds only 34, 56, 63 and 70. A 1.5 W rule finds all 7 matmul gaps but only 1 of 3 DRAM gaps. (5) 14 viewBox units in a 520-unit SVG scaled to about 358 px renders at about 9.6 px, which is still too small.


#### pt-v3 — MODIFIED [visualization/low] et-soc1-power-temperature

Where: §3 #vmap

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-20-power-aifoundry2/summary.json, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/power-temperature.script.js

Problem: The map shows only the minion rail's current value (and its low as text). The page's own data hold three rails, each with current, low and high, and the SRAM rail is where the only faint gradient is. The dashed cells are unlabelled, while the spatial brief labels the same cells 'master or spare' and 'I/O or PCIe (inferred)'.


APPLY (CORRECTED): As proposed, with these changes. The colour scale spans max(data range, 5 mV), and the legend always prints the mV range and '1 mV steps'. The live caption gives range and plane R² and, for the Lowest and Swing views, adds 'deepest droop since the last stats reset, including loads'. 'What the reader gains' should say 0–4 mV below the reading on the minion rail. Label the dashed cells as the spatial brief does, marked 'inferred'.

Base PROPOSAL (for "as proposed" references): Question: does any rail show a spatial pattern at idle, and how far below its reading does each shire's capture go?

Data: D.shires, from summary.json → shires[id].{mnn, sram, noc} = [now, low, high].

Controls:
- Two aria-pressed button groups above the map: 'Minion | SRAM | Mesh' and 'Now | Lowest captured | Highest captured | Swing (high − low)'.
- Tile opacity from var(--c1), scaled over the selected field's min–max across all 34 shires.
- A 5-swatch legend generated from the data, in mV.
- A live caption: 'range X–Y mV; a plane across the grid explains R² = Z'. It reuses a 3-parameter least-squares fit in about 10 lines of JS.
- Tiles get tabindex=0 and show the tooltip on focus as well as on pointer.
- Label the dashed cells as the spatial brief does.

What the reader gains: at idle the minion map is flat within 4 mV, while SRAM leans lower to the right and bottom and the captures reach 1–5 mV below the reading. That supports the 'baseline' caption of pt-c4 and shows what a loaded map should be compared against.


Verifier note: The data exist (34 shires × 3 rails × [now, low, high]) and the R² figures reproduce: SRAM 0.378 with slopes −0.31 mV/column and −0.22 mV/row, so it leans lower to the right and bottom. It is a modest but honest addition. Corrections: (a) 'captures reach 1–5 mV below the reading' is wrong. Now − low is 0–4 mV on the minion rail, 1–2 on SRAM and 0–2 on mesh. (b) Scaling opacity over each field's min–max makes a 3 mV mesh range (483–486) look as strong as any gradient. (c) The lows and swing views show since-reset droops, not idle values (see pt-c4).


#### sp-v2 — MODIFIED [visualization/low] et-soc1-spatial-temperature-brief

Where: §4 'Current best workaround', item 1 'Sub-degree de-quantization'

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-20-power-aifoundry2/thermal-telemetry.jsonl, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-22-et-soc1-spatial-temperature-brief.html

Problem: The claim that whole-degree readings polled at 10 Hz recover sub-degree information is stated, but the reader never sees why timing carries it, or why the polling rate matters. §3 row 4 contrasts ettelem's 10 Hz with the stock tool's rate.


APPLY (CORRECTED): Optional, lowest priority. Show a staircase of the whole-degree mean for t = 18–80 s with a 'Poll every 0.1 / 0.5 / 1 / 2 s' control. At each rate, mark the step instants the host would see and ring the 1 °C flickers at the launch gaps. The readout: 'N steps seen, timed to ±Δ/2; M of 5 launch-gap flickers seen'. Drop the 'recovered curve' and the ±°C readout. Add under item 1: 'For the recovered temperature itself, see the Horace experiment, §2 and §8.'

Base PROPOSAL (for "as proposed" references): Chart title: 'Whole degrees, sharp edges'. Question: how can a whole-degree reading give 0.01 °C?

Data: an embedded const of [t_s, mean] for the 10 Hz samples of the load step, t = 18–80 s (about 620 pairs, about 8 KB), or only its 48 change points plus the sample clock, produced by the same extractor as sp-v1.

Encoding: SVG staircase of the whole-degree mean against time, var(--c2). Dots at each upward step instant, var(--c1). A dashed var(--ink) line through the step instants, (t_step, value), labelled 'recovered curve'.

Controls:
- <input type=range> 'Poll every' with stops 0.1, 0.2, 0.5, 1 and 2 s (label: '0.1 s = ettelem, 1 s = et-powertop's default'). It resamples the stream at every k-th sample and redraws the staircase and the step dots as a host polling at that rate would see them.
- Readout: 'each crossing timed to ±Δ/2; at this run's median heating rate (4.5 s per degree) that is ±X °C'. X is 0.011 °C at 0.1 s, 0.11 °C at 1 s and 0.22 °C at 2 s.
- A toggle button 'Show recovered curve'.
- Pointer and focus tooltip on step dots: time, value, interval since the previous step.

Placement: under item 1 of §4; the item's text stays.

What the reader gains: the information is in when the reading changes, not in its value, and the polling rate sets the recovered resolution. The 1 °C flickers at the launch gaps also show that the die responds within tenths of a second, which a 1 s poll misses.


Verifier note: The data check out: 15 upward steps at 20.2…74.5 s, a median of 4.5 s per degree, and one-degree flickers at 27.2, 41.7, 49.2, 63.6 and 70.8 s, which coincide with the launch gaps. But the proposal mostly duplicates the Horace page, which already has interactive 'thin staircases = whole-degree readings; bold = temperature recovered from the step times'. Two parts would mislead. The dashed 'recovered curve' through (t_step, value) is not the brief's method: that method fits heating power through the thermal network. The '±0.011 °C at 10 Hz' readout counts only timing error, uses one median heating rate (the real rate runs from 0.3 to 6 s per degree), and sits next to the brief's '0.03 °C on repeated runs' and Horace's 0.3 °C rms. The new element worth keeping is the poll-rate comparison and the launch-gap flickers.


#### sp-o1 — MODIFIED [reorganize/low] et-soc1-spatial-temperature-brief

Where: §1 (pmic_sys paragraph, h3 #controllers), §2, §3, §4 item 3

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-22-et-soc1-spatial-temperature-brief.html

Problem: The reader's question is: can I watch heat move, what do I get today, and what would it take? Three pieces sit in the wrong place.
(a) The pmic_sys paragraph in §1 is about what the host receives, and it duplicates the §2 code comment '// the same minion-shire average, not a PMIC reading'.
(b) The h3 'Controller mapping and hardware registers' (base addresses, TS_SDIF_DATA, the conversion formula) is implementation detail for whoever writes the firmware patch, and it delays §2.
(c) §4 item 3 'Leakage loop feedback' is not a temporal-reconstruction method. It is a reason spatial data matters.


APPLY (CORRECTED): 1. §1: the sensor list, #mesh grid, then #controllers reduced to the TS_SDIF_DATA and TS_SMPL_HILO bullets and the conversion/truncation bullet. 2. §2: the code excerpt, then the pmic_sys sentence as proposed, then sp-c1's paragraph and sp-v1's chart, then the voltage card. 3. §3: table, then an h3 'Implementation notes' holding the PVTC table and base addresses. 4. §4: items 1–2 only, closing 'Both sharpen the chip-wide average; neither says where on the die the heat is.' Drop item 3; the DVFS page owns the leakage loop and is already in Related. Keep all ids.

Base PROPOSAL (for "as proposed" references): New order, keeping all ids:
1. h2 #sensors '1. Sensor layout and architecture': the sensor list, then h3 #mesh with the grid.
2. h2 #bottleneck '2. The firmware reduction bottleneck': the code excerpt, then the pmic_sys paragraph moved here and shortened to 'The field named pmic_sys is not a board sensor either: the firmware fills it with the same 34-shire average (3,679 of 3,681 samples agreed; the other two differed by 1 °C), and the SP does not forward the PMIC's own regulator temperatures.' Then sp-c1's paragraph and sp-v1's chart, then the voltage card.
3. h2 #needed '3. What is needed …': open with §4 item 3 rewritten as motivation: 'Why it matters: die leakage is 23 W of the 36 W idle power at 80 °C and grows 0.65 W/°C, a thermal feedback loop with gain 0.95, so where the heat sits changes how much of it there is.' Then the table, then h3 #controllers moved here unchanged as the implementation notes for rows 2 and 4.
4. h2 #workaround with items 1–2 only.
5. Sources, Related.


Verifier note: (a) is right. The pmic_sys paragraph belongs in §2, where the code comment already says it, and 3,679/3,681 checks out. (b) Moving the whole #controllers h3 after §3 is too much. It holds the TS_SMPL_HILO peak-hold explanation and the pvt_ts_conversion truncation sentence, which the lede, the KPIs, §2's peak-hold discussion and row 2's 'export the raw 12-bit code' all depend on. sp-r1 names that sentence as the canonical place. (c) is right that item 3 is not a reconstruction method. But the proposed motivation, 'where the heat sits changes how much of it there is', is not supported. With a spread of about 3 °C and T_L = 36 °C, the effect of the exponential's curvature is about 0.35% of leakage, roughly 0.08 W. The reviewer also missed that §4's closing sentence says 'All three sharpen the chip-wide average', which must change.


#### sp-r1 — MODIFIED [redundancy/low] et-soc1-spatial-temperature-brief

Where: §3 table rows 1 and 2 (Option C)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-22-et-soc1-spatial-temperature-brief.html

Problem: The 1 °C truncation is stated seven times: the lede, two KPIs, §1 (its canonical place), §3 row 1, Option C and the 'Whichever option is used' note. The row 1 and Option C parentheticals add nothing.


APPLY (CORRECTED): Row 1: cut ' (the firmware then truncates to 1 °C)'. Option C: replace ' (whole degrees; see the resolution note above)' with ' (whole degrees, since the existing print uses converted values; printing the raw code needs one more changed line)'.

Base PROPOSAL (for "as proposed" references): Row 1: cut ' (the firmware then truncates to 1 °C)'. Option C: cut ' (whole degrees; see the resolution note above)'. Keep the lede, the KPIs, §1's pvt_ts_conversion sentence and the row 2 'Whichever option is used, export the raw 12-bit code …' instruction.


Verifier note: The row 1 parenthetical is redundant with row 2's 'Whichever option is used … already truncated to 1 °C'. The Option C parenthetical is not redundant. Option C calls the existing print, pvt_print_temperature_sampled_values → 'MS %2d Temp [C]: %d [%d, %d]' with converted sample.current, so without further change it can only give whole degrees. That limits this option specifically, and row 2's 'export the raw 12-bit code' instruction conflicts with Option C unless the print is also changed.


#### pt-p4 — CONFIRMED [reproducibility/low] et-soc1-power-temperature

Where: tools/ettelem/run_horace.sh line 33; 03-experiments E5 and E7/E8; 05-claims row 83; horace*-telemetry.jsonl

Files: /home/yaroslavvb/claude/et-soc1-prototyping/tools/ettelem/run_horace.sh, /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/03-experiments.md, /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/05-claims.md

Problem: The E7 figures that this page, E5 and 05-claims quote ('22 runs') come from a degenerate run. run_horace.sh's rotation (k·(2r+1)+3r) mod 10 has multiplier 5 in round 2, so that round alternated onebit and ones five times each. Keyed by (round, values), the summary kept 22 rows from 30 runs. The E7/E8 telemetry was also committed thinned 5× to 2 Hz, while the rows (n = 30 samples each) came from the 10 Hz stream, so the rows can only be approximated from the repo.


APPLY (PROPOSAL): run_horace.sh: add 'mult=(1 3 7 9)' before the loop and change line 33 to 'v=${pats[$(( (k * ${mult[round % 4]} + round * 3) % 10 ))]}'. Or add '[ "$rounds" -le 2 ] || { echo "rounds > 2 repeats patterns" >&2; exit 2; }'.

E7: add 'Round 2 was degenerate (the rotation's multiplier was 5), so it alternated onebit and ones five times each; summary.json keeps 22 rows from 30 runs. The committed horace-telemetry.jsonl is thinned to 2 Hz with compact_telemetry.py, while the rows (30 samples each) were computed at 10 Hz, so they can be approximated from the repo (median |Δ| 0.02–0.04 W, max about 1 W) but not reproduced exactly.' Add the thinning sentence to E8 as well.

In E5 change '22 uncontrolled runs' to '22 run averages from 30 uncontrolled runs'. In 05-claims row 83 change '22 runs at 79–90 °C' to '22 run averages from 30 runs at 79–90 °C'. If pt-c1 is applied, the page no longer quotes E7.


Verifier note: Line 33 is 'v=${pats[$(( (k * (round * 2 + 1) + round * 3) % 10 ))]}'. With round = 2 that is (5k + 6) mod 10, which alternates indices 6 and 1 (onebit and ones). horace-runs.jsonl splits into 30 runs with exactly that pattern in round 2. The summary has 22 rows (10/10/2), and the fit is per_c 0.7818 board, 0.3774 minion. The committed E7 and E8 telemetry is 586 samples over 293 s and 1,247 over 624 s, i.e. 2 Hz. mult=(1 3 7 9) keeps rounds 0 and 1 identical to the current order, and all four multipliers are coprime to 10. I did not recompute the 0.02–0.04 W row-rebuild medians.


#### pt-p5 — MODIFIED [reproducibility/low] et-soc1-power-temperature

Where: tools/ettelem/ettelem.cpp lines 6–8 (header) and 178 (usage)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/tools/ettelem/ettelem.cpp

Problem: The tool's header says the SP rail figures are [avg, min, max] 'SINCE THEIR LAST RESET'. That contradicts canonical D2 and this page: avg is the PMIC's running average (τ ≈ 1 s), and only min and max run since the reset. The usage string also omits 'config' and '--reset-ms', which the header documents.


APPLY (CORRECTED): Lines 6–8: '// The SP's rail figures are [avg, min, max]: avg is the PMIC's own running average (roughly first-order, τ ≈ 1 s); min and max run since the last stats reset. --reset-ms R resets the stats (and sends the PMIC its stats reset) every R ms and tags each sample with its window; whether that makes avg a window mean is untested.' Fix line 125's comment the same way. Line 178 as proposed. In 14-card-behaviour.md and 09-method.md, change the '--reset-ms window means' advice to say it is untested.

Base PROPOSAL (for "as proposed" references): Lines 6–8: '// The SP's rail figures are [avg, min, max]: avg is the PMIC's own running average (roughly first-order, τ ≈ 1 s); min and max run since the last stats reset (a reset also restarts the PMIC's average). With --reset-ms R the stats are reset every R ms and each sample says how long its window has been open.' Line 178: 'usage: ettelem sample [--seconds T] [--every-ms M] [--reset-ms R] | config | loglevel debug|info | sptrace <out.bin>'.


Verifier note: The header (lines 6–8) and the usage string (line 178, missing config and --reset-ms) are as described. The reviewer missed the same error in the comment at line 125: 'the rail averages in this sample cover the window since the last reset'. The proposed header then asserts '(a reset also restarts the PMIC's average)', which nothing in the repo tests. RESET_COUNTER sends the PMIC stats-reset command 0x47 (power-telemetry.md), but what that does to a first-order running average is unknown. 14-card-behaviour.md line 59 and energy-manual/09-method.md recommend '--reset-ms window means'. That also rests on this untested assumption, and no script or experiment ever used --reset-ms.


#### pt-p6 — MODIFIED [reproducibility/low] et-soc1-power-temperature

Where: docs/findings/05-claims.md (the table containing the E5/E7 slope rows)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/05-claims.md

Problem: The claims register has no rows for several numbers these two pages state: the voltage-map ranges, pmic_sys equalling the minion mean, the peak-hold low of 62 °C, the new peak-hold +3 °C (sp-c1), and the 0.81 W/°C busy drift the page quotes.


APPLY (CORRECTED): As proposed, except the fourth row: '| Peak-hold high less the SP's maximum of the mean, 20 Sep | 3 °C after every rise (84/87 … 90/93); 2 °C for 1.5–3 s after each record in the load step, up to 27 s in Horace | M, R | E5, E7, E8 (`temp_c.minshire[2]` − `sp.minion_c[2]`); R3 (`Thermal_Pwr_Mgmt_Init_OP_Stats` resets both, via `pvt_hilo_reset`) |'. For the 0.81 row, write the source as `DATA/horace3.json` and `DATA/report.json` → `leak_w_per_c` = 0.807, following the file's DATA convention.

Base PROPOSAL (for "as proposed" references): Add rows:
'| Per-shire on-die voltage at idle, 34 minion shires (20 Sep) | minion rail 517–521 mV now, lows 513 (shires 0, 1, 2, 18) to 520, highs to 522; SRAM 703–707; mesh 483–486 | M | E6 (`docs/reports/data/2026-09-20-power-aifoundry2/per-shire-voltage-idle.json`, = `summary.json` `shires`) |'
'| Temperature field pmic_sys repeats the minion-shire mean | 3,679 of 3,681 samples (the other two differ by 1 °C) | M, R | E5, E7, E8 (`*-telemetry.jsonl` `temp_c.pmic` vs `temp_c.minshire[0]`); R3 (`get_module_current_temperature`) |'
'| Peak-hold low of the minion-shire sensors, 20 Sep | 62 °C in all 3,681 samples (the SP's minimum of the mean: 63 °C) | M | E5, E7, E8 (`temp_c.minshire[1]`, `sp.minion_c[1]`) |'
'| Peak-hold high less the SP's maximum of the mean | 3 °C after every rise (84/87 … 90/93); 2 °C for about 3 s during a rise | M | E5, E7, E8 (`temp_c.minshire[2]` − `sp.minion_c[2]`) |'
'| Drift of busy power within the hot 7 s runs (80–86 °C) | 0.81 W/°C | F | E9 (`docs/reports/data/2026-09-21-horace-aifoundry2/report.json` → `leak_w_per_c` = 0.807) |'


Verifier note: The rows are needed; grep finds no 517, 3,679, 0.81 W or peak-hold in 05-claims.md. The values check out: minion 517–521 now, lows 513 on shires 0, 1, 2 and 18 up to 520, highs up to 522, SRAM 703–707, mesh 483–486; pmic_sys 3,679/3,681; low 62 in all 3,681 against SP minimum 63; report.json leak_w_per_c = 0.807. The peak-hold high row repeats sp-c1's error ('2 °C for about 3 s'). That row also depends on the firmware resetting the hardware extremes and the SP stats together, so it is kind M, R.


#### hub-c1 — CONFIRMED [consistency/low] et-soc1-limits-of-observability

Where: Hub §4.3 table 'Moortec PVT on the die', row 'Temperature sensors', column 'What the host gets'

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/limits-of-observability.data.json, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-22-et-soc1-spatial-temperature-brief.html

Problem: The hub lists 'PMIC' among the temperatures the host gets, which implies a board or regulator temperature. The spatial brief (and the firmware at 353f20e) shows the field named pmic_sys is the same 34-shire average again, and the SP forwards no PMIC temperature. The two pages disagree.


APPLY (PROPOSAL): Change the value to "minion-shire average, low and high (integer °C; low and high are peak-hold); IO shire; a field named pmic_sys that repeats the minion-shire average", then rebuild the hub.


Verifier note: limits-of-observability.data.json line 664 reads 'minion-shire average, low and high (integer °C); IO shire; PMIC'. The firmware sets pmic_sys from pvt_get_minion_avg_temperature, and telemetry agrees in 3,679 of 3,681 samples. Optionally add that the SP stats' system-temperature triple is hard-wired to 0 (see missed items).


#### pt-l1 — CONFIRMED [layout/low] et-soc1-power-temperature

Where: §6 Reproduce <pre> block

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/power-temperature.body.html, /tmp/claude-1019/-home-yaroslavvb-claude/ed6d06d5-de26-4323-94f1-0dc808eafbda/scratchpad/validate2/work/power-temperature/pt1280-4.png

Problem: At 1280 px the Reproduce block's long lines, with trailing comments, are clipped at the right edge ('quit et-powertop first (one opene…', '… loglevel in…'). The block scrolls, but the key commands are hidden at first sight.


APPLY (PROPOSAL): Put each comment on its own line above its command ('# JSON lines at 10 Hz; quit et-powertop first (the management node allows one opener)'). Split the loglevel/sptrace line into three lines: 'build/ettelem/ettelem loglevel debug', 'build/ettelem/ettelem sptrace sp.bin' and 'build/ettelem/ettelem loglevel info   # restore'. Keep every line under about 90 characters.


Verifier note: pt1280-4.png shows the Reproduce lines clipped at the right edge ('(one opene…', '… loglevel in…'). The first cmake line is about 102 characters, so the 'under about 90 characters' rule should split it after '&&' as well.


### Missed by the reviewers (found by the verifiers)


#### M-pt-1 [claim] et-soc1-spatial-temperature-brief

Problem: The brief says the SP does not forward the PMIC's temperatures, so 'this query never carries a board or regulator temperature'. It never mentions that GET_SP_STATS does carry a 'system' temperature triple, and that the firmware fills it with a constant 0. thermal_pwr_mgmt.c line 702–703 reads 'TODO: update system temperature stats when it is available', CALC_MIN_MAX(…system.temperature, 0), and line 2837 reads 'PMIC is currently reporting system temperature as 0'. sp.system_c is [0,0,0] in all 3,681 samples. A reader who finds that field would take 0 °C as a reading.

APPLY: In the pmic_sys sentence (moved to §2 by sp-o1), add: 'The service processor's stats packet has a system-temperature slot meant for the PMIC, but the firmware writes 0 into it (a TODO in thermal_pwr_mgmt.c), and it read 0 in all 3,681 samples.' Add the same clause to hub-c1's replacement text.


#### M-pt-2 [claim] et-soc1-power-temperature

Problem: §2 bullet 3 gives 'Board minus rails is 15.0 W at idle' with no temperature. The remainder itself grows with die temperature: 15.03 W at 72 °C (idle0) and 15.9 W at 81 °C (cool1 and cool2, 1 s bins). D3 asks for the die temperature with every idle figure, and the 5 W DRAM shift is measured against the 81 °C value (20.94 − 15.91).

APPLY: Change to 'Board minus rails is 15.0 W at idle at 72 °C (15.9 W at 81 °C), 20–21 W under matmul and 21 W under DRAM load.'


#### M-pt-3 [reorganize] et-soc1-power-temperature

Problem: pt-v0, pt-v1 and pt-v2 each propose their own launch-gap detection, scrubber and remainder view. Applied separately, the page gets three crosshair mechanisms and two gap rules that disagree (neither 1 s-bin rule finds all 10 gaps).

APPLY: Implement one shared layer. The reducer writes thermal.gaps from the 10 Hz stream, and thermal.fast. script.js gets one setCross(t) driven by one keyboard scrubber and by pointer events on all charts. The #power chart, the scatter and the remainder panels all read thermal.gaps for their ticks and rings.



## Group hotline-relay-l2


### Reproduction problems


#### R-hrl-1 [medium] docs/reports/data/2026-09-22-hotline-aifoundry2/power.json (also copied into hotline.json power.* and docs/reports/data/2026-09-23-energy-manual/manual.json sync.atomics)

Problem: The per-rail averages are stale. The file predates the 23 Sep fix to analyze_hotline_power.py (4845a60, which takes [avg] from each [avg,min,max] triple) and was never re-run, so every minion_w, sram_w and noc_w value is the mean of avg, min and max. That is the same bug 04-artifacts.md records as fixed for onchip.json, but hotline was left out.

Evidence: Re-running the current script changes 18 fields by 30–56%. Idle minion/SRAM/NoC go from 24.55/3.63/5.45 W to 10.77/1.94/3.58 W. The committed rails add up to 33.6 W, more than the 31.27 W board total, which is impossible. The e5715db script reproduces the committed file exactly. Board power, over-idle watts, nJ/op and rates are unchanged, and no page displays the rails.

Fix: Regenerate power.json with the current script. Re-run analyze_hotline.py, carrying `context` over. Rebuild hot-line (the page text stays the same) and manual.json with build_energy_manual.py. Add a note to A13 in 04-artifacts.md like the one A14 has.


#### R-hrl-2 [medium] workloads/nocbench/analyze_hotline.py / docs/reports/data/2026-09-22-hotline-aifoundry2/hotline.json

Problem: No committed script produces hotline.json's `context` block, yet two consumers need it. Running the documented command (03-experiments E22 and the page's reproduce block) gives a file without it. That output breaks the hot-line page and makes build_energy_manual.py crash. The page's own disclosure names only the errata and the window table as hand-added, not barrier_cycles_chip, remote_atomic_latency_cycles or bank_service_cycles, which feed the k3sub KPI and the energy manual's sync table.

Evidence: A page built from the regenerated JSON has faircap, reqcap, pacecap and enfac empty, and the errata cards and window table are missing (check_page). build_energy_manual.py fails with KeyError: 'context' at line 164. Two of the three scalars can be derived from the sweep: 6e6/27,755 remote ops at n = 1 gives 216.18, and the placement cycles_per_op gives 10.0.

Fix: Have analyze_hotline.py compute remote_atomic_latency_cycles and bank_service_cycles from the sweep. Merge the hand-kept parts (errata, window_independence, barrier_cycles_chip) from a committed context.json through a --context flag. Update the page's disclosure sentence and the E22 command to match.


#### R-hrl-3 [low] docs/reports/sources/hot-line.body.html (line 179); docs/findings/03-experiments.md (line 427)

Problem: "Across all 42 configurations the host's count matches exactly in 13" does not match the data.

Evidence: Comparing the host shire's ops across cards row by row: 2 of the 42 rows (placement own and scp:own) have no host shire. Of the other 40, 15 match exactly, including the fairness rows homed at 15 (18,789) and 31 (18,782). The count is 13 only if the fairness rows are left out, i.e. 13 of the 33 local and pressure rows. "Within 2% in all but one (208 vs 240)" is correct.

Fix: Say "matches exactly in 15 of the 40 configurations that have a host shire" (or "13 of the 33 local and pressure rows"), in both files.


#### R-hrl-4 [low] docs/reports/data/2026-09-22-hotline-aifoundry2/hotline.json context.barrier_cycles_chip (quoted in hot-line §8, energy manual §6, 05-claims.md)

Problem: The 4,997-cycle chip barrier is in no committed raw data file.

Evidence: docs/reports/data/2026-09-18-nocbench-aifoundry2/barrier-chip1.jsonl gives cycles_per_iter_max 4,995.05 (mean 4,994.99) with 32 participants. barrier-chip32.jsonl gives 5,017.8 with 1,024. The on-chip communication page embeds 4,994.99 and 5,017.72. The conclusions (6%, about twice) do not change.

Fix: Quote 4,995 from barrier-chip1.jsonl, or commit the run that measured 4,997.


#### R-hrl-5 [low] docs/reports/sources/hot-line.script.js (wintab) / hotline.json context.window_independence

Problem: The window table's column "Remote atomics in the same window" appears to hold total operations, including the host's 384 loads, and its 10 ms row matches the host-reads-DRAM case rather than the scplocal case listed first in section 3.

Evidence: The 10 ms row, host 384 and remote 601,503, is identical to the a2 scpstream:0 sweep row's total_ops (601,503 = 601,119 remote atomics + 384). The scplocal:0 row has 601,121 remote atomics. The 5, 40 and 100 ms rows show the same +~1,500 offset. This is an inference: those runs are not in the data. The error is 0.06%.

Fix: Rename the column "Operations completed in the window (all shires)", or subtract the host's 384, and name the configuration (host reading DRAM, hot line in the scratchpad).


#### R-hrl-6 [low] docs/findings/17-hot-line.md (pacing table, line 103)

Problem: The pacing row "0 to 8,000 | 0.03%" is wrong. The page and the data say 0.023%.

Evidence: The host is at 0.0227–0.0231% of alone at paces 0, 1,000, 4,000 and 8,000 on both cards (390 and 387 ops at 8,000).

Fix: Change it to 0.02%.


### Review findings


#### RL-1 — MODIFIED [claim/high] et-soc1-on-chip-relay

Where: lede (on-chip-relay.body.html l.8–10); §5 heading (#how-far-the-slab-moves-does-not-change-the-bandwidth), distintro (script.js l.141–147) and paragraph after #dist (body l.90–92); same phrase on hub (limits-of-observability.data.json l.413) and Heat per mm related item (heat-per-mm.body.html l.195); docs/findings/18-on-chip-relay.md l.94–95; 04-artifacts.md l.213

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/on-chip-relay.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/on-chip-relay.script.js, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/onchip/analyze_onchip.py, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-22-onchip-aifoundry2/onchip.json, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-22-onchip-aifoundry3/sweep.jsonl, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/limits-of-observability.data.json, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/heat-per-mm.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/18-on-chip-relay.md, /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/04-artifacts.md

Problem: The page says which shire receives the slab "makes no measurable difference to the bandwidth" and that the bandwidth "does not depend on where that shire is". The page's own table shows a 1.24× spread. That spread is reproducible and it tracks the longest link in the ring. The claim is overstated. It is also the phrasing PLAN nav-06 warns against.


APPLY (CORRECTED): 1. Lede: replace 'and which shire it is makes no measurable difference to the bandwidth' with 'and over the five ring offsets tried, which shire it is moved the bandwidth by up to a quarter (593–733 GB/s), against the twelvefold gain over DRAM; the ring in ID order, used for the headline, was the slowest of the five'.
2. §5 heading text: '5. How far the slab moves: the farthest hand-off sets the pace' (keep the id).
3. distintro, last sentence: 'Across the five offsets the bandwidth runs from 593 to 733 GB/s. It does not follow the mean distance (1.6 to 4.5 hops). It falls with the longest hand-off in the ring: 10, 8, 7 and 6 hops give 593, 652, 686–703 and 733 GB/s, in the same order on both cards. That is what one would expect when every stage waits at a barrier for its slowest shire, but five offsets are a correlation, not a test:'.
4. Table #dist: split 'Mesh hops, mean (range)' into 'Mesh hops, mean' and 'Longest hand-off, hops', and give GB/s as 'a2 / a3' (add aifoundry3 distance rows in analyze_onchip.py). Do not add a third hop column.
5. Paragraph after #dist: replace everything from 'Transfers here are 32 KB…' to '…whichever shire suits.' with 'Transfers here are 32 KB per minion and pipelined, yet the mesh distance still shows: the stage time grows about 3,200 cycles for each hop of the longest hand-off. The practical consequence is to keep the longest hand-off short; in this sweep the ID ring's 10-hop pair cost about a fifth of the bandwidth.' Keep the energy sentences, shortened as RL-6 proposes.
6. §7 'Not established': add 'Whether a ring laid out along the mesh, with every hand-off one hop (such a ring exists on this map), is faster still; the trend over 6–10-hop longest hand-offs suggests it could be.'
7. The same wording in 18-on-chip-relay.md (l.83 heading, l.94–96), 03-experiments.md l.494 and 04-artifacts.md l.213 ('distance costs energy, and the longest hand-off costs bandwidth: up to 1.24× over the offsets tried').
8. Hub row: 'which shire receives the slab changed bandwidth by up to a quarter over the offsets tried'.
9. Heat per mm Related item: 'with bandwidth within a quarter over the ring offsets tried'.

Base PROPOSAL (for "as proposed" references): Five edits on this page, plus the same phrase elsewhere:

1. **Lede.** Replace "and which shire it is makes no measurable difference to the bandwidth" with "and which shire it is moves the bandwidth by at most a quarter (593–733 GB/s over five ring offsets), against the twelvefold gain over DRAM".
2. **§5 heading text.** Change it to "5. How far the slab moves: the farthest pair sets the pace", keeping id how-far-the-slab-moves-does-not-change-the-bandwidth.
3. **distintro.** Replace the last sentence (from "Across offsets whose mean distance…") with: "Across the five offsets the bandwidth runs from 593 to 733 GB/s. It does not follow the mean distance (1.6 to 4.5 hops). It falls with the longest link in the ring: 10, 8, 7 and 6 hops give 593, 652, 686–703 and 733 GB/s, in the same order on both cards, as it should when every stage waits at a barrier for its slowest shire. Five offsets cannot separate the length of that link from the link sharing that comes with long routes:". Add a column 'Longest link, hops' to #dist, computed in analyze_onchip.py ring_hops() (it already returns max).
4. **Paragraph after #dist.** Replace "what is left is the bandwidth of a scratchpad that is not this shire's own, and it does not depend on where that shire is. The practical consequence is that placement is free in bandwidth: a stage can be given to whichever shire suits." with "The practical consequence is that placement is nearly free in bandwidth: keep the longest hand-off short, since the ID ring's 10-hop pair costs about a fifth."
5. **Findings files.** Mirror the change in 18-on-chip-relay.md l.94–95. In 04-artifacts.md l.213 change 'distance costs energy, not bandwidth' to 'distance costs energy, and the longest hand-off sets the bandwidth, within 1.24×'.

Other owners:
- Hub row: 'which shire receives the slab makes no difference to bandwidth' → 'which shire receives the slab changes bandwidth by at most a quarter'.
- Heat per mm: 'with bandwidth independent of which shire' → 'with bandwidth within a quarter whichever shire receives it'.


Verifier note: The problem is real. From both sweep files, offsets 1/2/4/8/16 give 592.7/703.2/652.4/686.2/733.5 GB/s on aifoundry2 and 592.6/702.5/652.3/686.2/726.7 on aifoundry3, a spread of 1.24× and 1.23×. The longest link on the MARTY map is 10/7/8/7/6 hops. Correlation with the longest link is r = −0.990 (a2) and −0.991 (a3); with the mean it is −0.32 and −0.30. cycles_max/cycles_mean is 1.000–1.007. The hop counts (6 of 32 shires at 1 hop for offset 1, 24 of 32 for offset 8) are right.

Four things need changing:
(a) The reviewer says PLAN nav-06 warns against this phrasing. It does not: nav-06's corrected fix introduced 'which shire receives the slab makes no difference to bandwidth'. The claim is still overstated.
(b) The proposal leaves 'Transfers here are 32 KB per minion and deeply pipelined, so the 12-cycle round trip per hop never appears' in place. The new finding contradicts that: stage time rises about 3,200 cycles per hop of the longest link (67.9k cycles per stage at 10 hops, 54.9k at 6).
(c) 'Placement is nearly free in bandwidth' is itself not established. The five offsets only span longest links of 6–10 hops, and a straight-line fit (941 − 35 GB/s per hop) would put a ring whose every hand-off is one hop well above 733 GB/s. analyze.py one_hop_ring() builds exactly that ring, and it was never run.
(d) The busiest XY link carries 3/4/4/1/2 routes. That does not track bandwidth (r ≈ −0.27), so the 'link sharing' hedge is weaker than written. Say only that five offsets are a correlation, not a controlled test.

The proposal also misses two files that make the same claim: 03-experiments.md l.494 ('does not follow the distance') and the 18-on-chip-relay.md l.83 heading. Its proposed 'Longest link' column repeats data the table already has: the 'mean (range)' column already shows the maximum.


#### RL-8 — MODIFIED [visualization/high] et-soc1-on-chip-relay

Where: §5 (#how-far-the-slab-moves-does-not-change-the-bandwidth), above table #dist

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-22-onchip-aifoundry2/onchip.json, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/onchip/analyze_onchip.py, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/nocbench/analyze.py, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/on-chip-relay.script.js

Problem: §5's question, whether the network in between matters, is answered by a five-row table of offsets and mean hops. A reader cannot see:
- that the 'next shire by ID' is a mesh neighbour for only 6 of 32 shires;
- which pairs are far apart;
- that the bandwidth follows the longest pair, not the average.


APPLY (CORRECTED): Build the 'Which shire reads from which' map without routes.
- Left: a 6×6 grid. Each shire cell is filled by the hop count of its incoming hand-off on a sequential ramp; empty cells are dashed. For the selected offset, draw only the longest hand-off(s) as a straight source→destination arrow in var(--c2).
- On hover or focus, draw that shire's own straight arrow with a tooltip, e.g. 'shire 31 reads from shire 30 · 7 hops'.
- Right: GB/s against the longest hand-off for the five offsets, a2 filled and a3 hollow, with a toggle to mean hops (r −0.3 against −0.99).
- Drop the histogram.
- Buttons 1/2/4/8/16 as a radiogroup; stack the panels at 390 px.
- Data: add aifoundry3 distance rows and layout/empty to onchip.json in analyze_onchip.py.
- Caption: 'consistent with the slowest pair setting the pace at each barrier; five offsets, not a controlled test'.

Base PROPOSAL (for "as proposed" references): Build an interactive 'Which shire reads from which' mesh map. It complements #dist; keep the table.

**Question.** How far does each hand-off travel for a given ring offset, and what sets the bandwidth?

**Data:**
- onchip.json distance[] {hop_distance, gb_s, mesh_hops{mean,min,max}}.
- Add distance rows for every card in analyze_onchip.py; today only cards[0] is kept, and a3 is in docs/reports/data/2026-09-22-onchip-aifoundry3/sweep.jsonl group 'distance'.
- Add 'layout': MARTY {s:[x,y]} and 'empty': [[0,3],[0,4],[0,5],[5,3]] to onchip.json from shire_map(), which already exists in analyze_onchip.py.
- Per-pair hops are computed in the page as |dx| + |dy| between shire s and ids[(i−k) mod 32].

**Encoding** (inline SVG, vanilla JS):
- Left: a 6×6 grid of 44 px cells, each compute shire a rounded square labelled with its ID and empty cells dashed in var(--grid). For the selected offset k, draw an arrow from the source shire to each shire along its XY route, coloured by hop count (1–10) on a light-to-dark ramp of var(--c1). The longest route(s) are drawn in var(--c2), 2.5 px.
- Below: a 32-pair histogram of hop counts (bars var(--c1), x 1–10).
- Right: a scatter of GB/s (y 580–740) against the longest link (x 5–11) for the five offsets. a2 is filled, a3 hollow, the selected offset enlarged. A toggle switches x to 'mean hops' so the reader sees no relation to the mean (r −0.3) and a tight one to the longest (r −0.99).

**Interaction:**
- Buttons '1', '2', '4', '8', '16' (role=radiogroup, arrow keys).
- Hover or focus a shire (tabindex=0) for a tooltip such as 'shire 31 reads from shire 30 · 7 hops'.
- Readout under the buttons: 'offset 1: mean 3.5 hops, longest 10 → 592.7 GB/s (a2), 592.6 (a3)'.

**Tokens and phone width.** Use var(--c1), var(--c2), var(--grid), var(--ink) and var(--ref). At 390 px the three panels stack; the 264 px grid fits.

**What the reader learns.**
- 'Next shire' is not a neighbour.
- Offset 8 is mostly 1-hop and still not the fastest.
- The barrier makes the slowest pair set the pace.
- The whole effect is ≤ 1.24× against 12× over DRAM.


Verifier note: The data exist and the evidence is correct: the offset 1 histogram {1:6, 2:9, 3:7, 4:2, 6:2, 7:3, 8:2, 10:1}, offset 8 {1:24, …}, offset 16 {1:4, 2:26, 6:2}, and r = −0.99 against the longest hand-off. The layout and empty cells come from analyze.py.

Three problems with the design:
(1) It draws each hand-off 'along its XY route'. The routing dimension order has never been measured: wire-energy SYNTHESIS says 'Dimension order is unknown; Chang infers XY'. Drawn routes would present an assumption as fact.
(2) Thirty-two routes on a 264-px grid would overlap heavily at offsets 1 and 2 and be unreadable on a phone.
(3) The histogram repeats what coloured cells already show.

The mechanism is a correlation over five points, so the caption should say 'consistent with', not 'the barrier makes'.


#### HL-15 — MODIFIED [visualization/high] et-soc1-hot-line

Where: §4 (#the-threshold-is-the-bank-going-saturated): replaces chart #req and caption #reqcap; linked to §6 chart #pace

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-22-hotline-aifoundry2/hotline.json, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/hot-line.script.js, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/hot-line.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/nocbench/analyze_hotline.py

Problem: The §4 chart has problems of its own:
- It uses a dual y axis, with the right axis inverted.
- It draws a straight line from 20 to 24 requesters across counts that were never tested.
- At 390 px the cliff is scrolled out of view.

It also cannot show the page's main mechanism: one inequality explains both the 21–24 cliff (§4) and the 8,000→10,000 pacing knee (§6). Those two results sit in separate charts on different x axes.


APPLY (CORRECTED): Build the explorer as proposed, with these bands, from the data:
- ρ ≥ 1: 'saturated: in all 24 such runs the host got about 0.02%'.
- 0.9 ≤ ρ < 1: '98.9% for one shire's 20 requesters, 54–55% for 992 paced ones'.
- 0.5 ≤ ρ < 0.9: '99.6% for 16 requesters; 85–87% at 0.81 and 95% at 0.61 for 992 paced'.
- ρ < 0.5: 'at least 97% in every run'.

Other changes:
- The N steps stop at 992.
- Show measured ρ only in the tooltip.
- Label the two series with their host size ('host runs N minions' against 'host runs 32 minions').
- Mark the x value as predicted offered load, not a measurement.
- Keep 390-px stacking.

With #req replaced, HL-17's fix for #req is moot.

Base PROPOSAL (for "as proposed" references): Build an interactive 'Will this hot line stop its shire?' explorer that replaces #req.

**Data:**
- hotline.json requesters[] and pace[]: card, remote_minions, pace, frac_of_alone, total_ops, host_ops.
- context.remote_atomic_latency_cycles (216.2) and context.bank_service_cycles (10.0).
- The window, 6,000,000 cycles: add context.window_cycles in analyze_hotline.py from the sweep rows' window_cycles.

**Encoding:**
- One SVG chart. x is log 0.03–50: 'load the remote minions put on the bank (1 = saturated)', ticks 0.05, 0.1, 0.25, 0.5, 1, 2, 5, 10, 40. y is linear 0–115%: 'host shire's own memory throughput'.
- Shade x ≥ 1 with var(--grid), labelled 'bank saturated: the host's loads stop'. Draw a dashed var(--ref) line at x = 1.
- Series:
  - 'one other shire, N minions, no pause' (§4): circles in var(--c1).
  - '992 minions of 31 shires, paced' (§6): squares in var(--c3).
  - aifoundry3 as hollow markers of the same colour.
  - A small tick at each point's measured ρ.

**Interaction:**
- Two keyboard-usable range inputs with aria-labels:
  - N remote minions, stepping 1, 2, 4, 8, 12, 16, 20, 24, 32, 64, 256, 992, 1,024.
  - P, the pause between atomics: 0, 1k, 4k, 8k, 10k, 12k, 16k, 20k, 40k, 100k cycles.
- A ring marker moves to ρ = N·10/(P + 216).
- Readout: '<N> × 10 = <N·10> cycles of bank per round against <P> + 216 = <P+216> cycles → the bank is <ρ%> busy', then a verdict:
  - ρ ≥ 1: 'saturated: in every such run the host got 0.02%';
  - 0.8 ≤ ρ < 1: 'at the knee: 54–99% depending on how many requesters';
  - ρ < 0.65: 'measured ≥ 95%'.
- The nearest measured run is highlighted with its tooltip, e.g. '992 minions, pause 12,000: load 0.81 predicted, 0.81 measured; host 85%'.
- Points are tabindex=0 with the same tooltip.
- Optionally, hovering a point in §6's #pace highlights the same run here.

**Tokens and phone width.** Use var(--c1), var(--c3), var(--grid), var(--ref) and var(--ink). At 390 px use a viewBox of 360×280 with sliders stacked under the chart.

**What the reader learns.**
- The cliff and the pacing knee are the same inequality.
- Its prediction matches the measured load within 1%.
- A few closed-loop requesters are harmless right up to saturation, but many paced ones need headroom (HL-1).


Verifier note: Recomputed from hotline.json, the predicted load N·10/(P + 216.2) matches the measured (total − host)·10/6e6 in every unsaturated run to within 1.04% at worst (P = 10,000). The numbers in the table are right. Putting both sweeps on one offered-load axis is a good way to show the cliff and the pacing knee as the same limit. The current chart's inverted dual axis, and the cliff hidden at 390 px, are real problems.

The proposal's verdict bands are wrong or incomplete:
- 'ρ < 0.65: measured ≥ 95%' fails at P = 16,000: ρ = 0.612, host 94.8% on a2.
- Loads from 0.65 to 0.8 have no band at all.

The slider offers N = 1,024, which was never run (the maximum is 992 remote minions).

The 'tick at measured ρ' mark sits on top of the point for unsaturated runs, and for saturated runs it floats far from its point at 1.0. It adds nothing and can confuse.

The two sweeps also differ in host size (N host minions against 32), which the chart must say, since it explains part of the gap below ρ = 1.


#### HL-1 — MODIFIED [claim/medium] et-soc1-hot-line

Where: §4: hot-line.body.html l.95–98 (the $$ equation and the sentence after it); §8 third bullet (l.154–156); docs/findings/17-hot-line.md 'Rules this gives you' bullet 3

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/hot-line.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/17-hot-line.md, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-22-hotline-aifoundry2/hotline.json

Problem: 'N_remote/t_round trip < 1/10 cycles ⟹ the host shire is unaffected' is stated as sufficient. It holds for one shire's closed-loop requesters. For many paced requesters the same inequality holds and the host is still well below 100%. §8's rule '10 cycles × number of requesters' only reaches the knee (54%). The inequality is also never tied to §6, though it predicts §6's knee exactly.


APPLY (CORRECTED): 1. Replace the $$ line with the proposed HTML inequality and paragraph, with 'to within about 1%', and replace the last sentence with: 'Not saturating the bank is necessary, not sufficient: one shire's 20 requesters leave the host at 99% with the bank 93% busy, while 992 paced requesters leave it at 85% with the bank 81% busy and 95% at 61%. The two tests differ in how many requesters there are and in how many minions the host runs (20 against 32), and which of these matters was not tested.'
2. §8 third bullet: '<b>If you must, pace it:</b> keep N × 10 cycles below the pause plus the 216-cycle round trip. For the 992 here that is 10,000 cycles (about 17 µs), which gives the host shire back half its memory path for 4% of the hammering shires' rate; 12,000 gives it 85% for 20%, and 16,000 gives it 95% for 39% (section 6).' Use the new section number if HL-14 is applied.
3. 17-hot-line.md, as proposed.

Base PROPOSAL (for "as proposed" references): 1. **Replace the $$…$$ line and the sentence after it** with plain HTML (this also removes the mathjax-full dependency and the phone clipping):

<p style="text-align:center"><i>N</i> × 10 cycles &lt; <i>P</i> + <i>t</i><sub>round trip</sub> ⟹ the bank is not saturated</p>
<p>Here <i>N</i> is the number of remote minions hammering the line, <i>P</i> the cycles each waits between atomics, and <i>t</i> the measured 216-cycle round trip. With <i>P</i> = 0 it puts the edge at 22 requesters, between the 20 and 24 that were tested. It also prices section 6: for 992 requesters it needs <i>P</i> above about 9,700 cycles, which is why 8,000 does nothing and 10,000 is the knee. In every unsaturated run of both sweeps it predicts the bank's measured load to within 1%. Not saturating the bank is necessary, not sufficient. One shire's 20 requesters leave the host at 99% with the bank 93% busy. The 992 paced ones leave it at 85% with the bank 81% busy, and at 95% with it 61% busy, because many independent requesters arrive in bunches.</p>

2. **§8 third bullet.** Replace it with: "<b>If you must, pace it:</b> with <i>N</i> requesters, a wait of 10 × <i>N</i> cycles between atomics takes the bank out of saturation and gives the host shire back about half its memory path; about 16 × <i>N</i> gives it 95% (section 6)."

3. **17-hot-line.md.** Change the rule 'Below 20 concurrent remote requesters, or pace to 10,000 cycles. Either keeps the bank unsaturated.' to 'Keep N × 10 cycles below P + 216: with no pause, at most about 20 remote requesters; for 992, P ≥ 10,000 unsaturates the bank (host 54%) and P ≈ 16,000 gives the host 95%.'


Verifier note: The generalisation N·10 < P + 216 is right and predicts §6. It needs P > 9,704 at N = 992; 8,000 does nothing and 10,000 is the knee. It matches measured load to within about 1% (1.04% worst), and 'necessary, not sufficient' is borne out: 85.5% host at load 0.81, 94.8% at 0.61. HTML in place of TeX does remove this page's only equation, which is clipped at 390 px (screenshot confirmed). Other pages still use TeX, so mathjax-full stays a build dependency for them.

Three corrections:
(1) The problem statement overstates §8. Its bullet already says 10,000 cycles gives back 'half its memory path … 12,000 gives it 85%'.
(2) The proposed §8 replacement drops the price: 4% of the hammering shires' rate at 10,000, 20% at 12,000 and 39% at 16,000. That is the point of 'the workaround, priced'. It also generalises '16 × N gives 95%' from N = 992 alone.
(3) 'because many independent requesters arrive in bunches' is an untested mechanism. The two sweeps also differ in host size (20 host minions against 32, with a 1.6× larger demand on the same shire cache), so the cause is not established. Also 'within 1%' should read 'within about 1%'.


#### HL-2 — MODIFIED [claim/medium] et-soc1-hot-line

Where: §8 first bullet, hot-line.body.html l.148–151; same text in docs/findings/17-hot-line.md l.130–132

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/hot-line.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/17-hot-line.md

Problem: 'One global atomic per shire, never per minion. At 32 participants the serialisation is 320 cycles … six percent, invisible.' This reads as though 32 participants are safe. They are safe only if each makes a single atomic. If the 31 remote leaders then spin on the same line, they are past this page's own 22-requester edge. The host shire's loads stop, which is how the relay's first barrier hung.


APPLY (CORRECTED): Use the proposed bullet, with the barrier sentence rewritten as '…against a <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-on-chip-communication#every-primitive-against-a-gpu">chip-wide barrier of about 5,000 cycles</a> (4,995 with one minion per shire): six percent.' Keep the relay link and the 1,024-participant sentence. Mirror the change in 17-hot-line.md l.130–132.

Base PROPOSAL (for "as proposed" references): Replace the bullet with:

"<b>One global atomic per shire, never per minion, and never spin on the line.</b> At 32 participants a barrier's arrivals serialise in 320 cycles, against a chip-wide barrier of about 5,000 (section 9 of On-chip communication): six percent. But 31 shires polling one line are already past the edge in section 4, so wait on a per-shire flag or a credit instead. The relay's first barrier, with every shire's leader polling one counter, hung (<a href='https://spacesheep.dev/@yaroslavvb/et-soc1-on-chip-relay'>Hand it to the next shire</a>). At 1,024 participants the arrivals alone take 10,240 cycles, twice the whole barrier, with the hosting shire stopped throughout."

Mirror the change in 17-hot-line.md.


Verifier note: The finding stands. The fairness row with home 0 and one minion per shire made 600,061 atomics in 6e6 cycles, 10.0 cycles each, so 32 single requesters already saturate the bank. The relay page records that its first barrier, with every leader polling one counter, hung. Adding 'never spin on the line' is useful.

The proposed text cites '(section 9 of On-chip communication)', but that page's headings are unnumbered. The barrier is under #every-primitive-against-a-gpu, which the current bullet already links. The value should be 4,995 per HL-4. 10,240/4,995 = 2.05, so 'twice' holds.


#### HL-7 — CONFIRMED [reproducibility/medium] et-soc1-hot-line

Where: docs/reports/data/2026-09-22-hotline-aifoundry2/power.json (copied into hotline.json power.* and manual.json sync.atomics); 04-artifacts.md A13 row

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-22-hotline-aifoundry2/power.json, /home/yaroslavvb/claude/et-soc1-prototyping/tools/ettelem/analyze_hotline_power.py, /home/yaroslavvb/claude/et-soc1-prototyping/tools/ettelem/build_energy_manual.py, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-23-energy-manual/manual.json, /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/04-artifacts.md

Problem: power.json's minion, SRAM and NoC rail averages are stale. It was made by the pre-4845a60 script, which averaged the [avg,min,max] triple, and was never re-run. The documented command therefore does not reproduce it. The rails are physically impossible: they sum to more than the board total.


APPLY (PROPOSAL): Run from the repo root:
```
python3 tools/ettelem/analyze_hotline_power.py docs/reports/data/2026-09-22-hotline-aifoundry2 --out docs/reports/data/2026-09-22-hotline-aifoundry2/power.json
```
Then re-run analyze_hotline.py with the context fix from HL-8, then:
```
python3 tools/ettelem/build_energy_manual.py --out docs/reports/data/2026-09-23-energy-manual/manual.json
```
Then rebuild both pages with scripts/build-report.py (hot-line, energy-manual). The page text does not change.

Append to the A13 row in 04-artifacts.md: "Its power.json was regenerated on <date> by the current analyze_hotline_power.py. The rail averages now take the [avg] element; the committed file predated 4845a60 and averaged [avg,min,max], so its rails summed to 33.6 W against a 31.27 W board. Board power, nJ per operation and rates are unchanged. hotline.json and manual.json were rebuilt from it."


Verifier note: Re-running the current analyze_hotline_power.py into scratch changes exactly 18 fields, all rail averages. Idle minion/SRAM/NoC go from 24.55/3.63/5.45 to 10.77/1.94/3.58 W. The committed rails sum to 33.63 W against a 31.27 W board. board_w, over_idle_w, nj_per_op and ops_per_s are unchanged. No page displays these rails: hot-line.script.js reads no rail, and energy-manual.script.js uses only sync.atomics.runs[].over_idle_w/nj_per_op/ops_per_s from this block. build_energy_manual.py copies hot['power'] into manual.json sync.atomics, so the rebuild chain as proposed is right.


#### HL-8 — CONFIRMED [reproducibility/medium] et-soc1-hot-line

Where: workloads/nocbench/analyze_hotline.py; hotline.json 'context'; page reproduce block and disclosure (hot-line.body.html l.204–216); 03-experiments.md E22 command

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/nocbench/analyze_hotline.py, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-22-hotline-aifoundry2/hotline.json, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/hot-line.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/hot-line.script.js, /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/03-experiments.md, /home/yaroslavvb/claude/et-soc1-prototyping/tools/ettelem/build_energy_manual.py

Problem: No script produces hotline.json's 'context' block. Two consumers need it:
- **The hot-line page.** With context missing, faircap, reqcap, pacecap and enfac come out empty, and the errata cards and window table are gone.
- **build_energy_manual.py.** It fails with KeyError 'context' at l.164.

The page's disclosure names the errata and the window table as hand-kept, but not the three scalars that feed KPI 3 and the energy manual.


APPLY (PROPOSAL): 1. **Change analyze_hotline.py:**
   - Compute out['context']['remote_atomic_latency_cycles'] = round(window/(remote ops per minion), 1) from the first card's requesters row with remote_minions == 1.
   - Compute bank_service_cycles as the median cycles_per_op of the placement rows with a single home.
   - Record window_cycles from the sweep rows.
   - Add '--barrier PATH' to read NOCBENCH cycles_per_iter_max from docs/reports/data/2026-09-18-nocbench-aifoundry2/barrier-chip1.jsonl, rounded to 4,995.
   - Add '--context PATH' to merge a committed docs/reports/data/2026-09-22-hotline-aifoundry2/context.json holding only 'errata' and 'window_independence', with a 'note' saying both are hand-kept.
2. **Commit context.json** with the current errata and window rows.
3. **Update the E22 command in 03-experiments.md and the page's pre block** to:
```
python3 workloads/nocbench/analyze_hotline.py DATA/sweep.jsonl DATA3/sweep.jsonl --power DATA/power.json --context DATA/context.json --barrier docs/reports/data/2026-09-18-nocbench-aifoundry2/barrier-chip1.jsonl --out hotline.json
```
4. **Replace the disclosure sentence** 'Two parts of the page's data file are not produced by analyze_hotline.py: …' with: "The errata text, quoted by hand from the errata document, and the window table, whose 5, 40 and 100 ms runs are in no raw data file, come from context.json. The barrier is read from the 18 September nocbench run. The round trip and the bank's 10 cycles are computed from the sweep."
5. **Optional:** guard hot-line.script.js so that a missing D.context hides the errata cards and the window table instead of throwing.


Verifier note: Running analyze_hotline.py into scratch gives a hotline.json identical to the committed one except that 'context' is missing. The page built from it has empty faircap, reqcap, pacecap and enfac (check_page), and build_energy_manual.py reads hot['context'][…] at l.164–166.

216.2 = 6e6/27,755 (the N = 1 requesters row), and bank_service is 10.0. barrier-chip1.jsonl is a single 'NOCBENCH {…}' line with cycles_per_iter_max 4,995.05, which analyze.py's load() already parses. The committed page rebuilds byte-identical from the committed JSON, so the only gap is the generator. The proposal is sound; the defensive guard in item 5 is worth doing.


#### HL-16 — MODIFIED [visualization/medium] et-soc1-hot-line

Where: §1 (#the-atomic-itself-is-fair): replaces chart #fair (dot plot by shire ID)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-22-hotline-aifoundry2/hotline.json, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/nocbench/analyze_hotline.py, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/nocbench/analyze.py, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/hot-line.script.js

Problem: The §1 chart orders shires by ID, and shire IDs do not follow the mesh (D9). The one-minion-per-shire series therefore looks like random scatter. The text's claim, 'Shares fall step by step with distance from the line', has nothing on the page to point to.


APPLY (CORRECTED): Keep the two panels, share against mesh hops and the 6×6 map with the diverging fill, and the two buttons. On hover, highlight the square and its point and draw a straight line to shire 0, no route. Drop the home toggle. Add aifoundry3's one-per-shire shares (sweep fairness row home 0, per_shire 1) as hollow markers. Embed or emit the MARTY layout as proposed, and cut the caption sentence (HL-11).

Base PROPOSAL (for "as proposed" references): Build a 'Fair under load, ranked by distance with one request each' mesh map.

**Data:**
- hotline.json shares_home0[] {s, share, kind}.
- Add 'layout' (MARTY {s:[x,y]}) and 'empty' cells to hotline.json in analyze_hotline.py by importing shire_map() the way analyze_onchip.py does. Or embed the 32-entry map in hot-line.script.js with a comment citing workloads/nocbench/analyze.py.
- Optionally add per-shire shares for homes 7, 15 and 31 from the sweep rows' shire[] arrays, to allow a home toggle.

**Encoding:**
- Left: a 6×6 grid (44 px cells). Each compute shire is a square labelled with its ID, filled on a diverging scale around 1.0: below 1 blends toward var(--c2), above toward var(--c1), and 1.0 is var(--surface) with a var(--grid) stroke. The home shire gets a 2 px var(--ink) outline; empty cells are dashed.
- Right: share (y 0.80–1.25) against mesh hops from the home (x 0–10), points in the same colours. Draw the dashed var(--ref) curve share = 320/(267 + 11.1·hops) and a parity line at 1.0.

**Interaction:**
- Buttons '1,024 minions (32 per shire)' and '32 minions (1 per shire)'.
- Hovering or focusing a square or point (tabindex=0) highlights it in both panels, draws its XY route to shire 0 on the grid, and shows a tooltip such as 'shire 23 · 9 hops · share 0.873 with 1 per shire, 0.998 with 32'.

**Tokens and phone width.** Use var(--c1), var(--c2), var(--grid), var(--ref) and var(--ink). At 390 px the panels stack.

**What the reader learns.** Under saturation the map is one colour, so the arbitration is fair, shire 0 included. With one request per shire, rings of equal colour spread out from shire 0: the order is set by mesh round-trip time, about 11 cycles per hop, not by priority.

Also cut the duplicate caption sentence (HL-11).


Verifier note: The shares are verified. With one minion per shire, shares at equal hop counts from shire 0 agree within 0.0002 (1.1969 at 0 hops … 0.8476 at 10). r = −0.995; the fit 320/share = 267.05 + 11.06·hops holds within 0.0014, and full shares are 0.9984–1.004. The current ID-ordered dot plot hides this, so a hops axis earns its place.

Two parts of the proposal do not work:
(1) 'Draws its XY route to shire 0' asserts a routing order that has never been measured ('Dimension order is unknown').
(2) The optional home toggle is empty of information. The sweeps have one-per-shire runs only for home 0; homes 7, 15 and 31 exist only at 32 per shire, where every shire is about 1.0.


#### HL-17 — CONFIRMED [layout/medium] et-soc1-hot-line

Where: hot-line.script.js host() (l.4) and charts #fair, #req and #pace; template .chart.scroll svg {min-width:640px}; same pattern in on-chip-relay.script.js

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/hot-line.script.js, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/report.template.html

Problem: At 390 px every hot-line chart is 640 px wide inside a 358 px frame, and the key feature is off-screen:
- **§4:** the cliff at 24 is hidden.
- **§6:** the whole 10k–100k crossover is hidden, so the reader sees two flat lines.
- **§1:** shires above about 20 are hidden.

The §6 chart also draws pace 0 at x = 500 with no tick label, so the leftmost points look like a pace of about 500 cycles.


APPLY (PROPOSAL): 1. In host(), measure the container and pick the width: `const narrow=h.clientWidth<600, W=narrow?380:700`. Pass W to each chart's scales in place of the constant 700.
2. Remove the 'scroll' class from #fair, #req and #pace (and from #size and #intensity on the relay).
3. When narrow:
   - Move legends below the plot (the §1 legend at W−R−190 and the §6 legend at x(18000) overlap the data at 380).
   - Thin the x ticks: §4 [1,16,32]; §6 [1000,10000,100000].
4. In the §6 chart, label the leftmost points: `txt(svg,x(500),H-B+16,'0','tick','middle')`, plus a small axis-break mark between 0 and 1k. Alternatively drop the pace-0 point, which equals 1,000 in every measure.
5. The equation clipping goes away with HL-1's HTML formula.


Verifier note: Screenshots at 390 px confirm the problem. §4's chart ends at about 18 remote minions and hides the cliff; §6's chart shows only 0–4k, two flat lines; the equation is clipped. Pace 0 is plotted at Math.max(v,500) with no tick. The template's .chart.scroll forces 640 px. The fix is right. Also re-render on resize or orientation change (debounced), because host() measures width only once. If HL-15 is adopted, #req's part is moot.


#### HL-10 — CONFIRMED [redundancy/medium] et-soc1-hot-line

Where: §9 bullet 'An earlier reading of the same result' (hot-line.body.html l.184–192), byline parenthetical (l.2), Related reports last item (l.234–235)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/hot-line.body.html

Problem: The L2 brief is described three times: in the byline, in a nine-line history bullet in §9, and in Related reports. The bullet is internal history, and Related reports already says 'section 9 says where it and this page differ'.


APPLY (PROPOSAL): 1. **Cut the whole §9 bullet**, from '<li><b>An earlier reading of the same result.</b>' through 'Its warning about two-dimensional TensorSend arrays stands.</li>'.
2. **Replace the Related item** with: '<li><a href="https://spacesheep.dev/@yaroslavvb/2026-09-22-et-soc1-l2-mainline-starvation">L2 mainline starvation</a> — the same-day argument from Ivan's report, written before this measurement. Its advice to home hot structures in a shire that does no compute, or to use per-shire counters and a tree, agrees with section 8, and its TensorSend warning stands; its 6% and its reading of <code>l3_yield</code> do not.</li>'.
3. Keep the byline mention, which PLAN X4 requires.


Verifier note: The byline, the nine-line §9 bullet and the Related item all describe the L2 brief. The bullet (added by PLAN hl-2) is mostly history ('The brief now carries an update pointing here'). The proposed Related item keeps the substance: the 6% and the l3_yield reading do not hold, the advice agrees, the TensorSend warning stands. The byline keeps X4's two-way link. At three items the Related list stays within X1's cap of 8.


#### HL-12 — CONFIRMED [redundancy/medium] et-soc1-hot-line

Where: tables #fairtab, #placetab and #localtab (script.js l.56–74); §9 fourth bullet (body l.178–180)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/hot-line.script.js, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/hot-line.body.html

Problem: Each table lists aifoundry2 and aifoundry3 as separate row blocks with near-identical values: 10, 8 and 8 rows. That doubles the page length. At 390 px the columns that matter (share, spread, while hammered) are scrolled off. It also buries the card-to-card agreement, which §9 then has to restate in prose.


APPLY (PROPOSAL): Group rows by configuration and show paired values 'a2 / a3'.

| Table | Columns | Rows |
|---|---|---|
| fairtab | Line homed in · Minions per shire · Host share, a2 / a3 · Spread, a2 / a3 | 5 |
| placetab | Where the atomic lives · Atomics in 10 ms, a2 / a3 · Cycles per atomic (both cards) · Rate | 4 |
| localtab | Host is reading · Hot line is in · Alone, a2 / a3 · While hammered, a2 / a3 · Fraction, a2 / a3 | 4 |

In script.js, key the rows by `${r.home}|${r.per_shire}` and find the matching aifoundry3 row.

Then cut from §9: 'The stalled host's 384 and 192 operations and the 10.0 cycles per atomic repeat exactly.' The tables now show it.


Verifier note: The data match. fairtab a2 1.004/1.001/1.0002/0.9998/1.1969 against a3 1.0037/1.0007/1.0002/0.9998/1.1967. placetab: 10.00/10.00/0.31/0.31 on both cards. localtab 'while hammered': 384/208/384/192 against 384/240/384/192. At 390 px the share and spread columns are off-screen (screenshot confirmed). Pairing a2/a3 halves the rows and makes the §9 sentence redundant.


#### HL-13 — MODIFIED [redundancy/low] et-soc1-hot-line

Where: §7 (#what-it-costs-in-energy): #pwrtab, the paragraph 'A thousand minions stalled…' and the paragraph 'Re-measured for the energy manual…' (body l.135–144)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/hot-line.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/hot-line.script.js, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-23-energy-manual/reruns.json, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/nocbench/analyze_hotline.py

Problem: The first-session table and the rerun paragraph give the same two energies twice, and the 1.4 W / 1.2 W stall power appears twice. The canonical values (D12: 19.8 [16.9–23.6] against 1.16 [1.01–1.37], n = 7) are only in prose.


APPLY (CORRECTED): 1. Add the column 'nJ per operation, all passes: mean [range], n = 7'. Take the values either from a small constant in hot-line.script.js with a comment citing reruns.json hotline_nj_per_op and the analyze_reruns command, or by pointing analyze_reruns' FIRST['hotline'] at power.json (power.json → reruns.json → hotline.json, no loop).
2. Drop the redundant 'Board power, W' column (over-idle plus the idle row carry it).
3. Rename the session column 'nJ, first session (a2)'.
4. Replace the 'Re-measured' paragraph with: 'The last column pools this session with the energy manual's 23 September passes: n = 7, four on aifoundry2 including this one, three on aifoundry3. This session sits at the top of each range. The reading-only row's 0.07 W is inside the idle baseline's ±0.2 W, so its energy is an order of magnitude, not a measurement.'
5. Change '1.4 W' to '1.2–1.4 W', as proposed.

Base PROPOSAL (for "as proposed" references): 1. **Add a column to #pwrtab:** 'nJ per operation, all passes: mean [range], n = 7', holding 19.8 [16.9–23.6], 1.16 [1.01–1.37], 20.5 [16.5–24.4], 20.4 [16.9–24.2] and 0.50 [0.37–0.82]. Rename the existing column 'nJ, first session (a2)'.
2. **Supply the data:** add '--reruns docs/reports/data/2026-09-23-energy-manual/reruns.json' to analyze_hotline.py, copying hotline_nj_per_op into out['reruns']. analyze_reruns.py reads only power.runs[].nj_per_op, so there is no cycle.
3. **Replace the 'Re-measured…' paragraph** with: 'The last column pools this session with the energy manual's 23 September passes (four on aifoundry2, three on aifoundry3); the first session sits at the top of each range. The reading-only row's 0.07 W is inside the idle baseline's ±0.2 W, so its energy is an order of magnitude, not a measurement.'
4. **In the paragraph before it**, change 'about 1.4 W over idle in this session' to 'about 1.2–1.4 W over idle'.


Verifier note: The rerun values are right: contended 19.85 [16.92–23.57], spread 1.158 [1.007–1.371], contended_scp 20.52 [16.52–24.41], starved 20.42 [16.92–24.23], local_only 0.50 [0.37–0.82], n = 7.

The proposed data path makes a file-level loop. analyze_reruns.py builds reruns.json from hotline.json power.runs (FIRST['hotline']), so hotline.json would then read reruns.json, which was built from hotline.json. It works only if built twice.

The proposed wording '(four on aifoundry2, three on aifoundry3)' after 'pools this session with the 23 September passes' reads as 7 passes plus this session, which is 8. The pooled n is 7: 1 + 3 on a2 and 3 on a3.

A sixth column also widens a table that already overflows at 390 px.


#### HL-14 — CONFIRMED [reorganize/low] et-soc1-hot-line

Where: h2 order of the whole page

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/hot-line.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/hot-line.script.js, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-22-et-soc1-l2-mainline-starvation.html

Problem: The lede makes two claims: the atomic is fair, and the host's memory path stops. §2 (placement: 32× throughput) sits between them and interrupts that line. §7 (energy) is the other half of 'what contention costs' but sits five sections later.


APPLY (PROPOSAL): **New order** (ids unchanged):
1. The atomic itself is fair (#the-atomic-itself-is-fair)
2. The thing that actually starves (#the-thing-that-actually-starves)
3. The threshold is the bank going saturated (#the-threshold-is-the-bank-going-saturated)
4. Esperanto knew: two errata describe it (#esperanto-knew-two-errata-describe-it)
5. The workaround, priced (#the-workaround-priced)
6. What contention costs: 32× the time and 17× the energy (#what-contention-costs-and-what-it-does-not). Old §2's table and paragraph, then an h3 'What it costs in energy' (id what-it-costs-in-energy) holding old §7.
7. What to do instead
8. Method, and what is not established
9. Related reports

**References to update:**
- body §5 '(section 3)' → '(section 2)';
- §9 'section 1 comes out fair … starvation in section 3' → 'section 2';
- §9 'energy table in section 7' → 'section 6';
- script.js k3sub 'the inequality in section 4' → 'section 3';
- L2 brief vq-2 'One hot line stops a shire, §6' → §5, mc-1 '§3' → §2, and mc-4 '§2' → §6.


Verifier note: The proposed order (fair → starves → threshold → errata → workaround → costs with the energy h3 → do → method) follows the lede. §1's paragraph already introduces 'one atomic every 10 cycles'. Every inbound anchor (#the-atomic-itself-is-fair, #the-thing-that-actually-starves, #the-workaround-priced, #what-it-costs-in-energy ×2) keeps its id, and the L2 brief's §1/§2/§3/§6 references are listed correctly. Two additions: renumber the new section references in HL-1's and HL-2's proposed text (§8's '(section 6)' becomes section 5), and renumber the §5 paragraph's '(section 3)'.


#### HL-3 — CONFIRMED [claim/low] et-soc1-hot-line

Where: §9 fourth bullet (hot-line.body.html l.179); docs/findings/03-experiments.md E23 result ('exactly in 13 of the 42')

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/hot-line.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/03-experiments.md

Problem: 'Across all 42 configurations the host's count matches exactly in 13' does not match the data. Two configurations have no host shire; of the other 40, 15 match exactly.


APPLY (PROPOSAL): In both files, replace 'Across all 42 configurations the host's count matches exactly in 13 and agrees within 2% in all but one' with 'In the 40 configurations that have a host shire, its count matches exactly in 15 and agrees within 2% in all but one'.


Verifier note: Pairing the 42 a2/a3 rows by configuration, 2 have no host shire (placement own and scp:own). Of the other 40, the host shire's count matches exactly in 15: fairness 2/5, placement 0/2, local 3/8, requesters 2/9, shires 5/6, pace 3/10. Only dramlocal:0 (208 against 240) is outside 2%. The proposed wording is right for both files.


#### HL-4 — CONFIRMED [consistency/low] et-soc1-hot-line

Where: §8 first bullet 'a chip-wide barrier we measure at 4,997 cycles' (body l.149–150); hotline.json context.barrier_cycles_chip; 17-hot-line.md l.131; 05-claims.md l.219; energy manual §6 via manual.json

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/hot-line.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-18-nocbench-aifoundry2/barrier-chip1.jsonl, /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/17-hot-line.md, /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/05-claims.md

Problem: No committed raw file contains 4,997 cycles. The committed chip-barrier runs, which On-chip communication embeds, give 4,995 and 5,018.


APPLY (PROPOSAL): - Source the value via HL-8's --barrier flag, which yields 4,995.
- In the body, write 'a chip-wide barrier of about 5,000 cycles (4,995 with one minion per shire)'. The ratios stay the same: 320/4,995 = 6.4%; 10,240 is 2.05× the barrier.
- Change 17-hot-line.md l.131 to 4,995, and 05-claims.md l.219 to '4,995 cycles | M | … | docs/reports/data/2026-09-18-nocbench-aifoundry2/barrier-chip1.jsonl'.


Verifier note: barrier-chip1.jsonl gives cycles_per_iter_max 4,995.05 (mean 4,994.99), and barrier-chip32.jsonl gives 5,017.8. The On-chip communication page embeds 4,994.99 and 5,017.72. No committed jsonl anywhere under docs/reports/data contains 4,996–4,997. 4,997 appears only in hotline.json context, hot-line body l.150, 17-hot-line.md l.131, 05-claims.md l.219 and energy-manual 06-synchronisation.md l.10. The last is also rendered into the energy manual from manual.json; add it to the list.


#### HL-5 — CONFIRMED [claim/low] et-soc1-hot-line

Where: §3 window table #wintab (script.js l.75–76), column 'Remote atomics in the same window'

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/hot-line.script.js

Problem: The column is quoted to the operation (301,512 … 6,001,507). The runs are in no raw file, and the counts appear to include the host's 384 loads. That is false precision about an ambiguous quantity (C5).


APPLY (PROPOSAL): Rename the header 'Atomics completed in the window'. Render the values to two significant figures: `${(r.remote_ops/1e6).toPrecision(2)} M`, giving 0.30 M, 0.60 M, 2.4 M and 6.0 M. The host's 384 no longer matters at that precision, and the paragraph's 'six million remote atomics' still reads true.


Verifier note: The a2 scpstream:0 row (shires 32) has total_ops 601,503 = 601,119 remote atomics + 384 host loads; scplocal:0 has 601,121 remote. The 10 ms window row's 601,503 therefore counts the host's loads. The 5, 40 and 100 ms runs are in no raw file. Two significant figures (0.30/0.60/2.4/6.0 M) remove both the false precision and the ambiguity, and the prose still reads true.


#### HL-11 — CONFIRMED [redundancy/low] et-soc1-hot-line

Where: §1 caption #faircap (script.js l.51) and the paragraph after it (body l.42–46)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/hot-line.script.js

Problem: The one-minion-per-shire explanation appears twice back to back: once in the caption, and again at length in the next paragraph.


APPLY (PROPOSAL): Delete from the faircap template string: 'With one minion per shire the bank is still saturated, but each shire has one request queued, so the mesh round trip decides and the host shire leads. '. Keep the paragraph. If HL-16 is adopted, end the paragraph with 'The map above shows the rings.'


Verifier note: faircap (script.js l.51) and the paragraph at body l.42–46 give the same one-minion-per-shire explanation back to back. Deleting the caption sentence loses nothing.


#### HL-6 — CONFIRMED [consistency/low] et-soc1-hot-line

Where: docs/findings/17-hot-line.md pacing table, l.103

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/17-hot-line.md

Problem: The row '0 to 8,000 | 0.03%' disagrees with the page and the data, which give 0.02%.


APPLY (PROPOSAL): Change l.103 to '| 0 to 8,000 | 0.02% | 100% |'.


Verifier note: frac_of_alone at paces 0–8,000 is 0.0227–0.0231% on both cards (384–390 loads of 1,688,306), so the value is 0.02%, as the page's KPI and D12 have it. 17-hot-line.md l.101 says 0.03%. The finding cites l.103, but the table row itself is l.101.


#### HL-9 — CONFIRMED [reproducibility/low] et-soc1-hot-line

Where: reproduce <pre> block (hot-line.body.html l.206–210)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/hot-line.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/tools/ettelem/analyze_reruns.py

Problem: The block does not reproduce every number on the page:
- §7 quotes the rerun ranges (19.8 [16.9–23.6], 1.16 [1.01–1.37], 0.37–0.82), but analyze_reruns.py is not listed.
- The build needs mathjax-full only because of the one TeX equation.


APPLY (PROPOSAL): Append to the pre block:
```
python3 tools/ettelem/analyze_reruns.py docs/reports/data/2026-09-23-reruns-aifoundry2-warm docs/reports/data/2026-09-23-reruns-aifoundry3 --out reruns.json   # the passes behind the ranges in section 7
```
Replacing the $$ equation with HTML (HL-1) removes the mathjax-full requirement for this page. Nothing needs adding to the reproduce block for that.


Verifier note: analyze_reruns.py with the two rerun dirs regenerates reruns.json identical to the committed file (checked into scratch). §7 quotes its ranges, but the reproduce block omits the command. The mathjax note holds for this page only; other source pages still use TeX.


#### RL-9 — MODIFIED [visualization/medium] et-soc1-on-chip-relay

Where: §1 bar chart #head (body l.42–44, script.js l.37–50), replaced; top of §2 (#the-same-watts-a-thirtieth-of-the-work), complementing #power

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-22-onchip-aifoundry2/onchip.json, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-23-energy-manual/reruns.json, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/on-chip-relay.script.js, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/on-chip-relay.body.html

Problem: §2's headline, 'all three draw the same power, and one of them gets thirty times as much done', is carried only by a table. The §1 bar chart shows just GB/s, and those are the same numbers as the table next to it.


APPLY (CORRECTED): Build three small aligned bar panels shown together: 'Watts over idle', 'GB/s during the power bursts' and 'pJ per byte, 8 passes'. Stack them at 390 px; hover or focus gives per-card values, n and duty.
- In the pJ panel the bar is the pooled mean, the whisker the [lo–hi] range, and dots the per-card means and this session.
- Label the GB/s panel as burst rates.
- Colours are var(--c2)/var(--c1)/var(--c3), as proposed.
- Put it in §2 at the #power slot, or in §1 in place of #head (RL-3).
- Reduced motion does not matter here, since nothing animates.

Base PROPOSAL (for "as proposed" references): Build a 'Same watts, different work' metric toggle.

**Data:** onchip.json power.media[] {medium, over_idle_w, bytes_per_s, pj_per_byte, duty}; reruns.json relay_pj_per_byte.{dram,hop,scp}.{mean,lo,hi,per_card.*.mean}.

**Encoding:**
- Three horizontal bars: DRAM var(--c2), next shire var(--c1), own shire var(--c3). Value labels plus a ratio to DRAM.
- The metric is chosen by a segmented control:
  - 'Watts over idle': linear 0–6 W.
  - 'GB/s moved': linear 0–1,600.
  - 'pJ per byte moved': log 2–200. The session value is a bar; the [lo–hi] range over the eight passes is a var(--ink) whisker; the two per-card means are dots.
- Bars animate between metrics with a CSS transition on width (0.4 s, disabled under prefers-reduced-motion).

**Interaction:**
- Three buttons (role=radiogroup, arrow keys).
- Hover or focus a bar for per-card values, n and duty (0.83–0.84).

**Replaces and complements.** Replaces #head and #headcap, which duplicate the #media table. Complements #power.

**Tokens and phone width.** Bars use var(--c1), var(--c2), var(--c3); whiskers var(--ink); gridlines var(--grid). At 390 px the labels go above the bars.

**What the reader learns.** Switching from watts to GB/s shows the power barely moves while the work grows 12× and 30×. The pJ view shows the 12× and 26× survive eight passes on two cards.


Verifier note: The values are correct: over-idle 4.34/4.42/5.30 W; 49.7/594.1/1,502.5 GB/s; 104.8/8.9/4.25 pJ/B; reruns 105.7 [99.5–111.0], 8.6 [7.8–9.2], 3.99 [3.90–4.25], per-card 102.1/109.3, 9.08/8.11, 4.02/3.97; duty 0.83–0.84. The message 'same watts, 12× and 30× the work' deserves a picture.

Three problems:
(1) The design makes the first-session value the bar and the pooled mean a whisker. D13 makes the pooled means canonical and the first session one of the eight passes.
(2) A toggle shows one metric at a time, while the point is the side-by-side contrast.
(3) The widget's GB/s (49.7/594/1,502, burst rates) differ from the #media table's 48.4/592.9/1,483.7. Unlabelled, that will look like an error.


#### RL-3 — MODIFIED [redundancy/medium] et-soc1-on-chip-relay

Where: §1: chart-title 'Rate at which the chip moves its own intermediate data', #head and #headcap (body l.42–44), script.js l.37–50

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/on-chip-relay.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/on-chip-relay.script.js

Problem: 48.4 / 592.9 / 1,483.7 GB/s and 12.3× / 30.7× appear four times: in the lede, the KPI tiles, the #media table, and the bar chart directly under the table. The chart adds nothing the table lacks, and the table also has cycles and the verification column.


APPLY (CORRECTED): Remove #head, #headcap and the chart-title only when RL-9's panels take the slot (in §1 or at the top of §2). Move 'Identical kernel, identical barriers; only the destination of each stage differs.' into the #media intro either way.

Base PROPOSAL (for "as proposed" references): Delete body l.42–44 (chart-title, <div class="chart scroll" id="head">, <p id="headcap">) and the script.js IIFE at l.37–50. Move headcap's useful sentence into the #media intro paragraph: 'Identical kernel, identical barriers; only the destination of each stage differs.' If RL-9 is adopted, its widget takes this slot.


Verifier note: The #head bars show exactly the #media table's GB/s and ratios. On a page the owner wants made more visual, deleting its only §1 chart with nothing in its place is a net loss for a quick read.


#### RL-4 — MODIFIED [redundancy/medium] et-soc1-on-chip-relay

Where: §2: #powernote (script.js l.61–69) and the 'Re-measured.' paragraph (body l.55–63)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/on-chip-relay.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/on-chip-relay.script.js, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/onchip/analyze_onchip.py

Problem: The energy ratios are given twice: 25× and 12× from the session in powernote, then 12× and 26× from the reruns in the paragraph. The canonical values (D13) are only in prose. The paragraph ends with memory-hierarchy supersession history that belongs on that page and in the energy manual.


APPLY (CORRECTED): Apply items 1, 3 and 4 as proposed. Supply the column from a constant in on-chip-relay.script.js with a comment citing reruns.json relay_pj_per_byte and the analyze_reruns command (listed in the reproduce block per RL-7), not from a --reruns flag. Word the note 'pools this session with the 23 September passes: n = 8, four per card'.

Base PROPOSAL (for "as proposed" references): 1. **Add a column to #power:** 'pJ per byte moved, all passes: mean [range], n = 8', holding 105.7 [99.5–111.0], 8.6 [7.8–9.2] and 3.99 [3.90–4.25]. Rename the existing column 'pJ, this session'.
2. **Supply the data:** add '--reruns' to analyze_onchip.py, copying relay_pj_per_byte into onchip.json. Or hard-code the values in the body table, with a source comment.
3. **In powernote**, delete 'All three sit within a watt of each other while moving between … for the hand-off. '.
4. **Replace the 'Re-measured.' paragraph** with: '<b>Re-measured.</b> The last column pools this session with the energy manual's 23 September passes (four per card; <a …#bytes-between-cores-and-shires>§5</a>): 12× and 26× less than DRAM. Reading a byte costs 122 [117–129] pJ from DRAM, 2.52 from the shire's own scratchpad and 6.65 from another shire's (<a href="https://spacesheep.dev/@yaroslavvb/et-soc1-energy-manual#bytes-through-the-memory-hierarchy">the energy manual, §4</a>).'


Verifier note: The duplication is real: powernote gives 25× and 12× from the session, then the paragraph gives 12× and 26× from the reruns. The supersession history belongs on memory-hierarchy. The values match reruns.json, and '(four per card)' is correct for the pooled n = 8 (1 + 3 on a2, 4 on a3).

The same loop as HL-13 applies: analyze_reruns.py reads onchip.json power.media as its first pass, so '--reruns' in analyze_onchip.py makes onchip.json depend on a file built from onchip.json. The adjacent table also gets wider at 390 px.


#### RL-11 — CONFIRMED [layout/medium] et-soc1-on-chip-relay

Where: charts #size (§3) and #intensity (§4); host() in on-chip-relay.script.js l.4; template .chart.scroll svg {min-width:640px}

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/on-chip-relay.script.js

Problem: At 390 px the §3 chart shows only 2–8 MB, where DRAM and the hand-off coincide. The collapse to 48 GB/s at 32 MB, the L3 line and the legend are scrolled off, so the chart looks like it says the opposite of §3's text. The §4 chart similarly hides the 64–256-add tail where the lead falls to 1.5×.


APPLY (PROPOSAL): Apply the same responsive host() as HL-17:
- `W = h.clientWidth<600 ? 380 : 700`;
- remove 'scroll' from #size and #intensity;
- when narrow, move the legend under the plot and use R = 16;
- thin the ticks: size xt [2,8,32] plus 256 if RL-10 is adopted; intensity xt [1,16,256].

The dashed-line label 'footprint = 32 MB of L3' moves to the line's left side, under the plot top.


Verifier note: At 390 px (rl390-3.png) the §3 chart shows only 2–8 MB, where DRAM and the hand-off coincide; the 32 MB collapse, the L3 label and the legend are off-screen. §4 hides the 64–256 tail. Use the same responsive host() as HL-17, plus a debounced re-render on resize.


#### RL-10 — MODIFIED [visualization/low] et-soc1-on-chip-relay

Where: §3 chart #size (script.js l.73–105); §4 chart #intensity x axis

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/on-chip-relay.script.js, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-22-onchip-aifoundry2/onchip.json

Problem: The §3 text says the DRAM route 'stays there' at 47.9, 51.0 and 53.4 GB/s at 64, 128 and 256 MB, but the chart stops at 32 MB, so that evidence is only in prose. The chart also does not show why the on-chip lines stop at 32 MB. §4's x axis is 'vector adds per element', while the text and the ridge-points comparison speak in flops per byte.


APPLY (CORRECTED): 1 and 2 as proposed. For bigsize, plot only rows with footprint over 32 MB, since bigsize also repeats the size DRAM rows. 3: add a top axis 'flops per byte read' at w/4 (0.25, 1, 4, 16, 64), matching the ridge points' unit, and keep 'per byte moved' in the caption.

Base PROPOSAL (for "as proposed" references): 1. **Extend #size to 256 MB.** Set the x domain to log2 2–256, add D.bigsize points beyond 32 MB as a DRAM-only continuation, and shade x > 32 MB in var(--grid) with the label 'no room: two buffers must fit in the 2.25 MB left of each shire's scratchpad'.
2. **Add a hover crosshair** (tabindex points) listing all three media at that size with ratios, e.g. '16 MB: DRAM 379, next 545 (1.44×), own 1,263 (3.33×) GB/s'.
3. **Give #intensity a secondary top axis** 'flops per byte moved' at w/8 (0.125, 0.5, 2, 8, 32) in var(--ink-3), so the reader can place it against the ridge points' 130 FLOP/B.


Verifier note: bigsize has DRAM at 64/128/256 MB = 47.87/50.98/53.4 GB/s (a3: 47.84/51.52/53.48). Two buffers starting 256 KB in cap the on-chip media at 1 MB per shire (2.25 MB free), and the crosshair values (16 MB: 379/545 1.44×/1,263 3.33×) are right. So items 1 and 2 are sound.

Item 3 is wrong. It proposes a top axis in flops per byte moved (w/8) 'so the reader can place it against the ridge points' 130 FLOP/B'. The ridge figure is per byte read, as inttext says ('near 130 FLOP per byte read'), and per byte read is w/4. The proposed axis would invite a 2× mis-comparison.


#### RL-2 — MODIFIED [claim/low] et-soc1-on-chip-relay

Where: lede 'Both numbers reproduce on a second card to within 2%' (body l.10–11); inttext parenthetical (script.js l.126–127)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/on-chip-relay.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/on-chip-relay.script.js, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-22-onchip-aifoundry2/sweep.jsonl, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-22-onchip-aifoundry3/sweep.jsonl

Problem: The lede quotes card-to-card agreement, but not the larger repeat scatter inside each card. The §4 text has to explain away 12.2× with '(this sweep's own run; the headline run in §1 gives 12.3×)'.


APPLY (CORRECTED): Lede: 'Both hold on a second card (12.4× and 31.2×) and across five repeats on each card (12.0–12.7× and 30.0–31.7×).' Move 'the scatter is almost all DRAM (46.8–49.5 GB/s); the hand-off ran at 592–593 GB/s every time' to §7's cards bullet. Delete the inttext parenthetical, as proposed.

Base PROPOSAL (for "as proposed" references): 1. **Lede.** Replace 'Both numbers reproduce on a second card to within 2%.' with 'Both hold on a second card (12.4× and 31.2×) and across the six repeats of this configuration in each card's sweeps (12.0–12.7× and 30.0–31.7×). The scatter is almost all DRAM (46.8–49.5 GB/s); the hand-off ran at 592–593 GB/s every time.'
2. **inttext.** Delete "(this sweep's own run; the headline run in §1 gives ${…}×)".


Verifier note: Recomputed. The headline configuration (1 MB, 8 stages, 32 shires, work 1, offset 1) repeats with all three media in five groups per card (headline, intensity, size, stages, shires), not six; distance repeats the hand-off only. Ratios: hand-off/DRAM a2 11.98–12.66, a3 12.12–12.65; own/DRAM 30.04–31.70 and 30.50–31.73. DRAM spans 46.8–49.5 GB/s and the hand-off 592.2–592.9 in all 12 runs, so the numbers are right apart from the count. The proposed text also lengthens an already long lede.


#### RL-5 — MODIFIED [redundancy/low] et-soc1-on-chip-relay

Where: §6 fourth bullet 'In a two-dimensional systolic array, give each neighbour link its own minion' (body l.118–125); Related reports item 'L2 mainline starvation, "The landmine"' (l.179)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/on-chip-relay.body.html

Problem: This eight-line bullet restates a trap whose canonical home is On-chip communication's 'A trap: one ready flag per minion', which the brief also covers. Related reports then lists both pages for the same trap.


APPLY (CORRECTED): '<li><b>Inside a shire, use the register path, one partner at a time.</b> TensorSend/TensorRecv is immune to shire-cache contention, but a minion that takes readies from two partners at once can hang until the chip is reset (<a href="https://spacesheep.dev/@yaroslavvb/et-soc1-on-chip-communication#a-trap-one-ready-flag-per-minion">on-chip communication</a>): give each link its own minion, or take the directions in barrier-separated phases. The relay is the same idea at shire granularity, through the scratchpads, a path that cannot hang.</li>' Delete the L2-brief Related item.

Base PROPOSAL (for "as proposed" references): 1. **Replace the bullet** with: '<li><b>Inside a shire, use the register path, one partner at a time.</b> TensorSend/TensorRecv is immune to shire-cache contention, but a minion must never take readies from two partners at once (<a href="https://spacesheep.dev/@yaroslavvb/et-soc1-on-chip-communication#a-trap-one-ready-flag-per-minion">on-chip communication</a>); the relay is the same idea at shire granularity, through the scratchpads, a path that cannot hang.</li>'.
2. **Delete the Related item** '<li><a …#landmine>L2 mainline starvation, “The landmine”</a> — …</li>'.


Verifier note: The eight-line bullet restates On-chip communication's trap, and Related already lists that page for 'the one-ready-flag trap'. X4 does not require a relay↔L2-brief link, so the Related item can go. The proposed one-liner drops the two workable options (a minion per link, or barrier-separated phases) and the consequence (a hang until reset).


#### RL-6 — CONFIRMED [redundancy/low] et-soc1-on-chip-relay

Where: end of the §5 paragraph (body l.95–98) and the §7 'Not established' bullet (l.149–150)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/on-chip-relay.body.html

Problem: The untested physical-neighbour energy caveat is stated twice.


APPLY (PROPOSAL): In §5, replace 'Every byte the hand-off reads has crossed 3.5 hops on average, so a stage placed on a physical neighbour should cost less than the energy in §2; that was not measured.' with 'The hand-off's bytes cross 3.5 hops on average, so a physical neighbour should cost less (untested; section 7).' Keep §7 as it is.


Verifier note: §5 (body l.95–97) and §7's 'Not established' bullet (l.149–150) state the same untested physical-neighbour energy caveat. The shortened §5 wording is right. Coordinate with RL-1's rewrite of the same paragraph.


#### RL-7 — CONFIRMED [reproducibility/low] et-soc1-on-chip-relay

Where: reproduce <pre> block (body l.160–163)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/on-chip-relay.body.html

Problem: §2 quotes the 23 September energies (105.7 / 8.6 / 3.99 pJ/B, n = 8), but the block does not list the command that produces them. The aifoundry3 sweep appears only as a comment.


APPLY (PROPOSAL): Replace the block with:
```
workloads/onchip/run_onchip.sh DATA                 # 88 configurations on aifoundry2, milliseconds of card time each
workloads/onchip/run_onchip.sh DATA3                # the same sweep on aifoundry3
tools/ettelem/run_onchip_power.sh DATA 12           # board power, one burst per medium
python3 workloads/onchip/analyze_onchip.py DATA/sweep.jsonl DATA3/sweep.jsonl --power DATA --out onchip.json
python3 tools/ettelem/analyze_reruns.py docs/reports/data/2026-09-23-reruns-aifoundry2-warm docs/reports/data/2026-09-23-reruns-aifoundry3 --out reruns.json   # the passes behind §2's ranges
```


Verifier note: analyze_onchip.py reproduces onchip.json byte for byte (checked in scratch), and analyze_reruns.py reproduces reruns.json. §2 quotes the rerun ranges, but the reproduce block lacks analyze_reruns and lists DATA3 only as a comment. All the named scripts exist.


#### L2-1 — MODIFIED [claim/medium] 2026-09-22-et-soc1-l2-mainline-starvation

Where: h1 (l.138); lede last sentence (l.141); five-questions row vq-5; h2#landmine text and its contents entry; the relay's Related item text

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-22-et-soc1-l2-mainline-starvation.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/on-chip-relay.body.html

Problem: 'And don't build a 2D systolic array' and 'a 2D array hangs a hart until the chip is reset' overstate. The brief's own card 'Safe: 2D in alternating phases' contradicts them, as do the relay page ('give each neighbour link its own minion') and On-chip communication ('take the directions in separate, barrier-separated phases'). Only cells that take two partners at once hang.


APPLY (CORRECTED): Apply as proposed. Also, on the hub row l.493: 'why a two-dimensional TensorSend systolic array hangs' → 'why a 2D TensorSend array whose cells take two partners at once hangs (and how phases avoid it)'.

Base PROPOSAL (for "as proposed" references): Keep the slug and <title>.
- **h1:** 'Don’t fix the starvation. Move the line. And build 2D systolic arrays in phases.'
- **Lede:** 'but has a separate hazard: a 2D array hangs a hart until the chip is reset.' → 'but has a separate hazard: a cell that takes readies from two TensorSend partners at once, as in a naive 2D array, hangs its hart until the chip is reset.'
- **vq-5:** 'But a 2D array hangs a hart until the chip is reset, for a different reason.' → 'But a 2D array whose cells take both neighbours at once hangs a hart until the chip is reset; run the directions in phases.'
- **h2#landmine and its contents item:** 'The landmine: two TensorSend partners at once hang a hart until the chip is reset'.
- **Relay Related item** (if kept despite RL-5): 'why a cell with two TensorSend partners at once hangs its hart'.


Verifier note: The problem is real. The h1 says 'And don't build a 2D systolic array', and the lede and vq-5 say 'a 2D array hangs a hart until the chip is reset'. The brief's own card 'Safe: 2D in alternating phases', its KPI 'Cost of switching phase in a 2D systolic array: 237 cycles' and On-chip communication all say phased 2D arrays are fine. The fix is right, but it misses the hub's L2 row (limits-of-observability.data.json l.493: 'why a two-dimensional TensorSend systolic array hangs').


#### L2-5 — MODIFIED [redundancy/medium] 2026-09-22-et-soc1-l2-mainline-starvation

Where: Update box #update (l.143); KPI 2 (l.147); vq-2 last sentence; card rc-2

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-22-et-soc1-l2-mainline-starvation.html

Problem: The reproduction's numbers are repeated four to five times: in the Update box, KPI 1, the five-questions rows, the 'What Ivan reported' bars, fignote and cards, rc-2, and fix step 4. The Update box alone re-tells the fignote, mc-1, mc-2 and rc-2, and the hot-line page is the canonical home.


APPLY (CORRECTED): Apply 1, 2, 3 and 5 as proposed. For 4, point vq-2 to 'steps 1 and 4 below', and add to fs-4 '(<a href="https://spacesheep.dev/@yaroslavvb/et-soc1-hot-line#the-workaround-priced">One hot line stops a shire, §6</a>)', renumbered to §5 if HL-14 is applied.

Base PROPOSAL (for "as proposed" references): 1. **Update box:** replace its content with '<b>Update, 22 Sep, later the same day.</b> Reproduced on two cards in <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-hot-line">One hot line stops a shire</a>: the ~60 M atomics/s aggregate and the remote shires’ even split hold, and the owner’s 6% does not (its share of the atomic is 1.004). What stops is the owner shire’s own loads. The sections below are corrected in place.'
2. **mc-1:** append 'A global atomic cannot take the local path (through the self ID 0x7F it is a bus error), so the owner’s atomics queue with everyone else’s.' This keeps the one fact that would otherwise be lost from the page.
3. **KPI 2:** delete the whole tile <div class="kpi" data-ss-id="kpi-2">…</div>, leaving three tiles.
4. **vq-2:** replace 'Placement fixes it, and so does pacing the remote shires: at 10,000 cycles between atomics the owner gets back 54% of its memory throughput, at 16,000 about 95% (…§6).' with 'Placement fixes it, and so does pacing the remote shires (steps 1 and 4 below).'
5. **rc-2:** delete ' (20 still leave the owner at 99%)'.


Verifier note: The repetition is real: 1.004 five times, the errata three times, and KPI 2 duplicates the r-note 'Nothing earlier is invalidated'. X3 keeps a short Update box, and moving the 0x7F bus-error fact into mc-1 keeps the one unique fact.

The vq-2 change removes the brief's only link to the hot line's pacing section (#the-workaround-priced). fs-4, which it now points to, has no link.


#### L2-2 — MODIFIED [claim/low] 2026-09-22-et-soc1-l2-mainline-starvation

Where: 'When it bites' question box (#when-it-bites, r-test)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-22-et-soc1-l2-mainline-starvation.html

Problem: The test is framed as a count: 'hammered by about 24 or more minions in other shires'. Saturation depends on request rate. 992 minions pausing 12,000 cycles are well above 24, yet the bank is not saturated (the owner still loses 15%). 22 back-to-back requesters are enough.


APPLY (CORRECTED): '<b>Do minions in other shires ask one line for more than one request every 10 cycles between them (between 21 and 24 of them spinning on it back to back, or N of them each pausing less than about 10 × N cycles) while its home shire is also doing work?</b> If so, the home shire's own loads stop. Close to that rate the owner still loses some throughput (15% at 80% of it, with 992 paced requesters); well below it, ignore this.' rc-2: 'hammered by more than about 20 remote requesters at full speed (24 stop the owner)'.

Base PROPOSAL (for "as proposed" references): Replace the question with '<b>Do minions in other shires send one line more than one request every 10 cycles (about 22 of them spinning on it back to back, or <i>N</i> of them each pausing less than 10 × <i>N</i> cycles) while its home shire is also doing work?</b> If not, ignore this entirely.' In rc-2, change 'hammered by about 24 or more concurrent remote requesters' to 'hammered by more than about 22 remote requesters at full speed'.


Verifier note: The finding is right that a count is the wrong test: 992 minions paced at 12,000 are not saturating (load 0.81). But the proposed wording 'If not, ignore this entirely' is contradicted by that same run, where the owner is not saturated yet loses 15% (85.5% on a2). 'About 22' is also the model's edge, not a measurement: 20 were fine and 24 stopped (the hot line's KPI says 21–24).


#### L2-3 — MODIFIED [consistency/low] 2026-09-22-et-soc1-l2-mainline-starvation

Where: systolic section, primitives table rows st-1 to st-3 (Energy column) and the note after it

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-22-et-soc1-l2-mainline-starvation.html

Problem: The table shows the superseded 18 September energies, while the note under it gives the re-measured canonical ones. The current values should be in the table (D9: cross-shire messaging 9.3 + 1.7 pJ/B per mean hop).


APPLY (CORRECTED): Put the canonical values in the Energy column: 0.67 pJ/B, 2.1 pJ/B and 9.3 + 1.7/hop pJ/B (per mean hop). Shorten the note to: 'Energies re-measured on 23 September on two cards (the energy manual, §5); the 18 September figures in On-chip communication read 2–20% higher.'

Base PROPOSAL (for "as proposed" references): 1. Set the Energy cells to st-1 '0.67 pJ/B', st-2 '2.1 pJ/B' and st-3 '≈ 9.3 + 1.7/hop pJ/B'.
2. Change the header to 'Energy (23 Sep, two cards)'.
3. Replace the note with 'Latencies from <a …>On-chip communication</a> (18 Sep, 600 MHz); energies from <a …#bytes-between-cores-and-shires>the energy manual, §5</a> (23 Sep, three passes on each of two cards; the 18 September figures, 0.8, 2.3 and ~10 + 1.9 per hop, read higher).'


Verifier note: The finding text was cut off in the input, so its proposal could not be seen. Checked on the page: rows st-1 to st-3 give 18 September energies (0.8, 2.3, ~10 + 1.9/hop pJ/B). The note under the table then gives the 23 September re-measurement (0.67, 2.1, 9.3 + 1.7/hop), which D9 makes canonical and reruns.json confirms (pair 0.67 [0.61–0.73], neighbourhood 2.11, shire 2.08, n = 6). So the table shows superseded values and the note restates the canonical ones.


#### L2-4 — NOT VERIFIED (VERIFIER INPUT TRUNCATED) [claim/low] 2026-09-22-et-soc1-l2-mainline-starvation

Where: card mc-3 '60 M atomics/s is the aggregate'; Sources 'Arithmetic' bullet

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-22-et-soc1-l2-mainline-starvation.html

Problem: 'A sub-bank accepts one request every 2 cycles' is stated as a fact. It is a reading of the shire-cache spec that was not measured, and the hot-line page labels it that way.


APPLY (PROPOSAL): In mc-3, replace 'but a sub-bank accepts one request every 2 cycles: 300 M/s at 600 MHz' with 'but by the shire-cache spec (not measured) a sub-bank accepts one request every 2 cycles: 300 M/s at 600 MHz'. In Sources, change 'exceed the sub-bank’s one-request-per-2-cycles ceiling' to 'exceed the spec’s one-request-per-2-cycles sub-bank ceiling'.


#### L2-6 — NOT VERIFIED (VERIFIER INPUT TRUNCATED) [reorganize/low] 2026-09-22-et-soc1-l2-mainline-starvation

Where: section order: #answers, then #reported

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-22-et-soc1-l2-mainline-starvation.html

Problem: A reader arriving from the hub or the hot-line page first needs to know which of the brief's claims survived the reproduction. Today the five-questions summary comes before the section that shows what was reported and what reproduced, so the summary is read before its corrected evidence.


APPLY (PROPOSAL): Move <section data-ss-id="section-measure"> (h2#reported with its bars, fignote and cards mc-1 to mc-4) so it sits directly after Contents, before <section data-ss-id="section-verdict"> (#answers). New order:
1. What Ivan reported, and what reproduced (#reported)
2. Five questions, answered (#answers)
3. When it bites (#when-it-bites)
4. The fix, cheapest first (#fix)
5. The systolic array (#systolic)
6. The landmine (#landmine)
7. Related reports (#related)

Reorder the #toclist <li> items to match. Ids are unchanged; the inbound links go to #landmine only.


#### L2-7 — NOT VERIFIED (VERIFIER INPUT TRUNCATED) [visualization/low] 2026-09-22-et-soc1-l2-mainline-starvation

Where: #landmine section: replaces the four static cards ls-1 to ls-4 (keep their text as captions)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-22-et-soc1-l2-mainline-starvation.html

Problem: The brief's own contribution is the systolic advice: which TensorSend layouts hang and what the safe ones cost. It is given as a quotation and four text cards. The reader has to imagine what 'two partners at once' looks like in a 2D array and what a phased step costs.


APPLY (PROPOSAL): Build a 'Which layouts hang' diagram.

**Data:** the brief's primitives table and s-note, embedded as a JS object: {treeHop:68, otherHop:114, barrier:237, tree:432, treePairs:[[0,1],[0,2],[0,4],[2,3],[4,5],[4,6],[6,7]]}.

**Encoding:**
- One shire as a 4×8 grid of 32 minions, one neighbourhood per row.
- For the selected pattern, draw its message edges. Tree edges are solid var(--c1) and labelled 68; other in-shire edges are dashed var(--ink-3) and labelled 114.
- Any minion receiving from two partners in the same phase gets a var(--c2) outline and a 'hangs' badge.

**Interaction:**
- Buttons: '1D ring', '2D, both directions at once', '2D in two phases', 'hardware tree'.
- A 'next phase' button, or a range input as a timeline scrubber, walks the phases (west-pass, barrier, north-pass, barrier).
- Readout of cost per step from the table: ring 114 cycles per hop; 2D in phases 2 × (114 + 237) = 702 cycles; tree 432 for a 32-minion reduce and broadcast; the naive 2D case reads 'hangs until reset'.

**Tokens.** The brief has no --c* tokens. Add to :root and to both dark blocks: '--c1: var(--accent); --c2: var(--warn); --c3: var(--good); --grid: var(--line);'.

**Phone width.** The grid is 8 × 40 px = 320 px, so it fits at 390 px; buttons wrap.

**What the reader learns.** The rule forbids exactly the cells with two inbound arrows in one phase. The phased 2D array is safe and costs about two barriers per step.


### Missed by the reviewers (found by the verifiers)


#### M-hrl-1 [claim] et-soc1-on-chip-relay

Problem: The headline hand-off (592.9 GB/s, 12.3×) was run at ring offset 1, the slowest of the five offsets tested; offset 16 ran 733.5 GB/s, about 15× the headline's DRAM. The page never says so, and a ring whose every hand-off is one mesh hop (analyze.py one_hop_ring) was never measured. The 6–10-hop trend (about 35 GB/s per hop, r = −0.99) suggests that ring could be faster. §7 lists only the energy side of this as not established.

APPLY: In §5, after the table, add: 'The headline in section 1 uses offset 1, the slowest of these.' In §7 'Not established', add: 'Whether a ring laid out along the mesh, every hand-off one hop, raises the bandwidth as well as lowering the energy per byte.' (Folded into RL-1's corrected proposal.)


#### M-hrl-2 [claim] et-soc1-on-chip-relay

Problem: 'Transfers here are 32 KB per minion and deeply pipelined, so the 12-cycle round trip per hop never appears' (body l.90–91; also 18-on-chip-relay.md l.95–96) is contradicted by the data. Per-stage time rises from 54.9k cycles (longest hand-off 6 hops) to 67.9k (10 hops), about 3,200 cycles per hop. RL-1 leaves this sentence in place.

APPLY: Replace it as in RL-1's corrected item 5: the stage time grows about 3,200 cycles for each hop of the longest hand-off.


#### M-hrl-3 [consistency] et-soc1-on-chip-relay

Problem: The 'distance does not matter' claim also appears in docs/findings/03-experiments.md l.494 ('the bandwidth stays at 593–733 GB/s and does not follow the distance') and in the 18-on-chip-relay.md l.83 heading. RL-1's file list misses both.

APPLY: Change 03-experiments.md l.494 to '…the bandwidth runs 593–733 GB/s, not with the mean distance but with the longest hand-off (10 to 6 hops, r = −0.99 on both cards)'. Change the 18-on-chip-relay.md heading to 'How far the slab moves: the farthest hand-off sets the pace'.


#### M-hrl-4 [reproducibility] et-soc1-hot-line

Problem: HL-13 and RL-4 propose feeding reruns.json into analyze_hotline.py and analyze_onchip.py. analyze_reruns.py builds reruns.json from hotline.json power.runs and onchip.json power.media (its FIRST dict), so that would make a file-level loop: the page JSON would depend on a file built from itself.

APPLY: Hard-code the pooled values as a commented constant in each page script, citing reruns.json and the analyze_reruns command. Or, for the hot line, point FIRST['hotline'] at power.json so the chain is power.json → reruns.json → hotline.json.


#### M-hrl-5 [layout] et-soc1-hot-line

Problem: #pwrtab already overflows at 390 px. HL-13 adds a sixth column, and 'Board power, W' repeats what 'Over idle, W' plus the idle row already give.

APPLY: Drop the 'Board power, W' column when adding the reruns column. Keep the idle board power in the idle row's 'Over idle' cell as '(idle 31.27 W)'.


#### M-hrl-6 [claim] 2026-09-22-et-soc1-l2-mainline-starvation

Problem: The hub's row for the brief (limits-of-observability.data.json l.493) repeats the overstatement L2-1 fixes: 'why a two-dimensional TensorSend systolic array hangs'.

APPLY: '…and why a 2D TensorSend array whose cells take two partners at once hangs, and how phases avoid it.'


#### M-hrl-7 [consistency] et-soc1-hot-line

Problem: The 4,997-cycle barrier (HL-4) also appears in the energy manual's markdown (docs/energy-manual/06-synchronisation.md l.10) and is rendered into the energy manual page from manual.json sync.barrier_cycles_chip. HL-4 does not list that page.

APPLY: Once HL-8's --barrier yields 4,995, rebuild manual.json and the energy-manual page and change 06-synchronisation.md l.10 to 4,995. The ≈12 µJ derived value is unchanged.



## Group memory-anatomy


### Reproduction problems


#### R-anat-1 [medium] workloads/memprobe/report_template.html

Problem: §2 explorer intro says the model 'matches 97% of measured loads to ±3 cycles'. 97% is the per-line figure (the fastest of three loads per line); per measured load the model is within ±3 cycles for only 83%.

Evidence: Line 175 of the template. summary.json decomp.model_err_hist gives 1,450/1,500 lines within ±3 (97%). Recomputing over all 4,500 DRAM loads in decomp.u32 against 110+12·hops+91+12·dist gives 3,721/4,500 within ±3 (82.7%). The lede and KPI correctly say 'of lines'.

Fix: Change to 'which matches 97% of lines (fastest of three loads) to ±3 cycles'. Then rebuild with python3 workloads/memprobe/build_report.py docs/reports/data/2026-09-19-memprobe-aifoundry2/summary.json docs/reports/2026-09-19-et-soc1-memory-anatomy.html.


#### R-anat-2 [medium] workloads/memprobe/report_template.html

Problem: The §10 Reproduce command for pagetimeout omits --delays, so it generates a different experiment from the committed data: default delays 0,50,…,25,600 and 1,320 timed ops. The 'How long a row stays open' curve, and its '23% vs 44% at 1,000 idle cycles', cannot be reproduced from the page's instructions.

Evidence: Line 394 of the template reads: gen_ops.py pagetimeout --out . --row-bit 13 --trials 60. The committed pagetimeout.json meta.delays is [0,100,200,400,700,1000,1500,2000,3000,5000,8000,12000,20000] with 1,560 labels. Adding the flag makes the output byte-identical.

Fix: Append ' --delays 0,100,200,400,700,1000,1500,2000,3000,5000,8000,12000,20000' to that line, then rebuild the page.


#### R-anat-3 [medium] workloads/memprobe/analyze_power.py

Problem: The committed power data cannot be re-analysed by any committed script. analyze_power.py reads only dev0_sp_stats*.bin or trace/*.done, which are not committed, and crashes on the committed folder. The committed sp_stats.csv has no script that writes it or reads it.

Evidence: 'python3 workloads/memprobe/analyze_power.py docs/reports/data/2026-09-19-memprobe-aifoundry2/power --json X' fails with IndexError: list index out of range at 'base = board[-1][0] - trace[-1][0] / 1000.0'. With read_trace swapped for a CSV reader (scratchpad/validate2/ma/power_from_csv.py), the output is byte-identical to power/summary.json. grep finds no producer of sp_stats.csv.

Fix: In read_trace(), fall back to os.path.join(folder, 'sp_stats.csv') when no .bin or .done files exist: key = int(sp_us); minion_w→minion, sram_w→sram, noc_w→noc, board_w→system. Add a --csv option (or a final step in run_power.py) that writes that merged CSV. List analyze_power.py and build_report.py in the E1 Tool line of docs/findings/03-experiments.md.


#### R-anat-4 [low] workloads/traceprof/README.md

Problem: The documented flame-graph command omits --title, so the regenerated flame.svg differs from the committed one in its title line: 'Device flame graph' against 'traceprof on aifoundry2: 32 harts of shire 0, cycles'.

Evidence: git diff after running the README command shows one changed line in flame.svg; flame.folded is identical. With --title "traceprof on aifoundry2: 32 harts of shire 0, cycles" both files are byte-identical.

Fix: Add that --title argument to the README command, and quote the full command in 03-experiments.md E3.


#### R-anat-5 [low] workloads/memprobe/report_template.html

Problem: The ladder chart title says '128 loads each', but the 'evicted to L2' row has 127 samples: analyze.py's v > −50 filter drops one reading of −80, a counter glitch the in-kernel correction missed.

Evidence: summary.json ladder['ladder:1'].n = 127. The dropped sample is label ('ladder', 211180096, 1, 1) with value −80 (48 − 128).

Fix: Change the title to '(cycles at 600 MHz, 128 loads each; one L2 reading dropped as a counter glitch)', or render n from D.ladder.


#### R-anat-6 [low] workloads/memprobe/gen_ops.py

Problem: The committed l3map raw data (8,192 lines) is not used by analyze.py or the page, and is not in the Reproduce list. The docstring gives '[--lines 4096]', but the shared --lines default is 64 and the committed run used 8,192.

Evidence: l3map.json meta {'start': 0, 'lines': 8192}. gen_ops.py l3map --out . writes 64 lines; --lines 8192 is byte-identical to the committed file. The data is consistent with the page: 8,134 of 8,192 L3 reads are within ±4 of 110+12·hops.

Fix: Correct the docstring to '[--lines N] (the committed run used 8192)'. Either mention l3map in the data README or 03-experiments.md E1 as a larger check of the L3 model, or drop it.


### Review findings


#### anat-v2-01 — MODIFIED [claim/high] et-soc1-memory-anatomy

Where: §6 'How long a row stays open' (report_template.html lines 300–307) and its chart #pto (JS lines 823–844)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/analyze.py, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-19-memprobe-aifoundry2/refresh_jit.u32, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-19-memprobe-aifoundry2/pagetimeout.u32, /tmp/claude-1019/-home-yaroslavvb-claude/ed6d06d5-de26-4323-94f1-0dc808eafbda/scratchpad/validate2/work/memory-anatomy/rowlife.py, /tmp/claude-1019/-home-yaroslavvb-claude/ed6d06d5-de26-4323-94f1-0dc808eafbda/scratchpad/validate2/work/memory-anatomy/an/analyze.py

Problem: The subsection concludes that rows close 'about twice as fast as refresh alone would ... so something else closes rows'. The page's own refresh series contradicts this for its line: there, only a refresh closed the row. The comparison baseline is also wrong in two ways. It ignores loads that land inside a refresh, which spoil a pair: 7.2% of loads, and that alone explains 67% against 87% at 0 idle cycles. It also assumes a random phase against refresh, but the pagetimeout loop has no random delay; gen_ops.py's own refresh docstring says a fixed loop locks onto refresh. The curve is not monotonic either: 53% at 200 cycles, then 71% at 400. For random lines, rows do seem to close sooner, so the page reports one side of mixed evidence as a finding. The DVFS page repeats the claim (finding anat-v2-02).


APPLY (CORRECTED): (1) analyze.py: add refresh.rowlife, refresh.hit_by_phase and refresh.in_refresh as proposed. In pagetimeout(), keep refresh_model and add refresh_model_loop, the mean over pairs of max(0, 1 − (A + 5 + ovh + d + in_refresh·P)/P). Here ovh is two op dispatches measured from the locked refresh series (median stamp-to-stamp minus load, divided by 4, times 2 ≈ 180). (2) Replace lines 301–305 with: 'Open-row hits save 11 cycles. A row stays open until a refresh, or a load to another row of its bank, closes it. That is what the controller's open-page policy with no idle-close timer implies (<code>docs/research/counters-and-dram.md</code>). In the refresh series, 96% of loads whose previous load came after the last refresh were row hits (3,556 of 3,713, after 450–2,000 idle cycles), against 4% of those with a refresh in between (201 of 5,382). Pairs of loads to two lines of one random row agree once the probe's own time is counted. Between the two loads the program spends about 180 cycles fetching its next ops from the scratchpad, on top of the first load's ~300 cycles, and 7% of loads land inside a refresh. Refresh alone then predicts about 75% hits with no added idle time, 30% after 1,000 cycles and 10% after 1,500; the pairs gave 67%, 23% and 5% (60 pairs each).' (3) Chart as in anat-v2-25, as modified. (4) Keep the refresh bullet '215 → 226'.

Base PROPOSAL (for "as proposed" references): (1) Analysis: in workloads/memprobe/analyze.py refresh(), add the row-life tables, as tested in scratch an/analyze.py. Unwrap the refresh_jit stamps. Place the refresh start at the first curve bin whose p90 is 260 or more. For each load of 150–239 cycles, take the idle gap to the previous load and whether a refresh started in between, and count a row hit when the load reads 220 or less. Emit refresh.rowlife = [{gap (250-cycle buckets), hit_no_refresh, n_no_refresh, hit_refresh, n_refresh}], refresh.hit_by_phase = [{phase 0–49, hit, n}] and refresh.in_refresh = 0.0721. In pagetimeout(), multiply refresh_model by (1 − in_refresh)². (2) Replace the paragraph at lines 301–305 with: 'Open-row hits save 11 cycles, the activate. For the line of the refresh series (memory shire 0), only a refresh closed its row. Of the loads whose previous load came after the last refresh, 96% were row hits (3,556 of 3,713, after 450–2,000 idle cycles); of those with a refresh in between, 4% were (201 of 5,382). That is what the controller's open-page policy with no idle-close timer implies (<code>docs/research/counters-and-dram.md</code>). Rows of random lines closed sooner. Pairs of loads to two lines of one row, with a set idle time between them, kept fewer hits than refresh alone allows from 700 idle cycles on (23% at 1,000, against about 38% once the 7% of loads that land inside a refresh are counted). In the ladder (§3), the loads with a fence and no wait found their row open for memory shires 0–2 (32 of 54) but rarely for shires 3, 5 and 7 (2 of 38). These runs cannot say what closes those rows early; other traffic to the same banks is one candidate. The pairs' loop had no random delay, so its phase against refresh was not random, and it sampled only memory shires 0, 2, 4 and 6.' (3) Replace the #pto chart as specified in anat-v2-25. (4) Keep the refresh bullet 'Refresh also closes the open row ... 215 → 226'; it is now backed by the numbers above.


Verifier note: The problem is real, and the page's claim is weaker than the reviewer says. I re-ran rowlife.py and refresh_check2.py and got the same numbers: 3,556/3,713 no-refresh hits against 201/5,382, and in_refresh = 1,370/19,000 = 0.0721. Moving the refresh boundary by up to 60 cycles makes the split even cleaner (3,691/3,708 against 66/5,387). The reconstructed memory shires {2:17, 6:17, 0:14, 4:12} and the locked loop (17,999/24,000 fast) also check out. But the replacement text keeps 'Rows of random lines closed sooner', and that is wrong for two reasons. (a) Both the page's baseline and the reviewer's '(1−0.072)²' baseline leave out the probe's own time between A and B. Every op is read from the L2 scratchpad as two volatile words, about 85–90 cycles per op. The no-jitter refresh loop spends 357 cycles per iteration outside the load (576 − 221) on 4 op dispatches. In refresh_jit the stamp-to-stamp gap minus the regenerated random delay has a median of 446. Between pagetimeout's A and B there are about 2 dispatches (~180 cycles), plus A's own latency and the 7% chance that A lands in a refresh. With that, refresh alone predicts 75/70/66/57/44/32/10/0% at 0–2,000 idle cycles; measured is 67/77/53/71/35/23/5/2% (n = 60). Most points are within 1.5 standard errors, and 200/400 swing in opposite directions, so there is no sign of a second closer. The same accounting fits the bits sweep: 1 dispatch gives about 76%, measured 75–77%. It also fits the DVFS wake-up data: 13/20 rows open after about 1,000 true idle cycles, 2/20 after about 2,200, where refresh alone predicts about 57% and 5%. (b) The ladder evidence cited, 'fence, no wait' by memory shire (32/54 against 2/38), is confounded. For memory shires 3, 5 and 7 those loads read above the closed-row model (median residuals +27, +10, +30), not at it. With no fence, the residuals rise from +10 (M0) to +94 (M3). So the load is still queued behind the evict at the memory shire; the row did not close early. The claim that the pairs' phase is not random is also weak: each trial uses a new random line, and the trial's 52 DRAM loads differ by up to ~170 cycles, which randomises the phase between trials. 'That alone explains 67 against 87' is overstated: 0.87 × 0.861 = 0.75. Also, multiplying the existing refresh_model changes an existing key. Emit a new key instead.


#### anat-v2-02 — MODIFIED [consistency/medium] et-soc1-dvfs-leakage

Where: DVFS report, 'DRAM: +10.5 cycles' bullet (docs/reports/sources/dvfs-leakage.body.html lines 153–155)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/dvfs-leakage.body.html

Problem: The DVFS report repeats memory anatomy's row-closing claim as a finding: 'found that idle rows close within a few microseconds, faster than refresh (every 3.88 µs) alone would close them'. For the refresh series' line the claim is contradicted (anat-v2-01), and for random lines it is unexplained.


APPLY (CORRECTED): Replace 'and found that idle rows close within a few microseconds, faster than refresh (every 3.88 µs) alone would close them; the +40 cycles in that report are a row conflict, a different case.' with 'and found that an idle row stays open until a refresh closes it (every 3.88 µs), as the memory controller's open-page policy implies; the +40 cycles in that report are for a load issued right behind another to a different row of the same bank, a different case.' Change '(§6)' to '(§5)' only if anat-v2-24 is applied. Rebuild with scripts/build-report.py dvfs-leakage.

Base PROPOSAL (for "as proposed" references): Replace 'and found that idle rows close within a few microseconds, faster than refresh (every 3.88 µs) alone would close them;' with 'and found that a row can stay open until a refresh closes it (every 3.88 µs), though rows of some random lines closed sooner;'. If the reorganisation in anat-v2-17 is applied, also change '(§6)' to '(§5)'. Rebuild with scripts/build-report.py dvfs-leakage.


Verifier note: Confirmed that the DVFS body repeats the claim (dvfs-leakage.body.html lines 153–155). Per anat-v2-01, the random-line data also fit refresh-only closing once the probe's loop time is counted. The DVFS page's own wake-up data agree: 13/20 open with no added idle and 2/20 at 1.7 µs, where refresh alone predicts about 57% and 5%. So 'though rows of some random lines closed sooner' should not be added. The proposal cites 'anat-v2-17' for the reorganisation; it means anat-v2-24. The same sentence's '+40 cycles … are a row conflict' also needs changing, to match anat-v2-05.


#### anat-v2-03 — MODIFIED [claim/medium] et-soc1-memory-anatomy

Where: §2 explorer intro (template line 174–175); §5 model-error sentence (line 257)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html

Problem: 'Latency comes from the model, which matches 97% of measured loads to ±3 cycles' is wrong. The 97% is per line, using the fastest of three loads of each line (1,450 of 1,500). Per measured load it is 83% (3,721 of 4,500). The page never says that per-load figure.


APPLY (CORRECTED): Line 174–175: 'Latency comes from the model, which is within ±3 cycles for 97% of lines (the fastest of three loads of each line; 83% of single loads).' Line 257: after 'within ±5 for 1,490' insert ' (of all 4,500 single loads, 83% are within ±3: taking each line's fastest drops refresh waits and a few cycles of jitter, though it keeps the timer glitches)'.

Base PROPOSAL (for "as proposed" references): Line 174–175: replace with 'Latency comes from the model, which is within ±3 cycles for 97% of lines (the fastest of three loads of each line; 83% of single loads).' Line 257: after 'and within ±5 for 1,490' insert ' (of all 4,500 loads, 83% are within ±3; taking each line's fastest drops most refresh waits and timer glitches)'. Rebuild with build_report.py.


Verifier note: Recomputed: per load 3,721/4,500 (82.7%) are within ±3; per line (fastest of 3) 1,450/1,500. The explorer intro's 'of measured loads' is wrong. But the proposed insertion for line 257 says taking the fastest 'drops most … timer glitches'. It does the opposite: a glitch reads 128 short, so the fastest of three picks it. All 7 glitch loads end up among the per-line minima, and §8 says so. The per-load misses are 451 at +4 to +10, 91 at +11 to +60, 229 above +60 (refresh) and 7 glitches.


#### anat-v2-04 — MODIFIED [claim/medium] et-soc1-memory-anatomy

Where: KPI 'Energy of one DRAM load 5.1 nJ' (template line 139); explorer readout for DRAM (JS line 654–656) and its energy cell

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html

Problem: PLAN D7 requires the 19 September anatomy energies to be marked as superseded wherever they appear. The headline KPI and the explorer both show 5.1 nJ with no mark. They also use the rail-trace total, although §7 itself says 'the host log's totals are the cleaner measure of the whole' (5.9 nJ). The canonical DRAM figure is 122 pJ/B, which is 7.8 nJ per 64-byte line. The part of this measurement that is not superseded is the split across the rails.


APPLY (CORRECTED): KPI as proposed. Readout: for all levels, append ' <span class="small">(19 Sep rail-trace average; superseded, see §7)</span>', and for DRAM '(19 Sep rail-trace average over all paths; superseded, see §7)'. Renumber §7 if anat-v2-24 is applied.

Base PROPOSAL (for "as proposed" references): KPI (line 139): lab 'Where a DRAM load's energy goes', val '⅔ unmetered', sub '67% off the metered rails (mostly DDR), 18% mesh, 10% SRAM, 5% cores. The total here, 5.1 nJ on the rail trace (5.9 on the host log), is superseded: the energy manual measures 122 pJ/B, 7.8 nJ per 64-byte line.' Readout (line 656): for DRAM replace '(measured average over all paths)' with '(19 Sep rail-trace average over all paths; superseded, see §7)'.


Verifier note: Confirmed from summary.json: dram_seq 5,069 pJ trace / 5,896 host; shares rest 0.67, NoC 0.18, SRAM 0.10, cores 0.05. The manual's DRAM is 121.96 → 7.8 nJ per 64 B. PLAN D7 requires the mark. However, the explorer shows superseded 19 September energies for every level, not just DRAM: L2 183 pJ = 2.9 pJ/B against the manual's 2.51, L3 own 8.5 / far 13.7 against 10.5. So marking only DRAM leaves L1, L2 and L3 unmarked.


#### anat-v2-05 — MODIFIED [claim/medium] et-soc1-memory-anatomy

Where: Explorer 'DRAM row: conflict' state (JS lines 562 and 588)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html

Problem: 'conflict' adds 'wait for the other row + precharge: 40' to a closed-row load. The +40 was measured only for load B issued one cycle behind load A to another row of the same bank (§6 bits, back to back). A single load that finds another row open pays about +13 over a closed row: precharge, tRP = 18.2 ns = 11 cycles. So a reader who picks 'conflict' gets three times the cost of an ordinary row conflict.


APPLY (CORRECTED): Replace DSTATES ['conflict','conflict'] with ['other','other row open'] (push ['precharge the other row (tRP)', 11, 'c7']) and ['queued','behind a load to another row'] (push ['wait for the other row + precharge', 40, 'c7']). In §6's first paragraph add: 'Issued one after the other instead, B pays about 9 cycles more (median) when it needs another row of A's bank (the precharge; tRP = 18 ns = 11 cycles), saves about 12 when it shares A's row, and costs nothing extra in another bank.'

Base PROPOSAL (for "as proposed" references): Replace DSTATES entry ['conflict','conflict'] with two entries: ['other','other row open'] (push ['precharge the other row (tRP)', 13, 'c7']) and ['queued','behind a load to another row'] (push ['wait for the other row + precharge', 40, 'c7']). Or keep a single button renamed 'behind a load to another row'. In §6's first paragraph add: 'Issued one after the other instead, B pays about +13 cycles when it needs another row of A's bank (the precharge, tRP = 18 ns), saves about 12 when it shares A's row, and costs nothing extra in another bank.'


Verifier note: Real: +40 is B issued one cycle behind A to another row of the same bank (ab_med 337–346 against ~300). It is not the cost of a single load that finds another row open. But the proposed +13 is the mean of b_minus_b0, which a tail of refresh waits pulls up. For bits 18–29 the median is +9 and the mode is +8 to +11 (1,800 pairs; trimmed mean 8.6), in line with tRP = 18.2 ns = 11 cycles. Bits 13–17: median −12. Bits 6–12: median −1.


#### anat-v2-06 — CONFIRMED [claim/low] et-soc1-memory-anatomy

Where: §5 DRAM split (template lines 270–273); lede line 124–125; KPI line 137; explorer parts() lines 585–587

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/15-earlier-findings.md

Problem: The DRAM chip's share uses 'the 19.3 ns read latency and a 4.3 ns burst (14 cycles)'. According to the repo's own controller notes, a 64-byte line is two BL16 bursts in one row, 8.6 ns. The chip's share is then about 18.2 + 19.3 + 8.6 = 46 ns, which is 28 cycles, not 25, and the memory shire's share is about 63 cycles, not 66, unless the controller forwards the first 32 bytes early. The conclusion ('only a small part is the DRAM chip') stands.


APPLY (PROPOSAL): Line 270–273: 'Of the 91 cycles (152 ns), the DRAM chip itself accounts for about 25–28: an activate (tRCD, 11 cycles = 18 ns, §6), the 19.3 ns read latency, and one or two 4.3 ns bursts for the 64-byte line (14–17 cycles), from the controller's timing registers. The remaining ~63–66 cycles (~105–110 ns) are the memory shire ...'. Change the lede and KPI '~25' to '~25–28'. Leave the explorer at 66/14 and note 'one burst assumed' in the DRAM read segment's tooltip, or move 3 cycles from 66 to 14→17.


Verifier note: counters-and-dram.md line 335 gives '2 × BL16 = 64 B ≈ 8.6 ns' and line 366 'a 64 B line is 2 BL16 bursts'. 18.2 + 19.3 + 4.3 = 41.8 ns = 25 cycles; with 8.6 ns it is 46.1 ns = 28 cycles. '25–28' is the honest range, and the conclusion stands. If anat-v2-20 is applied, the KPI sentence goes away and only the lede changes.


#### anat-v2-07 — MODIFIED [claim/low] et-soc1-memory-anatomy

Where: §8 (template line 356–357)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html

Problem: 'the carry into bit 7 lands 11 cycles late. A simulation of the open RTL shows why' implies the simulation reproduces the card. The simulation (core-et Erbium at b38a1a3, a later revision) gives 12 short reads per wrap, not 11. PLAN D16 also requires the Erbium wording for RTL.


APPLY (CORRECTED): Replace 'A simulation of the open RTL shows why:' with 'A simulation of the open RTL (core-et's Erbium branch at b38a1a3: the same Minion core lineage in a later MCU-class configuration, not the taped-out ET-SoC-1) shows the mechanism, with a 12-cycle window where this card shows 11:'.

Base PROPOSAL (for "as proposed" references): Replace 'A simulation of the open RTL shows why:' with 'A simulation of the open RTL (core-et's Erbium branch at b38a1a3: the same Minion core lineage in a later configuration, not the taped-out ET-SoC-1) shows the mechanism, with a 12-cycle window where this card shows 11:'.


Verifier note: I re-ran rtl-sim/pmu_carry/obj_dir/Vtb: steps of −127 at low-7 value 0 and +129 at 12, so 12 short reads per wrap against 11 on the card (the README and E2 say the same). The Erbium caveat is required, but PLAN D16's canonical wording includes 'MCU-class', which the proposal drops.


#### anat-v2-08 — MODIFIED [claim/low] et-soc1-memory-anatomy

Where: §5 first paragraph (template lines 246–247)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html

Problem: '(each load at least 1,000 idle cycles after the row was last used, so the row had closed and every load paid an activate ...)' rests on the idle-close reading that anat-v2-01 undermines. The direct evidence that these loads found closed rows is different: the model matches the closed-row time.


APPLY (CORRECTED): '(each line's previous DRAM load came a full pass over the 1,500 lines earlier, about 4 ms and a thousand refreshes before, so its row had closed and every load paid an activate: home shire 0's lines read 225 cycles, the refresh series' closed-row time for a line of the same home and memory shire (226), not its open-row time (215); no contention)'.

Base PROPOSAL (for "as proposed" references): Replace with '(each load came at least 1,000 idle cycles after the line's evict, and its time is a closed row's: the model gives 225 cycles for home shire 0, the refresh series' closed-row time (226), not its open-row time (215); so every load paid an activate; no contention)'.


Verifier note: The current parenthetical rests on idle-close. But the proposed justification 'the model gives 225 cycles for home shire 0' is circular: the 91-cycle constant and the memory shire positions were fitted to these same loads. The independent facts are these. (i) Home-0 lines' measured fastest-of-three median is 225, against the refresh series' 226 closed / 215 open for a line with the same home and memory shire. (ii) Each line's previous DRAM access was a full pass over the other 1,500 lines earlier (~1,750 cycles per line, so ~4 ms and about 1,100 refreshes).


#### anat-v2-09 — CONFIRMED [claim/low] et-soc1-memory-anatomy

Where: Ladder chart title (template line 218)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html

Problem: The title says '128 loads each', but the 'evicted to L2' row has n = 127. analyze.py's v > −50 filter drops one −80 reading, a counter glitch that the in-kernel correction missed.


APPLY (PROPOSAL): Change the title to 'Load-to-use latency by where the line was left (cycles at 600 MHz; 128 loads each, one L2 reading dropped as a counter glitch)'.


Verifier note: summary.json ladder:1 n = 127. The dropped reading is ('ladder', 211180096, 1, 1) = −80 = 48 − 128, a missed carry glitch.


#### anat-v2-10 — CONFIRMED [claim/low] et-soc1-memory-anatomy

Where: §7 energy table, 'cycles/load' column (JS line 876–877)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/analyze_power.py, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html

Problem: cycles/load is the mean minion's (cycles_mean × minions / loads), but loads/s is set by the slowest minion. For far L3 and row conflicts, the slowest minion is 14% and 10% slower, so the row-conflict pattern reads faster than the sequential one (496 against 507 cycles) while it moves fewer loads per second (1.13 G against 1.21 G). That looks like an error.


APPLY (PROPOSAL): In analyze_power.py add 'cycles_per_load_slowest' = mean(cycles_max × minions / loads) per pattern and show the column as 'cycles/load (mean / slowest minion)': L1 11.0/11.0, L2 56.4/56.4, L3 own 205/206, far 258/294, DRAM seq 507/508, row conflicts 496/546. Alternatively add to the caption: 'cycles/load is the mean minion's; the slowest minion, which sets loads/s, took 14% longer on far L3 and 10% longer on row conflicts.'


Verifier note: From runs.jsonl: cycles_max/cycles_mean is 1.141 for l3far and 1.100 for dram_row, ≤1.002 otherwise. Slowest minion: l3far 294.2, dram_row 545.7 cycles/load, and 1,024 × 0.5997/545.7 = 1.125 G = the rate. The table shows dram_row 496 against dram_seq 507 while dram_row's loads/s is lower (1.13 against 1.21 G). Either fix is fine.


#### anat-v2-11 — CONFIRMED [claim/low] et-soc1-memory-anatomy

Where: §6 refresh intro (template line 288)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html

Problem: '(tREFI, the refresh interval, is 3.9 µs)' quotes the JEDEC nominal value. The controller's programmed interval, in the repo's own notes, is 3.87 µs, and that matches the measured 3.876 µs to 0.1%. That match is the stronger check, and it is what §3's claim that the clock was steady at 600 MHz rests on.


APPLY (PROPOSAL): Replace with '(the controller is programmed for one every 3.87 µs, tREFI; <code>docs/research/counters-and-dram.md</code>)'.


Verifier note: counters-and-dram.md line 312: t_rfc_nom = 113 (×32) = 3,616 → ~3.87 µs; measured period_us 3.8757. The ×32 reading is itself an inference in that note, and the measured match supports it.


#### anat-v2-12 — MODIFIED [consistency/low] et-soc1-memory-anatomy

Where: Explorer map caption (template lines 205–207)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html

Problem: 'The map appears to be the die turned a quarter (more exactly, with rows and columns swapped)' names two different transforms: a quarter turn is a rotation, while swapping rows and columns is a transpose, i.e. a rotation plus a mirror. PLAN D9's canonical wording is 'the die turned a quarter'.


APPLY (CORRECTED): Delete '(more exactly, with rows and columns swapped)' from memory anatomy's map caption and '; more exactly, with rows and columns swapped' from on-chip communication line 135, so both say 'the die turned a quarter' (D9).

Base PROPOSAL (for "as proposed" references): Delete '(more exactly, with rows and columns swapped)'. If Heat per millimetre's die map shows a transpose, change D9 and the hub glossary instead, so that every page says the same.


Verifier note: PLAN D9 says 'the die turned a quarter', and no repo note or Heat per millimetre section establishes a transpose. The die study gives tile size, not the order of memory shires along the sides; counters-and-dram.md only says '0-3 west, 4-7 east'. But the on-chip communication page (docs/reports/2026-09-18-et-soc1-on-chip-communication.html line 135) has the same parenthetical. Deleting it on one page only would make the two pages disagree.


#### anat-v2-13 — MODIFIED [reproducibility/medium] et-soc1-memory-anatomy

Where: §10 Reproduce, pagetimeout line (template line 394)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/gen_ops.py

Problem: The documented command generates a different experiment from the committed data. It uses the defaults 0,50,…,25,600 (1,320 timed ops), while the committed run used 0,100,…,20,000 (1,560). So the 'How long a row stays open' curve cannot be reproduced from the page.


APPLY (CORRECTED): Append ' --delays 0,100,200,400,700,1000,1500,2000,3000,5000,8000,12000,20000' to the page's pagetimeout line (and the README copy, if anat-v2-23 moves it). Leave the shared default alone, or give pagetimeout its own default inside pagetimeout().

Base PROPOSAL (for "as proposed" references): Append ' --delays 0,100,200,400,700,1000,1500,2000,3000,5000,8000,12000,20000' to line 394. Also change gen_ops.py's --delays default to that list, so that the command and the default agree. Rebuild the page.


Verifier note: Confirmed. The documented command gives 1,320 timed ops. Adding --delays 0,100,…,20000 reproduces the committed labels and meta exactly (1,560). But gen_ops.py's --delays default is shared with the wakeup experiment, so changing it to a pagetimeout-specific list would change what wakeup does by default. The committed wakeup command passes --delays explicitly, so nothing breaks, but it is the wrong place for this.


#### anat-v2-14 — CONFIRMED [reproducibility/medium] et-soc1-memory-anatomy

Where: workloads/memprobe/analyze_power.py read_trace() (lines 25–36); §10 Reproduce; docs/findings/03-experiments.md E1 'Tool' line

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/analyze_power.py, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/run_power.py, /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/03-experiments.md, /tmp/claude-1019/-home-yaroslavvb-claude/ed6d06d5-de26-4323-94f1-0dc808eafbda/scratchpad/validate2/work/memory-anatomy/analyze_power_patched.py

Problem: No committed script can re-analyse the committed power data. analyze_power.py reads only dev0_sp_stats*.bin or trace/*.done, which are not committed, and it fails with an IndexError. Nothing writes or reads the committed power/sp_stats.csv. The page's 'rebuild from the committed data' runs only build_report.py.


APPLY (PROPOSAL): In read_trace(), after the .bin loop: if no records were read and <folder>/sp_stats.csv exists, read it (key int(sp_us); minion_w→minion, sram_w→sram, noc_w→noc, board_w→system). Otherwise stop with 'no dev0_sp_stats*.bin, trace/*.done or sp_stats.csv'. Add '--csv PATH', which writes the merged trace as 'sp_us,minion_w,sram_w,noc_w,board_w' with rails at %.3f and board at %.2f. Call it from run_power.py's final step, or document it in the Reproduce command: analyze_power.py build/memprobe-power --json … --csv build/memprobe-data/power/sp_stats.csv. Replace the page's '# To rebuild this page from the committed data instead:' block with three lines: analyze_power.py docs/reports/data/2026-09-19-memprobe-aifoundry2/power --json docs/reports/data/2026-09-19-memprobe-aifoundry2/power/summary.json; analyze.py --data docs/reports/data/2026-09-19-memprobe-aifoundry2 --out docs/reports/data/2026-09-19-memprobe-aifoundry2/summary.json; build_report.py … . In 03-experiments.md E1, change Tool to '(device kernel …, gen_ops.py, run_power.py, analyze_power.py, analyze.py, build_report.py)'.


Verifier note: analyze_power.py on the committed power folder raises IndexError (no .bin or trace files). The reviewer's patched script reproduces power/summary.json byte-identically (cmp) and writes sp_stats.csv byte-identically; the trace is aligned with rms 0.94 W over 2,147 records.


#### anat-v2-15 — MODIFIED [reproducibility/low] et-soc1-memory-anatomy

Where: workloads/memprobe/gen_ops.py module docstring (lines 7–14) and pagetimeout() (line 230–247)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/gen_ops.py, /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/03-experiments.md

Problem: The docstring is stale:
- l3map '[--lines 4096]': the shared default is 64, and the committed run used 8,192.
- refresh '[--n 60000]': the default is 24,000.
- decomp '[--lines 2048] [--reps 4]': the defaults are 64 and 3.
- pagetimeout '--base 0x...': it is ignored; --row-bit and --delays matter.

The committed l3map run (8,192 lines) is used nowhere and is listed nowhere.


APPLY (CORRECTED): Docstring as proposed, plus 'gen_ops.py msmap --out D [--lines 64]' and 'gen_ops.py wakeup --out D [--reps 3] [--delays d1,d2,…]'. In 03-experiments.md E1 Method: 'l3map.u32: 8,192 consecutive lines as L3 hits, a larger check of the L3 model (8,124 within ±4 of 110 + 12·hops, 8 counter glitches); not used on the page.'

Base PROPOSAL (for "as proposed" references): Docstring: 'gen_ops.py l3map --out D [--lines N]   (the committed run used 8192)'; 'refresh --out D [--n 24000] [--jitter C] [--name N] [--start A]'; 'decomp --out D [--lines 64] [--reps 3] [--pre-delay 2000]'; 'pagetimeout --out D [--row-bit 13] [--delays d1,d2,…] [--trials 24]'. In 03-experiments.md E1 Method add: 'l3map.u32: 8,192 consecutive lines as L3 hits, a larger check of the L3 model (8,134 within ±4 of 110 + 12·hops); not used on the page.'


Verifier note: The stale docstring defaults are confirmed (--lines 64, --reps 3, --n 24000; pagetimeout ignores --base). l3map regenerated with --lines 8192 is byte-identical to l3map.json. But the l3map count is wrong: I get 8,124 of 8,192 within ±4 of 110 + 12·hops (8,177 within ±5; 8 glitches), not 8,134. The docstring also leaves out msmap and wakeup, and the proposal does not add them.


#### anat-v2-16 — MODIFIED [reproducibility/low] et-soc1-memory-anatomy

Where: workloads/memprobe/gen_ops.py pagetimeout() (for the next card run; no page change now)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/gen_ops.py

Problem: The row-open experiment cannot separate an idle-close from refresh, for three reasons. Its loop has no random delay, so its phase against refresh is not random. Its addresses are rng.randrange(0, 2**27 // 64) * 64 * 2, so PA bit 6 is always 0 and only memory shires 0, 2, 4 and 6 are sampled. And it cannot show whether a refresh fell between A and B.


APPLY (CORRECTED): For the next quiet-card session: stamp immediately before A and before B (p.stamp(('tA',d,t)), p.stamp(('tB',d,t))), so the true A→B gap is measured. Use a fixed set of lines, one per (memory shire, channel), reused over many trials (≥1,000 loads per channel), so analyze.pagetimeout() can fit each channel's refresh phase as refresh.rowlife does. Draw addresses with a = rng.randrange(0, (1 << 28) // 64) * 64 & ~neighbour to cover all memory shires. Record it as a new session in 03-experiments.md.

Base PROPOSAL (for "as proposed" references): For the next quiet-card session: use a = rng.randrange(0, (1 << 28) // 64) * 64 & ~neighbour (all memory shires). Add 'if args.jitter: p.delay(rng.randrange(args.jitter))' before p.tload(a, ('A', d, t)), and run with --jitter 2400. Add p.stamp(('tA', d, t)) before A, so that analyze.pagetimeout() can split pairs by whether a refresh started between them, as refresh.rowlife does. Record it as a new session in 03-experiments.md.


Verifier note: The facts are right: no stamps, addresses ×2 so PA bit 6 = 0, and only memory shires 0/2/4/6. But the analysis plan fails. Refresh runs per controller: 8 memory shires × 2 channels, not known to be in step. Random lines spread over 16 channels give only ~6 in-refresh loads per channel for 1,560 loads, far too few to fit each channel's refresh phase, so a single stamp cannot say whether a refresh fell between A and B. The main confound was also the unmeasured loop time between A and B (anat-v2-01), and stamps around both loads fix that directly. Jitter is not needed: random lines already randomise phase.


#### anat-v2-17 — MODIFIED [reproducibility/low] et-soc1-limits-of-observability

Where: workloads/traceprof/README.md flame-graph command; 03-experiments.md E3 (the hub quotes '512 events from 32 harts')

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/traceprof/README.md, /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/03-experiments.md

Problem: The documented command regenerates flame.svg with the title 'Device flame graph' instead of the committed 'traceprof on aifoundry2: 32 harts of shire 0, cycles'. flame.folded is identical. Also, the hub's '0.15 s of card time' is recorded nowhere in the data.


APPLY (CORRECTED): Add the --title to the README's trace-flamegraph.py command and quote the full command in 03-experiments.md E3. For the hub's '0.15 s of card time': either record the host's wall time in the data folder, or replace it with 'in 2.6 ms of kernel time (1.57 M cycles)', which the events show.

Base PROPOSAL (for "as proposed" references): In workloads/traceprof/README.md, append --title "traceprof on aifoundry2: 32 harts of shire 0, cycles" to the trace-flamegraph.py command, and quote the full command in 03-experiments.md E3. Either source the hub's '0.15 s of card time' (add the host's wall time to the data folder) or drop it.


Verifier note: Confirmed: without --title, flame.svg differs; with --title 'traceprof on aifoundry2: 32 harts of shire 0, cycles', flame.svg and flame.folded are byte-identical. But the '0.15 s of card time' is not recorded nowhere. workloads/traceprof/README.md line 10 has it as a comment on the run command ('# 0.15 s of card time'). It is unsupported by the data, whose events span 1,572,824 cycles (2.6 ms at 600 MHz) of kernel time.


#### anat-v2-18 — MODIFIED [redundancy/medium] et-soc1-memory-anatomy

Where: Top 'Later measurements' box (lines 130–134); §7 last bullet 'Later measurements put DRAM higher' (lines 340–351); Related item 'The energy manual, §4'

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html

Problem: The page tells the superseded-energy story three times. The top box gives 122 against 79 and the hop at 'about twice 0.9'. The §7 bullet repeats both numbers at length and also re-quotes the energy manual's per-hop fits (0.64–0.75 and 1.67–1.81, 2.1–2.3 over 1–6 hops) and Heat per millimetre's 1.5–2.2, which are those pages' canonical content. The 14–20% figure repeats the previous bullet's '16–25% higher' as its reciprocal.


APPLY (CORRECTED): '<b>Later measurements put DRAM higher</b> (see the note at the top): 122 pJ/B [117–129] in the energy manual (§4: 1 KB tensor loads over memory whose contents were not set, on two cards; with the data known, 91 pJ/B on zeros and 129 on random data), against 79 here on the rail trace and 92 on the host log, from 8-byte <code>ld</code>s that each bring a 64-byte line through the caches, on one card. For a mesh hop, use Heat per millimetre, not this page's ~0.9 pJ/B.' In the top box, cut 'The last note in §7 compares the numbers.' Keep the Related item.

Base PROPOSAL (for "as proposed" references): Replace the §7 last bullet with: '<b>Later measurements put DRAM higher</b> (see the note at the top): 122 pJ/B [117–129] in the energy manual (§4), against 79 here on the rail trace and 92 on the host log. This page's loads were 8-byte lds of lines whose contents were never set, on one card; the manual used 1 KB tensor loads on known data (91 pJ/B on zeros, 129 on random) on two cards. For a mesh hop, use Heat per millimetre, not this page's ~0.9 pJ/B.' In the top box, cut 'The last note in §7 compares the numbers.' Keep the Related item.


Verifier note: The redundancy is real. But the replacement bullet gets the manual's basis wrong. The manual's 122 pJ/B [117–129] is from 1 KB tensor loads over memory whose contents the probe does not set (energy-manual.script.js: 'The probe does not set the memory's contents'; PLAN D7). The 91/129 figures are a separate known-data measurement. As written, 'the manual used 1 KB tensor loads on known data (91 … 129)', set against this page's 'lines whose contents were never set', implies the contents explain the gap. They do not: both are over unset memory.


#### anat-v2-19 — MODIFIED [redundancy/medium] et-soc1-memory-anatomy

Where: §1 table 'Notes' cells: Time (line 161), Where a line lives (162), Rail power (167), Out of reach (168)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html

Problem: The §1 table repeats at length material that has another home:
- The Time row repeats §8: the 4,000 pairs, 'exactly 10', and 57 of 4,000.
- 'Evicting a dirty line and fencing costs 112–480 cycles (median 241)' repeats the ladder table and its footnote.
- Rail power repeats Power and temperature §2 and PLAN D2 (61% after 1 s, 88% after 2 s), plus a tool note that belongs in workloads/memprobe/README.md ('The ring holds ~15 minutes, and an extract returns only records since the last wrap, so extract often'; the README already has it).
- Out of reach repeats §9's third bullet (the M-mode syscall, the signed firmware) and §9's first bullet ('changes a shared card, so it isn't done here').


APPLY (CORRECTED): Time notes: 'Reads 128 short when its low 7 bits are 0–10 (§8). Even corrected in the kernel, about 1 timed interval in 70 is still ±128 off: drop those, or take the median of repeated loads rather than the fastest. The standard <code>cycle</code> CSR traps.' Move '(57 of 4,000 corrected timed no-ops read 138 or −118)' into §8 in place of '(see §1)'. Out of reach: 'DRAM activate/precharge counts, shire-cache hit/miss and occupancy, NoC counters (all need an M-mode syscall to choose events), per-event energy and faster power sampling. §9 says what would reach them; the full list is in <code>docs/research/counters-and-dram.md</code>.' The other two rows as proposed.

Base PROPOSAL (for "as proposed" references): Time notes → 'Reads 128 short when its low 7 bits are 0–10 (§8). Even corrected in the kernel, about 1 timed interval in 70 is still ±128 off: drop those, or take a median. The standard <code>cycle</code> CSR traps.' Where a line lives: cut the last sentence and end with '… still open (§3). A dirty line's evict costs a write-back (§3).' Rail power notes → 'The PMIC's own running average (τ ≈ 1 s), copied once per 133 ms pass (<a href='…et-soc1-power-temperature#a-load-step-seen-through-every-sensor'>Power and temperature §2</a>). There is no DDR rail: the rest is the board minus the three rails.' Out of reach notes → 'DRAM activate/precharge counts, shire-cache hit/miss and occupancy, NoC counters, per-event energy and faster power sampling. §9 says what would reach them; the full list is in <code>docs/research/counters-and-dram.md</code>.'


Verifier note: The repeats are real. The README has the ring note, and §9 has the M-mode and signed-firmware points. But two cuts lose what a reader needs. (1) The Time note's 'take the median of repeated loads rather than the fastest' is the practical rule: §5's fastest-of-three is exactly what picked up the 7 glitches. The proposal keeps only 'or take a median'. (2) §8 says 'Inside a running kernel it catches most but not all of them (see §1)', and the 57-of-4,000 count exists only in §1. Cutting it leaves §8 pointing at a vaguer figure. In 'Out of reach', the reason (these counters need an M-mode syscall to choose events) is also dropped.


#### anat-v2-20 — CONFIRMED [redundancy/low] et-soc1-memory-anatomy

Where: KPI 1 sub-text (line 137); KPI 4 (line 140) against the lede (lines 124–125)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html

Problem: KPI 1's 'Only ~25 cycles are DRAM timing; the rest is on-chip paths.' repeats the lede sentence 'Of a typical DRAM load's ~300 cycles, only about 25 are the DRAM chip's own timing; the rest is paths on the chip.' next to it.


APPLY (PROPOSAL): Cut that sentence from KPI 1's sub. Its sub becomes '500 ns at 600 MHz: median of 4,500 loads from shire 0 to random lines.'


Verifier note: The KPI 1 sub repeats the lede sentence next to it (lines 124–125 and 137).


#### anat-v2-21 — CONFIRMED [redundancy/low] et-soc1-memory-anatomy

Where: §3 ladder chart (#ladder) and ladder table (#ladder-table), lines 218–221

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html

Problem: The table repeats the chart's min, median, 90% and max for the same six rows, and the chart's hover already gives those numbers. Only the dirty-evict row and 'median ns' are new. On a phone the pair takes two screens.


APPLY (PROPOSAL): Wrap the table in <details><summary>The numbers (min, median, 90th percentile, max, median in ns)</summary>…</details>. Keep the dirty-evict row and its footnote visible as one sentence under the chart: 'Evicting a dirty line and fencing, which is not a load, took 112–480 cycles (median 241), the write-back; one of 128 took 16, as fast as a clean one.'


Verifier note: The table duplicates the chart's min/median/90%/max for the same rows, and the chart hover carries them. The dirty-evict line is kept visible, so no information is lost.


#### anat-v2-22 — CONFIRMED [redundancy/low] et-soc1-memory-anatomy

Where: §7 first paragraph, last sentence (lines 315–317); Versions line (lines 409–412)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html

Problem: The §7 sentence on delivery losses re-quotes the hub's §4.2 fit ('18–20% of the minion rail's power, 5–6% of the SRAM rail's, and part of the 26–29% it attributes to the mesh rail'), and the hub is the canonical home. The Versions line is a changelog of the review: 'the split of a DRAM load in §5 (…), the model's error counts, the reading of the evict ladder in §3, why the two board readings in §7 differ, and links …'.


APPLY (PROPOSAL): §7 → 'It also holds the regulators' delivery losses on the three metered rails (18–20% of the minion rail's power; <a …#the-unmetered-remainder-attributed>hub §4.2</a>).' Versions → 'Versions: published 19 September 2026; revised 24 September 2026 (the DRAM split in §5, the row and energy comparisons).' The full list is already in docs/findings/04-artifacts.md A1.


Verifier note: The hub body holds 18–20% and 26–29%. The '5–6% of the SRAM rail's' figure is not in the hub text at all, so trimming it also removes an unsourced number. 04-artifacts.md A1 already lists the revision details.


#### anat-v2-23 — MODIFIED [redundancy/low] et-soc1-memory-anatomy

Where: §10 Reproduce block (lines 385–404)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/README.md

Problem: 18 lines of card-side commands, most longer than the frame, scroll sideways on every screen. They are method notes that belong in the workload's README, which currently points back to the page for them. Meanwhile the 'rebuild from the committed data' part, the one a reader can actually run, is incomplete (anat-v2-14).


APPLY (CORRECTED): Keep the card commands on the page, with the --delays fix, optionally inside <details><summary>Card runs (each under timeout 10)</summary>. Put first, visible, a block '# Rebuild everything from the committed raw data (no card needed)' with the three commands from anat-v2-14 (analyze_power.py, analyze.py, build_report.py). Update the README's pointer if anything moves.

Base PROPOSAL (for "as proposed" references): Move the card-side commands, with the --delays fix, to a new '## Reproduce the report' section of workloads/memprobe/README.md. Replace the page block with: '# Rebuild everything from the committed raw data (no card needed)' followed by the three commands from anat-v2-14 (analyze_power.py, analyze.py, build_report.py), then the line '# The card runs (each under timeout 10, under 0.2 s of card time): workloads/memprobe/README.md#reproduce-the-report'. Keep the 'Raw results …' paragraph.


Verifier note: The rebuild-from-committed block is incomplete (anat-v2-14) and the pagetimeout line is wrong (anat-v2-13). Both are real. But moving every card-side command off the page makes it less self-contained, and sibling pages keep full reproduce blocks (DVFS has its wake-up command on the page). A <pre> that scrolls sideways is normal for code and is not an overflow of the page.


#### anat-v2-24 — MODIFIED [reorganize/medium] et-soc1-memory-anatomy

Where: Section order (h2s)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-on-chip-communication.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/dvfs-leakage.body.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/sources/limits-of-observability.data.json

Problem: The page opens with an 8-row instrument table (§1), which reads as reference material and is unreadable on a phone, before the explorer that answers the title's question. 'What the chip lets you see' and 'What would split it further' are two halves of one topic, but they sit at opposite ends of the page.


APPLY (CORRECTED): As proposed, but either keep the firmware sentence in the moved 'What the chip lets you see' section, or put D16's full wording in the byline: '· firmware source read at et-platform 353f20e; the card's own trace strings match an older build (before et-platform commit 60b40c10f, 24 Sep 2024)'. Renumber as listed, including '§7' in the top box. Update on-chip communication (§5 → §4), DVFS (§6 → §5) and limits-of-observability.data.json ('§7' → '§6'), then rebuild.

Base PROPOSAL (for "as proposed" references): New order, keeping every id:
1. Trace one load (#trace-one-load)
2. The ladder, one load at a time (#the-ladder-one-load-at-a-time)
3. L3: 110 cycles plus 12 per hop (#l3-110-cycles-plus-12-per-hop)
4. The memory shire leg (#the-memory-shire-leg-91-cycles-plus-12-per-hop)
5. Inside the DRAM (#inside-the-dram-rows-banks-and-refresh)
6. Where the energy goes (#where-the-energy-goes)
7. A timer bug worth knowing (#a-timer-bug-worth-knowing)
8. What the chip lets you see (#what-the-chip-lets-you-see), with the table trimmed per anat-v2-19
9. What would split it further (#what-would-split-it-further)
10. Reproduce (#reproduce)

Move the firmware sentence at the start of old §1 into the byline: '· firmware as installed (source read at et-platform 353f20e)'.

Renumber the in-page references:
- '§1' → '§8' in §8's '(see §1)'
- '§3' → '§2'
- '§4, §5' → '§3, §4'
- '§5' → '§4'
- '§6' → '§5'
- '§7' → '§6' (top box, Related list)
- '§8' → '§7'

Update the other pages that cite numbers:
- docs/reports/2026-09-18-et-soc1-on-chip-communication.html line 135 '(§5)' → '(§4)'
- docs/reports/sources/dvfs-leakage.body.html '(§6)' → '(§5)'
- docs/reports/sources/limits-of-observability.data.json line 928 'Anatomy of a memory access, §7' → '§6'


Verifier note: The order is reasonable, and anchor ids are kept. Inbound anchors are where-the-energy-goes (9), l3-… (6), inside-the-dram… (2) and the-memory-shire-leg… (1). I found exactly the three cross-page § references listed. But the byline text drops the firmware caveat that PLAN D16 requires until the owner resolves it ('the cards' own trace strings match an older build …').


#### anat-v2-25 — MODIFIED [visualization/high] et-soc1-memory-anatomy

Where: §6 'How long a row stays open': replaces the #pto chart

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/analyze.py, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/build_report.py

Problem: The current chart plots the delay experiment against a 'refresh only' line that leaves out loads caught in a refresh and assumes a random phase. So it shows a mystery closer that the page's own refresh series does not show. The page asks 'how long does a row stay open, and what closes it?', and no chart answers that.


APPLY (CORRECTED): One mode, 'by idle time': one line with no refresh in between (dots sized by n; merge the ≥1,750 bucket into the previous one or mark the boundary uncertainty); one line with a refresh in between; random-row pairs (hollow dots with 95% binomial whiskers, x = programmed delay, captioned 'plus ~180 cycles of probe time and the first load'); and the dashed 'refresh alone' from the new refresh_model_loop key (anat-v2-01). Add a note: 'no pair hit at 3,000–20,000 cycles (1 of 300)'. Optionally show hit share by refresh phase as a toggle on the existing refresh chart instead of a second mode. Keep the accessibility and width requirements as proposed. Takeaway: one closer, refresh.

Base PROPOSAL (for "as proposed" references): New chart 'What closes a DRAM row' (inline SVG in #pto, vanilla JS). Data:
- the new summary.json keys from anat-v2-01: refresh.rowlife[] {gap, hit_no_refresh, n_no_refresh, hit_refresh, n_refresh}, refresh.hit_by_phase[] {phase, hit, n}, refresh.in_refresh;
- the existing pagetimeout[] {delay, hit, refresh_model};
- in build_report.py: data.rowlife, data.hitPhase and data.inRefresh.

Two modes on a .seg button group ('by idle time' and 'by moment in the refresh period'):
- By idle time: x is idle cycles since the row was last used (0–3,500, linear), y is the % of loads that found the row open (0–100). Series:
  - var(--c1) line with dots sized by n: 'one line, no refresh in between' (about 96% flat);
  - var(--c2) line: 'one line, a refresh in between' (about 4%);
  - var(--c3) hollow dots with 95% binomial whiskers: 'two lines of one random row, fixed delays' (pagetimeout, n = 60 each);
  - var(--ref) dashed line: 'refresh alone, counting loads caught in one' = refresh_model × (1 − in_refresh)².
- By moment: bars of hit/n for the 50 phase bins on the same 0–3.88 µs axis as the refresh chart above. Shade in var(--grid) the bins where the refresh curve's p90 is 260 or more. The bars show 0% right after refresh, rising to about 50% just before the next one, which explains why that chart's median reads 215 only at the end.

Hover or tap on any point shows hits/n and the gap range. The mode buttons are <button aria-pressed>. The points are focusable (tabindex=0, role=img, aria-label with the numbers), and a <details> table holds the same numbers. Width follows the host (anat-v2-31); it fits 390 px without scrolling. Legend chips use the tokens.

The reader's understanding changes: the chart shows that refresh alone closes this line's row, that the random-row experiment falls between the two lines, and that the question is open rather than settled by an idle timer.


Verifier note: The data exist (refresh_jit, pagetimeout), and a chart answering 'what closes a row' is worthwhile. But as specified, its 'refresh alone' line, refresh_model × (1 − in_refresh)², leaves out the ~180 cycles of probe time between A and B. So it would still show the random-row pairs well below refresh-only (23% against 38% at 1,000 idle cycles), which misrepresents the data: with the loop time counted it is about 30%, within noise (anat-v2-01). The pagetimeout x-axis is the programmed delay, not the true idle time. The no-refresh series' last bucket (85/103 at 1,750) is a boundary artefact: one bin later it is 120/123. Plotted as it stands, it reads as rows starting to close. The 'by moment in refresh period' mode is secondary.


#### anat-v2-26 — MODIFIED [visualization/high] et-soc1-memory-anatomy

Where: §2 explorer (#mesh, #flame, #readout, #cells); complements §4's L3 scatter and §5's model-error histogram

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/analyze.py, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/build_report.py

Problem: The page's main result is a latency model accurate to about ±3 cycles, but the explorer shows only the model. A reader cannot see the measurement behind a chosen path, or where that path sits among real loads. The default path (shire 0 to home 31) reads 345 cycles, next to a KPI of '299 typical', with nothing to reconcile the two. The map colours only L3 latency, so the memory-shire leg, the half of the model that §5 found, is invisible on it. Map cells are <g> elements with click handlers only, so they cannot be reached by keyboard.


APPLY (CORRECTED): As proposed, with the DRAM colour ramp from 210 in 20-cycle steps. The takeaway text becomes: 'the memory shire's position adds 12–84 cycles'. The strip's caption says 'model fitted to these loads (one constant and eight memory shire positions); measured values are the median over each home's lines of the fastest of three loads'.

Base PROPOSAL (for "as proposed" references): Data:
- new decomp.mem_by_home {home: {model, fast_med, n}}, computed in analyze.decomp() from decomp.u32/json (tested: |fast_med − model| ≤ 1 cycle for all 32 homes);
- existing decomp.l3_by_slice (D.l3), decomp.mem_hist (6-cycle bins, 4,500 loads) and decomp.mem.med (299);
- in build_report.py: data.memByHome, data.memHist and data.memMed.

Additions:
(a) Under the latency bar, a 600×70 strip titled 'where this path sits among the 4,500 measured DRAM loads from shire 0'. It shows mem_hist bars in var(--grid), with the median bin in var(--c1) labelled 'median 299', a var(--ink) rule at the path's model latency labelled 'this path: 345', and, when the requester is 0, a var(--c2) tick at the chosen home's measured value ('measured, 45 lines: 345'). For level L3, the strip shows the 32 per-home L3 medians as ticks, with the chosen home ringed.
(b) A 'Colour map by' seg with two settings: 'L3 hit' (current) and 'DRAM load' (110 + 12·h1 + 91 + 12·h2 for each home, ramp var(--q1)…var(--q7) from 220 in 20-cycle steps). Cell tooltips add 'measured from shire 0: L3 230 (45 lines), DRAM 345' or 'measured only from shire 0'.
(c) Keyboard: tabindex=0 and role=application on the map SVG; arrow keys move the current 'sets' target (requester or home) across the grid, and Enter toggles which one is set. The seg buttons and selects already work.

This replaces nothing; it makes the §5 model-error histogram the per-line detail.

The reader's understanding changes: they see the model sitting on the measured median for every home, that 345 is the far tail and 299 the middle, and that the memory shire's position adds up to 60 cycles.


Verifier note: The data are right: home 31 model 345, measured fastest-median 345; home 0 225/225; max |fast_med − model| = 1.0 over 32 homes; mem_hist 57 bins 144–552; median 299. But two figures are off. The memory-shire leg is 1–7 hops (12–84 cycles), a spread of 72 cycles, not 'up to 60'. The DRAM model ranges 213–381 over all requester/home pairs, so a ramp starting at 220 clips the low end. Agreement per home is also in-sample, since the 91-cycle constant and the positions were fitted to these loads, so the strip must not present it as independent validation.


#### anat-v2-27 — MODIFIED [visualization/medium] et-soc1-memory-anatomy

Where: §7 energy chart (#energy, JS lines 846–874); complements the energy table

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/build_report.py, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-23-energy-manual/manual.json

Problem: On a linear 0–5,200 pJ axis, L1 (46 pJ) and L2 (183 pJ) are slivers. So the claims in the bullets ('an L2 hit is mostly SRAM', 'the NoC rail appears at L3') cannot be seen, and neither can how the split shifts down the hierarchy, which is the page's unique energy result. The chart also gives no view of which numbers the energy manual superseded, or by how much.


APPLY (CORRECTED): Add the modes. Keep the host-log total and pJ/B columns in the table; putting the table in <details> is fine. In mode 3, caption: 'manual: 1 KB tensor loads, two cards, host board power; here: 8-byte ld per 64-byte line, one card'. Pass manual.json to build_report.py as an explicit second argument.

Base PROPOSAL (for "as proposed" references): Add a .seg with three modes. Data: D.energy (summary.json power.<pattern>.watts and rate) and manual.json reruns.levels_pj_per_byte.{l1,l2,l3,dram}.{mean,lo,hi}, passed by build_report.py as data.manual.
1. 'pJ per load' (current).
2. 'Share of each load': each bar normalised to 100%, with the % of each rail labelled inside segments wider than 34 px. This makes cores → SRAM → NoC → off-rail visible level by level.
3. 'pJ per byte, against the energy manual': bars of sp_total/64 in var(--c1), a hollow var(--c1) tick at host_total/64, and a var(--ink) bracket with the manual's mean and lo–hi (L2 2.51 [2.36–2.64], L3 10.5 [9.6–11.4] beside own/far 8.5/13.7, DRAM 122 [117–129] beside 79/92). L1 is marked 'moves no line'. A log x-axis is used only in this mode (1–200 pJ/B, ticks 1, 10, 100).

Hover shows the rail, pJ, % and W above idle; the mode buttons are keyboard buttons, and the width follows the host. Move the table's 'total (host log)' and 'pJ per byte' columns into mode 3 and put the table in <details>.

The reader's understanding changes: they see where each level's energy goes and exactly which totals were superseded.


Verifier note: The numbers check out: l1 46/56, l2 183/214, l3near 541/643, l3far 874/1,094, dram_seq 5,069/5,896 pJ; manual l2 2.51, l3 10.5, dram 121.96 [116.8–129.0]. The share mode is the useful addition. But moving the 'total (host log)' column out of the table hides the numbers that §7 calls 'the cleaner measure of the whole' behind a hover-only mode, which is poor on touch. Mode 3 also compares unlike methods: 1 KB tensor loads against 8-byte lds bringing lines, and the manual's L3 at mixed distances against own and far here. So the chart has to label them.


#### anat-v2-28 — MODIFIED [visualization/low] et-soc1-memory-anatomy

Where: §6 'Which address bits share a row' chart (#bits, JS lines 768–792)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html

Problem: The chart shows only the back-to-back experiment (a +40 step from bit 18). The second measurement in the same data, B loaded right after A, separates all three DRAM cases: other bank ≈ 0, same row −12 (a hit saves the activate), same bank but another row +13 (precharge). It appears only in a tooltip. Those three cases are the row states the explorer offers.


APPLY (CORRECTED): In analyze.bits() add new keys b_minus_b0_med, b_minus_b0_p25 and b_minus_b0_p75 from bits.u32. Plot per-bit medians with IQR whiskers, y from −30 to +30. Label the bands 'other bank or channel: ~0', 'same row: −12, the activate saved', 'same bank, other row: +9, the precharge (tRP = 11)'.

Base PROPOSAL (for "as proposed" references): Add a .seg: 'issued together (A and B back to back)' (current) and 'one after the other (B − B alone)'. The second mode plots bits[b].b_minus_b0 with ±2·se whiskers, y from −25 to +25 cycles, a zero rule, and labels for the three bands ('other bank or channel: ~0', 'same row: −12, the activate saved', 'same bank, other row: +13, the precharge'), using the same c1/c3/c2 colours. Data: summary.json bits.* (already D.bits).


Verifier note: The idea is right: the one-after-the-other cases separate the three row states. But summary.json has only means ± se, and the mean for row bits (+13.5) is pulled up by refresh outliers. The per-band medians are +9 (bits 18–29), −12 (13–17) and −1 (6–12). Per-bit means reach 18.7 + 2·3.5, which is beyond the proposed ±25 axis.


#### anat-v2-29 — CONFIRMED [layout/medium] et-soc1-memory-anatomy

Where: §1 instrument table at 390 px (.table-wrap.wide, min-width 720 px; td.lvl nowrap)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html

Problem: On a phone, the nowrap 'What' column and the code column fill the screen. The Notes column, which holds the content, is off-screen to the right, and rows are 200–300 px tall with blank space. The table cannot be read without scrolling sideways row by row.


APPLY (PROPOSAL): Give this table class 'stack' and data-h attributes on each td ('Instrument', 'Finest granularity', 'Notes'). Add CSS: '@media (max-width:600px){.stack table{min-width:0}.stack thead{display:none}.stack tr,.stack td{display:block}.stack td.lvl{white-space:normal;padding-bottom:0;border:0}.stack td:not(.lvl)::before{content:attr(data-h) ": ";font-weight:600;color:var(--ink-2)}}'. Each instrument then reads as a small card.


Verifier note: Screenshot m-2.png at 390 px shows only the What/Instrument columns, with 200–300 px tall mostly empty rows; Notes is off-screen. The stacked-card CSS is the standard fix.


#### anat-v2-30 — CONFIRMED [layout/low] et-soc1-memory-anatomy

Where: Captions of #mstable (JS line 765) and #energy-table (line 878)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html

Problem: Both captions are <caption> elements inside .table-wrap, so they take the table's scroll width. At 390 px their text is cut off at the right edge ('…the one named by… lines it rose by 15…').


APPLY (PROPOSAL): Emit each caption as <p class='fn'> after the .table-wrap (document.getElementById('mstable').parentNode.after(p)) instead of a <caption>.


Verifier note: m-8.png and m-10.png show the msmap and energy captions cut off at the right. Being <caption> elements inside the scrolling .table-wrap, they take the table's width.


#### anat-v2-31 — CONFIRMED [layout/low] et-soc1-memory-anatomy

Where: All .chart.scroll charts (CSS line 60; each chart's 'const W = 900')

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memprobe/report_template.html

Problem: At 390 px each chart is 640 px wide (min-width) in a 900-unit viewBox. The 12-unit text therefore renders at about 8.5 px, the reader must scroll sideways, and the key parts (the DRAM rows of the ladder, the right half of the histogram and axis titles) start off-screen. The explorer's latency bar labels render at about 6.6 px.


APPLY (PROPOSAL): Size each chart to its host. Add const chartW = id => Math.max(360, Math.min(900, document.getElementById(id).clientWidth || 900)), use W = chartW(id) in each chart, scale the left margins (for example the ladder's L = W < 600 ? 120 : 190, with row labels at 11 px), and redraw on a debounced resize. Lower '.chart.scroll svg { min-width }' to 360px. Then 12-unit text renders at 12 px on phones.


Verifier note: At 390 px each 900-unit chart has min-width 640 px, so text renders at about 8 px and the key parts start off-screen (m-5, m-7, m-10). Sizing to the host works. At about 360 px the bits chart's 24 tick labels will collide, so label every other bit there.


### Missed by the reviewers (found by the verifiers)


#### M-anat-1 [claim] et-soc1-memory-anatomy

Problem: Every row-closing inference on the page (and in the review) leaves out the probe's own time. Each op of the program is fetched from the L2 scratchpad as two volatile words, about 85–90 cycles per op. The no-jitter refresh loop spends 357 of its 576 cycles outside the load on 4 ops. In refresh_jit, the stamp-to-stamp gap minus the regenerated random delay has a median of 446 cycles. Counted properly, all the data fit 'rows stay open until a refresh or conflict'. Pagetimeout: refresh alone predicts 75/70/66/57/44/32/10/0% at 0–2,000 cycles, measured 67/77/53/71/35/23/5/2%. Bits back-to-back: about 76% predicted, 75–77% measured. DVFS wake-up: 13/20 and 2/20, as refresh alone predicts.

APPLY: State once in §6, next to the refresh series, that the probe spends about 90 cycles per op between timed loads. Base every refresh-only comparison on the measured op time (analyze.py can derive it from refresh.u32). Use it in anat-v2-01, 02 and 25 in place of '(1 − in_refresh)²'.


#### M-anat-2 [claim] et-soc1-memory-anatomy

Problem: §3 says that with a fence and no wait 'a third of the loads find the row … still open', without saying what happened to the rest. By memory shire, the misses are not closed rows. For shires 3, 5 and 7 the fence-no-wait loads read above the closed-row model (median residuals +27, +10, +30). The no-fence loads' residuals rise across the map, from +10 (M0) to +94 (M3) and from +46 (M4) to +92 (M7). So the fence does not wait for an evict to memory to finish at the memory shire.

APPLY: After '…read 11 cycles fast (minimum 213, on a line whose closed-row time is 225).' add: 'For memory shires 3, 5 and 7 they instead read 10–30 cycles slower than a closed row: even after the fence, the load still waits behind the evict at the memory shire. With no fence that wait runs from about 10 cycles for memory shire 0 to about 90 for memory shires 3 and 7.' Recompute the medians in analyze.ladder() by memory shire, as a new key.


#### M-anat-3 [claim] et-soc1-memory-anatomy

Problem: Once §6 says rows close only by refresh or conflict, §3's 'With the fence and the 300-cycle wait, none read fast' needs its reason. The line's row was last opened by the first load of its sequence, about 20 ops (≈1,800 cycles) plus four 300-cycle waits and two cache hits earlier: more than one refresh period (2,325 cycles). So a refresh always intervened: 0 of 128 fast, as expected. The page currently relies implicitly on idle-close.

APPLY: Append to that sentence: '(the line's row was last opened by the first load of its sequence, some 3,000 cycles and at least one refresh earlier)'.


#### M-anat-4 [claim] et-soc1-memory-anatomy

Problem: The lede says the model 'predicts each line's DRAM latency to within ±3 cycles for 97% of lines'. The constant (91) and the eight memory shire positions were fitted to the same 1,500 lines (p10 of the per-pair residuals), so the 97% is an in-sample fit.

APPLY: Lede: 'A model built from those parts, fitted with one constant and eight memory shire positions, matches each line's DRAM latency to within ±3 cycles for 97% of lines.'


#### M-anat-5 [reproducibility] et-soc1-memory-anatomy

Problem: workloads/memprobe/README.md describes pagetimeout as 'how long rows stay open', and it will point to the page for commands. After anat-v2-01 that description misleads. The report's rebuild also has no step that regenerates the new rowlife keys unless analyze.py is re-run, and the page's rebuild block currently runs only build_report.py.

APPLY: README table: 'pagetimeout | Same-row second load after a set delay: whether anything but refresh closes a row'. Make sure the committed summary.json is regenerated by analyze.py when the new keys land, and check that the old keys stay byte-identical.



## Group memhier-noc


### Reproduction problems


#### R-mhn-1 [medium] docs/reports/data/2026-09-18-memhier-aifoundry2/energy/, energy2/ (vs workloads/memhier/run_energy.py)

Problem: The committed memhier energy data was written by an earlier, uncommitted version of run_energy.py. The committed script cannot produce files in this format, although it reproduces the values.

Evidence: power.csv header is 'epoch_ms,watts'; the committed script writes 'epoch_ms,watts,minion_mhz,minion_mv'. The results.json levels lack mean_mhz, mhz_values and mean_minion_mv, which the committed script always writes. The script and data were added together in commit 4601938. Recomputing every field from runs.jsonl + power.csv with the committed logic matches exactly. The page's 'minion voltage to about 0.6 V' in these runs is not in this data: power.csv has no voltage.

Fix: State in the data README that energy/ and energy2/ predate the clock and voltage columns (or commit the version that made them). Source the 0.6 V remark to the DVFS report, or drop it.


#### R-mhn-2 [low] docs/findings/05-claims.md:219; docs/reports/data/2026-09-22-hotline-aifoundry2/hotline.json context.barrier_cycles_chip

Problem: The claim index gives the chip-wide barrier as 4,997 cycles from `nocbench --test barrier --scope chip`. The committed nocbench data does not contain that value, and no script derives it. It is a hand-entered constant that feeds the energy manual (build_energy_manual.py:164) and the hot-line page.

Evidence: barrier-chip1.jsonl: cycles_per_iter_mean 4994.99 (32 participants). barrier-chip32.jsonl: 5017.72 (1,024 participants). hotline.json context.barrier_cycles_chip = 4997. analyze_hotline.py does not write it.

Fix: Use 4,995 cycles (or 5,018 for 1,024 minions) and cite barrier-chip{1,32}.jsonl, or have build_energy_manual.py read the value from the nocbench data.


#### R-mhn-3 [low] workloads/memhier/analyze.py (lines 72-90)

Problem: The printed plateau summary converts every L3 and DRAM chase at 600 MHz, including those run at 800 MHz. Running the page's own Reproduce command therefore prints L3 265–314 ns and DRAM 604 ns (479–613), against the page's 265–282 ns and about 490 ns. The embedded plateaus min/max mix the two clocks the same way (the page does not use them).

Evidence: Stdout: 'L3 median 169.0 range 159.3-188.4 cycles = 281.6 ns (265-314)' and 'DRAM median 362.3 range 287.3-368.0 cycles = 603.9 ns (479-613)'. The 314 ns is the false plateau the review removed from the page.

Fix: Print the plateaus per clock group (point_ghz below vs above 0.7), or only the ns_measured_clock lines. Optionally drop the unused plateaus, dram_samples and energy blocks from the embed.


#### R-mhn-4 [low] workloads/memhier/run_energy.py (energy/, energy2/ idle_w)

Problem: The idle baseline is the median of a bimodal set: 40 pre-run samples at about 27.0 W and 39 post-run samples at about 27.8 W. The median therefore lands on the largest pre-run sample, and one extra post-run sample would move it 0.57 W.

Evidence: energy: pre-run median 27.03 W (maximum 27.10), post-run 27.77 W, combined n=79 gives 27.10; dropping one pre-run sample instead gives 27.67. energy2: 26.95 = the second-largest pre-run sample. A 0.57 W shift moves the DRAM energy by about 7.5 pJ/B.

Fix: No page change needed: these energies are superseded and the page already says 'one idle reading taken before, 27.0 W'. If the script is reused, use per-configuration local idle as nocbench's run_energy.py does.


#### R-mhn-5 [low] workloads/memhier/run_energy.py:53, workloads/nocbench/run_energy.py:67

Problem: Stale comment: 'moves the minion clock between about 600 and 850 MHz'. The review fixed this in analyze.py (600–800 MHz) but not in these two files.

Evidence: grep '850' finds these two lines; analyze.py says 'operating points on these cards are 600, 700 and 800 MHz'.

Fix: Change both to 600–800 MHz.


#### R-mhn-6 [low] docs/reports/2026-09-18-et-soc1-on-chip-communication.html (How it was measured, Round trips)

Problem: The page says the round trips repeat '300–4,000 times' and that 'all 44 stream, ring, tree and barrier runs passed'. The data has 200–4,000 iterations. The 44 are 40 allreduce + 4 barrier records: the streams are inside the 3,699 pair records, and the rings are the throughput records of the energy runs.

Evidence: matrix-flag.jsonl pairs have iters=200. Record counts: pair 3699, allreduce 40, barrier 4 (all ok). energy-a/b runs.jsonl hold 133 + 139 throughput records, all ok.

Fix: '200–4,000 times'; 'All 3,699 pair and stream measurements, all 40 tree and 4 barrier runs, and every ring launch of the energy runs passed.'


#### R-mhn-7 [low] docs/reports/2026-09-18-et-soc1-on-chip-communication.html (What the numbers say, item 2)

Problem: The page says remote scratchpad loads 'fit within a cycle at 600, 700 and 800 MHz'. One point does not: row 24's load to shire 18.

Evidence: Model c=65.95 cyc, t0=56.48 ns, t_hop=20.00 ns. Rows 0, 7 and 31 fit within 0.12 cycles; row 24 fits within 1 cycle at 30 of 31 targets. Shire 24 to 18 (5 hops, 165.2 cycles) is 5.4 cycles from the nearest clock's prediction; its clock changed mid-chase.

Fix: '…and fit within a cycle at 600, 700 or 800 MHz, except one chase whose clock changed partway.'


#### R-mhn-8 [low] docs/reports/2026-09-18-et-soc1-memory-hierarchy.html (How it was measured, Latency)

Problem: The page says 'After warm-up (two passes, capped at 2^19 loads), 40,000 dependent loads are timed'. The warm-up also has a floor of 16,384 loads, and 22 of the 227 chases timed 20,000 loads.

Evidence: host/main.cpp:291 warm_steps = max(2*lines, 16384) capped at 2^19. run_lab.sh:52-53 run the placement and offsets groups with --steps 20000 (14 + 8 chases).

Fix: '…two passes, at least 16,384 and at most 2^19 loads; then 40,000 dependent loads are timed (20,000 in the placement repeats).'


#### R-mhn-9 [low] docs/reports/2026-09-18-et-soc1-on-chip-communication.html (How it was measured, Clock)

Problem: The page says the background loop read the minion clock 'during every run'. The isolated-pairs and loaded-pairs launches ran about 11 minutes after clock.csv ends. analyze.py then takes the nearest sample, 656 s away.

Evidence: clock.csv spans 02:14:54–02:17:16 UTC and the runs span 02:14:55–02:28:12. The nearest-sample distance for those two files is 656 s. Only their ratio (worst change 0.8%, in cycles) is used, so no number changes.

Fix: '…during every run except the loaded-pairs test, which is compared in cycles.'


#### R-mhn-10 [low] docs/reports/2026-09-18-et-soc1-on-chip-communication.html (section order)

Problem: 'Related reports' comes after 'Sources'. Review PLAN §3.13 item 4 says to add it before Sources, and the memory-hierarchy page puts it before.

Evidence: h2 order ends ...reproduce, sources, related; the memory-hierarchy page ends ...reproduce, related, sources.

Fix: Move <h2 id='related'> above <h2 id='sources'>, and its contents entry to match.


#### R-mhn-11 [low] workloads/nocbench/analyze.py (docstring); both pages' embedded JSON

Problem: Minor redundancy and drift. The docstring usage omits --search, which the README and page use. Both pages embed blocks their scripts never read.

Evidence: memhier-data: the page reads only curves and scp_matrix (plateaus, dram_samples and the superseded energy block are unused). nocbench-data: the page reads allreduce, classes, empty_cells, energy, layout, matrices and sizes (scp_rows, intra, functs, barriers, loaded and matrices.search are unused). The one-hop RING is hard-coded in the page and identical to the script's output.

Fix: Add --search to the docstring. Optionally stop embedding the unused blocks, or keep them for provenance, but label the memhier energy block as superseded.


### Review findings


#### mh-1 — MODIFIED [claim/medium] et-soc1-memory-hierarchy

Where: Load latency against working-set size: chart labels in renderLatency() ('L3 236–282 ns', 'DRAM 440–460 ns') vs the L3/DRAM stat tiles and the lede

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-memory-hierarchy.html, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memhier/analyze.py

Problem: The page's first chart contradicts the headline numbers directly above it. Every DRAM point it draws ran at 800 MHz and is labelled 'DRAM 440–460 ns', while the tile and lede say ~490 ns at 600 MHz. The six 600 MHz DRAM chases (287–297 cycles, 480–495 ns) are embedded (dram_samples) but never plotted. The L3 label '236–282 ns' spans shire 24's 800 MHz points and shire 0's 600 MHz points, while the tile says 265–282 ns at 600 MHz.


APPLY (CORRECTED): Build this only if mh-2 is not built.
1. Add filled markers, with no line, for every chase at 600 MHz, each at its own size: the six DRAM chases (479–495 ns) and the 4 MB L3 chases from shires 7, 24 and 31 (268, 265 and 281 ns).
2. Labels: 'L3 265–282 ns at 600 MHz (236–240 at 800)' and 'DRAM ~490 ns at 600 MHz (440–460 at 800)'.
3. Legend item: 'filled: chases at 600 MHz from shires 0, 7, 24 and 31'.
4. Write 479–495, not 480–495: 287.27 / 0.6 = 478.8.

Base PROPOSAL (for "as proposed" references): 1. In workloads/memhier/analyze.py, add a third curve: curves['DRAM at 600 MHz'] = [[r['size'], r['cycles_per_load'], round(r['cycles_per_load']/0.6, 1)] for every dram chase with size ≥128 MB, thread 0 and point_ghz(r) < 0.7] (six points).
2. In renderLatency(), draw that curve as filled markers without a line.
3. Change the labels to [narrow ? 'L3' : 'L3 265–282 ns at 600 MHz'] and [narrow ? 'DRAM' : 'DRAM ~490 ns at 600 MHz (440–460 at 800)'].
4. Add a legend item 'ET-SoC-1, DRAM chases at 600 MHz'.

The clock toggle in mh-2 subsumes this fix; do this one if mh-2 is not built.


Verifier note: The problem is real but overstated. The caption does say that every plotted DRAM point and the shire-24 L3 points ran at 800 MHz, and it gives 265–282 ns and about 490 ns at 600 MHz. Even so, the in-chart labels ('L3 236–282 ns', 'DRAM 440–460 ns') disagree with the tiles, and neither the 600 MHz DRAM chases nor shire 24's 600 MHz L3 chase is drawn. I recomputed the six DRAM chases with point_ghz < 0.7: 297.2, 287.3, 296.4, 288.4, 293.0 (offsets, implied 0.663 GHz) and 296.9 cycles, which is 479–495 ns. The proposal has a flaw. The label 'L3 265–282 ns at 600 MHz' would sit next to the orange shire-24 L3 line at 236–240 ns, and no drawn point would be at 265 ns.


#### mh-2 — MODIFIED [visualization/medium] et-soc1-memory-hierarchy

Where: Load latency against working-set size (#lat): add to the existing chart

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-memory-hierarchy.html, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memhier/analyze.py, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-18-memhier-aifoundry2/chase-dram-from24.jsonl, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-18-memhier-aifoundry2/chase-dram-sweep-from24.jsonl

Problem: The page's hardest idea gets about 8 paragraphs of prose and no picture: on-chip latency is fixed in cycles, while L3 and DRAM are part cycles and part fixed nanoseconds, so the governor's clock changes them differently. The chart freezes one arbitrary mix of clocks.


APPLY (CORRECTED): Store fits = {L3: {cycles: 72.3, ns0: 61.2, ns_per_hop: 20.0, mean_hops: {0: 5.0, 24: 4.19}}, DRAM: {cycles: 86.3, ns: 344.8}}.

For line s at clock f:
- ≤512 KB: ns = cycles / f.
- 768 KB–8 MB: 72.3/f + 61.2 + 20 × mean_hops(s).
- ≥128 MB: 86.3/f + 344.8.
- 16–64 MB: draw a dashed connector through the measured hollow points, not recomputed.

Mark 700 MHz as model only: no L3 or DRAM chase ran there. In the split bar, label the L3 fixed part 'mesh (400 MHz)' and the DRAM fixed part 'mesh and DDR'.

The rest stays as proposed; this subsumes mh-1.

Base PROPOSAL (for "as proposed" references): Question it answers: what does a load at each level cost at 600, 700 and 800 MHz, and which part of it speeds up with the minion clock?

Data:
- memhier-data.curves['shire 0'|'shire 24'][i] = [bytes, cycles, ns at the chase's own clock].
- New memhier-data.fits, written by analyze.py (least squares over the chase files as described): {'L3': {'shire': 24, 'cycles': 72.3, 'ns': 145.0}, 'DRAM': {'cycles': 86.3, 'ns': 344.8}}.
- The A100 constants already in the script.

Encoding:
- Same log–log axes. The two ET lines are recomputed for the selected clock f: points ≤512 KB take ns = cycles/f; L3 points take 72.3/f + 145; DRAM points take 86.3/f + 344.8.
- Measured points stay as small hollow circles at their measured ns, so the reader sees the model pass through the data.
- A100 plateaus are labelled in place: 'A100 L1 23', 'L2 148', 'far L2 253–313', 'HBM 405'.
- Under the chart, a 5-row mini stacked bar (L1, read buffer, L2, L3, DRAM) splits each level's ns at f into a 'minion-clock part' (var(--et)) and a 'fixed part: 400 MHz mesh and 933 MHz DDR' (var(--et2)). Example: DRAM at 600 MHz is 144 + 345 ns.

Interaction:
- Three <button>s '600 MHz | 700 MHz | 800 MHz' with aria-pressed; arrow keys move between them. The default is 600, so the chart matches the stat tiles.
- Hover or tap a point for a tooltip, e.g. 'L3, shire 24, 4 MB: measured 188 cycles at 800 MHz (235 ns); at 600 MHz the model gives 159 cycles, 266 ns = 121 ns clock-scaled + 145 ns fixed'.

Colours: var(--et), var(--et2), var(--ref), var(--grid), var(--ink) (these standalone pages use --et/--et2 for the template's --c1/--c2). It keeps the current responsive width, and the buttons wrap at 390 px.

It replaces the mixed-clock labels (mh-1) and the caption sentences from 'L3 and DRAM points use the clock implied…' to '…DRAM about 490 ns.' Item 5 can then shrink to its first two sentences.

What the reader gains: at 800 MHz on-chip latencies fall 25%, L3 11% and DRAM only 7%. '490 vs 453 ns' is one DRAM at two clocks.


Verifier note: The fits reproduce. DRAM over 18 chases is 86.31 cycles + 344.81 ns, max residual 10.0 cycles, predicting 489, 468 and 453 ns. Shire 24's L3 from the two clocks is 72.6 cycles + 144.5 ns. The flaw: the proposal applies shire 24's L3 fit to both lines. Shire 0's L3 was measured at 169 cycles, 281.6 ns, at 600 MHz, but the model would redraw it at 265.5 ns, 16 ns below its own measured points at the same clock. The L3 fixed part depends on the requester: 61.2 ns + 20 ns × the mean hops to the 32 slices (5.0 from shire 0, 4.19 from 24, 4.31 from 7, 5.0 from 31). That reproduces the measured 600 MHz L3 of all four requesters (169.0/160.7/159.3/168.9) within 0.1 cycle. It also gives shire 0 at about 800 MHz within 1.4 cycles (201.3 predicted; 199.9 and 200.4 measured at 24 and 32 MB). The proposal is also silent on the 16–64 MB points: the 16 MB point at implied 0.67 GHz, and the 48 and 64 MB points, which mix L3 and DRAM hits. Neither model covers them.


#### mh-3 — MODIFIED [visualization/medium] et-soc1-memory-hierarchy

Where: Scratchpad latency across the mesh (#heat): replace the ID-ordered heat map

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-memory-hierarchy.html, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memhier/analyze.py, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/nocbench/analyze.py

Problem: The heat map orders targets by shire ID, so the 20 ns-per-hop structure looks like noise. Its colours cannot be compared across rows, because the rows ran at different clocks, as the caption admits. At 390 px the cells are about 8 px wide, show no numbers and lose the 'from/to' labels. The hard-coded ramp also puts the slowest cells nearly on the background in dark mode. The page's claim 'Distance on the mesh is visible' is therefore not visible.


APPLY (CORRECTED): Build as proposed, with these fixes:
(a) The tooltip example values are 159.8 cycles at 600 MHz and 175.5 at 700, not 159.6 and 175.6.
(b) Colour each cell by its ns at that point's own nearest operating point. Row 24 changes clock partway, so 'the row's clock' is undefined for it.
(c) The memory-hierarchy page has no --empty token. Add it as on the on-chip page (#ecebe6 light, #242422 dark).
(d) Set the color-mix fill through style.fill. Pick the cell text colour per theme, because the on-chip page's hard-coded #fff/#0b0b0b by ramp step would be wrong on a color-mix ramp in dark mode.
(e) The scatter is the essential view; if only one view is built, build the scatter with the 600, 700 and 800 MHz model lines.

Base PROPOSAL (for "as proposed" references): Question it answers: how much does mesh distance cost a remote scratchpad load, and why does the L3 latency depend on the requesting shire?

Data:
- memhier-data.scp_matrix.
- A new memhier-data.layout: marty1885's coordinates. analyze.py imports MARTY from workloads/nocbench/analyze.py; they are identical to nocbench-data.layout.
- memhier-data.scp_model {c: 65.95, t0: 56.48, hop: 20.0}.
- memhier-data.l3_by_requester {0: 169.0, 7: 160.7, 24: 159.3, 31: 168.9}.

Encoding, two linked views:
- Left: the 6×6 grid as on the on-chip page. The 32 compute cells are coloured by the selected row's latency in ns at that row's clock. The ramp is color-mix(in srgb, var(--et) p%, var(--surface)) with p from 15 to 100, so emphasis stays correct in dark mode. The 4 non-compute cells use var(--empty), and the requester is outlined in var(--ink).
- Right: cycles against hops for the row, with the model drawn at 600 MHz (var(--et), solid), 700 (dashed) and 800 (var(--et2)). Each point is coloured by the operating point nearest the model.

Interaction:
- Buttons 'from 0 | from 7 | from 24 | from 31'.
- A mode toggle 'Remote scratchpad | L3 average trip'.
- Hovering or focusing a cell highlights its point, and vice versa. Example tooltip: 'shire 24 → 18: 5 hops, 165.2 cycles; the model gives 159.6 at 600 MHz and 175.6 at 700, so the clock changed during this chase'.
- In L3 mode the cells show the hop count from the requester to each L3 slice, with the readout 'mean 4.19 hops → 110 + 12 × 4.19 = 160.2 cycles predicted (Anatomy), 159.3 measured'.

At 390 px the grid is about 300 px square (cells about 46 px), with the scatter below it at full width.

It replaces the heat map and its legend.

What the reader gains: the concentric colour shows distance directly. Row 31 sits on the 800 MHz line, so the 271-against-220-cycle asymmetry is the clock. And the L3's per-shire spread is just the mean hop distance.


Verifier note: The problem is real. At 390 px the cells are 8 px wide, show no values, and the 'from' and 'to shire' labels are dropped (screenshot). ID order hides distance. In dark mode the slowest colour, #0d366b, sits on #1a1a19 at a contrast of 1.45:1. The data check out: the model is 65.95 cycles + 56.48 ns + 20.00 ns per hop. With the nearest operating point, 123 of 124 points fit within 1 cycle. Row 24 has 19 targets at 600 MHz, 4 at 700 and 8 at 800, and the 24→18 chase falls between clocks. The L3 values per requester and the mean hops are also correct.


#### mh-4 — MODIFIED [visualization/low] et-soc1-memory-hierarchy

Where: ET-SoC-1 against the A100, level by level: after the energy dumbbell (#cmp-en); or What the numbers say, item 6

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-memory-hierarchy.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-23-reruns-aifoundry2-warm, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-23-reruns-aifoundry3

Problem: Item 6 and caveat 2 argue that part of each energy per byte is busy cores, not memory: 'most of an L1 read, but only a fifth to a third of an L2, L3 or DRAM stream'. Nothing on the page shows that split.


APPLY (CORRECTED): Low priority. If built:
- Totals: reruns.json levels_pj_per_byte × the 600 MHz GB/s. That gives about DRAM 9.3 W, L3 10.3, remote scratchpad 6.4, L2 6.2 and L1 4.8.
- Floor for hart-0 streams: a band from 1.4 W (stalled, the hot-line measurement) to 2.2 W (one-hart addi loop). For L1, which uses both harts: 3.5 W.
- Label the floor 'estimate of the busy-core share'.
- Resulting shares: L1 about 73%, L2 23–36%, L3 14–21%, DRAM 15–24%.

A lighter alternative: a floor tick on each ET row of the existing energy dumbbell.

Base PROPOSAL (for "as proposed" references): Question it answers: how much of a streaming byte's energy is the busy cores?

Data:
- docs/reports/data/2026-09-23-reruns-aifoundry2-warm/levels-pass{1,2,3}/results.json and 2026-09-23-reruns-aifoundry3/levels-pass{1,2}/results.json, fields results.{spin,l1,l2,scp-local,scp-remote,l3,dram}.{above_idle_w,gb_per_s}, pooled as reruns.json pools them.
- The floor is 2.2 W for the hart-0 TensorLoad streams (energy manual §2) and the measured two-hart spin for L1.

Encoding:
- Horizontal stacked bars on a linear axis from 0, one per level: floor (var(--ref)) plus remainder (var(--et)).
- A right label gives the total and the floor's share. Example for DRAM: 9.3 W, of which 2.2 W, 24%, is the cores.

Interaction:
- A toggle 'watts above idle | pJ per byte'. In pJ/B mode the floor becomes floor ÷ GB/s, e.g. DRAM 29 of 122 pJ/B.
- Hover shows the pass range and the card.
- The whole chart is keyboard-reachable through the two toggle buttons.

It complements the energy dumbbell, and item 6 can drop to one sentence.

What the reader gains: the floor is visibly most of L1, while under a third of L2, L3 and DRAM.


Verifier note: The proposal uses the wrong data. levels-pass*/results.json come from the older run_energy.py runner. The rerun README says those runs are 'kept for the record and not pooled (no leakage correction … reads 10–50% high on 2 W signals)'. reruns.json pools rl-pass* (six passes, three per card), not levels-pass, so 'pooled as reruns.json pools them' and 'five passes' are both wrong. The rl-passes have no spin burst, so there is no leakage-corrected re-run of memhier's spin at all. The 'floor' is also an assumption. Energy manual §2 gives 2.19 W for the one-hart addi loop and 3.51 W for both harts, and says a stalled minion draws 1.4 mW against 2.1 mW spinning. TensorLoad streams stall their cores.


#### mh-5 — MODIFIED [visualization/low] et-soc1-memory-hierarchy

Where: Existing charts: #lat labels, #cmp-lat 'L3 / far L2' row, all charts' keyboard access

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-memory-hierarchy.html

Problem: Assessment of the charts that stay:
- Latency chart: clear, but the label 'read buffer 60' has no unit, and the A100 grey segments carry no values unless hovered.
- Dumbbells: clear, honest log scales, useful tooltips. But the 'L3 / far L2' row pits ET's upper value (282 ns, of 265–282) against the A100's lower value (253 ns, of 253–313). ET therefore looks slower than the A100's far L2, although the two ranges overlap.
- Keyboard: no chart can reach its tooltips from the keyboard (no tabindex or keydown on either page).


APPLY (CORRECTED): Items 1, 2 and 4 as proposed. Item 3: draw both as ranges (ET 265–282 against A100 253–313), with no midpoint option.

Base PROPOSAL (for "as proposed" references): 1. Label: 'read buffer 60' → 'read buffer 60 ns'.
2. A100 segments: at W ≥ 560, draw a small grey text label at each segment's right end, from A100[i].label.
3. 'L3 / far L2' row: draw both values as ranges (a thick segment from lo to hi) instead of dots, with ET 265–282 and A100 253–313. To keep dots, use ET 282 against the A100 midpoint 283.
4. Keyboard: give each dumbbell row and each latency point group tabindex='0' and an aria-label with its values, and show the tooltip on focus.


Verifier note: Every observation checks out. The label 'read buffer 60' has no unit. The A100 segments carry no values. The CMP row compares 282 against 253 although the A100's far L2 is 253–313. There are 0 tabindex and 0 keydown on the page. The fallback 'ET 282 against the A100 midpoint 283' should go: a midpoint of a published range is not a published value.


#### mh-6 — MODIFIED [redundancy/medium] et-soc1-memory-hierarchy

Where: 'Update, 24 September' box under the lede (line 101)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-memory-hierarchy.html

Problem: The update box repeats what the body now says in its permanent places:
- the energy values (table, dumbbells, item 6 and How it was measured);
- the bandwidth-at-600 MHz note (table footnote);
- the L2 = scratchpad conclusion (item 3);
- the floor fraction (item 6);
- the 128 GB/s placeholder (the DRAM notes).
Its 'Two conclusions changed' is changelog, which belongs in Versions.


APPLY (CORRECTED): Delete the Update box and add nothing to the byline. The Versions bullet stays as it is.

Base PROPOSAL (for "as proposed" references): Delete the whole <p class='small card'><b>Update, 24 September.</b> … listed under <a href='#how-it-was-measured'>How it was measured</a>.</p>.

Append to the byline: ' · revised 24 September: bandwidth from the launches at 600 MHz, energy per byte from <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-energy-manual#bytes-through-the-memory-hierarchy">the energy manual, §4</a> (first values under Versions)'.


Verifier note: Every fact in the box is repeated elsewhere on the page:
- the energies in the table, the CMP data and item 6;
- the 600 MHz bandwidth in the footnote;
- L2 = scratchpad in item 3;
- the floor in item 6;
- the 128 GB/s placeholder in the DRAM notes;
- the governor in the caveat;
- the first values under Versions.
Deleting the box is safe. But appending a revision note to the byline breaks convention C2 ('Version history goes on a Versions line at the end of Method, never in the byline'). The Versions bullet already records the 24 September changes.


#### mh-7 — CONFIRMED [redundancy/low] et-soc1-memory-hierarchy

Where: What the numbers say item 6; Caveats 'The clock was not pinned'; heat-map caption

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-memory-hierarchy.html

Problem: Values and caveats are repeated.
- The re-measured energies are listed a fourth time in item 6.
- The all-launch bandwidths (7.55 / 2.80 / 2.57 / 1.03 / 0.98 TB/s) appear both in Versions and in the caveat.
- The clock story is told in the chart caption, the heat-map caption, items 4 and 5, How it was measured (Energy), Caveats and Versions.


APPLY (PROPOSAL): 1. Item 6: cut the sentence 'Re-measured at 600 MHz on two cards (energy manual §4), a byte costs 0.77 pJ from L1, 2.5 from L2 or the local scratchpad, 10.5 from L3 and 122 from DRAM.' Change the next sentence to 'At a pinned 600 MHz (the table's values) the busy-core floor is most of an L1 read, but only a fifth to a third of an L2, L3 or DRAM stream.'
2. Caveat: replace 'Averaged over all launches (0.62–0.74 GHz on average, depending on the level), the rates were 2–22% higher: L1 7.55, L2 2.80, local scratchpad 2.57, L3 1.03 and remote scratchpad 0.98 TB/s; DRAM was 76 GB/s either way.' with 'Averaged over all launches (0.62–0.74 GHz) the rates were 2–22% higher (Versions lists them); DRAM was 76 GB/s either way.'
3. Heat-map caption: if mh-3 is built, cut 'The governor ran rows 0 and 7 at 600 MHz, row 31 at 800 MHz, and row 24 at 600, then 700, then 800 MHz, so compare colours within a row.' The per-row clock becomes the scatter's colour.


Verifier note: Item 6 repeats the energies. Versions lists the all-launch bandwidths (L1 7.55 … remote scratchpad 0.98 TB/s), and the replacement keeps 'DRAM 76 GB/s either way', which Versions does not have. The item-6 edits must be merged with mh-9 (and mh-4 if built).


#### mh-8 — MODIFIED [redundancy/low] et-soc1-memory-hierarchy

Where: How it was measured: 'Energy' and 'Lab etiquette' bullets

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-memory-hierarchy.html, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memhier/README.md

Problem: Leftovers.
- The Energy bullet spends three sentences on the superseded 18 September method: the 7 samples/s rate, the 4 s windows and the idle law aside.
- Lab etiquette narrates a runtime crash and a chip reset. That is repo and lab history, not something a reader of the numbers needs.


APPLY (CORRECTED): Energy bullet, after 'three passes on each of two cards.': 'The energies first measured here (board power against the median idle before and after each run, about 27.0 W, while the governor raised the clock) are superseded; the method is in workloads/memhier/run_energy.py.' Shorten Lab etiquette as proposed. Put the crash note under the workload README's 'Lab etiquette' section.

Base PROPOSAL (for "as proposed" references): 1. Energy bullet: replace everything after 'three passes on each of two cards.' with 'The energies first measured here (board power against one idle reading, 27.0 W with the die at 63 °C, while the governor raised the clock) are superseded; the method is in the data README.'
2. Lab etiquette: shorten to 'Every card run was its own process under timeout 10, on an otherwise idle card.'
3. Move the crash note to workloads/memhier/README.md under Run: 'One energy run crashed the host runtime during the DRAM stream and the master firmware then refused launches; a full chip reset through the management interface restored it.'


Verifier note: The data README does not describe the energy method; it says only 'Two runs of run_energy.py'. So 'the method is in the data README' is false. The page's 'one idle reading taken before, 27.0 W' is also not what the committed logic does. It takes the median of idle windows before and after the whole sequence. Those windows are bimodal (about 27.0 W before, 27.8 W after), and the median gave 27.1 and 26.95 W for the two runs. workloads/memhier/README.md already has a 'Lab etiquette' section, which suits the crash note better than 'Run'.


#### mh-9 — MODIFIED [claim/low] et-soc1-memory-hierarchy

Where: What the numbers say, item 6 ('Being awake inflated the energy measured here')

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-memory-hierarchy.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-23-reruns-aifoundry2-warm

Problem: '…lifted the clock to 700–800 MHz and the minion voltage to about 0.6 V' has no source in these runs: energy/ and energy2/ power.csv have no voltage column. The 12 W figure for this page's two-hart spin is compared with other loops (the energy manual's addi loop; nocbench's one-hart loop). The same probe re-run at a pinned 600 MHz on 23 September is the direct comparison, and the page does not use it.


APPLY (CORRECTED): Replace 'and the minion voltage to about 0.6 V' with '(0.57–0.62 V at those operating points, item 5)'. Add no 23 September spin figure.

Base PROPOSAL (for "as proposed" references): Replace 'In these runs the governor lifted the clock to 700–800 MHz and the minion voltage to about 0.6 V, and the die warmed against a single idle reading, so this page's two-hart spin loop added 12 W' with: 'In these runs the governor lifted the clock to 700–800 MHz (0.57–0.62 V at those operating points, per the DVFS report) and the die warmed against a single idle reading, so this page's two-hart spin loop added 12 W; the same loop re-run at a pinned 600 MHz on 23 September added 2.3–2.8 W (five passes, two cards)'.


Verifier note: The voltage point holds: power.csv is epoch_ms,watts, so 'about 0.6 V' is inferred from the operating points, which item 5 already lists. Adding '2.3–2.8 W' would be harmful. Those values come from levels-pass, which is not pooled and reads 10–50% high on 2 W signals. They would also sit two sentences after the manual's 3.5 W for both harts, and memhier's spin runs both harts (kernel/memhier.c:12). That puts an unexplained contradiction on the page.


#### mh-10 — CONFIRMED [claim/low] et-soc1-memory-hierarchy

Where: How it was measured, Latency

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-memory-hierarchy.html, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memhier/host/main.cpp

Problem: 'After warm-up (two passes, capped at 2^19 loads), 40,000 dependent loads are timed'. This omits the 16,384-load floor on the warm-up, and 22 of the 227 chases timed 20,000 loads.


APPLY (PROPOSAL): Change to: 'After warm-up (two passes, at least 16,384 and at most 2<sup>19</sup> loads), 40,000 dependent loads are timed (20,000 in the placement and offset repeats) with the minion cycle counter.'


Verifier note: host/main.cpp:291 sets warm_steps = round8(min(max(2*lines, 16384), 1<<19)). run_lab.sh runs chase-dram-placement (14 chases) and chase-dram-offsets (8) with --steps 20000, and the records show steps = 20000 for all 22.


#### mh-11 — MODIFIED [claim/low] et-soc1-memory-hierarchy

Where: Spec-sheet footnote 'Bandwidth is bytes over wall time for the launches here that ran at 600 MHz.'

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-memory-hierarchy.html, /home/yaroslavvb/claude/et-soc1-prototyping/scripts/ridge-points.py

Problem: The page does not say how thin the 600 MHz bandwidth sample is: L1 rests on 2 of 21 launches and DRAM on 3 of 14. Stronger corroboration is already in the repo and goes uncited: the 23 September pinned-600 MHz reruns, with 16–19 launches per level.


APPLY (CORRECTED): Append to the footnote: 'These runs have few launches at 600 MHz (L1 2 of 21, DRAM 3 of 14); the same probes re-run at a pinned 600 MHz on 23 September (five passes on two cards, 7–9 launches per level per pass; <a href=…ridge-points>Ridge points</a>) agree within 1%.'

Base PROPOSAL (for "as proposed" references): Append to the footnote: 'These runs have few 600 MHz launches (L1 2 of 21, DRAM 3 of 14); the 23 September re-runs at a pinned 600 MHz (16–19 launches per level over three passes, docs/reports/data/2026-09-23-reruns-aifoundry2-warm/levels-pass*/runs.jsonl) agree within 1%.'


Verifier note: 'L1 2 of 21' and 'DRAM 3 of 14' check out (memhier_levels). The launch count is wrong. levels-pass runs have 7–9 launches per level per pass, all at 600 MHz: 21–26 over the three aifoundry2 passes, and 35–43 over the five passes on two cards, not '16–19'. ridge-points.py rerun_levels() already computes this check. Its GB/s ranges are L1 6,163–6,165, L2 2,455–2,456, L3 982–983, local scratchpad 2,455–2,456, remote scratchpad 960–961 and DRAM 75.8–76.0, and it prints a maximum deviation of 0.2%.


#### mh-12 — CONFIRMED [consistency/low] et-soc1-memory-hierarchy

Where: What the numbers say, item 4 (last sentence); the L3 row's Notes

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-memory-hierarchy.html

Problem: The page says an L3 hit 'pays the average trip from the requesting shire' but gives no numbers. Anatomy's L3 model (110 cycles + 12 per hop) reproduces this page's per-requester L3 latencies to about 1 cycle. Stating it would tie the two pages together and explain 'Latency depends on the requesting shire'.


APPLY (PROPOSAL): Replace the item's last sentence with: 'The L3 hides distance by spreading lines over all 32 shires, so 31 of every 32 L3 hits cross the mesh and pay the average trip from the requesting shire: <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-memory-anatomy">Anatomy of a memory access</a>'s 110 cycles + 12 per hop, averaged over the slices (4.2–5.0 hops), predicts 160–170 cycles, and the chases measured 159–169 (265–282 ns) at 600 MHz.'


Verifier note: Recomputed from the layout: mean hops of 5.0, 4.3125, 4.1875 and 5.0 give 170.0, 161.75, 160.25 and 170.0 cycles, against 169.0, 160.7, 159.3 and 168.9 measured. Anatomy §4 is titled 'L3: 110 cycles plus 12 per hop', timed from shire 0. The proposed wording is accurate.


#### mh-13 — MODIFIED [reproducibility/medium] et-soc1-memory-hierarchy

Where: docs/reports/data/2026-09-18-memhier-aifoundry2/energy/, energy2/ and README.md; workloads/memhier/run_energy.py; workloads/nocbench/run_energy.py

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-18-memhier-aifoundry2/README.md, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memhier/run_energy.py, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/nocbench/run_energy.py

Problem: The committed memhier energy data came from an earlier, uncommitted run_energy.py: power.csv has 2 columns, and results.json lacks mean_mhz, mhz_values and mean_minion_mv. The committed script therefore cannot have produced these files, even though its logic reproduces every value. Neither run_energy.py saves its idle or process windows. So results.json can be re-derived offline only by reconstructing the windows. For memhier the idle median is also bimodal: 40 samples at about 27.0 W and 39 at about 27.8 W.


APPLY (CORRECTED): Severity low. Do (1), the README row, and (2), saving the windows. Keep 'the committed script's analysis reproduces every value' in the README only if the offline recompute is committed alongside it. (3), --reanalyze, and (4) are optional and only matter for future runs.

Base PROPOSAL (for "as proposed" references): 1. Data README, energy row → 'energy/, energy2/ | energy | Two runs of an earlier version of workloads/memhier/run_energy.py (before the clock and voltage columns: power.csv is epoch_ms,watts, and results.json has no mean_mhz or mean_minion_mv). The committed script's analysis reproduces every value from runs.jsonl + power.csv. Superseded by the energy manual §4 (23 September).'
2. Both run_energy.py: add 'idle_windows_ms': idle_windows (and in nocbench 'proc_windows_ms': proc_windows) to the summary dict before json.dump.
3. Both run_energy.py: add a --reanalyze DIR mode that rebuilds results.json from runs.jsonl + power.csv + those windows, with no card. This makes the card-only step checkable on any machine.
4. When the memhier script is reused, take a per-configuration local idle, as nocbench's version does.


Verifier note: The facts are confirmed:
- power.csv has only epoch_ms,watts.
- results.json lacks mean_mhz, mhz_values and mean_minion_mv, which the committed script writes (run_energy.py:135–136).
- The idle samples are bimodal: 41 before at 27.0–27.1 W and 71 after, mostly 27.7–27.9 W.
- idle_windows is a local variable.
- Script and data came in the same commit, 4601938.
The severity is overstated: these energies are superseded and the page says so.


#### mh-14 — CONFIRMED [reproducibility/low] et-soc1-memory-hierarchy

Where: Reproduce section (code block)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-memory-hierarchy.html, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memhier/run_lab.sh, /home/yaroslavvb/claude/et-soc1-prototyping/scripts/ridge-points.py

Problem: The Reproduce block does not regenerate this page's data.
- The latency lines are two single probes, but the data are 13 chase files made by workloads/memhier/run_lab.sh: sweeps from shires 0 and 24, hart 1, from-7/24/31, the repeat, placement and offsets.
- The bandwidth column (the 600 MHz launches) comes from scripts/ridge-points.py memhier_levels(), which is not mentioned.
- The analyze step's comment implies it produces 'numbers … for this page', but its energy output is superseded.


APPLY (PROPOSAL): Replace the code block with:
'# build on the lab machine
scripts/deploy-lab.sh aifoundry2 workloads/memhier

# every latency chase, the scratchpad map, the clock poll and both energy runs (each probe is its own timeout-10 process)
ssh aifoundry2 'cd ~/nekko && bash workloads/memhier/run_lab.sh build/memhier/host/memhier_host build/memhier-data'

# latency curves and scratchpad map for this page
python3 workloads/memhier/analyze.py docs/reports/data/2026-09-18-memhier-aifoundry2 --embed docs/reports/2026-09-18-et-soc1-memory-hierarchy.html

# the bandwidth column (launches at 600 MHz) and bytes per cycle
python3 scripts/ridge-points.py

# energy per byte: the energy manual's re-runs, docs/reports/data/2026-09-23-energy-manual/reruns.json, levels_pj_per_byte'


Verifier note: run_lab.sh (groups chase, scp, dvfs and energy by default) writes every file in the data directory. The page's two single probes do not. ridge-points.py prints the 600 MHz GB/s per level from memhier_levels(). The proposed block is correct.


#### mh-15 — CONFIRMED [reproducibility/low] et-soc1-memory-hierarchy

Where: workloads/memhier/analyze.py, plateau summary (lines 72–90) and the --embed payload

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memhier/analyze.py

Problem: The page's own Reproduce command prints 'L3 … 281.6 ns (265-314)' and 'DRAM … 603.9 ns (479-613)'. It divides every chase by 0.6 GHz, including those run at 800 MHz, so the output contradicts the page (265–282 ns, ~490 ns). The 314 ns is the false plateau today's review removed. The embed also carries three blocks the page never reads: plateaus, which mix the two clocks; dram_samples; and energy, the superseded 18 September values.


APPLY (PROPOSAL): In the plateau loop, handle L3 and DRAM per clock:

if level in ('L3', 'DRAM'):
    by = {}
    for r in (the same selection as now):
        by.setdefault(0.6 if point_ghz(r) < 0.7 else 0.8, []).append(r['cycles_per_load'])
    for g, v in sorted(by.items()):
        print(f'  {level} at {g*1000:.0f} MHz: median {statistics.median(v):.1f} range {min(v):.1f}-{max(v):.1f} cycles = {statistics.median(v)/g:.0f} ns ({min(v)/g:.0f}-{max(v)/g:.0f}) n={len(v)}')
    plateaus[level] = {str(g): {...} for g, v in by.items()}

Expected output:
- L3 at 600 MHz: 168.9 (159.3–169.3) cycles, 282 ns (265–282), n=21
- L3 at 800 MHz: 188.3 cycles, 235 ns, n=5
- DRAM at 600 MHz: 294.7 (287.3–297.2) cycles, 491 ns (479–495), n=6
- DRAM at 800 MHz: 362.9 (352.2–368.0) cycles, 454 ns (440–460), n=12

In --embed, drop dram_samples and energy. Add the 'DRAM at 600 MHz' curve (mh-1), 'fits' (mh-2), and 'layout' and 'l3_by_requester' (mh-3). Also correct the energy print's label to 'superseded, 18 September'.


Verifier note: I ran analyze.py locally. It prints 'L3 … 281.6 ns (265-314)' and 'DRAM … 603.9 ns (479-613)'. Grouping by point_ghz < 0.7 reproduces the expected output: L3 at 600 MHz n=21, 159.3–169.3; L3 at 800 n=5, median 188.3; DRAM at 600 n=6, 287.3–297.2, 479–495 ns; DRAM at 800 n=12, 352.2–368.0, 440–460 ns. The page script reads only D.curves and D.scp_matrix.


#### mh-16 — CONFIRMED [reproducibility/low] et-soc1-memory-hierarchy

Where: workloads/memhier/run_energy.py:52–53 and workloads/nocbench/run_energy.py:66–67 (comment)

Files: /home/yaroslavvb/claude/et-soc1-prototyping/workloads/memhier/run_energy.py, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/nocbench/run_energy.py

Problem: A stale comment says the governor 'moves the minion clock between about 600 and 850 MHz'. The operating points are 600, 700 and 800 MHz (D1). Today's review fixed this in analyze.py only.


APPLY (PROPOSAL): In both files change it to: '# The card runs a DVFS governor ("managed power", 65 W TDP) with operating points at 600, 700 and 800 MHz, so every sample records the clock and minion voltage next to the power.'


Verifier note: memhier/run_energy.py:52–53 and nocbench/run_energy.py:66–67 still say 'about 600 and 850 MHz', against canonical value D1 ('Never write 850 MHz').


#### mh-17 — MODIFIED [reorganize/low] et-soc1-memory-hierarchy

Where: Section order (h2) and the A100 table

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-memory-hierarchy.html

Problem: The two latency views are separated by the spec sheet and the A100 comparison. The A100 table and the three dumbbells then show the same A100 numbers back to back.


APPLY (CORRECTED): Use the order as proposed, with the A100 table under the dumbbells in <details id='a100-published'><summary>A100 (published) values and sources</summary>…</details>, with no heading inside the summary. Or keep it as a plain h3 and table, uncollapsed, after the dumbbells.

Base PROPOSAL (for "as proposed" references): New order, keeping all ids:
1. Load latency against working-set size (#load-latency-against-working-set-size)
2. Scratchpad latency across the mesh (#scratchpad-latency-across-the-mesh; with mh-3 it becomes the distance view)
3. The hierarchy as a spec sheet (#the-hierarchy-as-a-spec-sheet), ET table only
4. ET-SoC-1 against the A100, level by level (#et-soc-1-against-the-a100-level-by-level), with the A100 table moved under the dumbbells inside <details><summary><h3 id='a100-published'>A100 (published) values and sources</h3></summary>…</details>
5. What the numbers say
6. How it was measured
7. Caveats
8. Reproduce
9. Related reports
10. Sources

Update the contents list to match.


Verifier note: The new order is sensible, and no other page links this page's anchors (grep). But putting an <h3> inside <summary> clashes with the section-anchor script. It adds a click handler to every h3 that calls ev.preventDefault(), so clicking the heading would not open the <details>.


#### mh-18 — MODIFIED [layout/low] et-soc1-memory-hierarchy

Where: 'ET-SoC-1 (measured)' and 'A100 (published)' tables at 390 px

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-memory-hierarchy.html

Problem: At phone width the tables scroll inside their frames, and the first screen shows only Level and Capacity. Latency, bandwidth and energy, the spec sheet's point, sit off-screen to the right. The page does not overflow, but the table fails the reader.


APPLY (CORRECTED): 1. Reorder the columns to Level | Latency | Bandwidth | Energy | Capacity | Notes.
2. Make the first column sticky on both th and td (position: sticky; left: 0; background: var(--page); z-index: 1).
3. Leave Notes as the last column, or under 600 px switch these tables to the card pattern of noc-15 (data-label, display: block, with table min-width: 760px overridden to 0).

Base PROPOSAL (for "as proposed" references): 1. Reorder the columns to Level | Latency | Bandwidth, whole chip | Energy per byte | Capacity | Notes, in both tables.
2. Make the first column sticky: th:first-child, td:first-child { position: sticky; left: 0; background: var(--page); }
3. Under @media (max-width: 600px), render the Notes cell as a full-width second line: td.notes { display: block; } with the header cell hidden.


Verifier note: The 390 px screenshot confirms it: only Level, Capacity and a sliver of Latency are visible. But td.notes { display: block } inside a table does not give a full-width second line; the cell stays in the row's table layout.


#### noc-1 — MODIFIED [consistency/medium] et-soc1-on-chip-communication

Where: Lede; KPI 'Energy per byte moved'; bandwidth table 'Energy per byte' column; Energy per byte moved caption and chart; What the numbers say items 6 and 7

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-on-chip-communication.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-23-energy-manual/reruns.json, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/nocbench/analyze.py

Problem: The headline energies are the superseded 18 September values:
- 0.8–2.3 pJ and ~10 + 1.9 pJ per hop in the lede, KPI, table and chart;
- 6–26× and 0.8–20 pJ in items 6 and 7.
The page itself says four times that these read 2–20% high. The canonical cross-shire figure (PLAN D9) is 9.3 + 1.7 pJ/B per mean hop. The sibling memory-hierarchy page moved to the 23 September re-measurement. The table and chart also mix dates: 18 September messaging bars against 23 September ET reference bars. And '0.8–2.3 pJ inside a shire' omits the 128 B ring in the same chart (3.9; 3.3 re-measured).


APPLY (CORRECTED): Apply items 1–6 as proposed, plus:
- the 'Read these' paragraph: '1.7 pJ/B … the ~9 pJ intercept is the cores';
- Sources: '1.7 pJ per byte per hop is about 57 fJ/bit·mm';
- Caveats: 'r² 0.95', keeping '1.6–2.5 W on a 34 W card (18 September)';
- Versions: record the first-published values (0.8–2.3 pJ inside a shire, 10.0 + 1.9 per hop, 13–20 across the mesh);
- update the L2-starvation brief's st-3 row and docs/et-soc1-notes.md:121 to 9.3 + 1.7.

Base PROPOSAL (for "as proposed" references): Quote the 23 September values as the headline. Keep the 18 September values in the chart as the earlier run (see noc-2).

1. Lede: 'Messaging costs 0.8–2.3 pJ per byte inside a shire, busy cores included.' → 'Messaging costs 0.7–2.1 pJ per byte inside a shire with 1 KB messages, busy cores included (re-measured on two cards).'
2. KPI: value '0.7–2.1 pJ'; sub 'inside a shire, busy cores included; 9.3 + 1.7 pJ per mean hop across the mesh (two cards)'.
3. Table energy column: '0.67 pJ', '2.1 pJ', '12–18 pJ'. Footnote: 'Energies per byte are the 23 September re-measurement on two cards (the energy manual, §5)'.
4. Item 6: 'at 6–26× the energy per byte' → 'at 6–27× the energy per byte'.
5. Item 7: 'Messaging costs 0.8–20 pJ per byte' → 'Messaging costs 0.7–18 pJ per byte (1 KB messages)'.
6. Energy caption: 'Inside a shire messaging costs 0.8–2.3 pJ per byte. Over the mesh the cost fits 10.0 + 1.9 pJ per hop (r² 0.90)' → 'Inside a shire messaging costs 0.7–2.1 pJ per byte with 1 KB messages (3.3 with 128 B). Over the mesh the cost fits 9.3 + 1.7 pJ per mean hop (r² 0.95; 10.0 + 1.9 in the 18 September runs)'.


Verifier note: The values check out. The rerun rings: pair 0.67, neighbourhood 2.11, shire 2.08, 128 B shire 3.26, mesh 11.87–17.77 pJ/B. The fit over the six 1 KB mesh rings is 9.28 + 1.71 per mean hop, r² 0.949. The ratio range is 11.87/2.11 = 5.6 to 17.77/0.665 = 26.7, so '6–27×'. Switching also matches canonical value D9. But the proposal misses other places that depend on the old fit:
- the paragraph 'The per-hop slope, 1.9 pJ/B … the ~10 pJ intercept is the cores';
- Sources: '1.9 pJ per byte per hop is about 64 fJ/bit·mm';
- Caveats: 'the per-hop slope's r² is 0.90, so treat the mesh numbers as ±20%';
- other pages quoting the old values: the published L2-starvation brief (row st-3, '~10 + 1.9/hop pJ/B') and docs/et-soc1-notes.md:121.
The watts (1.6–2.5 W against a 2.7 W spin) exist only from 18 September.


#### noc-2 — MODIFIED [visualization/medium] et-soc1-on-chip-communication

Where: Energy per byte moved (#energy): replace the bar chart; also the bandwidth table's 'Whole chip' column

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-on-chip-communication.html, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/nocbench/analyze.py, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-23-energy-manual/reruns.json

Problem: The title's 'bandwidth cliff at the shire boundary' is shown only in one table column. The page's key argument, that the energy step is fewer bytes rather than costlier wires, is prose. The existing energy chart draws bars on a log axis starting at 0.5 pJ, so bar length means nothing. It also mixes the 18 September messaging values with the 23 September ET references, and shows no run-to-run spread.


APPLY (CORRECTED): Build the three aligned panels as proposed, with these changes:
- Print values directly beside each dot, or keep a compact table.
- Add the scratchpad TensorLoad (0.96 TB/s, 6.65 pJ/B) as a reference row in panels 1 and 3, and drop the table row only then.
- Label panel 2 '18 September'.
- Make rows focusable SVG <g tabindex=0 role=button aria-label=…>, or build the rows in HTML.
- Compute the rerun fit in analyze.py.

Base PROPOSAL (for "as proposed" references): Question it answers: why does a byte cost 6–27× more once it crosses the shire boundary?

Data:
- nocbench-data.energy.configs for pair, neigh, shire, shire-c4, xshire8, xshire16, xshire1, xshire4, xshire2, xshire6 and xshire1-c4, with configs.spin.above_idle_w and energy.mesh_fit.
- New nocbench-data.reruns, embedded by analyze.py from docs/reports/data/2026-09-23-energy-manual/reruns.json: rings_pj_per_byte[k].{mean,lo,hi,n}, plus the rerun fit 9.28 + 1.71.
- Reference lines: ET L2 2.51, remote scratchpad 6.65, DRAM 122 (levels_pj_per_byte); A100 L2 37.7, HBM 105.

Encoding: three aligned dot-plot panels with one row per configuration, sorted by mean hops (0 → 4.7):
1. aggregate GB/s on a log axis;
2. W above idle on a linear axis from 0, with a dashed rule at the 2.7 W spin;
3. pJ/B on a log axis: 18 September as a hollow dot with the two runs as ticks, 23 September as a filled dot with a lo–hi whisker. References are vertical rules in var(--ref).
Colours are var(--et) inside a shire and var(--et2) across the mesh.

Interaction:
- Hover or focus a row to highlight it in all three panels. Tooltip: its 'what' text, mean hops (min–max), GB/s, W, and pJ/B on both dates.
- A toggle 'by configuration | against mean hops' redraws panel 3 as pJ/B against hops with both fitted lines.
- Rows are <button>s, so the chart works from the keyboard.

At 390 px the panels stack vertically at full width with short row labels (e.g. 'mesh 1.6 hops').

It replaces the bar chart, the table's 'Whole chip' and 'Energy per byte' columns (the per-link columns stay), the 'Later measurements' box and the separate 're-measured' paragraph.

What the reader gains: watts stay flat at 1.6–2.5 W, below the spin, while bytes per second drop 7–34×. So pJ/B rises: the cost of messaging, not of wires.


Verifier note: The data check out: gb_per_s, above_idle_w of 1.56–2.53 W against a 2.71 W spin, and mean_hops. The 7–34× also checks out (1,120/156 = 7.2; 2,992/87.5 = 34.2), and bars on a log axis from 0.5 are indeed meaningless. But removing the table's Whole-chip and Energy columns empties the 'For comparison: TensorLoad from another shire's scratchpad' row, which has only those two values, and it makes the numbers readable only by hovering. Panel 2's watts and the spin are 18 September values; the rerun passes have no spin burst. A <button> cannot sit inside an SVG. The rerun fit 9.28 + 1.71 is not stored in reruns.json.


#### noc-3 — MODIFIED [visualization/medium] et-soc1-on-chip-communication

Where: Latency grows with distance (#dist): add toggles to the existing scatter

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-on-chip-communication.html, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/nocbench/analyze.py

Problem: The distance chart shows only 32 B messages. Its linear 0–1,200 ns axis is dominated by the memory-flag cloud, which flattens the 20 ns-per-hop line. The 1 KB round-trip matrix is embedded but never drawn. That matrix is the only evidence for the size section's 'Beyond about 5 hops, messages of 1 KB and up slow down'.


APPLY (CORRECTED): Add the '32 B | 1 KB' toggle. Auto-fit the y range to the visible series: 32 B without the flag about 0–500 ns, 1 KB about 500–1,000 ns. Fit the knee as +12 cycles per hop through 5 hops and about +36 per hop from 7, with 6 hops transitional (+27). The link to the map is optional.

Base PROPOSAL (for "as proposed" references): Question it answers: how does a round trip grow with distance, and where does it stop being 12 cycles per hop?

Data: nocbench-data.matrices['matrix-pingpong'|'matrix-pingpong-c32'|'matrix-fcc'|'matrix-flag'].pairs [a, b, cycles] and their fits; hops from nocbench-data.layout. Add to analyze.py a two-segment fit for c32 (knee at 5 hops), saved as matrices['matrix-pingpong-c32'].knee.

Encoding: the existing scatter plus a segmented toggle '32 B | 1 KB'. In 1 KB mode, draw the two-segment line (var(--et)) and hide credits and flags. Add a button 'Hide the memory flag' that rescales y to 0–600 ns so the 20 ns step per hop is legible.

Interaction:
- Hover a point: 'shire a ↔ b, h hops, cycles, ns, residual from the fit'.
- The same hover outlines shires a and b on the mesh map above, through a shared highlight function (the map lights the pair).
- The buttons use aria-pressed.

It fits 390 px as the current chart does.

It complements the existing chart and turns the 'Beyond about 5 hops' sentence into something the reader can see.


Verifier note: The data check out: c32 medians by hops are 348, 360, 372, 384, 396, 422.9, 458.9, 494.9, 530.9 and 567.2 cycles, and the page script leaves them unused. But a fixed 0–600 ns rescale cannot show 1 KB mode: 1 KB round trips run 580–945 ns, and there are no 0-hop points in that matrix. Highlighting shires on the mesh map, which is in an earlier section, will usually be off-screen.


#### noc-4 — MODIFIED [visualization/low] et-soc1-on-chip-communication

Where: Where the shires are (#mesh): extend the 'Show a one-hop ring' button into map modes

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-on-chip-communication.html

Problem: Two design rules are prose only: 'order chains by the map, not by shire ID' and the tree's per-level cost over the mesh. The map has one ring toggle and cannot show ID order, nor which shires each tree level joins.


APPLY (CORRECTED): Keep the chain modes as proposed. In tree mode, for the tree of n shires, show each level's pairs within those n shires and the model 432 + Σ over levels of (max over that level's pairs of 150 + 12.02 × hops). That gives 618, 853, 1,051, 1,213 and 1,423 cycles against measured 618, 853, 1,032, 1,188 and 1,368. Level 5 in the 64-minion tree is shires 0 ↔ 1, 3 hops: 186 predicted, 186 measured.

Base PROPOSAL (for "as proposed" references): Question it answers: how should a chain or a tree be laid on the mesh, and what does each level between shires cost?

Data: nocbench-data.layout, RING and allreduce['1']; the fit 150 + 12.02 × hops (matrices['matrix-pingpong'].a/.b).

Encoding: a mode switch above the map, 'Round trip from a shire | Chain in shire-ID order | One-hop ring | Tree levels 5–9'.
- Chain modes draw arrows between consecutive shires, coloured by hop count (var(--et) for 1 hop, var(--et2) for more), with a readout of total hops, mean, maximum, and the predicted one-way 32 B latency summed over the chain.
- Tree mode adds a range input (level 5–9). It draws the shire pairs merged at that level (s with s XOR 2^(level−5)) with hop labels, and reads out the farthest pair's round trip against the measured increment. For example, level 5: pairs 1–6 hops apart, 222 cycles for the farthest, 186 measured.

Interaction: buttons with aria-pressed and a keyboard-operable range input. Cells get tabindex='0' and role='button', and arrow keys move the selected shire.

It keeps the current map size, which fits 390 px.

It replaces the single ring button and shortens the 'Order chains by the map' bullet.


Verifier note: The chain numbers check out: 102 hops over 31 steps (mean 3.29, max 8); 112 over 32 when the ring closes (max 10); 2.125 hops for s ↔ s+16; the one-hop ring. The tree mode is wrong as specified (see noc-10). The increment from 2^L to 2^(L+1) minions involves only shires 0 to 2^(L−4)−1, and it also includes new, slower branches at the lower levels. Comparing it with the farthest pair over the whole chip gives mismatches that are not real.


#### noc-5 — MODIFIED [visualization/low] et-soc1-on-chip-communication

Where: Existing charts: #mesh, #neigh, #tree, #size, heat ramps on both pages

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-on-chip-communication.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-memory-hierarchy.html

Problem: Assessment of the existing charts:
- The mesh map is clear and well labelled, but only mouse or touch can select a shire: the SVG rects have no tabindex or key handler.
- The neighbourhood diagram is clear but leaves about 120 px empty below the tree at 1280 px.
- The tree chart is honest (log y, A100 reference), but at 390 px its 'one shire ← → across shires' label shrinks to 'shire'.
- The size chart is clear, but gives ns per message while its table gives GB/s.
- Both pages hard-code a hex RAMP (#cde2fb…#0d366b), so in dark mode the slowest cells sink toward the #1a1a19 surface. Emphasis reverses there.


APPLY (CORRECTED): (2): set align-self: start (or centre the SVG) on the neighbourhood card. (5): build the ramp with color-mix through style.fill, and choose the text colour from the step and the theme. The rest as proposed.

Base PROPOSAL (for "as proposed" references): 1. Mesh map: add tabindex='0', role='button' and aria-label='shire S, N hops, R ns' to each cell rect. Handle keydown: Enter/Space selects, arrow keys move to the adjacent cell.
2. Neighbourhood card: set the SVG height to its content (about 280 px), or place the shire-level caption beside the tree.
3. Tree chart at W < 520: draw the label as two tick labels, '← one shire' and 'across shires →'.
4. Size chart: add a toggle 'ns per message | GB/s per link', computed as bytes / (cycles/0.6 GHz).
5. Both ramps: build them from color-mix(in srgb, var(--et) p%, var(--surface)) with p from 15 to 100. Change 'Darker is slower' to 'Stronger blue is slower'.


Verifier note: (1), (3) and (4) check out: 0 tabindex, and the tree label shrinks to 'shire' at 390 px. On (2), the SVG is already 272 px tall. The roughly 110 px gap at 1,280 px comes from the .two grid stretching the card to the height of the text column, so resizing the SVG will not fix it. On (5), the ramp is a real dark-mode problem, but the mesh map hard-codes label fills #fff/#0b0b0b by ramp step, and those would be wrong on a color-mix ramp in dark mode.


#### noc-6 — CONFIRMED [redundancy/medium] et-soc1-on-chip-communication

Where: 'Later measurements' box under the lede (line 112); bandwidth-table footnote; Energy section's last paragraph; Caveats 'Energy is whole-card power above idle'

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-on-chip-communication.html

Problem: The 23 September re-measurement is announced four times, each with '2–20%' higher. The box also repeats the rerun values (pairs 0.67, rings 2.08, next shire 14.9) that the Energy section repeats, and repeats the Heat per millimetre pointer that the Energy section and Related reports already make.


APPLY (PROPOSAL): 1. Delete the whole <p class='small card'><b>Later measurements.</b> … The latencies and bandwidths here are not affected.</p>.
2. Table footnote: cut 'Energies per byte are the 18 September values, which read 2–20% above the 23 September re-measurement (see Energy per byte moved).' If noc-1 is applied, it becomes the new source sentence.
3. Caveat: cut 'Polling power without the die temperature on a cooling card, as here, reads high; these values read 2–20% above the later re-measurement.'
4. Keep one statement, in the Energy section's last paragraph (or in noc-2's chart legend).


Verifier note: '2–20%' appears four times: box, table footnote, energy paragraph and caveat. The box's Heat-per-millimetre pointer is repeated in the energy paragraph and in Related reports. If noc-1 is applied, the one kept statement becomes 'the 18 September values read 2–20% higher'.


#### noc-7 — CONFIRMED [redundancy/low] et-soc1-on-chip-communication

Where: What the numbers say, items 1, 3 and 5; systolic section's last bullet

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-on-chip-communication.html

Problem: Items repeat their own sections, and one bullet repeats an item.
- Item 1 repeats the map caption's search sentence.
- Item 3 repeats 'Inside a shire' ('Being in the same neighbourhood doesn't help').
- The systolic bullet 'Reductions and barriers belong to the trees' repeats item 5 and the primitives table's 3.7× and 'run in parallel in every shire'.


APPLY (PROPOSAL): 1. Item 1: cut 'A search starting from random layouts converged on the same distances every time.' and keep the caption's version, changing it to 'all 12 restarts of a search from random layouts, without his map, found the same distances'.
2. Item 3: cut 'A neighbourhood boundary costs nothing extra; only the tree edges are special.'
3. Systolic section: delete the bullet '<li><b>Reductions and barriers belong to the trees.</b> They beat atomics by 3.7× chip-wide, run in parallel in every shire, and their per-level cost follows the distance of each level's partners.</li>'. Append to item 5: ' Reductions and barriers belong on the trees.'


Verifier note: The repeats are as described. I ran the 12-restart search locally: every restart has cost 31.6 and the same hop distances as marty1885's map, so 'all 12 restarts' is true. The record should be committed first (noc-13 point 3).


#### noc-8 — MODIFIED [redundancy/low] et-soc1-on-chip-communication

Where: Versions paragraph (line 242); trap box second paragraph; How it was measured, Lab etiquette

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-on-chip-communication.html

Problem: Internal history on a public page.
- The Versions paragraph lists what a review changed, which readers cannot use without the old page.
- Two sentences relay the lab admin's reset policy and an apology for not following it.


APPLY (CORRECTED): Versions: 'Published 18 September 2026; revised 24 September 2026 (energies per byte now the 23 September re-measurement; first published 0.8–2.3 pJ inside a shire and 10.0 + 1.9 pJ per hop across the mesh; systolic guidance and map orientation corrected).' Steps 2 and 3 as proposed; drop step 4.

Base PROPOSAL (for "as proposed" references): 1. Versions → 'Published 18 September 2026; revised 24 September 2026 (energies linked to their re-measurement; systolic guidance and map orientation corrected).'
2. Trap box: delete 'The lab admin asks that a hung card be power-cycled by him rather than reset by users.'
3. Lab etiquette → 'Every card run was its own process under timeout 10, on an otherwise idle card. The one hang (above) was cleared with a software reset, and a health check passed before any further runs.'
4. Keep the admin's policy in the repo's lab notes (docs/getting-started.md or 01-resources.md).


Verifier note: The cuts are right. The admin's policy is already in docs/getting-started.md:198 and docs/et-soc1-notes.md:128, so step 4 is already done. If noc-1 is applied, the new Versions line must say what changed in the energies and keep the first-published values.


#### noc-9 — CONFIRMED [claim/low] et-soc1-on-chip-communication

Where: Message size and bandwidth, caption: 'Beyond about 5 hops, messages of 1 KB and up slow down: the sender seems to have a limited number of packets in flight.'

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-on-chip-communication.html, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-18-nocbench-aifoundry2/matrix-pingpong-c32.jsonl

Problem: The streams in this section cover only 1 and 10 hops, so they cannot locate a 5-hop knee. The evidence is elsewhere, the 1 KB round-trip matrix across all 496 shire pairs, and the page never cites it.


APPLY (PROPOSAL): Replace the sentence with: '1 KB round trips between all 496 shire pairs add 12 cycles per hop up to 5 hops and 27–36 per hop beyond (the 1 KB view of the distance chart), so the sender seems to have a limited number of packets in flight.' Pair this with noc-3.


Verifier note: counts-stream covers only 0.0→0.1, 0.0→0.7, 0.0→8.0 and 0.0→31.0. The 1 KB matrix steps +12 cycles per hop through 5 hops, then +27 and +36 per hop. The proposed sentence is accurate.


#### noc-11 — CONFIRMED [claim/low] et-soc1-on-chip-communication

Where: How it was measured (Round trips, Clock); What the numbers say item 2

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-on-chip-communication.html

Problem: Four wording errors found by the reproduction:
1. '300–4,000 times': the flag matrix used 200.
2. 'all 44 stream, ring, tree and barrier runs': the 44 records are 40 allreduce plus 4 barrier records. Streams are among the 3,699 pair records, and rings are the energy runs' throughput records.
3. 'during every run': clock.csv ends 142 s into the session, and isolated-pairs and loaded-pairs ran 656 s later. Those two files appear on no page.
4. 'fit within a cycle at 600, 700 and 800 MHz': the chase from shire 24 to shire 18 is 5.4 cycles off, because its clock changed partway through.


APPLY (PROPOSAL): 1. '300–4,000 times' → '200–4,000 times'.
2. 'All 3,699 pair measurements and all 44 stream, ring, tree and barrier runs passed.' → 'All 3,699 pair and stream measurements, all 40 tree and 4 barrier runs, and every ring launch of the energy runs passed.'
3. Clock: 'during every run' → 'during every run shown here'.
4. Item 2: 'and fit within a cycle at 600, 700 and 800 MHz.' → 'and fit within a cycle at 600, 700 or 800 MHz, except one chase whose clock changed partway (5.4 cycles off).'


Verifier note: All four check out:
1. Iterations are 200–4,000 (matrix-flag 200).
2. Record kinds: pair 3,699, allreduce 40, barrier 4, launch 46. Energy-a (133) and energy-b (139) throughput records are all ok.
3. clock.csv spans 141.8 s; loaded-pairs and isolated-pairs start at 797.8 and 798.0 s.
4. 24→18 is 5.38 cycles off (159.8 at 600 MHz, 175.5 at 700); the next worst point is 0.96.
The same fix belongs in item 1: 'scratchpad loads … worst residuals of 1–5 cycles' holds only per clock. Row 24's single-line fit has r² 0.88 and a worst residual of 25.9 cycles.


#### noc-12 — MODIFIED [reproducibility/low] et-soc1-on-chip-communication

Where: docs/findings/05-claims.md:219; docs/reports/data/2026-09-22-hotline-aifoundry2/hotline.json context.barrier_cycles_chip; tools/ettelem/build_energy_manual.py:164

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/05-claims.md, /home/yaroslavvb/claude/et-soc1-prototyping/tools/ettelem/build_energy_manual.py, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-22-hotline-aifoundry2/hotline.json, /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/17-hot-line.md, /home/yaroslavvb/claude/et-soc1-prototyping/docs/energy-manual/06-synchronisation.md

Problem: The chip-wide barrier, 4,997 cycles, is a hand-entered constant that no script derives and that the nocbench data do not contain. The energy manual labels it '1,024 minions', but its value is closest to the 32-participant barrier. (The page's 8.3 µs is correct.)


APPLY (CORRECTED): Steps 1–3 as proposed, and also change docs/reports/sources/hot-line.body.html to 4,995 (one minion per shire) and rebuild that page. Low priority.

Base PROPOSAL (for "as proposed" references): 1. build_energy_manual.py:164: read the value from the data rather than from hotline.json: json.loads(open(NOC + '/barrier-chip32.jsonl').read().split(' ', 1)[1])['cycles_per_iter_mean'], which gives 5,018 for the 1,024-minion row.
2. 05-claims.md:219 → '| Chip-wide barrier | 4,995 cycles (one minion per shire), 5,018 (all 1,024) | M | R4 | docs/reports/data/2026-09-18-nocbench-aifoundry2/barrier-chip{1,32}.jsonl, cycles_per_iter_mean |'.
3. Change 4,997 to 4,995 in 17-hot-line.md, and to 5,018 in 06-synchronisation.md. Drop hotline.json context.barrier_cycles_chip, or write it from the file.


Verifier note: Confirmed: barrier-chip1 is 4,995.0 cycles (32 participants) and barrier-chip32 is 5,017.7 (1,024). hotline.json context.barrier_cycles_chip = 4997 is hand-entered; no script writes it. The list of files misses the public hot-line page, whose docs/reports/sources/hot-line.body.html says 'barrier we measure at 4,997 cycles'. The difference is 0.04–0.4% and changes the 12 µJ figure not at all.


#### noc-13 — CONFIRMED [reproducibility/low] et-soc1-on-chip-communication

Where: Reproduce section; workloads/nocbench/analyze.py docstring and search_layout()

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-on-chip-communication.html, /home/yaroslavvb/claude/et-soc1-prototyping/workloads/nocbench/analyze.py, /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/data/2026-09-18-nocbench-aifoundry2/README.md

Problem: Gaps in the reproduction path:
- The page reports 'two runs, in opposite orders', but Reproduce gives only the energy-a command. The energy-b --only order is in the data README alone.
- The analyze.py docstring omits --search, which the page and README use.
- search_layout() returns only the best restart, so 'found the same distances every time' rests on a check nobody committed.
- The embed carries unused blocks: scp_rows, intra, functs, barriers, loaded and matrices.search.


APPLY (PROPOSAL): 1. Reproduce: after the energy-a line, add
ssh aifoundry2 'cd ~/nekko && python3 workloads/nocbench/run_energy.py --host-bin build/nocbench/host/nocbench_host --out build/nocbench-data/energy-b --only xshire1-c4,shire-c4,xshire6,xshire4,xshire2,xshire8,xshire16,xshire1,shire,neigh,pair,spin'
2. Docstring usage → '[--memhier DIR] [--search] [--embed REPORT_HTML]', with '--search: 12 simulated-annealing restarts from random layouts (about 30 s); records each restart'.
3. search_layout(): return a list of (cost, same_distances(layout, MARTY)) per restart, and embed it as matrices['matrix-pingpong'].search.restarts. The caption can then say 'all 12 restarts'.
4. Stop embedding intra, functs, barriers and loaded. Keep scp_rows, which mh-3 can use.


Verifier note: The README has the energy-b --only order, and Reproduce does not. The docstring omits --search. search_layout() keeps only the best restart, and I ran the reviewer's restart script locally: 12 of 12 restarts reach cost 31.6 with the same distances. The page reads only layout, empty_cells, matrices, classes, sizes, allreduce and energy. Keeping scp_rows is optional: mh-3 would use memhier-data, not nocbench-data.


#### noc-14 — MODIFIED [reorganize/low] et-soc1-on-chip-communication

Where: Section order (h2) and the contents list

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-on-chip-communication.html

Problem: 1. 'Related reports' comes after 'Sources', against PLAN X1/§3.13 item 4 and unlike the memory-hierarchy page.
2. The lede lists the mechanisms and promises each 'against its closest GPU equivalent', but the table that delivers this sits fourth, between the latency sections and the bandwidth section. It covers trees, credits and barriers that later sections detail. It is also the page's most-linked section (12 inbound links to #every-primitive-against-a-gpu).


APPLY (CORRECTED): Required: move Related reports before Sources. Optional: primitives first, keeping all ids.

Base PROPOSAL (for "as proposed" references): New order, keeping all ids:
1. Every primitive, against a GPU (#every-primitive-against-a-gpu), as the overview answering the lede
2. Where the shires are: a 6×6 mesh
3. Latency grows with distance, except through memory
4. Inside a shire, only the tree edges are fast
5. Message size and bandwidth
6. Reduction trees
7. Energy per byte moved
8. What the numbers say
9. A trap: one ready flag per minion
10. What it means for systolic and wavefront designs
11. How it was measured
12. Caveats
13. Reproduce
14. Related reports (#related)
15. Sources (#sources)

Update the contents list to match.


Verifier note: Related after Sources breaks plan rule X1 and §3.13 item 4. Inbound anchors check out (#every-primitive-against-a-gpu 12, #a-trap… 4, #reduction-trees 2). Moving the primitives table first is a defensible overview but optional. The contents list on this page is built by the template script (the page has no #toclist), so no manual update is needed.


#### noc-15 — MODIFIED [layout/low] et-soc1-on-chip-communication

Where: 'Every primitive, against a GPU' table and the bandwidth table at 390 px

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/reports/2026-09-18-et-soc1-on-chip-communication.html

Problem: At phone width the primitives table shows only 'Primitive' and 'ET-SoC-1, measured'. 'What it does' and 'Closest GPU equivalent', the comparison the section is named for, sit off-screen. The bandwidth table hides its whole-chip and energy columns the same way.


APPLY (CORRECTED): Add class='prim' and data-label attributes. Under @media (max-width: 600px), in addition to the proposed rules: table.prim { min-width: 0 }; table.prim td.num { text-align: left; white-space: normal }; table.prim td.lvl { min-width: 0 }. Make the bandwidth table's first column sticky with a background.

Base PROPOSAL (for "as proposed" references): For the primitives table, add a data-label attribute to each <td> and, under @media (max-width: 600px):
table.prim thead { display: none }
table.prim, table.prim tbody, table.prim tr, table.prim td { display: block }
table.prim td::before { content: attr(data-label); display: block; font-weight: 600; color: var(--ink-2) }
Each primitive then becomes a card.

For the bandwidth table, make the first column sticky (position: sticky; left: 0; background: var(--page)). Or, if noc-2 is built, drop the two whole-chip columns so the table fits.


Verifier note: The 390 px screenshot confirms that only Primitive and 'ET-SoC-1, measured' are visible, and the bandwidth table cuts its Whole-chip column to '0'. The card CSS as written does not work alone, because the page sets table { min-width: 720px }, td.num { white-space: nowrap; text-align: right } and td.lvl { min-width: 150px }.


#### x-1 — MODIFIED [reproducibility/low] et-soc1-memory-hierarchy, et-soc1-on-chip-communication

Where: docs/findings/05-claims.md (no section for R4); docs/findings/03-experiments.md

Files: /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/05-claims.md, /home/yaroslavvb/claude/et-soc1-prototyping/docs/findings/15-earlier-findings.md

Problem: The claim index traces most pages' numbers to files and fields, but has no rows for either page's headline numbers. Examples: 5.25/36/47 cycles; L3 159–169 and DRAM 287–297/352–368 cycles; 76 GB/s; 150 + 12.02 × hops; 68/114 cycles; 2.3 µs; 395 ns; 590–1,150 ns. Only the barrier (row 219) and one fp16 row cite R4. This review had to rebuild the mapping from the scripts.


APPLY (CORRECTED): Add '## Memory hierarchy (18 Sep, aifoundry2)' and '## On-chip communication (18 Sep, aifoundry2)' sections to 05-claims.md, giving the file and field behind each headline number (for example, chase-dram-from*.jsonl cycles_per_load; matrix-pingpong.jsonl a/b via analyze.py). Add the two sessions to 03-experiments.md with their run_lab.sh commands.

Base PROPOSAL (for "as proposed" references): Add to 05-claims.md a section '## Memory hierarchy and on-chip communication (R4, 18 September)', with rows in the existing format. For example:
- '| L1 / read buffer / L2 load | 5.25 / 36 / 47 cycles | M | R4 | DATAMH/chase-dram.jsonl, cycles_per_load at 256 B / 1 KB / 64 KB |'
- '| L3 at 600 MHz | 159–169 cycles | M | R4 | DATAMH/chase-dram*.jsonl, 4 MB chains with point_ghz < 0.7 |'
- '| DRAM at 600 / 800 MHz | 287–297 / 352–368 cycles | M | R4 | same, ≥128 MB |'
- '| Bandwidth at 600 MHz | 6.2 / 2.45 / 2.46 / 0.96 / 0.98 TB/s, 76 GB/s | M | R4 | scripts/ridge-points.py memhier_levels(), gbps_600 |'
- '| Shire-to-shire round trip | 150 + 12.02 × hops cycles, worst 1.1 | M | R4 | DATANOC/matrix-pingpong.jsonl via analyze.py matrices.matrix-pingpong.{a,b,worst} |'
- '| In-shire round trips | 68 / 114 cycles | M | R4 | intra-pingpong{,-s24}.jsonl |'
- '| Allreduce, 1,024 minions, 32 B | 1,368 cycles (2.28 µs) | M | R4 | xallreduce-c1.jsonl |'
- '| Shire barrier | 237 cycles | M | R4 | barrier-shire{1,32}.jsonl |'
- '| Flag through memory | 592–1,147 cycles-equivalent ns, median 873 | M | R4 | matrix-flag.jsonl, classes-flag.jsonl |'


Verifier note: The finding text is truncated at 'The claim', so I could check only what its location names. docs/findings/05-claims.md has no section for either page's latency, bandwidth or mesh numbers; the only related rows are line 219 (barrier) and the ridge-point rows. docs/findings/03-experiments.md has no entry for the 18 September memhier and nocbench sessions; E1 starts on 19 September.


### Missed by the reviewers (found by the verifiers)


#### M-mhn-1 [claim] et-soc1-memory-hierarchy

Problem: Item 5's 'Shire 24's L3 load … fits 72 cycles plus 145 ns' holds for shire 24 only and is not generalised. With 20 ns per mesh hop over the mean trip to the 32 slices it becomes one model: 72.3 minion cycles + 61.2 ns + 20 ns × mean hops. That reproduces all four requesters at 600 MHz within 0.1 cycle (169.0, 160.8, 159.3, 169.0 against 169.0, 160.7, 159.3, 168.9) and shire 0 at about 800 MHz within 1.4 cycles (201.3 predicted; 199.9 and 200.4 measured at 24 and 32 MB). It also splits Anatomy §4's 110-cycle constant: at 600 MHz, 72.3 + 61.2 × 0.6 = 109 cycles. Anatomy says that split is still open.

APPLY: In item 5, after the shire-24 fit, add: 'Of the 145 ns, 20 ns per hop is the mesh trip to the average slice (4.2 hops from shire 24, 5.0 from shire 0); 72 cycles + 61 ns + 20 ns per hop gives every requester's L3 latency here within a cycle at 600 MHz, and at 800 MHz for shire 0.' Also send the split to Anatomy §4. mh-2 needs this for its per-shire L3 curves.


#### M-mhn-2 [redundancy] et-soc1-memory-hierarchy

Problem: mh-2, mh-3 (L3 mode), mh-12 and the L3 Notes cell would all explain the per-requester L3 spread, which would create the kind of repetition this pass is meant to remove.

APPLY: Give it one home in the text: item 4, with mh-12's sentence. Let mh-3's L3 mode and mh-2's tooltips show it without repeating it. The L3 table cell keeps only 'Latency depends on the requesting shire (item 4)'.


#### M-mhn-3 [claim] et-soc1-memory-hierarchy

Problem: The table and CMP tooltip give the 600 MHz DRAM range as 480–495 ns, but 287.27 cycles / 0.6 GHz = 478.8 ns. analyze.py's per-clock output (mh-15) prints 479–495.

APPLY: Change '480–495 ns' to '479–495 ns' in the DRAM table row and in CMP['cmp-lat'] (DRAM row).


#### M-mhn-4 [reproducibility] et-soc1-ridge-points

Problem: scripts/ridge-points.py rerun_levels() says the levels-pass* runs are 'the energy manual's section 4.2 runs'. The energy manual actually pools rl-pass* (tools/ettelem/analyze_reruns.py), and the rerun README says levels-pass* are 'kept for the record and not pooled'. This mislabelling is what led mh-4 and mh-9 to treat levels-pass power as the pinned-600 MHz reference.

APPLY: Change the docstring to: 'The same streaming probes re-run on 23 September at a pinned 600 MHz by the older run_energy.py runner (levels-pass*: three passes on aifoundry2, two on aifoundry3); their bandwidths are used here, while the energy manual's §4.2 energies come from the rl-pass* bursts.' The bandwidth check stays valid: rl-pass GB/s agree within 0.3%.


### Refuted — do not apply


- noc-10 (et-soc1-on-chip-communication): The reviewer compared each per-level increment with the farthest pair of that level in the 1,024-minion tree. But growing the tree from 32 to 64 minions adds level 5 for shires 0 ↔ 1 only: 3 hops, 150 + 36 = 186 cycles, exactly the measured 186. From 64 to 128, the new pair 2 ↔ 3 at 6 hops (222) slows level 5 by 36, and level 6 (0 ↔ 2, 4 hops, 198) is added: 234 predicted, 234 measured. Summing each level's slowest pair gives 618, 853, 1,051, 1,213 and 1,423 against measured 618, 853, 1,032, 1,188 and 1,368: exact for 64 and 128 minions and within 2–4% beyond. 'The slowest branch sets the pace' and 'per-level cost follows the distance of each level's partners' are supported. Optionally, the caption could add this check.



## Group matmul-sparse-testdrive


### Reproduction problems


#### R-msd-1 [medium] scripts/deploy-lab.sh

Problem: The Reproduce steps call scripts/deploy-lab.sh, and it fails on any Linux machine: it passes BSD-tar-only flags. The test drive also says its last block 'runs on a lab machine', but deploy-lab.sh has to run from the Mac, because it ssh's to the lab.

Evidence: GNU tar 1.35 on aifoundry2: `tar --no-xattrs --no-mac-metadata -czf /dev/null workloads/sgemm` → `tar: unrecognized option '--no-mac-metadata'`, exit 64. Pages and docs that call it: the sparsity page's Reproduce (line 1), the test drive's Reproduce, the sgemm and sparsity READMEs, and getting-started.md §8 'Measuring' ('Build on the machine with scripts/deploy-lab.sh aifoundry2 workloads/<name>'). The owner's memory note already says deploy-lab.sh fails on Linux.

Fix: Pass the mac-only flags only under bsdtar: `extra=(); tar --version | grep -q bsdtar && extra=(--no-xattrs --no-mac-metadata)`, or copy with rsync. In the test drive, change 'the last runs on a lab machine' to 'the last block runs from the Mac and builds and runs on the lab machine'.


#### R-msd-2 [low] docs/reports/2026-09-18-et-soc1-matmul-efficiency.html

Problem: The page states the power sampling rate as 'about 7 times a second' and 'about 7 samples/s'. The committed power.csv has 8.25 samples per second; the reading itself changes about 7 times a second (once per ~133 ms service-processor pass). mmbench-power.py's docstring says 8. getting-started.md §4 repeats the 7.

Evidence: power.csv: 646 samples over 78.1 s, median gap 116 ms, 550 value changes = 7.04/s. Page lines 134 and 166. getting-started.md line 241. mmbench-power.py line 10 ('about 8 times a second').

Fix: 'Board power polled about 8 times a second (the reading itself changes once per ~133 ms service-processor pass)', in the chart caption, the Power bullet and getting-started §4, matching the sparsity page's wording and D2.


#### R-msd-3 [low] docs/reports/2026-09-18-et-soc1-matmul-efficiency.html

Problem: 'Launch-to-launch spread was below 0.03%' holds only for the three L2 workloads. The DRAM run's launches spread 0.34%.

Evidence: runs.jsonl, per-launch total_flop/wall_s (max−min)/mean: fp32 0.014%, fp16 0.023%, int8 0.006%, fp32-DRAM 0.34%.

Fix: 'Launch-to-launch spread was below 0.03% in the L2 runs and 0.3% in the DRAM run.'


#### R-msd-4 [low] docs/reports/2026-09-18-et-soc1-sparsity.html

Problem: The hooks table says '160 → 81 → 45 cycles for 16, 8 and 4 of 16 rows from L2 or the scratchpad', but the scratchpad's 4-row load takes 47 cycles. The body text correctly says 'a floor of about 45–47 cycles'.

Evidence: tload-scp-one.jsonl: lines 16/8/4 → 160.06/81.06/46.81 cycles. tload-l2-one.jsonl: 160.44/81.01/44.86.

Fix: '160 → 81 → 45–47 cycles for 16, 8 and 4 of 16 rows from L2 or the scratchpad'.


#### R-msd-5 [low] docs/reports/2026-09-18-et-soc1-sparsity.html

Problem: The Later-measurements note gives '0.41, 2.1 and 5.4 pJ (energy manual §3.2)'. These are aifoundry3's per-card values. The manual's headline bars are two-card means, 0.42 / 2.23 / 5.78 pJ, so a reader who follows the link sees different numbers.

Evidence: docs/reports/data/2026-09-23-energy-manual/manual.json tensor.bars: fp32_zeros/ones/randn means 0.418/2.229/5.779, per_card aifoundry3 0.411/2.109/5.415. The +1.9/+9.7/+24.9 W are also aifoundry3's (Horace §10).

Fix: 'Per multiply-add that is 0.41, 2.1 and 5.4 pJ on this card (energy manual §3.2, whose two-card means are 0.42, 2.2 and 5.8)'.


#### R-msd-6 [low] workloads/sparsity/run_lab.sh

Problem: A header comment says the DVFS governor 'moves the clock between 600 and 850 MHz'. This contradicts canonical value D1 (600/700/800 MHz; never write 850), and aifoundry3, where this script ran, never leaves 600 MHz.

Evidence: run_lab.sh line 7. PLAN.md D1.

Fix: '…because the DVFS governor can move the clock (600, 700 or 800 MHz on aifoundry2; aifoundry3 stays at 600)'.


#### R-msd-7 [low] workloads/sparsity/analyze.py

Problem: The console summary prints the all-minion scratchpad 1-line TensorLoad as 64 cycles, while the data (64.516) and the page (65) say 65. The value is rounded twice: to 0.1 when stored, then with banker's rounding when printed.

Evidence: analyze.py output 'scp-all … 1:64c/604.0GB/s'. Raw cycles_per_load 64.516. The page's table shows 65.

Fix: Print from the unrounded value, or with f'{c:.1f}'.


#### R-msd-8 [low] docs/report/index.html

Problem: No committed script or data can regenerate the Test drive's silicon SGEMM numbers: the host output was never committed. The published pair '16.8 ms, 127 GFLOP/s' implies 2·1024³/16.8 ms = 127.8 GFLOP/s, so it is consistent only if both figures were truncated.

Evidence: There is no data directory for the test drive. workloads/sgemm/host/main.cpp prints 'launch r: X ms, Y GFLOP/s' with default precision. The same 127 appears in README.md, getting-started.md, the hub and workloads/sgemm/README.md.

Fix: If the run output still exists (for example under ~/nekko on aifoundry3), commit it as docs/reports/data/2026-09-18-sgemm-aifoundry3/. Otherwise leave the numbers and add 'figures truncated from the host's printout'. The simulator facts on the page were re-verified (524,359 warnings; about 38 s per run).


#### R-msd-9 [low] docs/reports/2026-09-18-et-soc1-matmul-efficiency.html

Problem: Redundancy (the owner asked for it to be removed). The ±1/±2-operand caveat and the A100 comparison appear four times: the lede, the Later-measurements note, the Why-low-power paragraph and Caveat 1. The Setup notes also repeat what the Test drive covers (it_test_code_loading, the gp-sdk launcher booting sys_emu without firmware).

Evidence: Rendered text lines 5, 7–11 and 114, and lines 128–137 against Test drive §'Things worth fixing upstream' 2.

Fix: Merge the lede's qualifier, the Later-measurements note and the Why-low-power paragraph into one 'How this compares' box after the KPIs, and keep Caveat 1 for the spec-sheet point only. Cut the Setup notes to the lab-install fixes (the four gp-sdk patches) and link Test drive and getting-started §4 for the rest.


#### R-msd-10 [low] docs/reports/2026-09-18-et-soc1-sparsity.html

Problem: Redundancy. The 86% / 80–92% / 12% results are stated in the lede, the KPI, §1, 'Answers to the questions…' and Caveats. 'Answers' and 'Where the A100 wins' largely restate earlier sections.

Evidence: Rendered text lines 7, 17–18, 93, 169, 297 and 317 (zero-skip share), and lines 290–292 against 118 and 215.

Fix: Turn 'Answers' into a six-row table (question → one-line answer → link to its section) and cut the repeated percentages from Caveats.


#### R-msd-11 [low] docs/report/index.html

Problem: Visualization opportunity (the owner asked for interactive visualizations). The Test drive has no chart. The matmul and sparsity charts show hover values only and cannot explore the data they already embed.

Evidence: The Test drive's only visuals are tables. The matmul efficiency panels cannot show the random-data figures the page discusses. The sparsity page's embedded gemv rows already carry slices_per_minion and lines_per_minion for every point.

Fix: Test drive: a log-scale 'ladder' chart with links: 1.7 GFLOP/s (1 shire) → 127 GFLOP/s scalar → FOSDEM 13 GFLOP/s naive and 2.94 TFLOP/s vector → 9.51 TFLOP/s tensor (matmul page). Matmul: an operand toggle on the efficiency panels (±1/±2 → random-normal at 80 °C: fp32 168 → 144, fp16 321 → 301, with the measured A100 bf16 at 779). Also let a click on a trace window highlight its idle-before window and show how the per-W-above-idle figure is computed. Sparsity: a zero-fraction slider over the layer data that shows latency, slices computed, rows loaded and the predicted empty-slice share p^16 against the measured share, for the masked and skip variants.


### Review findings


#### x-deploy-tar — CONFIRMED [reproducibility/medium] et-soc1-testdrive

Where: scripts/deploy-lab.sh line 16 (the tar pipe). It is called by the Test drive's Reproduce, the sparse page's Reproduce, docs/getting-started.md §8 'Measuring' and six workloads/*/README.md files.

Files: scripts/deploy-lab.sh, scripts/deploy-lab-gpsdk.sh

Problem: deploy-lab.sh always passes the BSD-tar-only flags --no-xattrs --no-mac-metadata, so it exits 64 on any Linux machine: 'tar: unrecognized option --no-mac-metadata'. Every published 'copy to the lab and build' step fails unless it is run from a Mac. scripts/deploy-lab-gpsdk.sh already solved this with a tar_create helper.


APPLY (PROPOSAL): In scripts/deploy-lab.sh, insert before the tar pipe the helper copied verbatim from scripts/deploy-lab-gpsdk.sh lines 24–31:
# macOS bsdtar would otherwise add AppleDouble files and xattr headers that GNU tar complains about.
tar_create() {
  if tar --version 2>/dev/null | grep -q bsdtar; then
    COPYFILE_DISABLE=1 tar --no-xattrs --no-mac-metadata "$@"
  else
    tar "$@"
  fi
}
Then replace line 16, 'COPYFILE_DISABLE=1 tar --no-xattrs --no-mac-metadata -czf - "$dir" |', with 'tar_create -czf - "$dir" |'.
To verify, run 'bash -n scripts/deploy-lab.sh', then source the helper and run 'tar_create -czf /dev/null workloads/sgemm'. On GNU tar 1.35 it should exit 0.
No page text changes are needed beyond the Test drive wording in td-reproduce.


Verifier note: Reproduced here with GNU tar 1.35: 'COPYFILE_DISABLE=1 tar --no-xattrs --no-mac-metadata -czf - d' fails with 'unrecognized option --no-mac-metadata' and exits 64; plain tar works. The helper in scripts/deploy-lab-gpsdk.sh lines 24–31 is correct. deploy-lab.sh is referenced by the Test drive, the sparse page, getting-started line 327 and exactly six workloads READMEs (nocbench, onchip, enercat, sgemm, sparsity, memhier). One small slip: the tar pipe is on line 17 of scripts/deploy-lab.sh, not line 16 (line 16 is blank), so match on the text, not the line number.


#### td-reproduce — MODIFIED [reproducibility/medium] et-soc1-testdrive

Where: Reproduce (h2 id 'reproduce'): the intro sentence and the <pre> block; Makefile target run-sgemm

Files: docs/report/index.html, Makefile, workloads/sgemm/README.md

Problem: (1) The intro says 'Commands in the first two blocks run on the Mac; the last runs on a lab machine.' In fact the last block (deploy-lab.sh plus ssh) runs from the Mac and only builds and runs on the lab machine.
(2) The card command runs only '-n 1024'. The table's other three rows (n = 64 on 1 shire, n = 512 on 1 shire, n = 512 on 32 shires) and the '2–3 launches each' cannot be reproduced from the page.
(3) The simulator claim '524,359 type A warnings at n = 64' needs n = 64, one shire and -vpurf_warn. 'make run-sgemm' is hard-wired to n = 128, so no documented command reproduces it. The reproduction had to call sgemm_host directly.


APPLY (CORRECTED): Apply the Makefile change (SGEMM_N ?= 128, SGEMM_ARGS ?=, recipe as proposed) and the <pre> as proposed, with two changes. Comment the grep line '# 524,359 (150 MB log; 524,291 of them on compute shire 0, see the VPURF note)'. Use this intro: 'All commands run from a checkout of the project repository. The first two blocks use the Lima VM on the Mac (on a Linux machine with /opt/et, drop the scripts/vm prefix). The last block also runs from the checkout: it copies the sources to aifoundry3, builds them there against its /opt/et and runs each table row as its own timeout 10 process. The table is the host's “launch r: X ms, Y GFLOP/s” lines.' The deploy step depends on x-deploy-tar on Linux.

Base PROPOSAL (for "as proposed" references): Makefile: add 'SGEMM_N ?= 128' and 'SGEMM_ARGS ?=' next to SIM_PARAMS, and change the run-sgemm recipe to '... sgemm_host --sysemu -n $(SGEMM_N) --reps 1 $(SGEMM_ARGS) $(if $(SIM_PARAMS),--sim-args "$(SIM_PARAMS)")'.
Page intro becomes: 'All commands run from a checkout of the project repository on the Mac (or any machine that can ssh to the lab). The last block copies the sources to aifoundry3, builds them there against its /opt/et and runs each size as its own timeout 10 process. Keep the output: the table is the host's “launch r: X ms, Y GFLOP/s” lines.'
The <pre> becomes:
# one-time: Lima VM + toolchain + et-platform (~15 min)
scripts/create-vm.sh

# simulator, on the laptop
scripts/vm make run-hello        # 2048-hart check-in
scripts/vm make run-sgemm        # SGEMM n=128 on sys_emu
scripts/vm make run-sgemm SGEMM_N=64 SGEMM_ARGS='--shires 0x1' SIM_PARAMS=-vpurf_warn
grep -c 'VPURF workaround required for type A' build/sgemm/run/sysemu.log   # 524,359

# real card: copy sources, build on aifoundry3, run each table row with a hard cap
scripts/deploy-lab.sh aifoundry3 workloads/sgemm
ssh aifoundry3 'cd ~/nekko/build/sgemm && for a in "-n 64 --shires 0x1" "-n 512 --shires 0x1" "-n 512" "-n 1024"; do timeout 10 host/sgemm_host $a --reps 3; done'


Verifier note: All three problems are real. Makefile line 72 hard-codes -n 128, and the page gives only '-n 1024' for the card. I re-ran the reviewer's simulator command locally: sgemm_host --sysemu -n 64 --shires 0x1 --reps 1 --sim-args -vpurf_warn gave PASS in 38 s, and grep -c 'VPURF workaround required for type A' sysemu.log returned exactly 524,359. The log is written to <run dir>/sysemu.log, so build/sgemm/run/sysemu.log is the right path. The sgemm_host flags (-n, --shires, --reps, default reps 3) are as described. Two problems with the proposal. (a) The new intro says every command runs 'on the Mac (or any machine that can ssh to the lab)', but scripts/create-vm.sh and scripts/vm need Lima/brew and are macOS-only. (b) The n=64 -vpurf_warn run writes a 151 MB log, and the reader should be told.


#### mm-redundancy-a100 — MODIFIED [redundancy/medium] et-soc1-matmul-efficiency

Where: The 'Later measurements' box (3 paragraphs), the caption of 'Energy efficiency against the A100', the A100 reference table note, 'How the benchmark works' → 'Inputs and checking', and Caveats bullet 1

Files: docs/reports/2026-09-18-et-soc1-matmul-efficiency.html

Problem: The operand caveat and the A100 comparison are stated five times.
- The lede gives 3.4× and 'about 2.9× in a later random-data measurement'.
- The box has three paragraphs: the Horace wattages, 144/301 GFLOP/s per W, then the 5.4×/2.6× framing.
- The chart caption gives 'One measured A100 run lands on the same ratio: Horace He's 8192³ bf16 matmul on random data ran at 257 TFLOPS under a 330 W power limit, 779 GFLOP/s per W against the spec sheet's 780.'
- Caveat 1 repeats Horace He's run and adds 'Like for like on random data, this card's fp16 TensorFMA costs 3.3 pJ per FLOP … against the A100's 1.3 pJ in bf16, 2.6×, close to the 2.4× above.', which is the box's 2.6× again.
- 'Inputs and checking' ends 'Small powers of two keep the multipliers' mantissa bits at zero, so these operands draw less power than random data would.', which repeats the box's opening.
The PCIe 250 W per-watt figures are drawn as chart bars and listed again in the table note: 'On the 250 W PCIe 40 GB card the A100's per-watt figures are 1.6× higher: 78, 624, 1,248 and 2,496.'


APPLY (CORRECTED): Use the merged paragraph, with these changes. Keep '38 W on zeros, 47 W on ones, 51–53 W with only the signs or only the exponents random (these operands have both), 63 W on random-normal values'. Say the random-data figures come from 'a variant of this loop with both operands in the L1 scratchpad (546 cycles per op rather than 529), on random-normal data at 80 °C'. Keep one clause in the A100 table note: 'The 250 W PCIe 40 GB card's ratios are 1.6× higher (fp32 CUDA cores 78 GFLOP/s per W, so ET's lead there is 2.2×).' Items 2, 3 and 4 as proposed; in item 4 you may leave a pointer instead of deleting outright: '(low-power operands; see Later measurements)'.

Base PROPOSAL (for "as proposed" references): 1. Replace the whole box with one paragraph that states the D4 framing once: '<p><b>Later measurements.</b> These ±1/±2 operands have all-zero mantissas, which draw little power: on the same TensorFMA at 80 °C the card draws 38 W on zeros, 47 W on ones and 63 W on random-normal values (<a href='https://spacesheep.dev/@yaroslavvb/et-soc1-horace-experiment'>the Horace experiment</a>). On random data, with both operands in the L1 scratchpad (546 cycles per op rather than 529), fp32 gives 144 GFLOP/s per W and fp16 301 (<a href='https://spacesheep.dev/@yaroslavvb/et-soc1-energy-manual#the-tensor-unit-per-multiply-add'>energy manual §3.2</a>). So the A100's bf16 tensor cores (Horace He's measured 779 GFLOP/s per W) are 5.4× more efficient per FLOP than this card's fp32 and 2.6× more than its fp16 (<a href='https://spacesheep.dev/@yaroslavvb/et-soc1-why-low-power'>Why is the ET-SoC-1 low power?</a>); against the A100's fp32 CUDA-core datasheet figure (19.5 TFLOPS at 400 W) this card is about 2.9× better on random data and 3.4× on these operands.</p>'
2. Delete the caption sentence 'One measured A100 run lands on the same ratio: … against the spec sheet's 780.'
3. Caveat 1 becomes: '<b>The A100 figures are spec-sheet numbers, not measurements.</b> The one measured A100 matmul (Horace He: bf16 on random data, 257 TFLOPS under a 330 W limit) matches peak ÷ TDP, so the tensor-core ratios are a fair estimate; no A100 fp32 CUDA-core GEMM was measured.'
4. Delete the last sentence of 'Inputs and checking'.
5. Delete the PCIe sentence from the A100 table note. The chart keeps the PCIe bars, or the PCIe toggle in mm-viz-explorer.
Keep the lede as the summary.


Verifier note: The repetition is real, and the merged paragraph's arithmetic checks out: 779/143.6 = 5.4, 779/300.6 = 2.6, 143.6/48.75 = 2.95, 168.1/48.75 = 3.45, matching D4. Three losses would hurt. (1) The proposal drops the '51–53 W when only the signs or only the exponents are random' data point, which is the one that matches this page's ±1/±2 operands (random sign and random exponent, zero mantissa). (2) The paragraph attributes the whole 168 → 144 to the operands, but the random figure is also a different kernel (both operands in the L1 scratchpad) on a hotter die: idle is 36.3 W at 80 °C in manual.json against 30.6 W at 71 °C here. The current box names both the operands and '71–77 °C'. (3) Deleting the PCIe sentence removes the only statement that the fp32 advantage drops to 2.16× against the 250 W PCIe card, and the tf32 PCIe figure (624), which the chart does not draw.


#### mm-redundancy-setup — MODIFIED [redundancy/low] et-soc1-matmul-efficiency

Where: 'Setup notes (for running it yourself)' items 1, 3, 5 (second sub-bullet) and 6; the hello-world lines of Reproduce; the Versions line; the hub's Matmul row

Files: docs/reports/2026-09-18-et-soc1-matmul-efficiency.html, docs/reports/sources/limits-of-observability.data.json, docs/getting-started.md

Problem: The setup notes repeat what the Test drive covers, and they add lab-internal history.
- Item 1 ('I logged in over Tailscale SSH … Firmware is BL 0.20 and minion 0.23.') is lab-access history.
- Item 3 ('3/3 tests pass on the simulator in 110 s, about 34 s per test … 0.6 s') repeats the Test drive's hello worlds. The two pages give different simulator timings (110 s for 3 tests here on aifoundry2; 'about 40 s' per run on the Mac there) and neither names the machine.
- Sub-bullet 5.2 repeats Test drive fix 2 (GenericLauncher boots sys_emu without firmware).
- The Versions line is a changelog ('… the setup notes moved after the method; and the page links the reports that followed.').


APPLY (CORRECTED): Delete item 1. Move the account-creation sentence to docs/lab-access.md next to line 61, and append the hardware facts to item 2 as proposed. Item 3 becomes: 'Hello world: et-platform's it_test_code_loading --mode=pcie passes 3/3 on the card in 0.6 s (the simulator runs are in Test drive).' Merge that into item 4 if you want. Sub-bullet 5.2, item 6 → 'Code.', and the Versions line as proposed. In Reproduce, keep one card line, 'timeout 10 /opt/et/bin/it_test_code_loading --mode=pcie   # the card', and replace the simulator line with '# simulator hello worlds: see Test drive'. Leave the hub row's 'also the first hello world' alone, or ask the hub group to write 'also the first hello world on a card'.

Base PROPOSAL (for "as proposed" references): - Delete item 1. Move its account-creation text to docs/getting-started.md's lab-access section. Append its hardware facts to item 2 as: 'aifoundry2 is x86-64 Ubuntu 24.04 with one card (PCIe Gen4, 32 GB, minion shires at 600 MHz, NoC at 400 MHz, firmware BL 0.20 / minion 0.23).'
- Delete item 3.
- Sub-bullet 5.2 becomes: 'gp-sdk's GenericLauncher boots sys_emu without the firmware images (<a href='https://spacesheep.dev/@yaroslavvb/et-soc1-testdrive#gp-sdk-launchers-can-t-boot-the-simulator'>Test drive, fix 2</a>); patches/et-platform-0002 preloads them.'
- Move item 6 ('Wrote the benchmark …') into 'How the benchmark works' as its first bullet, headed '<b>Code.</b>'.
- In Reproduce, replace the three hello-world lines with '# hello worlds: see Test drive'.
- Versions line becomes 'Versions: published 18 September 2026; revised 24 September 2026 (per-workload idle, operand and A100 context, corrections).' Move it to the end of 'How the benchmark works' (convention C2).
- Hub, docs/reports/sources/limits-of-observability.data.json, Matmul efficiency row 'what': replace '…a spec-sheet comparison with the A100; also the first hello world.' with '…a spec-sheet comparison with the A100.' Replace '(The scalar SGEMM is in Test drive.)' with '(The scalar SGEMM and the first hello worlds are in Test drive.)'.


Verifier note: The simulator hello-world timing and GenericLauncher sub-bullet do repeat the Test drive. But item 3's second sentence ('The same binary with --mode=pcie passes 3/3 on the card in 0.6 s') and item 4 (et-testdrive's hello on shire 0 of the card) are card hello worlds, and they appear only on this page. The Test drive's hello worlds are all on sys_emu (td.txt lines 50–53, and the hub row says 'hello worlds on the sys_emu simulator'). So deleting item 3 whole loses information. The proposed hub text '(The scalar SGEMM and the first hello worlds are in Test drive.)' would misattribute the first card hello world, and that file belongs to the hub group anyway. The Tailscale 'user must exist on the machine' tip complements docs/lab-access.md line 61 ('policy does not permit'), so it belongs there, not in getting-started.


#### mm-reorganize — MODIFIED [reorganize/low] et-soc1-matmul-efficiency

Where: Section order after the Contents list

Files: docs/reports/2026-09-18-et-soc1-matmul-efficiency.html

Problem: The A100 reference table (h3 under Results) sits two sections away from the A100 chart it quantifies. The board-power trace comes before the Results table whose power columns it explains. The setup notes form a separate h2 between Next steps and Reproduce, though they are instructions for reproducing.


APPLY (CORRECTED): Use the proposed order and ids. Also change 'the DRAM-streaming row above' to 'the DRAM-streaming row in Results below'. Rebuild the Contents list by hand. Make sure the section-anchor script leaves an explicit id='setup-notes-for-running-it-yourself' on the h3 as it is.

Base PROPOSAL (for "as proposed" references): New order, keeping every id:
1. 'Energy efficiency against the A100' (#energy-efficiency-against-the-a100): the chart, or the explorer in mm-viz-explorer, followed by the h3 'A100 reference (NVIDIA A100 datasheet, dense)' (#a100-reference-nvidia-a100-datasheet-dense), moved here from Results.
2. 'Results' (#results): the throughput table and its note.
3. 'Board power during the benchmark' (#board-power-during-the-benchmark).
4. 'How the benchmark works' (#how-the-benchmark-works), now opening with the 'Code.' bullet and ending with the Versions line.
5. 'Caveats' (#caveats).
6. 'Next steps' (#next-steps).
7. 'Reproduce' (#reproduce), with the trimmed setup notes as an h3 'Running it on a lab machine' carrying id='setup-notes-for-running-it-yourself'.
8. 'Related reports' (#related).
Update the Contents list to match.


Verifier note: The order is as described, and grep finds no inbound fragment links to this page (only et-soc1-sparse-compute#layer is linked anywhere). The new order is sensible. One piece of text would break: the A100 table note ends 'That gap is what the DRAM-streaming row above measures.' Once the table moves ahead of Results, that row is below it.


#### mm-sample-rate — CONFIRMED [claim/low] et-soc1-matmul-efficiency

Where: Caption of 'Board power during the benchmark'; 'How the benchmark works' → Power bullet; the Reproduce note ('roughly 35 power samples'); docs/getting-started.md line 241

Files: docs/reports/2026-09-18-et-soc1-matmul-efficiency.html, docs/getting-started.md

Problem: The page says board power was read 'about 7 times a second' and 'about 7 samples/s'. The committed power.csv was polled 8.25 times a second, and the reading itself changes about 7.0 times a second (one service-processor pass is about 133 ms). scripts/mmbench-power.py's docstring says 'about 8 times a second'. The sparse page and D2 use the poll-rate-plus-pass wording.


APPLY (PROPOSAL): - Caption: 'Card power read from the service processor about 7 times a second.' → 'Board power polled from the service processor about 8 times a second (the reading itself changes once per service-processor pass, about every 133 ms).'
- Power bullet: 'about 7 samples/s' → 'polled about 8 times a second, a new reading about every 133 ms'.
- Reproduce note: 'which still leaves roughly 35 power samples per workload after the settle time' → 'which still leaves about 40 samples (about 35 distinct readings) per workload after the settle time'.
- docs/getting-started.md line 241: 'about 7 times a second' → 'about 8 times a second (a new reading about every 133 ms)'.


Verifier note: From power.csv: 645 samples (not 646; the header is not a sample) over 78.1 s, so the poll rate is 8.25/s. The median gap is 116 ms, and there are 550 value changes (7.04/s). scripts/mmbench-power.py line 10 says 'about 8 times a second', and getting-started.md line 241 says 'about 7'. With the new 6 s default minus the 1 s settle, that is about 41 polls and about 35 distinct readings, so the proposed wording is right.


#### mm-spread — CONFIRMED [claim/low] et-soc1-matmul-efficiency

Where: The Results table note, last sentence

Files: docs/reports/2026-09-18-et-soc1-matmul-efficiency.html

Problem: 'Launch-to-launch spread was below 0.03%.' holds only for the three L2 workloads. The DRAM run's launches spread 0.34%.


APPLY (PROPOSAL): Replace with: 'Launch-to-launch spread was below 0.03% in the L2 runs and 0.34% in the DRAM run.'


Verifier note: Recomputed from runs.jsonl as (max−min)/mean of total_flop/wall_s: fp32 0.014%, fp16 0.023%, int8 0.006%, fp32-DRAM 0.337%. The note's 'below 0.03%' is wrong for the DRAM run.


#### mm-int8-random — MODIFIED [consistency/low] et-soc1-matmul-efficiency

Where: The 'Later measurements' box (random-data efficiencies), read with the lede's 'At fp16 and int8 the A100's tensor cores win on efficiency (2.4× and 1.3×)'

Files: docs/reports/2026-09-18-et-soc1-matmul-efficiency.html

Problem: The box says 'These operands favour low power' and gives random-data efficiencies for fp32 (144) and fp16 (301) only. A reader will assume int8 also gets worse on random data. The energy manual's int8 row goes the other way: random-normal int8 on the same card at 80 °C, in the L1-scratchpad variant (318 cycles per op), runs 63.1 TOP/s at 46.3 W. That is 1,362 GOP/s per W, above this page's 1,162. The gap to the A100's int8 spec narrows from 1.34× to 1.15×. In this loop int8 draws 27.9 W above the idle before it; the energy-manual variant draws 10.0 W. The difference is mostly the kernel, not the operands, and the page does not say so.


APPLY (CORRECTED): Append one sentence to the merged box: 'In int8 the energy manual's variant is more efficient than this loop even on random data: 1,360 GOP/s per W (63.1 TOP/s at 46.3 W, 80 °C), which narrows the A100 int8 spec's lead from 1.34× to 1.15×. The difference is the kernel, not the operands. This loop streams both tiles from L2 at 280 cycles per op (7.3 B per minion-cycle, roughly 11 W at 2.5 pJ/B, an estimate), while that one keeps them in the L1 scratchpad (318 cycles per op).'

Base PROPOSAL (for "as proposed" references): Append to the box (after the fp16 figure in the merged paragraph of mm-redundancy-a100): 'For int8 the energy manual's variant is more efficient than this loop: 1,360 GOP/s per W on random data (63.1 TOP/s at 46.3 W), against the A100 int8 spec's 1,560, a gap of 1.15× rather than 1.34×. It is a different kernel (both operands in the L1 scratchpad, 318 cycles per op), so there the kernel matters more than the operands.'


Verifier note: The numbers check. manual.json int8_randn (aifoundry2, the same card): 3.1535e13 MAC/s = 63.1 TOP/s; idle 36.31 W + 9.98 W = 46.3 W; 2000/1.468 = 1,362 GOP/s per W. 1560/1162 = 1.34 and 1560/1362 = 1.15. This loop draws 61.75 − 33.83 = 27.9 W above idle. The 'kernel, not operands' inference holds: ±1/±2 operands are cheaper than random-normal (int8_ones draws 4.2 W over idle in the manual), yet this loop draws almost 3× more. The page can also say why instead of just asserting it. Ridge points reports that this int8 loop pulls 7.3 B per minion-cycle from L2; at D7's 2.5 pJ/B that is about 11 W, a derived estimate.


#### mm-clock-dram — CONFIRMED [consistency/low] et-soc1-matmul-efficiency

Where: Caveats 'One clock point'; 'How the benchmark works' → Working set

Files: docs/reports/2026-09-18-et-soc1-matmul-efficiency.html

Problem: (1) The clock caveat gives only the temperature condition ('steps the clock down whenever the die reads above 65 °C'). D1 adds 'or board power is above 65 W'.
(2) The Working-set bullet says 'Effective read bandwidth there was about 78 GB/s', and the A100 table note says 'the 76 GB/s this card streams'. Nothing on the page reconciles the two DRAM figures.


APPLY (PROPOSAL): (1) Replace 'aifoundry2's governor steps the clock down whenever the die reads above 65 °C, and raises it to 700 or 800 MHz (0.57 or 0.62 V) only while the die reads 65 °C or less' with 'aifoundry2's governor steps the clock down whenever the die reads above 65 °C or board power exceeds 65 W, and raises it to 700 or 800 MHz (0.57 or 0.62 V) only below both'.
(2) Replace 'Effective read bandwidth there was about 78 GB/s.' with 'Effective read bandwidth there was about 78 GB/s (2 KB per op), in line with the 76 GB/s the memory-hierarchy probe streams.'


Verifier note: D1 names both triggers: a die reading above 65 °C or board power above 65 W. The caveat names only temperature. DRAM run: 0.3103e12/8192 FLOP per op × 2,048 B per op = 77.6 GB/s, against D8's 76 GB/s. The page states both figures and never connects them.


#### mm-reproduce — CONFIRMED [reproducibility/low] et-soc1-matmul-efficiency

Where: The Reproduce <pre> block and 'Raw data' note; 'How the benchmark works' → Power bullet; scripts/mmbench-power.py summary (lines 145 and 177)

Files: docs/reports/2026-09-18-et-soc1-matmul-efficiency.html, scripts/mmbench-power.py

Problem: (1) The page's own numbers come from 'python3 scripts/mmbench-report-data.py DATA --embed HTML', which reproduces the page byte for byte, but the page describes this only in prose. The Reproduce block shows only the card commands.
(2) No block shows the no-card check. 'make mmbench-check' on sys_emu passed exact in all four modes in the reproduction.
(3) The block has no step that copies the output back into docs/reports/data.
(4) results.json does not store the idle windows, so the reproduction had to infer where the 30.61 W median came from. The page says 'the median over the 8 s before the first workload', but the code skips the first second (t_idle0 + 1000 ≤ t ≤ t_idle1, 53 samples).


APPLY (PROPOSAL): Replace the <pre> with:
# regenerate this page's numbers and power chart from the committed data (no card)
python3 scripts/mmbench-report-data.py docs/reports/data/2026-09-18-aifoundry2 \
    --embed docs/reports/2026-09-18-et-soc1-matmul-efficiency.html

# exact checks of every mode on the simulator, one shire, no card (about 40 s each)
scripts/vm make mmbench-check          # laptop VM; on a lab machine: cd ~/nekko && make mmbench-check

# on the card: copy the repository to the lab machine, build gp-sdk (pinned, patched) and mmbench there
scripts/deploy-lab-gpsdk.sh aifoundry2
# then on aifoundry2 (quit et-powertop first: the power logger needs the management node)
cd ~/nekko && nice make mmbench-check bench-power DEVICE=silicon JOBS=4
# copy ~/nekko/build/mmbench-power/ into a new dated docs/reports/data/ directory

Power bullet: 'The idle row is the median over the 8 s before the first workload' → 'The idle row is the median of the last 7 s of the 8 s idle before the first workload'.
scripts/mmbench-power.py: add 'idle_window_ms': [t_idle0 + 1000, t_idle1] to the summary dict. Add 'idle_before_window_ms': [t_first − 3500, t_first − 1800] to each results entry.


Verifier note: I re-ran 'scripts/mmbench-report-data.py docs/reports/data/2026-09-18-aifoundry2 --embed <copy>' and the copy is byte-identical to the published HTML. The reviewer's mmbench-check on sys_emu passed exact in all four modes (msd/mmbench-sim/out.txt), and the Makefile comment gives 'about 40 s each'. mmbench-power.py line 145 uses t_idle0 + 1000 ≤ t ≤ t_idle1, so the idle row is the median of the last 7 s of the 8 s idle, not 'the 8 s'. results.json stores no windows. Adding the window fields to the summary is harmless.


#### mm-viz-explorer — MODIFIED [visualization/medium] et-soc1-matmul-efficiency

Where: 'Energy efficiency against the A100' (#eff, #eff-panels), replacing the three bar panels

Files: docs/reports/2026-09-18-et-soc1-matmul-efficiency.html, scripts/mmbench-report-data.py, docs/reports/data/2026-09-18-aifoundry2/results.json, docs/reports/data/2026-09-23-energy-manual/manual.json

Problem: The existing chart is clearly labelled and keyboard-focusable. But each of its three panels has its own scale, so bar lengths cannot be compared across precisions: 168 and 1,162 draw about the same length. It shows only the ±1/±2 operands and the spec-sheet A100. It cannot show the random-data figures or the measured A100 bf16 run that the page's two verdicts rest on (3.4× better against CUDA cores; 5.4× worse against tensor cores). Readers must reconcile those in prose.


APPLY (CORRECTED): Build it as specified, with these changes. Draw the 780 spec and 779 measured points as one A100 fp16/bf16 marker whose tooltip gives both. On the fp32 row, label the measured point 'A100 bf16 tensor cores (measured; lower precision)'. Word the second toggle's delta as 'this variant (random data, operands in L1, 80 °C)' and never as 'random data costs'. Keep the one-clause PCIe note in static text (see mm-redundancy-a100). Keep a no-JS fallback: the A100 table stays.

Base PROPOSAL (for "as proposed" references): An 'efficiency explorer'. It answers: is this card more efficient than an A100, and against which A100 unit and on which data?

Encoding: one inline SVG with a shared log x-axis, 'GFLOP/s (GOP/s) per W, board', from 5 to 3,000 with ticks at 10, 30, 100, 300, 1,000 and 3,000. There are three rows: fp32, fp16→fp32 and int8→int32. ET markers are filled circles in var(--c1); A100 markers are open diamonds in var(--ref) with short labels. On a log axis equal ratios are equal distances, so 3.4× looks the same in every row.

Data:
- ET, this run: docs/reports/data/2026-09-18-aifoundry2/results.json results[].{workload, tflops, mean_w, gflops_per_w} (168.1, 320.9, 1,162.5).
- ET, random normal: docs/reports/data/2026-09-23-energy-manual/manual.json tensor.rows[config in fp32_randn, fp16_randn, int8_randn].{per_s, pj_loaded, idle_w, cycles_per_op}. GFLOP/s per W = 2000/pj_loaded, giving 143.6, 300.6 and 1,362.6.
- A100: the constants of the page's A100 table (19.5, 156, 312 and 624 TFLOP/s; 400 W SXM4, 250 W PCIe), plus Horace He's measured bf16 run (257 TFLOPS / 330 W = 779). The measured point sits on the fp16 row and, as D4's tensor-core comparator, on the fp32 row.
- Embed: extend scripts/mmbench-report-data.py with '--manual PATH'. It writes an 'eff' object (both ET series plus provenance strings) into the #trace-data JSON, so no number is hand-typed.

Interactions:
- Two toggle buttons (aria-pressed): 'ET: ±1/±2 operands, B streamed from L2, 71–77 °C (this run)' and 'ET: random normal, operands in L1, 80 °C (energy manual §3.2)'. The ET markers animate between the two.
- A comparator picker. Tab to an A100 marker and press Enter, or click it. Each row's readout then recomputes, e.g. 'ET ÷ A100 fp32 CUDA cores = 3.45×' or 'A100 bf16 (measured) ÷ ET fp32 = 5.4×'.
- A checkbox 'A100 PCIe 250 W instead of SXM4 400 W'.
- Hover or focus on any marker shows throughput, watts and source (e.g. '9.51 TFLOP/s at 56.6 W, results.json').

Phone (390 px): rows stack, the axis spans the 358 px frame, labels alternate above and below markers, and the readouts sit under each row as text. Controls are native buttons and a checkbox, so the chart is keyboard-usable.

Colour tokens: the page defines only --accent and --ref. Add the template's --c1…--c5 and --c7 to :root and both dark blocks (--c1: var(--accent); the others use the template's values) and use var(--ink) and var(--grid) for the axis.

This replaces #eff-panels and the PCIe sentence of the A100 table note; the A100 table stays for exact values. The reader sees that the two published verdicts are one dataset against two A100 units, that random data costs this card 15% in fp32 and 6% in fp16, and that int8 depends on the kernel variant.


Verifier note: The data exists: results.json, and manual.json tensor.rows (aifoundry2, the same card): 2000/pj_loaded = 143.6, 300.6 and 1,362.6. A shared log axis that shows both A100 verdicts is a real improvement. Problems in the spec: (1) On the fp16 row the A100 SXM4 spec point (780) and Horace He's measured bf16 point (779) coincide, so two markers stack exactly on top of each other. (2) Putting the bf16 measured point on the fp32 row crosses precisions; it needs an explicit label. (3) The stated takeaway 'random data costs this card 15% in fp32 and 6% in fp16' is confounded. The toggle changes the operands, the kernel (529 vs 546 cycles, B from L2 vs L1) and the die temperature (idle 30.6 W at 71 °C vs 36.3 W at 80 °C) together. (4) With the chart replaced, the PCIe values would live only behind a checkbox.


#### mm-viz-idle — MODIFIED [visualization/low] et-soc1-matmul-efficiency

Where: 'Board power during the benchmark' (#trace), complementing the existing trace

Files: docs/reports/2026-09-18-et-soc1-matmul-efficiency.html, scripts/mmbench-report-data.py

Problem: The trace is honest (y from 0) and labelled. But it draws one idle line at 30.6 W, while the Results table subtracts four different idles (30.6, 32.5, 33.8, 35.2 W). The window behind each idle ('the mean from 3.5 to 1.8 s before its first timed launch') and the 1 s settle skipped at the start of each workload exist only in prose. Hover responds to the pointer only.


APPLY (CORRECTED): Build it as proposed (radio group, shaded idle and averaging windows, dashed idle and mean lines, readout), but keep the four idle values in the Results note. Only shorten the window description to '(the idle windows are shaded on the power chart)'.

Base PROPOSAL (for "as proposed" references): An idle-window explainer. It answers: what does 'per W above idle' subtract, and why does idle rise from one workload to the next?

Data: the page's #trace-data (trace [t, W]; windows[].{workload, start, end}). Extend scripts/mmbench-report-data.py so each windows[] entry also carries idle_before_w (30.61, 32.53, 33.83, 35.16), idle_t0 and idle_t1 (first timed launch − 3.5 s and − 1.8 s, seconds from trace start), settle_end (start + 1.0), mean_w (56.57, 59.27, 61.75, 43.35) and tflops (9.511, 19.019, 71.784, 0.310). All of these values are already computed there.

Interaction:
- A four-button radio group (fp32, fp16, int8, DRAM), also driven by ←/→ keys.
- Selecting a workload shades its idle window in var(--c2) at 25% opacity and its averaging window (settle_end to end) in var(--c1) at 12%.
- Dashed horizontal lines mark idle_before_w and mean_w.
- A readout states the arithmetic: 'fp32: 9.51 TFLOP/s ÷ 56.57 W = 168 GFLOP/s per W on the board; ÷ (56.57 − 30.61) W = 366 above the idle just before it.'
- The single 30.6 W idle line becomes four short idle steps, one per gap.

Phone: the trace already fits 390 px; the buttons and readout sit below it.

This lets the Results note drop the parenthesis '(30.6, 32.5, 33.8 and 35.2 W, the mean from 3.5 to 1.8 s before its first timed launch)' in favour of '(shown on the power chart)'. The reader sees that the rising idle is leakage from a warming die, which is the reason the above-idle column uses per-workload baselines.


Verifier note: The data is right. mmbench-report-data.py prints idle before = 30.61, 32.53, 33.83 and 35.16 W, mean_w and tflops, and the fp16 idle window is not clipped by the previous workload (22.68 s > 20.77 + 1 s). The readout arithmetic checks: 9510.8/25.96 = 366. But dropping the four idle values from the Results note in favour of '(shown on the power chart)' would make the above-idle column impossible to check without JS or hover, or on paper. Low priority next to the explorer.


#### sp-redundancy-summaries — MODIFIED [redundancy/medium] et-soc1-sparse-compute

Where: 'Answers to the questions this work started from' (#answers); Caveats bullets 3 and 7; 'Where the A100 wins' bullet 3; the Reproduce note; the Sources 'Companion reports' item

Files: docs/reports/2026-09-18-et-soc1-sparsity.html

Problem: The headline results are restated four or five times.
- 86% / 80–92% appears in the Later box, the KPI, §1, Answers and Caveats bullet 3.
- '90% zeros … about 12%' appears in §3, Answers and Caveats bullet 3.
- Caveat 7 ('All divergence runs draw work from one global atomic counter … may be partly the queue's.') repeats the §4 paragraph 'What limits the loop …'.
- 'Where the A100 wins' bullet 3 restates §4 ('Narrow lanes give 1.6–2.8× better lane efficiency, but a modelled A100 kernel at its full 9.75 T FMA/s stays ahead. That peak is 2× ET's 8-lane peak at 600 MHz, and this ET loop reaches under a fifth of its own.').
- The Reproduce note repeats the data README's 'Superseded data' section ('diverge-v1/ holds an earlier divergence sweep … whose 256 KB buffer stayed in L2.').
- Sources 'Companion reports: ET-SoC-1 on-chip communication (…), memory hierarchy (…), matmul efficiency (9.51 TFLOP/s fp32).' duplicates Related reports.
- The Answers item on point-to-point messaging restates the on-chip communication page's 'A trap: one ready flag per minion' at length.


APPLY (CORRECTED): Keep the <ul>. Shorten each item to the reviewer's answer text, with its links inline, for example '<b>Does zero-skip save cycles or only energy?</b> Only energy: 80–92% of a TensorFMA loop's power above idle, about 12% in the batch-1 layer (<a href='#zeros'>§1</a>, <a href='#layer'>§3</a>).' Make steps 2–5 as proposed.

Base PROPOSAL (for "as proposed" references): 1. Keep h2 id='answers' and its intro sentence. Replace the <ul> with a three-column table (Question | Answer | Where), one row per question:
- 'Does zero-skip save cycles or only energy?' | 'Only energy: 80–92% of a TensorFMA loop's power above idle, about 12% in the batch-1 layer. tensor_mask on TensorFMA behaves the same.' | links #zeros, #layer
- 'Is the manual's fp16 skip rule right?' | 'No; the silicon computes the correct sum.' | #zeros
- 'Do inactive neurons cost neither bandwidth nor FMAs?' | 'No bandwidth for SRAM-resident weights; a zero still spends its TensorFMA cycles unless its whole 16-element slice is skipped.' | #masked-loads, #layer
- 'Can a step afford its synchronisation?' | 'Within 10 µs only through the hardware tree (2.3 µs for 32 B, 5.4 µs for 1 KB; 8.3 µs for a barrier from atomics); an all-gather was not measured.' | On-chip communication #reduction-trees
- 'Does point-to-point messaging work across shires?' | 'Yes, with one ready flag per minion: change partners only after a barrier.' | On-chip communication #a-trap-one-ready-flag-per-minion
- 'How close does it get to peak?' | 'A vector-FMA loop reaches 0.9 of 4.9 T FMA/s; the tensor unit 9.2 TFLOP/s here, 9.5 in the matmul report.' | #divergence, Matmul efficiency
2. Delete Caveats bullets 3 and 7.
3. 'Where the A100 wins' bullet 3 becomes: '<b>Divergence in run length alone</b> (<a href='#divergence'>§4</a>): narrow lanes help, but not enough.'
4. In the Reproduce note, delete from 'diverge-v1/ holds an earlier divergence sweep' to the end of the paragraph. '(its README lists what each file is)' already covers it.
5. Delete the Sources item beginning 'Companion reports:'.


Verifier note: The repetition is confirmed. 86% / 80–92% appears in the Later box, the KPI, §1, Answers and Caveat 3. The Caveat 7 queue text repeats §4. The Reproduce note's v1 and diverge-v1 text matches the data README's 'Superseded data' section. The Sources 'Companion reports' item duplicates Related reports, which already lists all three pages. The fix is wrong on one point: a 3-column Question | Answer | Where table with sentence-length answers is cramped at 390 px, and this page's existing wide table already fails there (sp-charts-existing d). The answers' content is fine. Moving 'how close to peak' to 4.9 T FMA/s (1,024 × 8 × 0.6 GHz) is a better comparison.


#### sp-redundancy-scenarios — MODIFIED [redundancy/low] et-soc1-sparse-compute

Where: §3 last paragraph; §5 scenario 1 'ET-SoC-1 estimate'; scenario 2 'Published baseline' and 'ET-SoC-1 estimate'

Files: docs/reports/2026-09-18-et-soc1-sparsity.html

Problem: The sync costs (2.3 µs for 32 B and 5.4 µs for 1 KB allreduce; the 8.3 µs barrier) are stated in §3, in the §5 intro, again in scenario 1, and in Answers. Their canonical home is the on-chip communication page, and the §5 intro paragraph already summarises them for the scenarios. Scenario 2 restates §3's measurements verbatim: 'Measured: 7.5 µs dense (7.3 µs with plain loads) → 2.1 µs at 99% for a 1024×4096 fp32 layer; 251 → 74 µJ per layer for the whole board (host-reduced kernel, 7.4 → 2.7 µs per layer including the barrier).'


APPLY (CORRECTED): Add the 1 KB figure to the §5 intro: 'A 1,024-minion allreduce takes 2.3 µs for 32 B and 5.4 µs for 1 KB, …'. Then shorten §3 and scenario 1 as proposed, and shorten scenario 2's 'ET-SoC-1 estimate' to 'Measured in §3: 7.5 → 2.1 µs and 251 → 74 µJ per layer.' Keep scenario 2's 'Published baseline' text unchanged.

Base PROPOSAL (for "as proposed" references): Keep the §5 intro paragraph ('The chip's sync costs come from the on-chip communication report …') as the single statement.
- §3: '(a 1,024-minion allreduce takes 2.3 µs for 32 B and 5.4 µs for 1 KB)' → '(2.3–5.4 µs per chip-wide allreduce; <a href='#scenarios'>§5</a>)'.
- Scenario 1: '(a 32 B allreduce over all 1,024 minions takes 2.3 µs, and 1 KB takes 5.4 µs; an all-gather …' → '(2.3–5.4 µs for 32 B to 1 KB, above; an all-gather …'.
- Scenario 2 'ET-SoC-1 estimate': replace the 'Measured: …' sentence with 'Measured in <a href='#layer'>§3</a>: 7.5 → 2.1 µs and 251 → 74 µJ per layer.' Keep 'A model of ≤ 40 M fp16 parameters fits on chip …'.
- Scenario 2 'Published baseline': replace 'A100: one isolated launch plus a null kernel 3.7 µs; cuBLAS fp16 GEMM floor ~4.5 µs.' with 'A100 launch and GEMM floors: see <a href='#layer'>§3</a>.' Keep the TEAL and Deja Vu clauses.


Verifier note: The repetition is real, but the fix has two problems. (1) The §5 intro gives 2.3 µs, 8.3 µs and 0.72 µs, but not the 5.4 µs for 1 KB. After the edit, §3 points to §5 for '2.3–5.4 µs' and scenario 1 says 'above', yet the 1 KB figure would appear nowhere above. (2) The scenario cards are designed to be self-contained ('Each scenario below gives … the best published baseline'). Scenario 2 is the one measured scenario, so replacing its two baseline numbers with 'see §3' makes the card less useful to save a dozen words.


#### sp-scp-floor — CONFIRMED [claim/low] et-soc1-sparse-compute

Where: §1 hooks table, row 'tensor_mask on TensorLoad', column 'Measured on the card'

Files: docs/reports/2026-09-18-et-soc1-sparsity.html

Problem: '160 → 81 → 45 cycles for 16, 8 and 4 of 16 rows from L2 or the scratchpad'. The scratchpad's 4-row load takes 46.8 cycles, so it rounds to 47. §2's body text correctly says 'a floor of about 45–47 cycles'.


APPLY (PROPOSAL): Replace '160 → 81 → 45 cycles' with '160 → 81 → 45–47 cycles'.


Verifier note: #sparsity-data: l2-one at 4 lines is 44.9 cycles and scp-one is 46.8, so '45' applies to L2 only. §2 already says 45–47.


#### sp-percard-pj — MODIFIED [consistency/low] et-soc1-sparse-compute

Where: The 'Later measurements' note (#later), sentence 'Per multiply-add that is 0.41, 2.1 and 5.4 pJ (energy manual §3.2).'

Files: docs/reports/2026-09-18-et-soc1-sparsity.html

Problem: 0.41, 2.1 and 5.4 pJ are aifoundry3's per-card values, measured at its 56 °C launch temperature in Horace §10. The energy manual §3.2 headline figures are two-card means (0.42, 2.23, 5.78). A reader who follows the link sees different numbers.


APPLY (CORRECTED): Change the sentence to 'Per multiply-add that is 0.41, 2.1 and 5.4 pJ on this card (<a href='…#the-tensor-unit-per-multiply-add'>energy manual §3.2</a>, per-card column; the two-card means are 0.42, 2.2 and 5.8).'

Base PROPOSAL (for "as proposed" references): Replace with: 'Per multiply-add that is 0.41, 2.1 and 5.4 pJ on this card (<a href='https://spacesheep.dev/@yaroslavvb/et-soc1-energy-manual#the-tensor-unit-per-multiply-add'>energy manual §3.2</a>, whose two-card means are 0.42, 2.2 and 5.8).'


Verifier note: 0.41, 2.1 and 5.4 pJ are aifoundry3's per-card values (manual.json per_card.aifoundry3 0.411/2.109/5.415), and 1.89/9.68/24.86 W ÷ 4.59e12 MAC/s gives the same. But the linked energy manual §3.2 table does print them: its 'per card' column reads 'a3 0.411', 'a3 2.109' and 'a3 5.415' next to the two-card means. So a reader who follows the link does find them. A label is enough.


#### sp-queued-launch — CONFIRMED [consistency/low] et-soc1-sparse-compute

Where: §3 'Against the A100' paragraph and the bold conclusion that follows it

Files: docs/reports/2026-09-18-et-soc1-sparsity.html

Problem: The page says 'Kernels queued back to back in a stream cost less, about 1.5 µs each on an A100 (on-chip communication report)' and concludes, in bold, that ET 'never gets under the ~1.5 µs of a queued A100 kernel except when x is all zeros'. The cited page gives '1.5–2.3 µs each'. ET's 2.14 µs at 99% zeros lies inside that range, so the bold sentence picks the end of the range least favourable to ET.


APPLY (PROPOSAL): - 'about 1.5 µs each on an A100' → 'about 1.5–2.3 µs each on an A100'.
- The bold sentence becomes: '<b>ET-SoC-1 reaches A100-class latency on one layer. It beats a single isolated A100 launch (3.7 µs) only at 99% zeros or more, and there (2.1 µs) it only matches a queued A100 kernel (1.5–2.3 µs).</b>'


Verifier note: The on-chip communication page's primitives table says device-wide reductions 'are built from atomics or extra kernel launches (1.5–2.3 µs each)'. tree-skip is 4.00 µs at 95% zeros and 2.14 µs at 99%. So 'only at 99% zeros or more' is exact, and 2.14 µs falls inside the 1.5–2.3 range. The proposed bold sentence is accurate.


#### sp-l2-rate — MODIFIED [consistency/low] et-soc1-sparse-compute

Where: The caption under the all-1,024-minion TensorLoad table (#t-tl)

Files: docs/reports/2026-09-18-et-soc1-sparsity.html

Problem: The table's L2 row at 16 lines reads 297 cycles (2.03 TB/s), below the canonical 2.45 TB/s for L2 (D8) that the memory-hierarchy and ridge-points pages use. The table's own 8-line L2 cell is higher (2.39 TB/s). The page never explains the lower figure, although Ridge points attributes it to 'the sparsity report's shorter L2 probe'.


APPLY (CORRECTED): Append to the caption: 'At 16 lines L2 reads 2.03 TB/s here, below the 2.45 TB/s the memory-hierarchy probe reads on both cards, including this one on 23 September at a pinned 600 MHz (<a href='https://spacesheep.dev/@yaroslavvb/et-soc1-ridge-points'>Ridge points</a>). This probe is shorter (2,000 loads per minion); the cause of the gap was not isolated.'

Base PROPOSAL (for "as proposed" references): Append to the caption: 'At 16 lines L2 reads 2.03 TB/s here, below the 2.45 TB/s of the memory-hierarchy probe; this probe is shorter (2,000 loads per minion), and the same probe at a pinned 600 MHz on 23 September read 4.0 B per cycle (<a href='https://spacesheep.dev/@yaroslavvb/et-soc1-ridge-points'>Ridge points</a>, caveats).'


Verifier note: The anomaly is real: l2-all at 16 lines is 296.8 cycles, 2.03 TB/s (3.3 B per minion-cycle), against 2.39 TB/s at 8 lines and the scratchpad's 2.45. The proposed caption misstates its source, though. Ridge points' '4.00 B per cycle … on aifoundry3' is the memory-hierarchy streaming probe rerun on 23 September, not 'the same probe' as this page's. Ridge only calls this page's probe 'shorter'; it does not show that length causes the lower rate.


#### sp-reproduce — CONFIRMED [reproducibility/low] et-soc1-sparse-compute

Where: The Reproduce <pre> block

Files: docs/reports/2026-09-18-et-soc1-sparsity.html, workloads/sparsity/README.md

Problem: The block leaves out several steps, and step 1 fails on Linux (see x-deploy-tar).
- The second energy run (energy-b, the reverse --only order). Every energy figure is the mean of energy-a and energy-b.
- The step that copies build/sparsity-data back into docs/reports/data.
- The no-card check. sparsity_host --sysemu builds and passes here, and its fp16-pair classification matches the card's.


APPLY (PROPOSAL): Replace the <pre> with:
scripts/deploy-lab.sh aifoundry3 workloads/sparsity
ssh aifoundry3 'cd ~/nekko && bash workloads/sparsity/run_lab.sh build/sparsity/host/sparsity_host build/sparsity-data'
ssh aifoundry3 'cd ~/nekko && python3 workloads/sparsity/run_energy.py --host-bin build/sparsity/host/sparsity_host --out build/sparsity-data/energy-a'
ssh aifoundry3 'cd ~/nekko && python3 workloads/sparsity/run_energy.py --host-bin build/sparsity/host/sparsity_host --out build/sparsity-data/energy-b --only gemv-skip-99,gemv-skip-90,gemv-skip-0,gemv-dense-90,fma-rowmask,fma-col50,fma-zero,fma-875,fma-50,fma-dense,spin'
scp -r aifoundry3:nekko/build/sparsity-data/. docs/reports/data/DATE-sparsity-aifoundry3/
python3 workloads/sparsity/analyze.py docs/reports/data/2026-09-18-sparsity-aifoundry3 --embed docs/reports/2026-09-18-et-soc1-sparsity.html

Add to the note after it: 'Without a card, add --sysemu to any sparsity_host command to check a kernel (the simulator's cycle counts mean nothing), e.g. build/sparsity/host/sparsity_host --sysemu --test fma --type fp16 --pattern pair --sweep 0,0.5,1 --shires 0x1 --per-shire 1.'


Verifier note: The energy-b --only list matches the data README exactly, and run_energy.py accepts --host-bin, --out and --only. I re-ran analyze.py --embed on a copy of the page, and it is byte-identical. I also ran the proposed no-card command locally (sparsity_host --sysemu --test fma --type fp16 --pattern pair --sweep 0,0.5,1 --shires 0x1 --per-shire 1). It finished in 36 s with ok:true on all three points and result both/math/math, and the cycle counts it prints are meaningless (11 per op), as the proposed note says.


#### sp-scripts — CONFIRMED [reproducibility/low] et-soc1-sparse-compute

Where: workloads/sparsity/run_lab.sh line 7; workloads/sparsity/analyze.py line 94 and the energy block; workloads/sparsity/run_energy.py line 40 and line 184; the renderPow() defs in the page script

Files: workloads/sparsity/run_lab.sh, workloads/sparsity/analyze.py, workloads/sparsity/run_energy.py, docs/reports/2026-09-18-et-soc1-sparsity.html

Problem: (1) run_lab.sh's header says the governor 'moves the clock between 600 and 850 MHz'. That contradicts D1 (600/700/800; never 850), and aifoundry3 never leaves 600.
(2) analyze.py prints the all-minion scratchpad 1-line load as '64c' because it rounds twice: 64.516 → 64.5, then f'{c:.0f}' applies banker's rounding. The page shows 65.
(3) run_energy.py describes fma-col50 as 'TensorFMA32, half of A's columns zero', but the drawn tile had nnz_a 80 of 256 (11 of 16 columns zero). The page script hard-codes the chart x positions (127/256, 80/256, 26/256) instead of reading nnz_a from the data.
(4) run_energy.py does not store its idle windows, so idle_w (24.59/24.745) could be reproduced only by inferring them.


APPLY (PROPOSAL): (1) run_lab.sh line 7 → '(OUTDIR/clock.csv), because the DVFS governor can move the clock (600, 700 or 800 MHz on aifoundry2; aifoundry3 stays at 600).'
(2) analyze.py line 94: format from the unrounded value (store round(r['cycles_per_load'], 1) only in the JSON and print f'{r_cycles:.1f}c'), or print with f'{c:.1f}c'.
(3) run_energy.py line 40 → 'TensorFMA32, whole columns of A zero (--pattern col --sweep 0.5)'. In analyze.py, copy nnz_a and a_elems from each config's runs.jsonl records into energy.configs[name]. In renderPow(), replace the literals 127 / 256, 80 / 256 and 26 / 256 with c.nnz_a / c.a_elems, and label the point 'zero columns (11 of 16)'.
(4) run_energy.py line 184: summary = {'idle_w': idle_w, 'idle_windows_ms': idle_windows, 'info': info, 'results': results}.


Verifier note: All four check. (1) run_lab.sh line 7 says '600 and 850 MHz', which contradicts D1. (2) Python formats round(64.516, 1) = 64.5 as '64'; the unrounded value gives '65', and analyze.py's console shows 'scp-all … 1:64c'. (3) The energy-a and energy-b fma-col50 records carry nnz_a 80 and a_elems 256 (11 of 16 columns zero), and renderPow() hard-codes 127/256, 80/256 and 26/256. (4) run_energy.py builds idle_windows (lines 108–127) but line 184 does not store them.


#### sp-charts-existing — CONFIRMED [visualization/low] et-soc1-sparse-compute

Where: All six charts (c-fma, c-pow, c-tl, c-gemv, c-lane, c-thr) and the layer table t-gemv

Files: docs/reports/2026-09-18-et-soc1-sparsity.html

Problem: The charts are labelled, legended and use honest ranges, with these exceptions:
(a) Hover works only with a pointer (pointermove/pointerdown). No chart can be reached or read from the keyboard.
(b) c-gemv spaces 0, 50, 75, 90, 95, 99 and 100% zeros evenly and does not say so, so 95 → 99% looks as wide as 0 → 50%.
(c) In c-tl the L2 and scratchpad lines coincide, so the L2 series (listed in the legend) is invisible.
(d) At 390 px the 8-column layer table scrolls sideways and shows only its row labels on first view.


APPLY (PROPOSAL): (a) In the shared chart() helper, give each chart's SVG tabindex='0'. On ArrowLeft/ArrowRight move a highlighted point through the series and call the existing tooltip function; on Escape hide it.
(b) c-gemv xTitle → 'fraction of x that is zero (uneven steps)'. The explorer in sp-viz-layer replaces it anyway.
(c) Draw the scratchpad series in c-tl with stroke-dasharray '5 3' so the L2 line shows through.
(d) Once sp-viz-layer exists, wrap t-gemv in <details><summary>All layer timings (µs) and energies</summary>.


Verifier note: The chart() helper attaches only pointermove, pointerdown and pointerleave, with no tabindex or keydown. c-gemv uses an ordinal x axis (xs.ordinal), so it spaces 0 to 100% evenly. In c-tl the L2 and scratchpad one-minion series sit within 0.3 cycles of each other except at 4 lines (44.9 vs 46.8). The 390 px screenshot sp390-c2 shows t-gemv displaying only its row labels.


#### sp-viz-layer — MODIFIED [visualization/medium] et-soc1-sparse-compute

Where: §3 'A batch-1 layer that skips zeros' (#layer), replacing c-gemv and moving t-gemv into <details>

Files: docs/reports/2026-09-18-et-soc1-sparsity.html

Problem: The page's main ML question is why sparsity makes this layer only 3.5× faster, and only near 99% zeros. That hangs on three measured mechanisms: masked loads cut rows, per-slice fixed costs plateau at 5.4 µs, and only whole empty slices are skipped (p^16). The current chart shows only latency per variant on an unevenly spaced axis. The rows-loaded and slices-computed counts are embedded but never shown.


APPLY (CORRECTED): Keep a latency-vs-zeros line chart as panel (b), with the three variants and the compute-only checkbox, and draw it on the same numeric-but-labelled axis. Draw the A100 references on it: the 6–11 µs band, the 3.7 µs line and a new 1.5–2.3 µs queued-kernel band. The slider or keys highlight the selected point on the curve and drive the 16×16 grid (a) and readout (c) as proposed. Label the energy line 'from separate runs of the compute-only kernel (own x draw)'. Move t-gemv into <details> as proposed.

Base PROPOSAL (for "as proposed" references): A 'layer explorer'. It answers: what does the kernel skip at each sparsity, and how does its latency compare with an A100?

Controls:
- A range input 'zeros in x' with 7 stops (0, 50, 75, 90, 95, 99, 100%), keyboard-steppable, with its value shown.
- Three toggle buttons: 'Masked loads + skip empty slices', 'Masked loads only', 'Every row loaded'.
- A checkbox 'include the on-chip TensorReduce' (tree-* versus compute-only series).

Panels:
(a) A 16×16 cell grid: one minion's 256 inputs as 16 slices (columns) of 16 rows. round(lines_per_minion) cells are lit in var(--c1) (rows loaded). 16 − round(slices_per_minion) columns are greyed with var(--grid) hatching (slices skipped). The caption reads 'a representative minion drawn with the measured means' because the positions are illustrative and the counts are measured.
(b) A latency number line from 0 to 12 µs. The ET marker (var(--c1)) sits at the selected series' µs. The A100 references are drawn in var(--ref): a band at 6–11 µs 'A100 dense layer (estimate)', a tick at 3.7 µs 'isolated launch + empty kernel (measured)' and a band at 1.5–2.3 µs 'queued A100 kernel'.
(c) A readout: 'rows loaded 26.8 of 256; slices computed 13.62 of 16; empty slices measured 14.9%, independent zeros predict 0.9¹⁶ = 18.5%'. Energy is added where measured: 0% gives 251 / 70 µJ, 90% gives 137 / 19 µJ and 99% gives 74 / 7.1 µJ (board / above idle).

Data: the page's #sparsity-data. gemv.{tree-skip, tree-masked, tree-dense, skip, masked, dense}[i] = [zero fraction, cycles, µs, slices_per_minion, lines_per_minion, ok]. energy.configs['gemv-skip-0'|'gemv-skip-90'|'gemv-skip-99'].j_per_unit.mean and .j_per_unit_above_idle.mean (×10⁶ µJ).

Plain inline SVG plus vanilla JS in the page's existing script. Colours var(--c1), var(--c2), var(--ref), var(--grid) and var(--ink); add --c1: var(--et), --c2: var(--et2), --c3: var(--et3) and the template's --c4, --c5 and --c7 to :root and both dark blocks.

Phone: 12 px cells make the grid 192 px, and the number line spans the frame. Controls wrap.

This replaces c-gemv and the phone-hostile table. Reader sees the three regimes (bytes cut, fixed per-slice cost, slice skipping only near the top) and that the measured empty-slice share tracks p¹⁶.


Verifier note: The data exists: gemv.* rows are [fraction, cycles, µs, slices_per_minion, lines_per_minion, ok], all variants, 7 levels. The readout arithmetic checks: 16 − 13.62 = 2.38 slices, 14.9% empty; 0.9¹⁶ = 18.5%. Two flaws. (1) The page's point is the three regimes: bytes cut, then a plateau at 5.4 µs, then the drop near 99%. Only the whole curve shows them. A number line with a single marker per slider stop hides the shape the explorer is meant to explain. (2) The energy values (251/137/74 and 70/19/7.1 µJ) come from separate runs of the compute-only (host-reduced) kernel with their own x (45 nonzeros at 99% vs 34). Putting them next to the tree-skip latency without a label pairs numbers from different runs.


#### sp-viz-operands — MODIFIED [visualization/low] et-soc1-sparse-compute

Where: §1, the chart 'Board power above idle against the fraction of multiplies that are not zero' (#c-pow)

Files: docs/reports/2026-09-18-et-soc1-sparsity.html, workloads/sparsity/analyze.py, docs/reports/data/2026-09-22-horace-aifoundry3/horace3.json

Problem: The chart shows only the −3…3 integer operands and the fit 2.4 + 14.8 W × fraction. The page's own qualifier, that the saving is 80–92% depending on the data (+1.9 W zeros, +9.7 W ones, +24.9 W random on this card), lives only in the Later note, the KPI and Caveats. It is also why the Caveats bullet exists.


APPLY (CORRECTED): Add only the toggle: three extra markers (zeros at x = 0, ones and random normal at x = 100%) in a distinct style, legend 'aifoundry3, 22 Sep, temperature-controlled; A and B zero at 0%'. Label the dashed connectors 'straight line assumed, not measured', and label the saving on each (80%, 86%, 92%). Drop the fraction slider. Embed the three values via analyze.py --later as proposed.

Base PROPOSAL (for "as proposed" references): Add an operand toggle and a fraction slider to c-pow. It answers: how much does zero-skip save, and does the answer depend on the values being multiplied?

Controls:
- Two toggle buttons: 'Operands −3…3 (this page, 18 Sep)' and '+ later runs on this card: zeros, ones, random normal (Horace §10, 22 Sep)'. The second adds three markers: +1.89 W at x = 0 in var(--c3), and +9.68 W (ones) and +24.86 W (random normal) at x = 100% in var(--c2) and var(--c4). Dashed lines from the zero point are labelled 'interpolated, not measured'.
- A range input over the nonzero fraction f (0–100%). It moves a vertical guide and recomputes the page's fit P = 2.39 + 14.83 f W and pJ per multiply slot = P / (per_s × 4096), with per_s = 1.1245 × 10⁹.

A readout gives zero-skip's saving 1 − P(0)/P(dense): 86% (−3…3), 80% (ones) and 92% (random normal).

Data:
- #sparsity-data energy.configs['fma-dense'|'fma-50'|'fma-875'|'fma-zero'|'fma-col50'|'fma-rowmask'].above_idle_w.mean and .per_s.mean, plus nnz_a/a_elems once embedded (sp-scripts).
- docs/reports/data/2026-09-22-horace-aifoundry3/horace3.json patterns.{zeros,ones,randn}.p80 − .p_before and .tflops. Embed them via a new 'analyze.py --later PATH' option that writes energy.later.

Keyboard: native buttons and range input; the point tooltips come from sp-charts-existing (a).

The Later note can then drop its percentage sentence, and Caveats bullet 3 goes (sp-redundancy-summaries). Reader sees the 86% as one point in a data-dependent range.


Verifier note: The data checks. horace3.json p80 − p_before gives zeros 1.89 W, ones 9.68 W and randn 24.86 W. The savings are 1 − 1.89/9.68 = 80% and 1 − 1.89/24.86 = 92%, and the page's own is 1 − 2.37/17.34 = 86%. Refitting the six points gives 2.39 + 14.83 f. The toggle adds real information. The fraction slider does not: it evaluates a straight line the chart already draws, so it adds interaction without insight. The later-run markers also differ in conditions (a temperature-controlled run four days later, with both operands zero instead of only A), and the page itself says the two zero points are not directly comparable. So the overlay must not invite reading 1.9 against 2.4.


#### sp-viz-queue — MODIFIED [visualization/low] et-soc1-sparse-compute

Where: §4 'Divergence', after the paragraph 'What limits the loop was not measured …'

Files: docs/reports/2026-09-18-et-soc1-sparsity.html, workloads/sparsity/analyze.py

Problem: The page's open question about divergence ('the shared work queue may be part of it') is argued with arithmetic in prose: 184,000 cycles of queue against 173,000 for the average run, 67–83% at α = 3 and about half at 1.5–1.2. The two existing charts show efficiency and throughput but not run length against the queue's floor. The page's own proposed test (larger chunks) cannot be explored.


APPLY (CORRECTED): Draw the grouped mean-cycle bars and the dashed queue-floor line, with the readout, and keep only the 'cycles per contended atomic' slider (5–20, default 10, linked to One hot line stops a shire) as a sensitivity control. Drop the chunk-size slider, or grey out the bars with the note 'not run' whenever the chunk is not 32. Show cycles_max in the tooltip rather than as whiskers, or use a log y axis.

Base PROPOSAL (for "as proposed" references): A 'queue floor' chart. It answers: could one global atomic counter be what limits the divergence loop?

Encoding: grouped bars per α (none, 3, 2, 1.5, 1.2) of mean hart cycles. Static is var(--c2), refill var(--c1) and scalar var(--c3), each with a thin whisker to the slowest hart (cycles_max). A horizontal line in var(--ink), dashed, marks the queue floor = (items / chunk + harts) × c.

Controls:
- A range input 'cycles per contended atomic' from 5 to 20, default 10 (the measured ceiling in One hot line stops a shire, linked).
- A range input 'chunk size' of 8, 16, 32, 64, 128 or 256 items, default 32 and labelled 'only 32 was run'.
- Both recompute the floor line and a readout, e.g. 'queue busy 184,320 cycles: 107% of the static run's mean hart at α = none, 83% at α = 3, 44% at α = 1.2'.

Data: docs/reports/data/2026-09-18-sparsity-aifoundry3/diverge/diverge-{static,refill,scalar}-a{0,3,2,1.5,1.2}.jsonl, fields cycles_mean, cycles_max, items (524,288), harts (2,048) and chunk (32). Have analyze.py add cycles_mean and cycles_max to each #sparsity-data diverge.<variant>[i].

Phone: 5 groups of 3 bars fit 358 px. Tab reaches the sliders, and the bars get tooltips via sp-charts-existing (a).

This replaces the paragraph's middle sentences ('The 16,384 chunk grabs … about half of it at α = 1.5 and 1.2.') with one sentence pointing at the chart. The reader sees where the queue could bind (low divergence) and where it cannot (heavy tails), and what the proposed larger-chunk run would test.


Verifier note: The data exists in the diverge/*.jsonl records (cycles_mean, cycles_max, items 524,288, harts 2,048, chunk 32). The page's arithmetic checks: (16,384 + 2,048) × 10 = 184,320, which is 107% of static's 172,904 and 67–83% of the α = 3 runs. One correction: scalar is not '≈539,000' everywhere; at α = 1.2 it is 444,563. The chunk-size slider misleads. Only chunk 32 was run, so the measured bars stay fixed while the floor line moves, which suggests larger chunks would free the loop, although larger chunks also change the load balance the bars measure. Whiskers to cycles_max reach 1.42 M (static, α = 1.2) against means of 173–421 k, which squeezes the bars on a linear axis.


#### td-sgemm-rate — MODIFIED [claim/low] et-soc1-testdrive

Where: KPI '127 GFLOP/s' and the SGEMM table row n = 1024 ('16.8 ms', '127')

Files: docs/report/index.html, workloads/sgemm/README.md

Problem: No committed data behind the silicon SGEMM numbers: the host printout was not kept. The pair '16.8 ms, 127 GFLOP/s' implies 2·1024³ / 16.8 ms = 127.8 GFLOP/s. The two figures agree only if both were truncated rather than rounded. The other rows check out (1.69, 3.95, 113.3; 28.7×; 1,576,960 outputs).


APPLY (CORRECTED): Leave the numbers everywhere as they are. Append to the table caption: 'The host's printout was not kept, so these values cannot be rechecked; at n = 1024, 2·n³ / 16.8 ms is 128 GFLOP/s, within the launch-to-launch spread of the 127 shown.' Add an open question for the owner: is the 18 September sgemm_host output still in ~/nekko on aifoundry3?

Base PROPOSAL (for "as proposed" references): If the 18 September host output still exists (e.g. under ~/nekko on aifoundry3), commit it as docs/reports/data/2026-09-18-sgemm-aifoundry3/sgemm-host.txt, correct the row from it, and add 'Raw output: <link>' to the caption. Otherwise append to the table caption: 'Times and rates are truncated from the host's printout, which was not kept (16.8 ms and 127 GFLOP/s bracket 2·n³ / time = 127–128).' The same 127 appears in README.md, docs/getting-started.md, the hub and workloads/sgemm/README.md, so change them all together if the log gives a different value.


Verifier note: No raw SGEMM output exists anywhere in the repo, and 2·1024³/16.8 ms = 127.8. But 'they agree only if both were truncated' is too strong. Rounding also fits if the time was 16.843–16.85 ms, and the 2–3 launches (spread under 2%) mean the two columns may come from different launches. Also, this workflow may not ssh to aifoundry3, so the 'if the output still exists' branch can only be left as a question for the owner. The other rows check (1.69, 3.95, 113.3, 28.7×, 1,576,960 outputs).


#### td-for-scale — CONFIRMED [claim/low] et-soc1-testdrive

Where: 'SGEMM on the card', the paragraph beginning 'For scale: the FOSDEM 2026 talk'

Files: docs/report/index.html

Problem: The paragraph calls FOSDEM's 13 GFLOP/s 'naive scalar'. The committed ladder shows it is the naive kernel spread over all 2,048 harts (512×512, 650 MHz); single-hart naive was 7 MFLOP/s. The paragraph misses what the comparison shows: this page's scalar kernel already does 113 GFLOP/s at n = 512 on 2,048 harts, 8.6× FOSDEM's step and above its 8-lane SIMD rung (104). 'Its last rung was reached the same day' compares 9.5 TFLOP/s at 600 MHz with 10.25 at 650 MHz without saying they are equal once scaled.


APPLY (PROPOSAL): Replace the paragraph with: 'For scale: the FOSDEM 2026 talk “Zero to matmul with the ET-SoC-1” (512×512 fp32, 650 MHz) climbed from 13 GFLOP/s (the naive kernel on all 2,048 harts) through 104 (8-lane SIMD) and 312 (operands in the L2 scratchpad) to 10.25 TFLOP/s on the tensor unit. This page's scalar kernel already gets 113 GFLOP/s at n = 512 from its 16 register accumulators. The tensor-unit rung was reached the same day: 9.5 TFLOP/s in fp32 on aifoundry2 (<a href='https://spacesheep.dev/@yaroslavvb/et-soc1-matmul-efficiency'>Matmul efficiency</a>), which is FOSDEM's 10.25 scaled to 600 MHz.' If td-viz-ladder is built, shorten this to its last sentence.


Verifier note: docs/et-soc1-notes.md's ladder confirms 13.1 GFLOP/s is 'Use all 2048 harts' (the naive kernel), and 1 hart is 7 MFLOP/s. 113/13.1 = 8.6, 113 > 104, and 10.25 × 600/650 = 9.46 against 9.51 measured. One wording nit: 'from its 16 register accumulators' asserts a cause. 'with 16 accumulators per hart' is safer.


#### td-next-section — CONFIRMED [reorganize/low] et-soc1-testdrive

Where: h2 'Next (as planned on 18 September)' (id 'next') and 'Related reports' (id 'related'); the Versions line

Files: docs/report/index.html

Problem: 'Next (as planned on 18 September)' is a to-do list from the day, and 'Related reports' ('What came next') immediately supersedes it. The page records its own history twice. The Versions line adds a third changelog ('terms defined, the lab install named, and links to the reports that followed').


APPLY (PROPOSAL): Delete the h2 'Next (as planned on 18 September)' and its <ol>. Open 'Related reports' with a paragraph that keeps the id: '<p id='next' class='secondary'>Of the steps planned that day (8-wide .ps SIMD with register blocking, A and B staged in the L2 scratchpad, then the tensor unit), the tensor unit was done the same day; SIMD and scratchpad staging were not taken further. What came next:</p>'. Replace the existing 'What came next, starting the same day:' paragraph with it. Shorten the Versions line to 'Versions: published 18 September 2026; revised 24 September 2026.' Remove the Contents entry for 'Next'.


Verifier note: The 'Next (as planned)' list is superseded by 'What came next' right below it. No inbound links target #next. No SIMD or L2-scratchpad SGEMM exists in workloads/ or kernels/, so 'SIMD and scratchpad staging were not taken further' is true. Moving id='next' to the paragraph keeps the anchor.


#### td-viz-ladder — MODIFIED [visualization/medium] et-soc1-testdrive

Where: 'SGEMM on the card', after the table, replacing the 'For scale' paragraph's number list

Files: docs/report/index.html, docs/et-soc1-notes.md, docs/reports/data/2026-09-18-aifoundry2/results.json

Problem: The page has no chart. Its question is how far this first scalar SGEMM is from what the chip can do and what closes the gap. That question is answered only in a sentence of prose numbers and by links, although the complete committed ladder (FOSDEM's nine rungs plus this project's four SGEMM rows and the tensor-unit result) spans six orders of magnitude.


APPLY (CORRECTED): Build it as proposed, but drop the global clock-scaling toggle. Put a single static annotation on FOSDEM's last rung: '10,250 at 650 MHz ≈ 9,460 at 600 MHz; this project measured 9,510'. Link the FOSDEM slides as the source of the FOSDEM rows, with notes.md as the transcription.

Base PROPOSAL (for "as proposed" references): A log-scale performance ladder. It answers: how far is this scalar SGEMM from the chip's peak, and which step buys what?

Encoding: horizontal bars on a log x-axis in GFLOP/s, from 0.001 to 20,000, with ticks at 0.01, 1, 100 and 10,000. One row per rung, in two groups:
- 'This project, 600 MHz' in var(--c1): SGEMM n = 64 on 1 shire, 1.7; n = 512 on 1 shire, 3.9; n = 512 on 32 shires, 113; n = 1024 on 32 shires, 127. Tensor unit, fp32: 9,510 (Matmul efficiency).
- 'FOSDEM 2026, 512×512 fp32, 650 MHz' in var(--ref): 0.007 (1 hart), 3.4 (512 harts), 13.1 (2,048 harts), 104 (8-lane SIMD), 312 (L2 scratchpad), 1,640 (2×16 register blocks), 2,940 (4×32), 7,050 (tensor unit), 10,250 (software-pipelined).
- A vertical dashed var(--ink) line at the fp32 peak, 9,830 at 600 MHz.

Data:
- The page's SGEMM table, embedded as a JSON array.
- docs/et-soc1-notes.md, section 'Performance ladder (FOSDEM "Zero to matmul", 512x512 fp32)' (step text and result for each rung).
- docs/reports/data/2026-09-18-aifoundry2/results.json results[workload='fp32-tensor-L2'].tflops (9.5108).

Interactions:
- Toggle 'Scale FOSDEM to 600 MHz' (×600/650): 10,250 → 9,460, which lands on this project's 9,510.
- Toggle 'Interleave by speed': one sorted ladder that shows this page's 113 falling between FOSDEM's SIMD (104) and L2-scratchpad (312) rungs.
- Every row is focusable (Tab). Hover or focus shows the step description, n, harts, clock and source. Rows for other pages link to them (Matmul efficiency).

Colour tokens: the page defines only --accent, --hairline and --text-*. Add the template's --c1…--c5 and --c7, plus --ink: var(--text-primary), --grid: var(--hairline) and --ref (#8c8b85 light, #76756f dark) to :root and both dark blocks.

Phone: 28 px rows with labels above each bar, bars at 100% of the frame width, and the axis at the bottom.

This complements the SGEMM table and replaces the prose ladder. The reader sees that register blocking alone matched FOSDEM's SIMD step, and that the remaining 75× is SIMD, scratchpad and above all the tensor unit.


Verifier note: The data exists (docs/et-soc1-notes.md ladder, the page's SGEMM table, and results.json 9.5108 TFLOP/s). The page has no chart, and a log ladder is a good fit: 9,510/127 = 75× remains. One interaction misleads. A global 'Scale FOSDEM to 600 MHz' toggle multiplies every rung by 600/650, but the low rungs (naive DRAM-bound kernels, 512 harts) do not scale with the minion clock, since DRAM and the NoC are fixed. Only the compute-bound tensor rung scales cleanly. The 'Interleave by speed' toggle is harmless.


### Missed by the reviewers (found by the verifiers)


#### M-msd-1 [claim] et-soc1-testdrive

Problem: 'sys_emu -vpurf_warn flags essentially every FMA in this SGEMM (524,359 type A warnings at n = 64)' includes firmware warnings. Re-running n = 64 on one shire here and grouping the warnings by shire gives 524,291 on compute shire S0, 59 on the master shire S32 and 9 on the service processor S254. 524,291 is two warnings per fmadd.s (64³ = 262,144 FMAs) plus 3.

APPLY: Change the sentence to: 'sys_emu -vpurf_warn flags every fmadd.s in this SGEMM, twice (524,291 “type A” warnings on the compute shire at n = 64; the firmware adds 68 more), and gp-sdk's own saxpy_vector.elf as well.' In the td-reproduce block, use: grep 'type A' build/sgemm/run/sysemu.log | grep -c ' S0:'   # 524,291 (150 MB log).


#### M-msd-2 [claim] et-soc1-matmul-efficiency

Problem: The lede says 'about 2.9× in a later random-data measurement'. That measurement changes three things at once: the operands, the kernel (both operands in the L1 scratchpad instead of B streamed from L2) and the die temperature (idle 36.3 W at 80 °C against 30.6 W at 71 °C). The kernel difference (about 6 W of L2 traffic at 3.9 B per minion-cycle × 2.5 pJ/B, an estimate) and the temperature difference (+5.7 W idle) roughly cancel, which is why 144 is still a fair random-data figure. But the reader is told only 'random data'.

APPLY: Lede parenthesis: '(about 2.9× on random data, measured later with a variant of this loop at 80 °C)'. The merged Later box (mm-redundancy-a100) should keep the kernel and temperature qualifiers.


#### M-msd-3 [visualization] et-soc1-sparse-compute

Problem: The §3 conclusion compares ET's 2.1 µs with 'a queued A100 kernel' (1.5–2.3 µs after sp-queued-launch), but c-gemv draws only the 3.7 µs isolated-launch line and the 6–11 µs dense estimate. The comparison the bold sentence rests on is missing from the chart.

APPLY: Add a band from 1.5 to 2.3 µs to c-gemv (or to the curve in sp-viz-layer panel b), labelled 'queued A100 kernel, 1.5–2.3 µs', in the same style as the 6–11 µs band.


#### M-msd-4 [ownership] et-soc1-matmul-efficiency

Problem: mm-redundancy-setup edits docs/reports/sources/limits-of-observability.data.json (the hub row). The hub group owns that file, and the proposed text misattributes the card hello world to Test drive.

APPLY: Drop the hub edit from this group's change list. If the hub row changes at all, send the hub group 'also the first hello world on a card'.



## Group ridge-points


### Reproduction problems


#### R-ridge-1 [low] scripts/ridge-points.py (rerun_levels docstring, RERUN_DIRS comment); docs/reports/2026-09-18-et-soc1-ridge-points.html (Caveats, third bullet); docs/findings/05-claims.md (Ridge points intro)

Problem: The bandwidth check against the 23 September reruns reads levels-pass*/runs.jsonl, and the docstring calls these 'the energy manual's section 4.2 runs'. The page adds 'The energies per byte come from those reruns'. They are not the same runs. levels-pass* are the older run_energy.py measurements, which both rerun READMEs say were 'kept for the record and not pooled'. The §4.2 energies (reruns.json levels_pj_per_byte, built by analyze_reruns.py) come from rl-pass*/: 3 passes on each card, where levels-pass has 3 on aifoundry2 and 2 on aifoundry3.

Evidence: docs/reports/data/2026-09-23-reruns-aifoundry2-warm/README.md: 'rings-pass* and levels-pass* are ... kept for the record and not pooled'. tools/ettelem/analyze_reruns.py globs only rl-pass*[0-9]. Against rl-pass the largest difference from the bandwidths used is 0.254% (L3, aifoundry2 rl-pass1: 985.2 against 982.7 GB/s), which the page's ceil rounding would show as 0.3%. levels-pass gives 0.19%, shown as 0.2%. PLAN.md §3.16 item 2 had specified 'within 0.3%'. The conclusion holds either way.

Fix: Either make rerun_levels() read rl-pass*/runs.jsonl (records carry 'label' rather than 'config'), re-embed, and let the caveat and 05-claims read 0.3%; or keep levels-pass and correct the docstring and caveat to say these are the same probe's run_energy.py reruns, not the runs the §4.2 energies were pooled from.


#### R-ridge-2 [low] docs/reports/2026-09-18-et-soc1-ridge-points.html (prose in 'Ridge points by level', 'Which ridge points move with the clock', 'Other limits', 'Energy balance points', Caveats)

Problem: Several numbers in the prose are typed into the HTML, not filled from ridge-data. They all match the data today, but a re-run of --embed would not update them. The script already holds some of them: rerun DRAM GB/s range, 75.8–76.0 (levels[dram].measured.rerun.gbps); the sparsity DRAM probe's 72 GB/s (gbps_card2); clock elasticities 0.65× and 0.33× (clock_elasticity); launch range 0.35–0.69 ms (limits.launch_overhead_ms_range). Others the script does not compute at all: the sparsity L2 probe's 3.3–3.5 B/cycle; the write rates 1.23 TB/s, 76 GB/s and 27 GB/s (manual.json catalogue); 'up to about 740 MHz'; the 1.5 and 45 in 'That does not change the conclusion' (the same values also appear in the JS-filled spans just before).

Evidence: Static HTML (JS slots stripped) contains these literals. The recomputed values are 75.8/76.0, 72.1, 0.648/0.331, 0.353/0.688 ms, 3.309 (cycles_max) to 3.450 (cycles_mean), 1.2305e12, 7.607e10 and 2.69e10 B/s, max implied_ghz 0.745 and 0.740, and 1.46 and 44.69.

Fix: Give these spans ids and fill them in renderText() from fields ridge-data already has. For the write rates and the sparsity L2 range, add them to limits in ridge-points.py, from manual.json catalogue.combined (or the per-card bytes_per_s) and all_minion_tload('l2').


#### R-ridge-3 [low] docs/reports/2026-09-18-et-soc1-ridge-points.html (byline)

Problem: The byline dates the page '24 September 2026' and never says it was computed on 18 September. The review plan (PLAN.md §3.16 item 1, and nav-28) said to keep 'Computed 18 Sep 2026' and add '; published 24 September 2026'. 04-artifacts.md A19 and the hub keep 18 Sep.

Evidence: render.txt line 3: '24 September 2026 · arithmetic on the 18 September measurements and the 23 September energy manual, no new runs · ...'. PLAN.md line 2631: 'ridge points was computed 18 Sep ... only add published 24 September'.

Fix: Either write 'Computed 18 September 2026; published 24 September 2026 (energy balance points recomputed the same day)', or confirm that C2's single date is meant to be the date of the latest version and record that in the Versions line.


### Review findings


#### ridge-energy-scope — MODIFIED [claim/medium] et-soc1-ridge-points

Where: Energy balance points, the paragraph after table t-energy

Files: 

Problem: The conclusion is stated without its operand condition: 'At the measured bandwidths every fp32 energy balance point lies below the matching time ridge point. So a kernel that is compute-bound at those rates already spends more energy on arithmetic than on moving data.' It holds only on random-normal operands (2.89 pJ/FLOP). The page's own e_flop data reverse it on zeros and nearly on ones. The intro only says the balance points 'move by up to 14×'. It never says which levels cross.


APPLY (CORRECTED): Replace the paragraph with: 'On random-normal operands, every fp32 energy balance point lies below the matching time ridge point at the measured bandwidths. So a compute-bound kernel on random-like data spends more energy on arithmetic than on moving data. At the spec rates only L3's <span id="e-spec-l3">3.6</span> FLOP/B lies above its ridge of 3.0. The operands can change this. On all-ones operands the balance points stay below, though L3 (<span id="e-ones-l3">9.4</span> against 10) and DRAM (<span id="e-ones-dram">109</span> against 130) come close. On zeros the tensor unit adds little more power than cores that are merely awake, and every level from the shire's own scratchpad outward lies well above its time ridge, even with byte energies also measured on zeros (§4.1: DRAM <span id="e-zeros-dram">434</span> against 130, own scratchpad <span id="e-zeros-scp">9.6</span> against 4.0). For zero-heavy operands, moving the bytes costs more energy than the arithmetic even when the kernel is compute-bound. Treat the zeros figures as a direction, not a value.' In ridge-points.py, export energy.tload_by_operand = {w: {o: cat[f'tload/{w}/{o}']['mean'] for o in ('zeros','const','random')} for w in ('scp','dram')}. Fill e-zeros-dram and e-zeros-scp from it divided by F.fp32_zeros.pj, and e-ones-l3 and e-ones-dram from the section 4.2 L3 and DRAM energies divided by F.fp32_ones.pj, as the reviewer proposed. In 05-claims, extend the row: '(random fp32 at 2.89 pJ per FLOP over idle; on all-zero operands, 0.21 pJ, mostly the awake-core floor, every level from the shire outward lies above its time ridge)'.

Base PROPOSAL (for "as proposed" references): Replace the paragraph 'At the measured bandwidths every fp32 energy balance point lies below the matching time ridge point. So a kernel that is compute-bound at those rates already spends more energy on arithmetic than on moving data. At the spec rates only L3's 3.6 FLOP/B lies above its ridge of 3.0.' with: 'On random-normal operands, every fp32 energy balance point lies below the matching time ridge point at the measured bandwidths. So a kernel with random-like data that is compute-bound at those rates spends more energy on arithmetic than on moving data. At the spec rates only L3's <span id="e-spec-l3">3.6</span> FLOP/B lies above its ridge of 3.0. The operands can reverse this. On all-ones operands the balance points stay below, but L3 comes close (<span id="e-ones-l3">9.4</span> against 10) and so does DRAM (<span id="e-ones-dram">109</span> against 130). On zeros every memory level's balance point lies above its time ridge (DRAM <span id="e-zeros-dram">584</span> against 130). For sparse or zero-heavy data, moving bytes costs more energy than the arithmetic even when the kernel is compute-bound.' In renderEnergy() fill the spans: lev = E.e_byte by name; put('e-ones-l3', fr(L3.pj / F.fp32_ones.pj)); put('e-ones-dram', fr(DRAM.pj / F.fp32_ones.pj)); put('e-zeros-dram', fr(DRAM.pj / F.fp32_zeros.pj)). In docs/findings/05-claims.md, extend the 'Energy balance, fp32' row: '(random fp32 at 2.89 pJ per FLOP over idle; on zeros, 0.21 pJ, every memory level's balance point exceeds its time ridge)'.


Verifier note: The problem is real. I recomputed from ridge-data: on all-ones operands (1.114 pJ/FLOP) own scratchpad is 2.26, remote 5.97, L3 9.43 against 10.0 and DRAM 109 against 129.5, all below their ridges. On zeros (0.209) own scratchpad and L2 are 12.0 against 4.0, remote 31.8, L3 50.3, DRAM 584, TensorSend in a shire 9.97 against 8.8, and the fast local network 3.18 against 3.29 (still below). The proposed text has two flaws. (1) It pairs the zeros FLOP energy with the section 4.2 byte energies, which were measured on never-written buffers. manual.json catalogue.combined has TensorLoad energies for the same operands: tload/scp/zeros 2.01 and tload/dram/zeros 90.7 pJ/B; const (0x3F800000, all ones) 2.63 and 99.0. Matched, the zeros points are 9.6 against 4.0 and 434 against 130: they still flip, but 584 is the wrong number to quote. (2) On zeros, the tensor unit's 0.209 pJ/FLOP is mostly the cost of keeping the cores awake. 0.418 pJ/MAC × 4.59e12 MAC/s gives 1.92 W over idle, against 1.46 W for the spin loop in the same ablation (manual.json awake.spin_hart0_1024) and 2.1 mW per minion for the catalogue's addi loop (D6). The zeros magnitudes are therefore not robust; only the direction is. Also, 'sparse' data was not measured; only all-zero operands were.


#### ridge-l1-row — MODIFIED [consistency/low] et-soc1-ridge-points

Where: Energy balance points: table t-energy row 'L1 data cache (vector loads)', and the sentence 'For L1 the manual's catalogue gives … a balance point of 0.19 FLOP/B.'

Files: 

Problem: The L1 row divides the energy of an L1 vector load by the tensor unit's energy per FLOP. Only the vector unit's fmadd.ps consumes those loads; the page's own ridge-data says of L1 'Feeds the vector unit only'. The row also uses 0.77 pJ/B, the §4.2 probe loop, although the energy manual says to use 0.54. The page gives 0.54 only as an afterthought.


APPLY (CORRECTED): As proposed: L1 entry = flw.ps/random/h2 ÷ 32 over fmadd.ps/random/h2 ÷ 16 (0.54 pJ/B, balance 0.15). Int8 shows '–' and the time ridge shows '1.6 (vector)'. Export energy.e_flop.vec32. Delete the 'For L1 the manual's catalogue gives…' sentence and its two put() calls, and update 05-claims to 'L1 0.15 (flw.ps against fmadd.ps, random data)'. In addition, change the caption's '(1 KB TensorLoads; vector loads for L1)' to '(1 KB TensorLoads)', and append: 'The L1 row is the manual's §4.1 catalogue on random data: a 32 B vector load (flw.ps) against the vector unit's fmadd.ps (3.49 pJ per FLOP), since the tensor unit does not read through the L1 cache.'

Base PROPOSAL (for "as proposed" references): In scripts/ridge-points.py, build the L1 entry separately: e_vec = cat['fmadd.ps/random/h2']['mean'] / 16; the L1 entry is {'name': 'L1 data cache', 'pj': rnd['l1'], 'balance_fp32': rnd['l1'] / e_vec, 'balance_int8': None, 'vs': 'fmadd.ps'}. Export e_vec as energy.e_flop.vec32 = {'pj': e_vec}. In renderEnergy() label the row 'L1 data cache (flw.ps, random data; against the vector unit's fmadd.ps)', show int8 '–' and time ridge fr(LV.l1d.ridge.measured.vec32) + ' (vector)' (1.6), and add to the table caption 'The L1 row compares a vector load with the vector unit's fmadd.ps (3.49 pJ per FLOP on random data, catalogue); the tensor unit does not read through L1.' Delete the sentence 'For L1 the manual's catalogue gives <span id="e-rnd-l1">0.54</span> pJ/B for 32 B vector loads on random data (§4.1), a balance point of <span id="e-rnd-l1-b">0.19</span> FLOP/B.' and its two put() calls. Update 05-claims 'L1 0.27' to 'L1 0.15 (flw.ps against fmadd.ps, random data)'. (If D7's 0.77 must stay, keep 0.77 but still divide by e_vec: 0.22.)


Verifier note: Confirmed. The row divides a flw.ps (vector-load) energy by the tensor unit's energy per FLOP. The tensor unit does not consume vector loads from the L1 cache; it reads its operands from the L1 scratchpad. The energy manual's section 4.2 note (docs/energy-manual/04-bytes-memory.md:21) says 0.54 is 'the figure to use'. Catalogue: fmadd.ps/random/h2 is 55.86 pJ per 16 FLOP, or 3.49 pJ/FLOP; flw.ps/random/h2 is 17.135 pJ per 32 B, or 0.535 pJ/B. The balance point is 0.15, against the vector time ridge of 1.59, which is consistent with the page's conclusion. The proposal is right but leaves one line stale: the t-energy caption still says the memory energies are section 4.2, '(1 KB TensorLoads; vector loads for L1)'. With the L1 row taken from the section 4.1 catalogue, that caption would be wrong for L1.


#### ridge-rerun-passes — CONFIRMED [reproducibility/low] et-soc1-ridge-points

Where: scripts/ridge-points.py rerun_levels() (lines 26, 131–151); page Caveats third bullet (span rerun-dev); docs/findings/05-claims.md 'Ridge points' intro

Files: 

Problem: The bandwidth check reads levels-pass*/runs.jsonl and its docstring calls these 'the energy manual's section 4.2 runs'. The caveat then says 'The energies per byte come from those reruns'. They are not the same runs. levels-pass* are the older run_energy.py runs, which both rerun READMEs mark as not pooled. §4.2 pools rl-pass*: three passes per card, against levels-pass's three and two. On the pooled runs the page's own ceil rounding shows 0.3%, the figure PLAN.md §3.16 item 2 specified, not 0.2%.


APPLY (PROPOSAL): In scripts/ridge-points.py: change the RERUN_DIRS comment to '# rl-pass*/runs.jsonl: the passes the energy manual pools (tools/ettelem/analyze_reruns.py)'. In rerun_levels() replace the filter `if not (p.startswith("levels-pass") and os.path.exists(path)):` with `if not (re.fullmatch(r"rl-pass\d+", p) and os.path.exists(path)):`. Replace the runs list with `runs = [dict(r, config=r.get("config") or r.get("label")) for r in jsonl(path)]` then `runs = [r for r in runs if r["config"] in ("l1", "l2", "scp-local", "l3", "scp-remote", "dram") and r.get("launch", -1) >= 0 and r.get("bytes", 0) > 0 and 0.59 <= r.get("implied_ghz", 0) <= 0.61]`. Docstring: 'three passes on each card: the rl-pass* runs that tools/ettelem/analyze_reruns.py pools into the energy manual's section 4.2 (levels-pass* are older run_energy.py runs, kept but not pooled)'. Re-run `python3 scripts/ridge-points.py --embed docs/reports/2026-09-18-et-soc1-ridge-points.html`; the caveat then reads 0.3%. In 05-claims.md change '(reproduced within 0.2% by the 2026-09-23 reruns on both cards)' to '(reproduced within 0.3% by the 2026-09-23 reruns on both cards, the rl-pass runs the energy manual pools)'.


Verifier note: Reproduced. The READMEs of both rerun directories say levels-pass* are older run_energy.py runs, 'kept … and not pooled'. analyze_reruns.py globs rl-pass*[0-9]. I patched a scratch copy with the proposed filter: rl-pass records use 'label' rather than 'config', which the proposal handles. rerun_max_deviation goes from 0.00188 to 0.00254 (worst: L3, aifoundry2 rl-pass1, 985.2 against 982.67 GB/s), aifoundry3 goes from 2 passes to 3, the DRAM range stays 75.8–76.0 and the per-cycle bandwidths are unchanged. The page's ceil rounding then shows 0.3%, which matches PLAN §3.16 item 2. I also rebuilt reruns.json from the rl-pass directories with analyze_reruns.py into scratch: byte-identical to the committed file.


#### ridge-typed-numbers — MODIFIED [reproducibility/low] et-soc1-ridge-points

Where: Prose in the lede, 'Ridge points by level' bullets and chart caption, 'Which ridge points move with the clock', 'Other limits', 'Energy balance points', Caveats

Files: 

Problem: The Reproduce note says the script 'prints every number used here and writes the tables' and chart's data into this page'. But many prose numbers are typed into the HTML, and a re-run of --embed would not update them. They all match today. One also mixes conventions: the sparsity L2 probe's '3.3–3.5' spans cycles_max (3.31, the page's stated rule, 'as a kernel would see') and cycles_mean (3.45).


APPLY (CORRECTED): Do (3): change '3.3–3.5' to '3.3' (slowest minion). Do (2): add limits.sparsity_l2_bpc and limits.write_gbps (tstore/scp, tstore/dram and st_stream/dram random, bytes_per_s.mean ÷ 1e9) and fill the write-rate caveat from them. For (1), wrap only the literals that sit next to computed spans and have a single source value: 75.8–76.0, 72, 0.65×/0.33×, 0.35–0.69 ms and 7.3. Leave 'about 740 MHz' and the lede's rounded figures typed. Then make the Reproduce sentence exact: 'It prints the numbers behind the tables, the chart and the figures in the text, and writes the tables' and chart's data into this page.'

Base PROPOSAL (for "as proposed" references): (1) Wrap each literal in a span and fill it in renderText(). Examples: put('dram-rerun', rr[0].toFixed(1)+'–'+rr[1].toFixed(1)) from LV.dram.measured.rerun.gbps; put('dram-card2', Math.round(LV.dram.measured.gbps_card2)); put('el-l3', LV.l3.clock_elasticity.toFixed(2)); put('el-rs', LV.scp_remote.clock_elasticity.toFixed(2)); put('lim-launch-range', r[0].toFixed(2)+'–'+r[1].toFixed(2)); put('demo-bpc'/'demo-bpc2', LV.l2.demonstrated.bpc.toFixed(1)); put('l1-bpc', Math.round(LV.l1d.measured.bpc)); put('l1-cyc', (32/LV.l1d.measured.bpc).toFixed(1)); put('l1-ridge', fr(LV.l1d.ridge.measured.vec32)); put('int8-own-t', Math.round(LV.scp.measured.gbps*16/1000)); put('int8-ran', Math.round(D.kernels[2].t)); and fill the lede's ridges from LV.*.ridge.measured, and its block sides from e×ridge (4×129.5 → 520, 1×1036 → 1,040). (2) In ridge-points.py add to limits: 'sparsity_l2_bpc': sparsity_tload('l2') (3.31), and 'write_gbps' from manual.json catalogue.cards.aifoundry2.summary['tstore/scp/random' | 'tstore/dram/random' | 'st_stream/dram/random'].bytes_per_s.mean / 1e9 (1,230.5, 76.1 and 26.9 GB/s, the same on both cards). In memhier_levels() add 'max_mhz': 1000*max(r['implied_ghz'] for r in rs). Fill the caveat's 1.23/76/27 and the clock text's 'up to <span id="clk-max">740–745</span> MHz' from these. (3) Change '3.3–3.5' to '<span id="spar-l2">3.3</span>' (slowest minion, the page's rule).


Verifier note: The problem is real but low value. The committed data are frozen, and `--embed` is idempotent (I re-embedded a copy: byte-identical). The typed literals all match today. The sparsity L2 figure does mix conventions: cycles_max gives 3.31 B/cycle and cycles_mean 3.45, and the page's rule is cycles_max. The write rates exist in manual.json catalogue.cards.*.summary: 1,230.5 GB/s, 76.07/76.08 and 26.9 GB/s, the same on both cards. Wrapping about 20 literals in spans is churn with little benefit. Two parts are unnecessary: the proposed 'clk-max 740–745' adds false precision to 'about 740' (L3's highest launch was 0.745 GHz, the remote scratchpad's 0.740); and computing the lede's rounded 'about 520/1,040/620' needs rounding rules for no gain.


#### ridge-reproduce-chain — MODIFIED [reproducibility/low] et-soc1-ridge-points

Where: Reproduce section (the paragraph under the command); scripts/ridge-points.py mmbench()

Files: 

Problem: Reproduce gives one command but does not say that its inputs can themselves be rebuilt, or which two inputs need a card. The only derived file that cannot be regenerated off-card is results.json, and ridge-points.py reads it instead of the runs.jsonl beside it, whose fields recompute exactly.


APPLY (CORRECTED): Put the exact command chain in docs/findings/04-artifacts.md A19 first: `python3 tools/ettelem/analyze_reruns.py docs/reports/data/2026-09-23-reruns-aifoundry2-warm docs/reports/data/2026-09-23-reruns-aifoundry3 --out docs/reports/data/2026-09-23-energy-manual/reruns.json`; `python3 tools/ettelem/build_energy_manual.py --out docs/reports/data/2026-09-23-energy-manual/manual.json`; plus the catalogue and nocbench steps. On the page, add one sentence: 'Its inputs rebuild from committed data with the commands in <code>docs/findings/04-artifacts.md</code> (A19); only the raw probe and matmul runs needed a card.' The mmbench() change to read runs.jsonl is an optional cleanup with no change in output.

Base PROPOSAL (for "as proposed" references): Append to the Reproduce paragraph: 'Its inputs rebuild from committed data too: <code>tools/ettelem/build_energy_manual.py</code> (manual.json), <code>tools/ettelem/analyze_reruns.py</code> (reruns.json, from the rl-pass runs), <code>workloads/enercat/analyze_catalogue.py</code> (catalogue.json) and <code>workloads/nocbench/analyze.py … --embed</code> (the on-chip page's JSON); docs/findings/04-artifacts.md gives the exact commands. Only the raw probe and matmul runs need a card.' In scripts/ridge-points.py change mmbench() to read docs/reports/data/2026-09-18-aifoundry2/runs.jsonl directly: per workload, tflops = sum(total_flop)/sum(wall_s)/1e12 and flop_per_minion_cycle = mean of the per-launch field, over records with launch >= 0. The output is unchanged; the dependency on results.json goes. Add the same command chain to 04-artifacts.md A19.


Verifier note: Partly verified. Both rebuilds I ran into scratch were byte-identical: `tools/ettelem/build_energy_manual.py --out …` reproduced manual.json, and `tools/ettelem/analyze_reruns.py <a2-warm> <a3> --out …` reproduced reruns.json. results.json tflops (sum total_flop ÷ sum wall_s) and flop_per_minion_cycle (mean per launch) recompute exactly from runs.jsonl for all four workloads, and mm_idle is never used. But the proposed Reproduce text says '04-artifacts.md gives the exact commands', which is untrue today: A19 and A16 name the tools but give no command lines. The five-tool paragraph also adds to a page the owner wants trimmed.


#### ridge-byline — MODIFIED [consistency/low] et-soc1-ridge-points

Where: byline (p.byline)

Files: 

Problem: The byline dates the page '24 September 2026' and drops 'computed 18 September'. D20, the hub ('18 Sep (published 24 Sep)') and 04-artifacts A19 all keep that date, and PLAN §3.16 item 1 asked for it to stay. The byline also runs to four lines at 1,280 px, repeating the minion count (given in Terms) and the sources summary (given in Sources), against C2's short format.


APPLY (CORRECTED): 'Ridge points computed 18 September 2026; energy balance points added and published 24 September 2026 · <code>aifoundry2</code> and <code>aifoundry3</code> at a 600 MHz minion clock (NoC 400 MHz, DDR 933 MHz) · arithmetic on the 18 September measurements and the 23 September <a …>energy manual</a>, no new runs · code: <a …><code>scripts/ridge-points.py</code></a> · part of the <a …>ET-SoC-1 measurement reports</a>'.

Base PROPOSAL (for "as proposed" references): Replace the byline text with: 'Computed 18 September 2026, published 24 September 2026 · <code>aifoundry2</code> and <code>aifoundry3</code> at a 600 MHz minion clock (NoC 400 MHz, DDR 933 MHz) · arithmetic on the 18 September measurements and the 23 September <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-energy-manual">energy manual</a>, no new runs · code: <a …><code>scripts/ridge-points.py</code></a> · part of the <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-limits-of-observability">ET-SoC-1 measurement reports</a>'. This cuts '1,024 compute minions,' and 'compute peaks from the Minion VPU Specification, spec values from the manuals and micro-architecture docs (sources at the end)'. The Versions line already records the same-day recompute.


Verifier note: Confirmed that the byline drops 'computed 18 September', which D20, the hub ('18 Sep (published 24 Sep)') and A19 keep, and that it is long. But the proposed 'Computed 18 September 2026, published 24 September 2026 · … arithmetic on … the 23 September energy manual' contradicts itself: a whole section (the energy balance points) was computed on 24 September from a 23 September input. The cuts ('1,024 compute minions', the sources summary) are fine; Terms and Sources carry them.


#### ridge-claims-file-stale — CONFIRMED [consistency/low] et-soc1-ridge-points

Where: docs/findings/05-claims.md, '## Ridge points' intro and 'Two corrections to earlier reports' bullet 1

Files: 

Problem: 05-claims says the memory-hierarchy report prints '2.80 TB/s and "about 144 B/cycle"' and that its column 'averages launches taken at 600–800 MHz'. That page now prints the 600 MHz values and keeps the old ones only on its Versions line. The intro's '0.2%' changes to 0.3% once the rerun check reads the pooled runs.


APPLY (PROPOSAL): In 05-claims.md replace bullet 1 with: '- The memory-hierarchy report's first version averaged launches taken at 600–800 MHz (2.80 TB/s for L2, "about 144 B/cycle"). At 600 MHz the cycle counters give **2.45 TB/s** and **128 B per shire-cycle**, which that report now prints.' Apply the 0.3% change from ridge-rerun-passes.


Verifier note: The memory-hierarchy page now prints 2.45 TB/s and '128 B per shire-cycle by the cycle counters' in its table, 'The tables use only the launches that ran at 600 MHz', and keeps 2.80 only on its Versions line. 05-claims.md still says 'not the 2.80 TB/s and "about 144 B/cycle" printed there'. The replacement bullet is accurate. The 0.3% change follows from ridge-rerun-passes.


#### ridge-red-shire-block — CONFIRMED [redundancy/medium] et-soc1-ridge-points

Where: What it takes to reach them › Matrix multiplication: bullets 'The shire.' and 'Beyond the shire.'

Files: 

Problem: Both bullets analyse the same 4 × 8 grid of 16×16 C tiles (a 64 × 128 block) and reach the same '21, 43 and 85' per byte, once against the banks and once against L3 or another shire. The reader meets the same arithmetic twice, framed as two different results.


APPLY (PROPOSAL): Replace the two bullets with one: '<li><b>The shire.</b> A shire's 32 register-resident C tiles form a 64 × 128 block. A block of m × n outputs held while K streams past does 2mnK operations for every e·K·(m + n) bytes it reads (e = bytes per element), an intensity of H/e with H = 2mn/(m + n), the harmonic mean of m and n. Here H = 85: 21, 43 and 85 operations per byte. That is well past the banks' spec ridge of 2, 4 and 16 if a cooperative TensorLoad reads each line once for every minion that needs it (A shared by the 8 minions of a neighbourhood, B across the 4 neighbourhoods: 384 B of bank reads per minion-op instead of 2 KB). It also beats the measured 10, 20 and 80 from L3 or another shire, with little to spare in int8, if each byte enters the shire once. Cooperative loads have not been measured on these cards, and they cannot read L3-homed addresses, so L3 data must first be captured by the shire's L2 or copied into its scratchpad.</li>'. Move 'Likewise, the DRAM figures below assume each DRAM byte is read once for the whole chip.' to the start of the DRAM bullet as 'These figures assume each DRAM byte is read once for the whole chip.'


Verifier note: Same block, same arithmetic. 1 KB/8 + 1 KB/4 = 384 B per minion-op gives 8,192/384 = 21.3, and H = 2·64·128/192 = 85.3 gives H/4 = 21.3. The two bullets differ only in the source they are compared against (banks, or L3 and other shires). The merged bullet keeps both conditions: cooperative loads for the banks, and each byte entering the shire once, with L3 data captured first. It also keeps 'not measured' and the move of the DRAM assumption to the DRAM bullet. Nothing a reader needs is lost.


#### ridge-red-tilepool — CONFIRMED [redundancy/low] et-soc1-ridge-points

Where: 'One op.' bullet; roofline caption; (also present: t-ridge subrow, Own shire bullet, A lone minion)

Files: 

Problem: The shared-32 KB-tile-pool caveat appears five times: the table subrow, the Own shire bullet (the canonical explanation), the chart caption, the One op bullet and A lone minion. The One op bullet also repeats the 97% and 91% already shown in the compute-ceilings table.


APPLY (PROPOSAL): In 'One op.' replace those two sentences with: 'The matmul benchmark's 97% and 91% of peak came from one shared 32 KB tile pool (see <a href="#ridge-points-by-level">Own shire</a>), so they do not show that private tiles would keep the tensor unit busy.' In the chart caption replace 'because all 1,024 minions read the same 32 KB of tiles. It stays under the spec line.' with 'because every minion read the same 32 KB of tiles; it stays under the spec line.' Keep the Own shire bullet's full explanation as the one home.


Verifier note: The caveat appears four times, not five: the t-ridge subrow, the Own shire bullet, the chart caption and the One op bullet. 'A lone minion' cites 7.3 B/cycle without naming the pool. The One op bullet repeats the 97%/91% shown in t-peaks. The shortened sentence keeps the caveat, and the Own shire bullet remains its one full explanation.


#### ridge-red-history — MODIFIED [redundancy/low] et-soc1-ridge-points

Where: 'Ridge points by level' intro paragraph; Energy table caption; Reproduce › Versions

Files: 

Problem: There is internal history in two places. (a) The section intro retells the memory-hierarchy report's first version, which that page records on its own Versions line. (b) The energy caption and the Versions line both describe the supersession of the 18 September energies.


APPLY (CORRECTED): (a) As proposed. (b) Delete the caption sentence. Versions: 'First published 24 September with energy balance points from the 18 September memory-hierarchy energies (clock free) and 1.88 pJ per FLOP on small-integer operands. Recomputed the same day from the energy manual, which moved the DRAM balance point from 79 to 42 FLOP/B and the L2 cache's below its spec ridge.'

Base PROPOSAL (for "as proposed" references): (a) Replace the quoted two sentences with 'The <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-memory-hierarchy">memory-hierarchy report</a> uses the same launches.' (b) Delete the caption sentence 'The 18 September figures (memory-hierarchy report, clock free, busy-core floor of about 12 W) are superseded.' Replace the Versions paragraph with '<b>Versions.</b> First published 24 September with energy balance points from the 18 September memory-hierarchy energies (clock free) and 1.88 pJ per FLOP on small-integer operands; recomputed the same day from the energy manual (DRAM balance point 79 → 42 FLOP/B).'


Verifier note: (a) is right: the memory-hierarchy page records its own first version in its Update box and Versions line. (b) Deleting the caption sentence is fine, since no page now shows the 18 September energies as current. The proposed Versions line, however, drops the one substantive change in conclusion that a returning reader needs. The first version said the L2 cache's balance point (2.3) was above its spec ridge; the recompute put it below (0.87 against 2.0).


#### ridge-red-caveats — CONFIRMED [redundancy/low] et-soc1-ridge-points

Where: Caveats, bullets 3 and 4

Files: 

Problem: Caveat 3 repeats the clocks from the byline, and its last sentence repeats the energy caption. Caveat 4's first clause repeats the Own shire and DRAM bullets, which already say both cards agree. Two bullets carry one point.


APPLY (PROPOSAL): Replace both bullets with one: '<li>The levels beyond the shire use the 600 MHz launches of the 18 September runs on <code>aifoundry2</code>, whose governor moved the clock; the 23 September reruns at a pinned 600 MHz reproduce every level on both cards to within <span id="rerun-dev">0.3</span>%. <code>aifoundry3</code> also supplied the <a href="https://spacesheep.dev/@yaroslavvb/et-soc1-sparse-compute">sparsity report</a>'s TensorLoad-size and batch-1 measurements.</li>'


Verifier note: Caveat 3 repeats the clocks in the byline (which the proposed byline keeps) and the energy caption's source statement. Caveat 4's first clause repeats the Own shire and DRAM bullets. The merged bullet keeps what is specific: 600 MHz launches, the governor on aifoundry2, the reruns on both cards within the rerun-dev span, and aifoundry3's sparsity measurements. It should read 0.3% only once ridge-rerun-passes lands; the span fills itself either way.


#### ridge-red-sources-a100 — MODIFIED [redundancy/low] et-soc1-ridge-points

Where: Sources item 5; A100 section prose and caption; DRAM bullet

Files: 

Problem: (a) Sources item 5 'Companion reports: …' lists the same five pages, with the same roles, as Related reports. (b) The A100 paragraph restates the table cell by cell ('21 … 8 … 71 … 20 … 223 … 259'). (c) The A100 caption's '; the memory-hierarchy report quotes 1.41' flags another page's inconsistency instead of fixing it (D5 is 1.40). (d) The DRAM bullet's 'The datasheet prints 133 Gbytes/s, which is 136,512 MB/s divided by 1,024.' repeats the spec-table cell '(datasheet prints 133 GB/s)'.


APPLY (CORRECTED): (a) Delete Sources item 5. (b) As proposed. (c) Caption '(HBM2 1.40 TB/s)'. Note to the memory-hierarchy group: its 1.41 is 1,407 GB/s rounded, and harmonising to 1.40 is optional. (d) In specBw(), change the cell to '136.5 GB/s at 4,266 MT/s' (drop '(datasheet prints 133 GB/s)'). Keep the bullet's '133 Gbytes/s, which is 136,512 MB/s divided by 1,024'. Shorten the last two sentences to 'A third party's estimate of about 88 GB/s on another card was calculated from single-memory-shire rates, not measured chip-wide.'

Base PROPOSAL (for "as proposed" references): (a) Delete Sources item 5. (b) Replace the A100 paragraph with: 'The A100's tensor cores outrun its bandwidth by more, so on chip its fp16 and int8 ridge points are higher than the ET-SoC-1's. From DRAM the fp16 ridges are close (223 against 259). In int8 the ET-SoC-1 needs 2.3× more, and in IEEE fp32, which the A100 runs on its CUDA cores, about 9× more (130 against 14). With fp32 inputs rounded to TF32 on its tensor cores (156 TFLOP/s dense), the A100's HBM ridge would be about 111.' (c) Change the caption's '(HBM2 1.40 TB/s; the memory-hierarchy report quotes 1.41)' to '(HBM2 1.40 TB/s)', and flag 1.41 to the memory-hierarchy group against D5. (d) Delete 'The datasheet prints 133 Gbytes/s, which is 136,512 MB/s divided by 1,024.' and shorten the last two sentences to 'A third-party estimate of about 88 GB/s was calculated from single-memory-shire rates, not measured chip-wide.'


Verifier note: (a) Confirmed: Sources item 5 lists the same five pages as Related reports. (b) Confirmed: the rewritten paragraph checks out (fp16 on chip 21 vs 8 and 71 vs 20; DRAM fp16 223 vs 259; int8 1,036/446 = 2.3×; fp32 130/13.9 = 9.3×; TF32 156/1.40 = 111). (c) Dropping the note is fine. The flag to the memory-hierarchy group should say that 1.41 is the A100 source's 1,407 GB/s (40 GB PCIe) rounded, a rounding choice rather than an error; aligning it with D5's 1.40 is cosmetic. (d) The reviewer deletes the wrong copy. The bullet's '136,512 MB/s ÷ 1,024' is the only place that explains why the datasheet's 133 differs from 136.5, whereas the table cell's '(datasheet prints 133 GB/s)' is unexplained and widens a cell that already overflows on phones. The shortening also drops 'on another card', which is context.


#### ridge-red-clockcol — CONFIRMED [redundancy/low] et-soc1-ridge-points

Where: Table t-spec, column 'Does the ridge grow with the minion clock?' and its caption sentence

Files: 

Problem: The spec table's fourth column (no / partly / yes) repeats the next section, 'Which ridge points move with the clock', which gives the same answer with numbers. The caption points there anyway. At 390 px that column's header wraps one word per line and makes the header row 191 px tall.


APPLY (PROPOSAL): In renderRidge() drop `td(CLOCK[lv.clock] || "", "")` from the t-spec rows, change the group row's colspan from 4 to 3, and delete the header cell `<th>Does the ridge grow with the minion clock?</th>` and the CLOCK map. Rename the table title to 'Spec bandwidth and ridge points'. Replace the caption with 'The same levels at what the documented port and bank widths allow, in the same units.' Add to the t-clock caption: 'TensorSend inside a neighbourhood or a shire runs on the minion clock, so its ridges hold at any clock; between shires it crosses the 400 MHz NoC.'


Verifier note: Measured at 390 px: t-spec's thead is 191 px tall (every other table's is 37). The column's answers for the memory levels are all in t-clock and its prose. The only information unique to the column, for the three TensorSend levels, is moved into the t-clock caption by the proposal. Colspan 4→3 and removing the CLOCK map are correct.


#### ridge-reorg — CONFIRMED [reorganize/low] et-soc1-ridge-points

Where: Section order; 'Ridge points by level' internal order; heading ids

Files: 

Problem: The roofline, the page's main picture, sits at the end of 'Ridge points by level', after two tables and six bullets: about two screens after the heading at 1,280 px and five at 390 px. The A100 comparison answers the reader's next question, 'is 130 FLOP/B a lot?', but comes after the energy section. Only three headings carry explicit ids; the rest get ids generated from their text, so any wording edit would break links from other pages.


APPLY (PROPOSAL): H2 order: The compute ceilings (#the-compute-ceilings) → Ridge points by level (#ridge-points-by-level) → The same numbers for an A100 (#the-same-numbers-for-an-a100) → Which ridge points move with the clock (#which-ridge-points-move-with-the-clock) → What it takes to reach them (#what-it-takes-to-reach-them; h3 #matrix-multiplication, #inference-that-streams-its-weights) → Other limits that act like ridge points (#other-limits-that-act-like-ridge-points) → Energy balance points (#energy-balance-points) → Caveats (#caveats) → Reproduce (#reproduce) → Related reports (#related) → Sources (#sources). Inside 'Ridge points by level': intro paragraph → roofline chart and caption → 'Measured bandwidth and ridge points' table and caption → the six per-level bullets → 'Spec bandwidth and ridge points' table and caption. Write every one of these ids explicitly on its h2/h3 so they no longer depend on the heading text.


Verifier note: Measured: at 1,280 px the roofline starts 2,627 px below its h2; at 390 px, 5,221 px below. Only which-ridge-points-move-with-the-clock, energy-balance-points and related have explicit ids; the rest are slugged at load. No page links to a ridge-points fragment today, so explicit ids are cheap insurance. Putting the A100 section right after 'Ridge points by level' is a reasonable judgement. Putting it after the clock section would also work and keep the clock analysis next to the tables it modifies. Either is harmless.


#### ridge-layout-phone — MODIFIED [layout/low] et-soc1-ridge-points

Where: Tables t-ridge, t-clock, t-peaks at 390 px

Files: 

Problem: At phone width the measured ridge table puts its point, the fp32/fp16/int8 columns, beyond the frame's right edge: Level (min 190 px) and Size (min 150 px) fill the 343 px frame. t-clock is 885 px wide because its headers are long, and t-peaks is 849 px.


APPLY (CORRECTED): t-ridge: move the size under the name, as proposed, and order the columns Level | fp32 | fp16 | int8 | Bandwidth (thead and both row() calls, including the l2demo subrow). Group-row colspan 5; replace `table.ridge.measured td:nth-child(2)` with `@media (max-width:560px){ table.ridge td.lvl{min-width:0} }`. Optionally break measBw after 'B/cycle' in both branches. t-clock: shorten the headers as proposed and move the parentheticals into the caption. t-peaks: 'At 1 GHz', and either drop class 'wide' from its table or accept scrolling in the frame (no page overflow).

Base PROPOSAL (for "as proposed" references): t-ridge: drop the Size column and render size under the name, `td(lv.name + "<br><span class='small'>" + lv.size + "</span>", "lvl")`, removing `<th>Size</th>`, the empty size cell in the l2demo subrow and the CSS rule `table.ridge.measured td:nth-child(2)`. Add `@media (max-width:560px){ table.ridge td.lvl{min-width:0} }`. t-clock: headers 'fp32 ridge (FLOP/B)', '600 MHz', '800 MHz', '1,000 MHz'; move the parentheticals into the caption: '600 MHz is measured; 800 MHz is the top of the firmware's table; 1,000 MHz is the shire design clock.' t-peaks: header 'At 1 GHz' in place of 'At the 1 GHz design clock'.


Verifier note: The widths reproduce: t-ridge 784 px, t-clock 885, t-peaks 849, t-energy 780, t-a100 780, all in a 343 px frame. But the proposed t-ridge fix does not reach its goal. I applied it to a copy (Size under the name, colspan 5, td.lvl min-width 0 under 560 px) and measured at 390 px: the table is still 567 px, with Level 123 px and Bandwidth 236 px (the nowrap 'xmesh 0.142–0.254 B/cycle · 87–156 GB/s'), so fp32 starts at 359 px, outside the frame. Adding a <br> in the bandwidth cell gives 476 px (fp32 visible, fp16 and int8 not). Putting the ridge columns first gives Level 123 + 64 + 72 + 72 = 331 px, and all three fit. For t-peaks, the header change alone does nothing, because table.wide sets min-width 780px. The t-clock header shortening works.


#### ridge-viz-existing — CONFIRMED [visualization/low] et-soc1-ridge-points

Where: Roofline chart #c-roof (renderRoof) and its legend and caption

Files: 

Problem: The chart is clear and honest: log–log, with slopes computed from the axis ratio. But its interaction is pointer-only: dots and rings are not focusable, so keyboard users get nothing. The five measured-kernel rings are unlabelled, so a reader must hover to know which is which. fp16 and int8 ridges are shown only on hover. The legend's 'bandwidth, spec' suggests spec lines for every level, but only the shire banks and PCIe are drawn; the mesh (3.28 TB/s, assumed) and DRAM (119 and 136.5 GB/s) spec lines from the spec table are missing. The three TensorSend levels in the table are silently absent.


APPLY (PROPOSAL): If V1 (ridge-viz-roofline-explorer) is not built, at least do this. Give every ridge dot and kernel ring `tabindex="0"`, `role="img"` and an `aria-label` equal to its tooltip text (strip tags), and add `focus`/`blur` listeners that call showTip()/hide. At W ≥ 560 label the rings next to them ('fp32, L2', 'fp16, L2', 'int8, L2', 'fp32, DRAM', 'batch-1'). Rename the legend item 'bandwidth, spec' to 'spec: shire banks, PCIe'. Add to the caption: 'TensorSend rates are in the table, not drawn.'


Verifier note: Accurate. renderRoof binds only pointermove/pointerdown/pointerleave; dots and rings are not focusable; only fp32 ridges are labelled; kernel rings have no labels; `lines` has only the banks spec, measured scp/L3/DRAM, and PCIe. Also, the 'bandwidth, spec' legend swatch (border-top dashed on a 22 px, border-radius 2px element) renders almost solid at 1× DPR in Chrome. I checked this with a screenshot, so it barely differs from 'measured'. When labelling rings, avoid the fp32 own-shire ridge label '4.0', which sits at Y+17 right under the fp32/L2 ring at (4, 9.51): place ring labels up and to the left. Superseded if V1 is built.


#### ridge-viz-roofline-explorer — MODIFIED [visualization/medium] et-soc1-ridge-points

Where: Ridge points by level: replaces the static roofline #c-roof (same id and position, moved to the top of the section per ridge-reorg)

Files: 

Problem: The page's main result is 'which level sets my speed at a given reuse, and how far am I from peak?'. The current chart shows 3 ceilings × 4 levels at once as an unbent grid, and the reader must work out min(compute, bandwidth × intensity) in their head. The clock question gets its own table (t-clock) with no picture.


APPLY (CORRECTED): Build as proposed, with these changes. The clock control is a four-stop segmented control, 600 | 700 | 800 (firmware) | 1,000 (design); t-clock stays. xmesh is drawn fixed with the clock (treat e = 0, labelled 'NoC-bound, not measured against clock'). The spec overlay is limited to banks, mesh (assumed), DRAM 119/136.5 and PCIe. The readout gives attainable TFLOP/s, % of peak and the reuse factor needed. For the own shire it adds 'private tiles top out at 4/8/16 per byte at batch 16; int8 cannot reach its ridge without cooperative loads'. The batch and block translation lives in V2 only; if V2 is not built, compute it with the page's minBatch() rules, not N = I·e/2. Use the existing --et/--et2/--et3 tokens rather than new aliases.

Base PROPOSAL (for "as proposed" references): An interactive roofline in inline SVG with vanilla JS. First add colour aliases to the page's three :root blocks (--c1: var(--et); --c2: var(--et2); --c3: var(--et3); --c4: #eda100, dark #c98500) so the new code uses var(--c1)…var(--c4), var(--ink), var(--ink-2) and var(--grid). Controls sit above the SVG and wrap on phones. (1) A precision segmented control, three <button aria-pressed> fp32 | fp16 | int8: the selected ceiling is drawn in its colour, the others faint in var(--grid). (2) Level chips as toggle buttons: Own shire, L3, Other shire, DRAM, PCIe (spec), TensorSend: pairs, in shire, between shires (xmesh drawn as a band from gbps_low to gbps). The selected level is drawn as its bent roof, min(peak, BW·I), 2.5 px in the precision colour; the others are thin var(--ink-2) diagonals. (3) A 'show spec' toggle overlays dashed spec lines for every level with a spec: banks 4.92 TB/s, mesh 3.28 TB/s marked 'assumed', DRAM 119 and 136.5 GB/s, PCIe 15.75 GB/s. (4) An intensity slider, <input type=range> over log10 I from −1 to 4 in steps of 0.01, with aria-valuetext, draws a vertical cursor. A live readout (aria-live=polite) says, for example: 'At 20 FLOP/B from DRAM, fp32 runs at most 1.52 TFLOP/s, 15% of peak: memory-bound, needs 6.5× more reuse. That is a batch of 40 fp32 weights (N = I·e/2) or a square C block of side 80 (H = I·e).' It computes attainable = min(peak·f, BW(f)·I/1000). (5) A minion-clock slider, 600–1,000 MHz in 50 MHz steps. It applies the page's clockRidge() model: the ceiling scales by f = MHz/600; minion-clock levels (scp, l2, fln, xbar) scale BW by f; NoC levels are drawn as a shaded wedge between BW·f^e and BW (the two assumptions in the t-clock caption); DRAM and PCIe stay fixed. The ridge dots and their fp32 labels slide; at 800 MHz they read 4.0, 11–13, 173 and 832, matching t-clock. Kernel rings, labelled at ≥560 px, stay at their measured points, with a note that they were measured at 600 MHz. Keyboard: all controls are native buttons and ranges; dots and rings get tabindex=0, an aria-label, and the tooltip on focus. At 390 px: the SVG uses the host width (343) at a height of 360, the ceiling labels move into the button row, and diagonal labels drop their GB/s as now. This replaces #c-roof and complements t-clock, which stays as the numbers. The reader now sees one roof at a time, reads off their own kernel's attainable speed and missing reuse, and watches the DRAM/PCIe ridges slide right with the clock while the own-shire ridge stays put and L3 lands in a band.


Verifier note: All inputs exist in ridge-data, and the readout example checks: 75.9 × 20 = 1.52 TFLOP/s, 15% of 9.83, 129.5/20 = 6.5×, N = 40, H = 80. Four problems. (1) 'N = I·e/2' and 'H = I·e' are wrong for the own shire. The page's batch model there is 32N/(e(16+N)), capped at N = 16, so int8 can never reach its 32 OP/B ridge with private tiles. The readout would give a wrong batch for the level most readers pick first. (2) LV.xmesh.clock is 'noc' but it has no clock_elasticity, so clockRidge() returns NaN (Math.max(0, undefined)) when the clock slider applies to TensorSend between shires. (3) A 600–1,000 MHz slider in 50 MHz steps shows 650, 750 and 850 MHz. The firmware offers only 600, 700 and 800 (D1: 'never write 850 MHz'), and 1,000 is the design clock. (4) The fast local network's spec is per sender (the page deliberately shows no chip GB/s), so it must not be drawn as a chip spec line. Also, the readout's batch and block translation duplicates V2's purpose; keep it in one place.


#### ridge-viz-reuse-curves — MODIFIED [visualization/medium] et-soc1-ridge-points

Where: What it takes to reach them: a new chart after the Matrix multiplication bullets, above table t-batch

Files: 

Problem: The section's question, 'how big a block or batch do I need from each level?', is answered only in prose and in a threshold table (t-batch). The reader cannot see how the fraction of peak grows with reuse. Two key facts get lost in the bullets: the 1,024 register tiles (512 × 512) leave fp32 just short of DRAM (99%) and int8 at half, and batch reuse inside a shire stops at 16 rows.


APPLY (CORRECTED): Blocked mode: x = H (the harmonic mean of the block's sides; for a square block, its side), from 16 to 8,192. Markers: 'one shire's 32 tiles, H = 85 (limit for L3 and other-shire reads with C in registers)' and 'all 1,024 tiles, H = 512 (DRAM, each byte read once for the chip)'. Band: 'C in scratchpads, swapping unmeasured' up to about 4,580 for DRAM. Streaming mode as proposed; label the own-shire curve 'TensorFMA tiles, fresh activation tile per op' and the ring 'measured GEMV, weights only, 0.5 FLOP/B'. The ticks follow the selected precision from minBatch(). Keep t-batch and the DRAM bullet's 99%/half sentence.

Base PROPOSAL (for "as proposed" references): A line chart with a mode toggle (<button aria-pressed> 'Blocked matmul' | 'Streaming weights') and precision buttons (fp32 | fp16 | int8). Blocked mode: x = square C block side m, log from 16 to 8,192; y = fraction of peak = min(1, (m/e)/ridge_level), one line per level (L3 var(--c2), other shire var(--c3), DRAM var(--c1)). Background bands in var(--grid): 'C in registers' for m ≤ 512, 'C in scratchpads (swapping unmeasured)' for 512 < m ≤ 4,580, 'does not fit' beyond. Vertical markers: 'shire's 32 tiles (H = 85)' and 'all 1,024 tiles (512²)'. Streaming mode: x = batch N from 1 to 1,024 (log); y = min(1, I(N)/ridge), with I(N) = 2N/e for L3, other shire and DRAM, and 32·min(N,16)/(e·(16+min(N,16))) for own shire, so that curve flattens at N = 16 and int8 stops at 50%. A ring marks the measured batch-1 layer (1.24 TFLOP/s = 12.6% of fp32 peak). Threshold ticks at 16, 20, 21 and 259 (the t-batch values). A range slider moves a cursor along x, with an aria-live readout, for example: 'DRAM, fp32, 512 × 512: 128 FLOP/B, 99% of peak; needs ≥ 520 for 100%'. Keyboard: buttons and range; hovering a line or focusing the slider shows the values. At 390 px the chart keeps an inner min-width of 343 and the level legend wraps above it. It complements t-batch, which stays as the exact thresholds, and replaces the numeric detail of the DRAM bullet ('which gives 128, 256 and 512 per byte. That is 99% …'). The reader sees reuse turn into speed and where register-held blocks stop.


Verifier note: The formulas check: square block H = m; own shire 32·min(N,16)/(e(16+min(N,16))) caps at 4/8/16 per byte, so int8 stops at 50%; the thresholds 16/20/21/259 are fp32 and fp16 (int8: never/40/41/518); 512² gives 128/129.5 = 99%; √(80 MiB/4 B) = 4,579. Four problems. (1) The x-axis mixes two kinds of block. The page's L3 and other-shire intensities are for a block held in one shire (at most 64 × 128, H = 85, in its registers), while the DRAM figures are for a chip-wide block (512² in all registers, each DRAM byte read once for the chip). A single 'C in registers, m ≤ 512' band is wrong for the L3 and other-shire curves. (2) The batch-1 ring sits at 2N/e = 0.5, 12.6% of peak, the page's own GEMV intensity, not on the own-shire tile curve (0.47 at N = 1, 11.8%). Label which model each belongs to. (3) Replacing the DRAM bullet's '128, 256 and 512 per byte … 99% … half' removes the key takeaway for readers who do not interact, or without JavaScript; keep that sentence. (4) Threshold ticks must change with precision.


#### ridge-viz-energy-dumbbell — MODIFIED [visualization/medium] et-soc1-ridge-points

Where: Energy balance points: a new chart between the intro paragraph and table t-energy

Files: 

Problem: The section asks whether data movement or arithmetic dominates energy once a kernel is compute-bound. The table puts balance points and time ridges in separate columns, and the operand effect ('moves by up to 14×') is never shown. Because of that the reversal on zeros (see ridge-energy-scope) is invisible.


APPLY (CORRECTED): Export energy.tload_by_operand from the catalogue in ridge-points.py. One operand control (random-normal | all-ones | zeros) sets both sides: FLOP from e_flop, and bytes from the matched §4.1 TensorLoad energy for own scratchpad and DRAM. Other levels keep the §4.2 value, drawn as a hollow circle labelled 'byte energy on unset buffers'. Drop the separate byte-energy toggle. Keep the time-ridge measured/spec toggle, the focusable rows and the phone layout. The zeros summary reads, for example: 'zeros: every level from the shire outward flips (DRAM 434 against 130); the tensor unit then costs about as much as awake cores'. Keep t-energy and the corrected prose paragraph; the chart complements them.

Base PROPOSAL (for "as proposed" references): A dumbbell chart, one row per level (own scratchpad, L2, other shire, L3, DRAM, TensorSend pairs, in shire, between shires as a range). x is log FLOP/B from 0.1 to 1,000. The circle is the fp32 energy balance point (pJ/B ÷ pJ/FLOP, with a whisker from lo/hi); the diamond is the time ridge. The connecting segment is var(--c1) when balance < ridge ('arithmetic dominates once compute-bound') and var(--c2) when balance > ridge ('moving data dominates'). Operand buttons (<button aria-pressed>: random-normal | all-ones | zeros) recompute the circles from e_flop. Byte-energy buttons (§4.2 probe | random data) swap in random_tload for own scratchpad and DRAM. A 'time ridge: measured | spec' toggle moves the diamonds. A summary line (aria-live) counts the flips, for example: 'zeros: 6 of 8 levels flip, DRAM 584 against 130', or 'spec ridges: only L3 flips, 3.6 against 3.0'. Each row is focusable (tabindex=0) with an aria-label giving both values; hover or focus shows pJ/B, pJ/FLOP and both points. At 390 px the row labels go above each dumbbell and the SVG scrolls inside its frame at min-width 343. It complements t-energy, which keeps the numbers, and replaces the prose comparisons in 'At the measured bandwidths…' and 'That does not change the conclusion: 1.5 is below … 72–82.' The reader sees that the energy-cheap-arithmetic conclusion holds on random and all-ones data and reverses on zeros.


Verifier note: The data exist (e_byte, xshire, e_flop with lo/hi, random_tload), and the counts check with the section 4.2 pairing: zeros flips 6 of 8 levels (all but the fast local network and the ambiguous between-shires range); at spec ridges only L3 flips (3.64 vs 3.0). But the operand buttons change only the FLOP side and leave the byte side on never-written buffers (section 4.2). That produces the mismatched 'DRAM 584' and overstates the reversal. Matched TensorLoad energies exist for own scratchpad and DRAM (catalogue tload/{scp,dram}/{zeros,const,random}; const is 1.0f, i.e. all ones) but are not in ridge-data. On zeros the tensor side is mostly the awake-core floor (see ridge-energy-scope), which the chart should note. Replacing the prose conclusion with the chart would lose it for readers who do not interact; keep the prose, corrected as in ridge-energy-scope.


### Missed by the reviewers (found by the verifiers)


#### M-ridge-1 [claim] et-soc1-ridge-points

Problem: The energy balance definition ('both measured as card power above idle') does not say that both sides include the cost of keeping the cores awake. A kernel that loads and computes at once pays that cost only once. Sizes, from manual.json and the rerun rates: spin loop on hart 0 of 1,024 minions 1.46 W (awake.spin_hart0_1024), catalogue addi loop 2.1 mW per minion (D6). Byte streams: L2 2.51 pJ/B × 2,455 GB/s = 6.2 W, of which 24–35% is that floor; DRAM 122 × 75.9 = 9.3 W (16–23%); L1 0.77 × 6,164 = 4.7 W against a two-hart floor of about 3.5 W (most of it). Tensor: random 26.5 W (6–8%); zeros 0.418 pJ/MAC × 4.59e12 = 1.92 W, at or below the floor. With the floor removed from both sides, the random-data points fall by about 10–30% (DRAM about 36–38, L2 about 0.6–0.7, L3 at spec rates about 3.1–3.3, still just above 3.0), so the random conclusions hold. The zeros ratios, however, are dominated by the floor.

APPLY: Append to the energy intro: 'Both sides include the cost of keeping the cores awake (about 1.5–2 W for the whole chip), which a kernel doing both pays once. Taking it out of both lowers the random-data balance points by about 10–30% and changes none of the conclusions below; on zeros it is most of the tensor unit's 0.21 pJ per FLOP.' Cite energy manual §2 (#a-core-that-is-awake).


#### M-ridge-2 [layout] et-soc1-ridge-points

Problem: On a phone, the measured ridge table shows only Level and Size; every ridge value is off-screen. The reviewer's fix still leaves fp32 at 359 px in a 343 px frame (tested on a copy: table 567 px, Bandwidth column 236 px).

APPLY: See the modified ridge-layout-phone: put the fp32, fp16 and int8 columns before Bandwidth. Tested: all three ridge columns fit at 390 px (331 px).



## Set-level review (information architecture; not separately verified)

PLAN2.md §2 records which of these are adopted, changed or rejected.


#### IA-01 [reorganize/high] et-soc1-limits-of-observability

Where: Whole hub: top matter (lede list, tiles, #terms card, .start, #toc) and the order of sections 1 to 9

Problem: The hub does two jobs: it is the index of the set and the longest reference page. It is 20,709 px tall at 1,280 px and 40,903 px at 390 px. A first-time reader on a phone scrolls 4,586 px before reaching the index table. That space goes to four lede bullets (291 words, 960 px), four tiles that repeat those bullets (594 px), the full glossary (413 words, 1,472 px), a weak 'Start here' line and the contents list. Further down, three blocks repeat others. The sessions table (1,886 px desktop, 2,815 px phone) overlaps the index. The improvement ladder (2,644 / 4,216 px) mirrors the ladder (IA-06). §9 Related reports repeats 8 rows of §1 with new blurbs.

Proposal: Reorder the hub and keep every existing id, since other pages link to #reports, #ladder, #bits, #power, #the-chain, #the-unmetered-remainder-attributed, #improve, #terms, #sessions, #method and #related.
(0) Keep the h1. Add an eyebrow line above it: 'ET-SoC-1 measurement reports · the hub'. Replace the lede paragraph and ul.lede-list with two sentences: 'This chip ships with its manuals, errata, firmware source, functional simulator and the RTL of its core. This page indexes every measurement made on two of its cards and asks how far down they let you see: one cycle, one register, one event, one bit.' Rewrite the four tiles so each carries one short answer: Time, '1 cycle', 'the cycle counter, from a kernel, after a late-carry fix (§3)'; State, '64 bits', 'one register of a halted hart, through a debug interface no client uses yet (§2)'; Energy, '~1 J of identical events', 'the meter resolves 10 mW per 133 ms, so one event needs ≥10⁹ a second for seconds (§2)'; Bit flips, 'simulation only', 'every flop every cycle in the open RTL; nothing on the die counts toggles (§3)'. Move the 'Power on no sensor' tile into §4 as the caption of VIS-03. Move the 'Below silicon…' sentence to open §5 Against a GPU.
(1) Add a new h2 id='start' 'Start here'. Give it a one-sentence chip description ('1,024 small in-order RISC-V cores (minions) in 32 shires of 32 on a mesh, each shire with 4 MB of SRAM; the full glossary is §6') and the reading paths of IA-02.
(2) §1 The measurement reports (#reports): the map of VIS-01 first, then the table with its 'What it established' column cut to one line per report. The full text moves into the map's detail panel.
(3) §2 The ladder (#ladder), merged with the improvement ladder as in IA-06, with VIS-02 after the time chart.
(4) §3 Bits, unchanged.
(5) §4 Power, with VIS-03 replacing #idletab, #fittab and #drooptab. Those tables move into <details>.
(6) §5 Against a GPU.
(7) §6 Terms: the #terms card becomes a section here, keeping id='terms' so the 17 'hub's glossary' links still land.
(8) §7 Sessions (#sessions): the intro plus <details><summary>All 17 sessions as a table</summary> around #sessionstab. The map in §1 shows the same data.
(9) §8 Method.
Delete §9 Related reports. Put a closing line with id='related' in its place: 'The experiment register, every claim with its file and field, and every artifact are in docs/findings/.' Record this as the hub's exception to X1: on the hub, the index is the related list.

Evidence: Heights from a headless render: at 390 px, .lede-list 496+960, .kpis 1618+594, #terms 2226+1472, #reportstab starts at 4586. At 1280 px: #laddertab 4015 px, #imptab 2644, #sessionstab 1886, #reportstab 1862. Section tops at 1280 px: reports 1760, ladder 3781, bits 8828, power 9801, improve 12739, gpu 15897, sessions 17269, method 19340, related 20055. Tiles repeat the bullets one for one (1 cycle / 64 bits / 133 µJ / 15.1 W). Expected effect: the index at under ~2,000 px on a phone, and the page about a fifth shorter.

Files: docs/reports/sources/limits-of-observability.body.html, docs/reports/sources/limits-of-observability.script.js, docs/reports/sources/limits-of-observability.data.json


#### IA-02 [reorganize/high] set

Where: Hub 'Start here' (.start card) and the whole set's navigation

Problem: The only guidance a newcomer gets is 'Start here. §1 lists every report… for energy go to the energy manual… The chip's vocabulary is in the box above.' The 17 pages are grouped by subject and date. Nothing says which order answers which question. Pages from 18 September (memory hierarchy, anatomy, on-chip communication, matmul, sparse) carry superseded numbers, and a reader who starts there gets stale energies.

Proposal: Put four reading paths in the new hub section #start (IA-01). Render each as one row of linked page names in order, with a one-line 'read this for' after each name.
A. 'Why is this chip low power, and what does a FLOP cost?' (newcomer, about 45 min): Why is the ET-SoC-1 low power? → The Horace experiment §1, §3, §6 → The energy manual §1–§3 → The DVFS loop and its leakage §1–§2, §4.
B. 'Writing fast kernels' (programmer): Test drive (toolchain; after IA-15 also the lab setup notes) → Matmul efficiency → Memory hierarchy → Ridge points → On-chip communication → Hand it to the next shire → One hot line stops a shire → Sparse compute.
C. 'What does each operation cost?' (energy modeller): The energy manual (all) → Heat per millimetre → Horace §8 (flips to temperature) → this hub §4 (what the meters do not see).
D. 'How far down can you see?' (tools and observability): this hub §2–§4 → Power and temperature (§2 load step, §3 voltage map) → Anatomy of a memory access (one load to ±3 cycles) → Spatial temperature: a brief → The DVFS loop §1 (the firmware as the gate).
Mark each 18 September page in the paths as 'baseline (energies superseded, see VIS-01)'. Each page's Related reports list should keep its current '— why read it' form. Add one line under that list: 'Next on the X path: <page>', using the same four paths, so a reader can follow a path page to page without returning to the hub.

Evidence: Current start text in docs/reports/sources/limits-of-observability.body.html line 36. The hub index lists 18 rows in 4 subject groups. X3 names 8 pages that carry superseded numbers.

Files: docs/reports/sources/limits-of-observability.body.html, docs/reports/sources/limits-of-observability.data.json


#### VIS-01 [visualization/high] et-soc1-limits-of-observability

Where: §1 The measurement reports (#reports), above #reportstab; also serves §7 Sessions (#sessions)

Problem: The hub's first question is what was measured, when, on which card, and which page is current for each number. Today that answer is spread over two tables: the 18-row index (1,862 px) and the 17-row sessions table (1,886 px). Neither shows the order of discovery, which card a result stands on, or which pages superseded which numbers. PLAN.md §1 item 4 names that freshness problem as the set's main risk.

Proposal: Build an explorable map of reports and sessions (inline SVG with vanilla JS, no library).
Data:
- limits-of-observability.data.json → sessions[] (id, when, card, what, instruments, data[].path, reports[].url) and reports[] (title, url, date, what, instruments).
- One new key, superseded[] = {from_url, to_url, to_anchor, what}, with the 9 edges in PLAN.md X3 and D7/D9: memory hierarchy energies → energy manual #reads-by-level; memory anatomy §7 → energy manual #reads-by-level and heat-per-mm; on-chip communication energies → energy manual #bytes-between-cores-and-shires and heat-per-mm; sparse compute power → Horace #from-flips-to-watts; matmul 3.4× → why-low-power #the-comparison; power-temperature slope, 2 s average and §5 → dvfs #what-that-costs and hub #the-chain and #improve; L2 brief 6% → hot-line; energy manual §4.3 1.81 pJ/B/hop → heat-per-mm #ones.
Encoding:
- x is time, 18 Sep 00:00 to 24 Sep 24:00. Parse 'when' into a day and an optional time span; with no time, place the session at midday.
- Top band: two lanes, aifoundry2 and aifoundry3. A session on 'both' spans the two lanes. Session marks are short bars, labelled with their E-ID.
- Bottom band: one row per index group (energy and power; contention and moving data; memory and compute baselines; briefs). Each report is a node at its last-revised date, as a pill with its short title.
- Thin curves in var(--grid) run from each session to the reports it fed.
- Dashed arrows in var(--c2) run from each superseded page to the page that now holds the number.
- Colours: group var(--c1), var(--c3), var(--c4), var(--c7); aifoundry2 lane var(--c1), aifoundry3 lane var(--c5). Text in var(--ink).
Interaction:
- Every node is a focusable button; Tab, arrow keys, Enter and Esc work.
- Selecting a report highlights its sessions and its arrows in and out. A panel beside the map (below it on a phone) shows the full 'what' text, the instruments, and 'current source for: …' / 'superseded here: … → link'.
- Selecting a session shows what it measured, its raw-data links and the reports it fed.
- Toggles: 'show superseded numbers' and 'card: both / aifoundry2 / aifoundry3'.
- At 390 px the axes swap: days run down the frame and the frame scrolls inside max-height:75vh.
It complements #reportstab, whose 'What it established' column shrinks to one line (IA-01). It replaces #sessionstab as the primary view; the table goes into <details>.
What the reader gains: at a glance, the 18 September baselines, the 20–22 September power and thermal work, the 23 September manual and the 24 September wires; which older page each number moved from; and which results rest on one card.

Evidence: data.json already holds 17 sessions with card and report links and 18 reports with dates, so only the superseded[] edges are new. The template defines --c1 to --c5, --c7 and --ref, and no --c6 (report.template.html lines 13, 21, 29).

Files: docs/reports/sources/limits-of-observability.data.json, docs/reports/sources/limits-of-observability.script.js, docs/reports/sources/limits-of-observability.body.html, docs/reports/data/2026-09-24-report-review/PLAN.md


#### VIS-02 [visualization/high] et-soc1-limits-of-observability

Where: §2 The ladder, directly after the time-resolution chart (#gran); replaces the 'Finest energy 133 µJ' tile text and the long note of the ladder row 'Energy per event'

Problem: The hub's energy answer ('a few joules' worth of identical events… a bit flip is ~10⁻¹⁶ J… the median bar ±6%') is stated in words three times: lede, tile and ladder note. The per-operation costs it refers to are spread over the energy manual, Heat per millimetre and Horace §8. The reader cannot see the 12 orders of magnitude between a flip and the meter, which events can be seen at all, or where each number comes from.

Proposal: Build an energy-resolution explorer: 'How many identical events must the card run before its meter sees one?'
Data:
- 2026-09-23-energy-manual/manual.json:
  - catalogue.combined[<instr>/<random|zeros>/h2].{mean,lo,hi,unit} for the 161 instructions and the byte paths tload/*, tstore/*, st_stream/*, wire/hop*;
  - catalogue.cards.aifoundry2.summary[cfg].ops_per_s.mean and bytes_per_s.mean, the chip's maximum rate for each event;
  - tensor.bars.{fp32,fp16,int8}_{zeros,ones,randn} with tensor.rows[].per_s;
  - reruns.levels_pj_per_byte.*, reruns.rings_pj_per_byte.*, reruns.relay_pj_per_byte.*, reruns.hotline_nj_per_op.*.
- 2026-09-24-wire-energy/report.json → wire.per_mm and headline (fJ per bit·mm; pJ/B per hop).
- 2026-09-21-horace-aifoundry2/model.json → power.e_fJ (the four flip energies) and power.rms_idle (0.205 W, the idle law's uncertainty).
- The meter constants from the hub's own ladder[] rows 'Board power' (10 mW, 0.133 s) and 'Rail power' (1 mW).
Encoding:
- One horizontal log axis from 10⁻¹⁷ J to 10⁻⁴ J.
- Six rows by family: flips and wires (var(--c7)); tensor multiply-adds (var(--c1)); instructions (var(--c2)); bytes by level (var(--c3)); messages and relay (var(--c4)); synchronisation (var(--c5)).
- Each event is a dot with a whisker for [lo–hi].
- A shaded band marks what one meter reading resolves: 1 mW × 133 ms = 133 µJ on a rail, 10 mW × 133 ms = 1.33 mJ on the board.
Interaction:
- Range input 'baseline uncertainty σ': 0.01 to 0.2 W, default 0.2 W. The idle law gives 0.2 W today; the PCIe riser of rung 8 would push it toward 0.02 W.
- Range input 'target precision': ±50% to ±2%, default ±6%.
- For each event, required rate r = σ / (precision × E). Dots whose chip maximum rate is at least r are filled, 'measurable in a burst'. The others are hollow, 'invisible to the meter'.
- A readout gives the example r for the focused event, e.g. one random bit per mm at 36 fJ needs about 9×10¹³ bit·mm per second for ±6%. The idle-law ±0.2 W on a 1.2 W signal reproduces the hot line's ±17%.
- Hover, or keyboard focus through a select list of events, shows the value [range], the per-card values, and a link to the page and anchor behind it: energy manual #every-instruction-the-core-executes, #the-tensor-unit-per-multiply-add, #reads-by-level, #bytes-between-cores-and-shires, #synchronisation; heat-per-mm #ones; Horace #a-model-from-flips-to-temperature.
- A zeros/random toggle moves the instruction and byte dots and shows the data dependence.
- At 390 px the axis scrolls sideways inside its frame. The select list gives the same access without pointing.
It complements the energy manual's §3.1 chart, which covers instructions only, and replaces the hub's three verbal restatements. The reader sees which events the card can price, how the riser of rung 8 would change that, and one click leads to the page behind any number.

Evidence: The hub lede says 'at least 10⁹ a second for 3 s'. Energy manual §9 gives the idle law's ±0.2 W as the reason the hot line's bar is ±17% at about 1.2 W over idle. All the named JSON paths exist (checked: manual.json top keys include catalogue, tensor, reruns, rest and unmetered; model.json power.e_fJ = {ffclk 3.179, mult 0.025, rest 0.801, bus 15.539}; power.rms_idle 0.205).

Files: docs/reports/data/2026-09-23-energy-manual/manual.json, docs/reports/data/2026-09-24-wire-energy/report.json, docs/reports/data/2026-09-21-horace-aifoundry2/model.json, docs/reports/sources/limits-of-observability.script.js


#### VIS-03 [visualization/medium] et-soc1-limits-of-observability

Where: §4.1–4.3 (#the-chain, #the-unmetered-remainder-attributed, #what-the-moortec-sensors-can-and-cannot-do-for-power); replaces the tables #idletab, #fittab and #drooptab

Problem: §4 is the hub's main argument: what the meters miss and how the remainder was attributed. It has no chart, only four tables and about 1,100 words. The key result is hard to see from coefficient tables: an instruction's unmetered energy is a fixed fraction of the minion rail, while a DRAM byte's is mostly off-chip (60–75%). The droop meter confuses mesh traffic with DRAM.

Proposal: Build a 'Where the watts go' explorer.
Data:
- 2026-09-23-energy-manual/catalogue.json → cards.<card>.summary[cfg].over_idle_w.mean, rails_over_w.{minion_w,sram_w,noc_w}.mean, bytes_per_s.mean and pattern.
- 2026-09-23-energy-manual/unmetered_fit.json → <card>.coef/se/rms_w, and ddr_droop.{mv_per_dram_offrail_w, mv_per_board_w_common, examples[]}.
- The idle bar from manual.json rest.rails_73c.
Encoding:
- One horizontal stacked bar per selected configuration, drawn in watts: minion rail var(--c1), SRAM var(--c3), NoC var(--c4), and the unmetered remainder hatched in var(--ref).
- The configurations are buttons: 'idle at 73 °C', add/zeros/h2, fmadd.ps/random/h2, tload/scp/random, wire/hop6/random, tload/dram/zeros, tload/dram/random, tstore/dram/random, st_stream/dram/random.
Interaction:
- Toggle 'attribute the remainder'. The hatched segment splits into minion delivery loss (coef.minion × minion W), SRAM, NoC, and DRAM (bytes/s × 72.9 pJ), plus a residual shown as ± rms_w.
- For idle, the remainder stays unsplit and is labelled 'the idle 15 W is not split'.
- Card toggle aifoundry2/aifoundry3: the coefficients differ by 10%.
- A small gauge beside the bar shows the predicted DDR droop (0.84 mV per off-rail DRAM W plus 0.025 mV per other W) against the measured droop from examples[]. It turns amber for tload/scp and wire/hop6, where the phantom is 0.8–1.8 W.
- Keyboard: buttons and toggles. At 390 px the bars stack one per row.
It replaces #idletab, #fittab and #drooptab; keep them in <details> as the text alternative. It complements the energy manual's rail-split chart (#railsplit), whose code it can reuse, and lets the energy manual's two attribution paragraphs shrink to one link (IA-12b). The reader sees the delivery-loss fraction, the off-chip DRAM term and the droop meter's blind spot in one view, instead of inferring them from 4 coefficients.

Evidence: The per-configuration rail and byte fields exist in catalogue.json (checked on remw/random/h2: rails_over_w.minion_w.mean, over_idle_w.mean, bytes_per_s.mean). unmetered_fit.json holds coef, se and rms for both cards, and 8 droop examples.

Files: docs/reports/data/2026-09-23-energy-manual/catalogue.json, docs/reports/data/2026-09-23-energy-manual/unmetered_fit.json, docs/reports/data/2026-09-23-energy-manual/manual.json, docs/reports/sources/limits-of-observability.script.js


#### IA-06 [redundancy/high] et-soc1-limits-of-observability

Where: §2 The ladder (#laddertab, 26 rows) against §5 The improvement ladder (#imptab, 20 rungs); §3 bullets; §4.1 starved-meter paragraph; §9 Related

Problem: The same content appears twice or three times on the hub itself.
- 10 of the 20 rungs restate a ladder row: rung 2 = Unmetered power, attributed; 3 = DDR-rail droop; 11 = Regulator input power per rail; 12 and 13 = Temperature and voltage; 14 = Faster power sampling; 15 = ECC errors; 16 = Chosen counter events; 17 = Halted-hart state and Single-stepping; 18 = Every flop, every cycle.
- §3 tells five ladder notes again in fuller form: ECC, MDI, raw SRAM rows, UltraSoC, scan chains.
- The starved meter appears in the Board power row, in §4.1 (200 words) and in rung 7.
- The unmetered result appears in the lede, a tile, a ladder row, §4.2, rungs 2 and 3, and the 'What each rung does' paragraph.

Proposal: Merge §5 into §2 as a single table with a view toggle.
- Columns: Instrument · What it shows · Finest granularity · How · Status · Ways to see more (rung, cost, what changes in the numbers).
- Put each mapped rung in its row's last column. Rung 20 becomes a new row, 'Current below the regulators'. Rung 4 ('Undo the rails' one-second average') goes in the Rail power row, and rung 8 (the riser) in the Board power row.
- The method rungs (1 bracketed bursts, 6 sub-degree temperature, 7 watch the meter, 9 infrared camera, 10 a second card) become a five-item list, 'Methods that sharpen what the card already gives', under the table.
- The view toggle reads 'Today' (hides the last column) and 'Ways to see more' (sorts by done, tooling, firmware, research). Put id='improve' on an h3 'Ways to see more' so inbound links resolve.
- Keep the firmware caveat paragraph, and give it id='firmware-caveat' (IA-18).
- Give the existing #gran chart a 'with rung' select. Rung 8 moves Board power from 133 ms to 1 ms; rung 14 moves Rail power from 1 s to the PMIC's own rate, drawn as an open interval; rung 12 adds 'per-shire temperature, 133 ms'. This needs new fields improvements[].row and improvements[].sec_after in data.json.
- Shorten each note that §3 or §4 tells in full to one sentence ending '(§3)' or '(§4.1)'. This applies to ECC errors, Halted-hart state, Raw SRAM row, Signal-level debug fabric, Every flop one snapshot, Board power, Rail power, DDR-rail droop and Unmetered power attributed.
- In rung 7 keep one sentence: 'The sampler records its own latency; bursts that starve the service processor are dropped (§4.1).'
- Fold 'What each rung does to the unmetered watts' into the last paragraph of §4.2.

Evidence: data.json has ladder 26 entries (level, sec, status, note) and improvements 20 entries (rung, group, status, done, what, adds, cost, effect). Rendered: #laddertab 4,015 px and #imptab 2,644 px at 1280; 6,509 and 4,216 px at 390.

Files: docs/reports/sources/limits-of-observability.data.json, docs/reports/sources/limits-of-observability.script.js, docs/reports/sources/limits-of-observability.body.html


#### IA-07 [reorganize/high] 2026-09-22-et-soc1-l2-mainline-starvation

Where: Whole brief (2,160 words): Update box, 'Five questions', 'What Ivan reported', 'When it bites', 'The fix', 'The systolic array', 'The landmine'

Problem: The brief's headline, the 6% owner penalty with l3_yield as the lever, was not reproduced. Its Update box and corrected sections now restate One hot line stops a shire: the 1.004 share, 0.01–0.05% loads, about 24 requesters, pacing at 54% and 95%, errata 4.1 and 4.2. The systolic 'landmine' section restates on-chip communication's trap. The hot line's §9 spends 124 words reconciling the two pages.

Proposal: Demote the brief to a pointer page. Keep the space (slug and UUID unchanged) and the title 'L2 mainline starvation: a brief · ET-SoC-1'.
New h1: 'L2 mainline starvation: superseded by One hot line stops a shire'. New body, about 150 words:
'On 22 September, before any reproduction, this brief argued from a result Ivan reported in the AI Foundry Discord (shire 0 got 6% of its fair share of a contended global atomic) and from the shire-cache spec that requests arriving from other shires starve the shire that owns the line. The reproduction that afternoon, on two cards, kept the aggregate (60 million atomics a second) and the even split, but not the 6%: the owner's share of the atomic is 1.004. What stops is the owner shire's other memory traffic, to 0.01–0.05% of normal, once about 24 remote requesters saturate its bank.'
Follow it with two links:
- One hot line stops a shire: the measurement, the errata and what to do instead (#what-to-do-instead).
- On-chip communication, 'A trap: one ready flag per minion': why a 2D TensorSend array hangs a hart, and the safe layouts.
End with 'The brief as first published is in this space's version history' and the hub back-link.
Before replacing it, move the brief's unique content into hot-line.
- Into §8 as two bullets: 'Make the owner a shire that does no compute: one of 32 is 3.1% of the chip; not the master shire, whose scratchpad the firmware uses.' and 'Measure the victim from user mode: syscall 9 (SYSCALL_PMC_SC_SAMPLE) reads any shire's cache-bank counters.'
- Into §9: 'l3_yield_priority is a 5-bit field of sc_reqq_ctl, an M-mode register no syscall writes; the 21 queue entries reserved for L3-slave requests look like deadlock avoidance, so changing the priority risks mesh back-pressure.'
- Then cut hot-line §9 'An earlier reading' to one sentence.
Move the brief's safe/unsafe layouts to on-chip communication (IA-13).
On the hub, the index row becomes 'L2 mainline starvation (superseded): an argument from Ivan's report; see One hot line stops a shire', and VIS-01 shows it as a superseded edge.

Evidence: Brief text: 2,160 rendered words. The landmine section is 191 words. The Update box already concedes the headline. The facts in the proposed text come from hot-line §1–§4 and match D12.

Files: docs/reports/2026-09-22-et-soc1-l2-mainline-starvation.html, docs/reports/sources/hot-line.body.html, docs/reports/sources/limits-of-observability.data.json, docs/findings/04-artifacts.md


#### IA-08 [redundancy/high] et-soc1-dvfs-leakage

Where: §7 'What the second card says about the model' (#what-the-second-card-says-about-the-model); plus Horace §10's first paragraph

Problem: DVFS §7 (513 words) repeats Horace §10 (644 words) almost word for word. Both have the chart 'Switching power over idle, eight operand patterns, two cards'. Both have the paragraph with 1.38 W rms, 2.32 W, 0.92, 0.20 W, 0.36 and 1.53 W, and 0.27 W; the 523 against 518 mV paragraph; the aifoundry3 idle table at 50–57 °C (+0.73 W); and the 'shelf of cards' consequence. Horace §10's first paragraph in turn repeats DVFS §6 (aifoundry1 unopenable, the TDP of 0 W).

Proposal: Make Horace §10 (#a-second-card-and-what-transfers) canonical for the transfer, and DVFS §6 canonical for the three-machine configuration.
Replace DVFS §7's body (keep the heading and its id) with: 'The strict protocol on aifoundry3 is the strongest out-of-sample test of the flip-counting model, and it is reported in full in the Horace experiment, §10: the aifoundry2 model is off by one factor, 0.92, which a single random-data run calibrates (0.20 W rms after scaling), and the idle law, extrapolated 7–14 °C below its fit onto the cooler card, predicts its idle to +0.73 W. The gap is the card, not the operating point: aifoundry3 runs its minions 5 mV higher and still switches 8% less.'
Drop DVFS §7's chart, which saves the 'cardsw' SVG, and the leaktab table.
In Horace §10 replace the opening paragraph's first three sentences with: 'aifoundry1's two cards could not be opened, and aifoundry3's card is held at 600 MHz by a flashed TDP of 0 W (The DVFS loop and its leakage, §6).'

Evidence: Word-sequence similarity between the two sections is 0.61; 10 shared runs of 12 or more words cover 214 words. Both build from docs/reports/data/2026-09-22-cards/cards-report.json (manual.json cards.*).

Files: docs/reports/sources/dvfs-leakage.body.html, docs/reports/sources/dvfs-leakage.script.js, docs/reports/sources/horace-experiment.body.html


#### IA-09 [redundancy/high] set

Where: Idle law and leakage: energy manual §1 chart (#idle); Horace §8 chart 'Leakage: idle board power against die temperature, all sessions'; why-low-power §3 'Leakage and temperature' chart; DVFS §4 (#what-that-costs); power-temperature 'Later measurements' first bullet; the 20.6-hour check on 5 pages

Problem: The law P = 12.6 W + 23.3 W·e^((T−80)/36) is charted three times (energy manual §1, Horace §8, why-low-power §3), with near-identical dots and curve. The 31.79 W against 31.78 W check after about 20.6 h is told on DVFS §4, why-low-power §3, Horace §8, the energy manual §1 table caption and hub §4.1. The rail split of that idle (11.05 / 2.00 / 3.64 / 15.10 of 31.79 W) is a table on hub §4.1 and on energy manual §1, and a paragraph on DVFS §4.

Proposal: Canonical sources:
- The law and its chart: energy manual §1 (#the-card-at-rest), from manual.json rest.*, with both cards.
- The out-of-sample 20.6-hour check and the leakage share against Kanter's 5–30%: DVFS §4 (#what-that-costs).
- The rail-split table: energy manual §1 (#rails).
Changes on other pages:
- Why-low-power §3 'Leakage and temperature': drop the chart and replace its first bullet with 'Idle board power follows the idle law of the energy manual, §1 (0.2 W rms, 64–88 °C): 23 W of leakage in a 36 W idle at 80 °C, 14 W in 27 W at 62 °C, and it predicted the 20.6-hour idle of 22 September to 0.01 W (The DVFS loop, §4).' Keep the thermal-fragility bullet.
- Horace §8: keep its chart (the law was fitted there), but point the caption to energy manual §1 for the tabulated law, and drop the 20.6-hour sentence from 'The budget belongs to this card…'. Keep only the ambient inference.
- DVFS §4: replace 'Of those 31.8 idle watts, 11.0 W…' with 'Half of it, 15.1 W, is on no rail sensor (energy manual, §1).'
- Hub §4.1: VIS-03's idle bar replaces #idletab, with the caption 'the full table is the energy manual, §1'.
- Power-temperature: cut the 'Later measurements' leakage bullet to 'Idle power is now a fitted law, 0.65 W/°C at 80 °C (energy manual §1); it reproduces this page's two idle readings to 0.1 W.'

Evidence: Pattern counts across rendered texts: '12.6 W + 23.3' on 4 pages; '20.6 h' on 5; the rail split (15.1, 11.05, 31.79) on 4. Why-low-power's Leakage subsection is 213 words with a chart.

Files: docs/reports/sources/why-low-power.body.html, docs/reports/sources/why-low-power.script.js, docs/reports/sources/horace-experiment.body.html, docs/reports/sources/dvfs-leakage.body.html, docs/reports/sources/power-temperature.body.html, docs/reports/sources/limits-of-observability.body.html


#### IA-10 [readability/high] set

Where: The 'Terms.' paragraph on 17 pages, and the hub glossary card (#terms)

Problem: C3 asks for a 2–4 sentence Terms paragraph on each page. The pages carry 56–225 words each (energy manual 225, ridge points 205, on-chip communication 198, power-temperature 196, sparse 166, memory anatomy 152, why-low-power 151, heat-per-mm 148, DVFS 146), about 2,350 words in all. Most of it is the same definition of minion, hart, shire, 4 MB SRAM split, mesh, SP and PMIC. On phones each one is 400–800 px before the first result.

Proposal: Keep one glossary source: docs/reports/sources/glossary.json, holding term → one-sentence definition, generated from PLAN.md G.
- report.template.html renders a collapsed block for each source-built page: <details class='terms'><summary>Terms used here: minion, hart, shire, scratchpad, PMIC…</summary>. It contains only the terms listed in that page's meta.json 'terms' array, plus page-specific definitions from meta.json 'terms_extra', and ends 'more in the hub's glossary' linked to hub #terms.
- Standalone pages paste the same rendered block.
- Page-specific terms stay: hot-line's 'host shire' and 'L3-slave requests'; heat-per-mm's flit and tensor load; DVFS's VMIN-LUT and TDP; ridge points' TenB and TenC.
- Where a page keeps prose, cap it at 4 sentences. Energy manual example: 'Minions are the chip's small RISC-V cores, two harts each, 32 to a shire; each shire's 4 MB of SRAM is a 512 KB L2, a 1 MB slice of the 32 MB L3 and a 2.5 MB scratchpad any shire can address. Board power is the PMIC's reading of the 12 V input; the minion, SRAM and mesh rails are its three metered regulators. a2 and a3 are the two cards. More in the hub's glossary.'
- On the hub, move the glossary card below the index (IA-01).

Evidence: Word counts measured on rendered text: l2 118, dvfs 146, energy-manual 225, heat 148, horace 87, hot-line 100, matmul 91, anatomy 152, hierarchy 123, on-chip 198, relay 97, P&T 196, ridge 205, sparse 166, spatial 87, testdrive 56, why-low-power 151. Hub glossary: 413 words.

Files: docs/reports/sources/report.template.html, scripts/build-report.py, docs/reports/sources/limits-of-observability.body.html


#### IA-11 [redundancy/medium] set

Where: The 'Later measurements' and 'Update' boxes on power-temperature, matmul, memory hierarchy, memory anatomy, sparse compute, on-chip communication and the L2 brief

Problem: Each box restates the newer numbers in prose: power-temperature 205 words (3 bullets), matmul 203 words (3 paragraphs), memory hierarchy 152 words, sparse 143 words, memory anatomy about 90 words plus a 150-word §7 bullet, on-chip communication 89 words. Readers pay the cost of the old page before its result, and the boxes drift from the canonical numbers when those change.

Proposal: Standardise the box at no more than 3 lines, one per superseded number: 'Energy per byte (18 Sep): L2 4.3 → 2.51 pJ/B, DRAM 148 → 122 pJ/B, energy manual §4.2.' Drive the lines from the superseded[] list proposed in VIS-01, so that the hub map and the pages share one record. Standalone pages get the rendered HTML pasted.
Per page:
- Matmul: see IA-15.
- Power-temperature: 3 lines (idle law; rails as a ~1 s running average, hub §4.1; unmetered attribution, hub §4.2), with the §5 pointer removed from the box.
- Memory hierarchy: 'These runs left the governor free (600–800 MHz); bandwidths are now the 600 MHz launches, energies the energy manual's §4.2 (the values first published are under How it was measured). At 600 MHz the L2 cache and the local scratchpad cost the same per byte.'
- Sparse compute: 'Power depends on the operand values, not only the zeros: +1.9 / +9.7 / +24.9 W over idle on zeros, ones and random data, 0.41 / 2.1 / 5.4 pJ per multiply-add (Horace §10; energy manual §3.2).'

Evidence: Word counts measured on rendered text. X3 in PLAN.md lists the eight pages that should carry a box.

Files: docs/reports/2026-09-18-et-soc1-matmul-efficiency.html, docs/reports/2026-09-18-et-soc1-memory-hierarchy.html, docs/reports/2026-09-18-et-soc1-sparsity.html, docs/reports/2026-09-18-et-soc1-on-chip-communication.html, workloads/memprobe/report_template.html, docs/reports/sources/power-temperature.body.html


#### IA-12 [redundancy/medium] et-soc1-power-temperature

Where: §1 'Every way to measure, by granularity' (#every-way-to-measure-by-granularity); §4; §5 'What would unlock more'; §2 bullets on the rails' lag and on the clock; §6 'Firmware.' paragraph

Problem: Most of this page has been superseded by the hub.
- §1's 16-row table (549 words) is the first draft of the hub's 26-row ladder.
- §5 (7 rows) says of itself 'Superseded by the hub's fuller improvement ladder… The table stands as it was' and still prints in full.
- §4 (MDI) repeats hub §3 and the Halted-hart ladder row.
- §2's 'Why the remainder sometimes looks too small' bullet retells the τ ≈ 1 s averaging (hub §4.1) and the trace-against-host-log gap (memory anatomy §7).
- 'The clock stayed at 600 MHz' (139 words) retells the governor.
- §6 has a 99-word firmware-build paragraph.
The page's unique results, the §2 load step and the §3 voltage map, sit behind 1,000 words of superseded tables.

Proposal: Keep the page and its slug. It stays canonical for the load step and the per-shire voltage map (D15).
- §1: replace the table with 'Every instrument the card offers, with its granularity and what it takes to use, is now the ladder in the limits of observability, §2. What this page's client, ettelem, adds over the stock tool: the per-rail snapshot the CLI refuses (DM_CMD_GET_SP_STATS), up to 45 samples a second, and the 34-shire on-die voltage map of §3.' Keep the old table in <details><summary>The table as of 20 September</summary>.
- §4: 'The Minion Debug Interface reads only minion state (registers, CSRs, memory of a halted hart), so it adds no power or temperature sensor; for energy work it could write counter event selectors without a reflash (hub §2–§3).'
- §5: one line: 'Superseded by the hub's improvement ladder (limits of observability, §5), which marks what has since been done.'
- §2 lag bullet: keep the measured transients (39 W → 22 W, −3.5 W). Replace the mechanism with '(the rails are the PMIC's ~1 s running average; hub §4.1)'. Cut the memory-anatomy gap to 'the same lag explains memory anatomy's 14–20% trace-against-log gap (§7 there)'.
- Clock bullet: 'The clock stayed at 600 MHz because the die was above 65 °C, where the governor holds the lowest point (The DVFS loop, §1–§2).'
- §6 'Firmware.': the byline clause only (IA-18).
- Retitle the h1: 'Power and temperature on the ET-SoC-1: a load step through every sensor, and the per-shire voltage map'.

Evidence: Rendered word counts: §1 549, the Later box 205, §4 and §5 377, the clock bullet 139, the firmware paragraph 99. The page is 7,751 px at 1280.

Files: docs/reports/sources/power-temperature.body.html, docs/reports/sources/power-temperature.script.js


#### IA-12b [redundancy/medium] et-soc1-energy-manual

Where: §4.3 paragraphs 'Attributed: over the whole catalogue…' and 'A droop meter for DRAM…'; §10 Related reports

Problem: The unmetered attribution and the droop meter (217 words, with coefficients for both cards, rms figures and the reproduction note) repeat hub §4.2–§4.3, the canonical home: E30 is 'This page, §4' on the hub. The manual's Related list has 10 items; X1 caps it at 8.

Proposal: Replace both paragraphs with: 'Attributed: the unmetered part of each configuration's power over idle fits as a delivery loss of 18–20% of the minion rail's watts plus 68–73 pJ per DRAM byte off-rail (0.35 W rms over 392 configuration means; 1.1–1.3 W on the DRAM ones), and the DDR rail's droop, 0.84 mV per off-rail DRAM watt, reads that DRAM term every 133 ms; how the fit was made, and what it cannot split, is the limits of observability, §4.2–§4.3.' Make the same edit in render_catalogue.py, which writes those sections of docs/energy-manual/04a-fine-grain.md.
Cut §10 to 8 items: drop the L2 brief (IA-07) and fold Matmul efficiency and Sparse compute into one item.

Evidence: Rendered word count of the two paragraphs: 217. 04-artifacts.md A16 notes that render_catalogue.py writes the attribution and droop sections of 04a.

Files: docs/reports/sources/energy-manual.body.html, tools/ettelem/render_catalogue.py, docs/energy-manual/04a-fine-grain.md


#### IA-13 [redundancy/medium] et-soc1-on-chip-communication

Where: 'A trap: one ready flag per minion' (#a-trap-one-ready-flag-per-minion) and 'What it means for systolic and wavefront designs'; relay §6 fourth bullet; L2 brief 'The landmine'; sparse 'Answers' bullet

Problem: The one-ready-bit-per-minion hazard and the 2D systolic hang are explained on three pages: on-chip communication, the L2 brief's landmine section (191 words and 4 layout cards) and relay §6 (136 words). The pointers run in a circle: on-chip communication says 'worked through in the section The landmine of L2 mainline starvation', and relay's Related list links that landmine.

Proposal: Make on-chip communication canonical.
- Replace its sentence 'What this means for a 2D systolic array… is worked through in the section The landmine of L2 mainline starvation; the safe layout is below.' with four list items in 'What it means for systolic and wavefront designs':
  - 'Safe: 1D rings (partners never change).'
  - 'Safe: 2D in alternating phases (west pass, barrier, north pass, barrier; a 32-minion FLB plus credit barrier is 237 cycles against 68–114 per hop).'
  - 'Safe: the hardware trees (one ready bit per level; 432 cycles for a 32-minion reduce and broadcast).'
  - 'Hangs: a naive 2D array whose cells take readies from two partners, until the chip is reset; sys_emu tracks partners separately and will not show it.'
- Relay §6 fourth bullet becomes: 'Inside a shire TensorSend is the right tool, but a minion may hold only one partner's ready at a time; a 2D array needs one minion per neighbour link or barrier-separated phases (on-chip communication, A trap: one ready flag per minion). The relay is the same idea at shire granularity, through the scratchpads, a path that cannot hang.'
- Point relay's Related item 'L2 mainline starvation, The landmine' at on-chip communication #a-trap-one-ready-flag-per-minion.
- The L2 brief's landmine goes with IA-07.

Evidence: Rendered word counts: L2 landmine 191, relay bullet 136. The on-chip communication text 'is worked through in the section The landmine of L2 mainline starvation' is quoted from its rendered page.

Files: docs/reports/2026-09-18-et-soc1-on-chip-communication.html, docs/reports/sources/on-chip-relay.body.html, docs/reports/2026-09-22-et-soc1-l2-mainline-starvation.html


#### IA-14 [redundancy/medium] set

Where: Governor retold: Horace §6 first paragraph; power-temperature §2 clock bullet; why-low-power §2 'Voltage and clock' bullet and §3 'Voltage and clock'; memory hierarchy 'The card changed its clock'; matmul 'One clock point'; sparse caveat 'One card, one day'; DVFS §5 V²f

Problem: The governor is explained in full on DVFS §1–§2: the 65 °C and 65 W tests, thermal priority, no dead band, three operating points, one pass per 133 ms. Six other pages each spend 100–210 words re-describing it: Horace §6 142, power-temperature 139, memory hierarchy 210. The 600-against-800 MHz V²f test (2.0× against 1.90×) appears in both why-low-power §3 and DVFS §5.

Proposal: Canonical sources: DVFS #the-loop-as-built and #the-loop-as-measured for the governor; why-low-power #voltage-and-clock for the V²f test.
Everywhere else keep one sentence: 'The governor holds 600 MHz at 0.52 V while the die reads above 65 °C, and lifts a cooler busy card to 700–800 MHz (The DVFS loop and its leakage, §1–§2).'
- Horace §6: replace the first paragraph's governor description with that sentence, then 'Every run on 20 September started above 72 °C… After a night idle the die sits at 62 °C, and the same kernels behave differently:'.
- Memory hierarchy: shorten 'The card changed its clock…' to its measurement content, the per-clock L3 and DRAM latencies and '72 cycles plus 145 ns', and drop the governor description.
- DVFS §5: cut the V²f sentences to 'Voltage and clock scale as V²f predicts, within 5–8% on seven short runs (Why is the ET-SoC-1 low power?, Voltage and clock).'

Evidence: Pattern '65 °C' appears 27 times on DVFS, 5 on Horace, 4 on why-low-power, 3 each on memory hierarchy and power-temperature. Rendered word counts are given above.

Files: docs/reports/sources/horace-experiment.body.html, docs/reports/sources/power-temperature.body.html, docs/reports/sources/why-low-power.body.html, docs/reports/2026-09-18-et-soc1-memory-hierarchy.html, docs/reports/2026-09-18-et-soc1-matmul-efficiency.html, docs/reports/2026-09-18-et-soc1-sparsity.html, docs/reports/sources/dvfs-leakage.body.html


#### IA-15 [redundancy/medium] et-soc1-matmul-efficiency

Where: Lede; 'Later measurements' box (3 paragraphs); Caveats 'The A100 figures are spec-sheet numbers…'; 'Setup notes (for running it yourself)'

Problem: The page gives the A100 verdict three times: in the lede ('3.4× … about 2.9× in a later random-data measurement'), in a 203-word box (random operands; the 546-against-529 variant at 2.9×; why-low-power's 5.4× and 2.6×) and in the caveats ('Like for like on random data … 2.6×'). The 510-word Setup notes duplicate Test drive, which is the onboarding page. Both describe the same GenericLauncher firmware-preload bug (matmul fix 2 = test drive issue 2).

Proposal: Make why-low-power #the-comparison canonical for per-FLOP (D4).
- Lede: keep the rates and, per D4, one sentence: 'Against the A100's fp32 CUDA-core datasheet figure this card is 3.4× more efficient on these ±1/±2 operands (about 2.9× on random data); the A100's bf16 tensor cores are 5.4× more efficient than its fp32 (Why is the ET-SoC-1 low power?).'
- Box: 'These operands favour low power: on random data at 80 °C the tensor unit draws 63.9 W (the Horace experiment), 144 GFLOP/s per W.'
- Caveats: delete the 'Like for like on random data…' sentence.
- Move 'Setup notes' into Test drive as a new h2, 'On the lab machines: gp-sdk against the older /opt/et', after 'Things worth fixing upstream'. Merge its fix 2 into test drive issue 2. In matmul leave: 'Setup for the lab machines (the /opt/et install, the four gp-sdk fixes, the hello worlds) is in Test drive.'

Evidence: Rendered word counts: Later box 203, Setup notes 510. The two GenericLauncher descriptions are in matmul Setup notes item 2 and test drive 'Things worth fixing upstream' item 2.

Files: docs/reports/2026-09-18-et-soc1-matmul-efficiency.html, docs/report/index.html


#### IA-16 [redundancy/medium] set

Where: Energy per byte by level: memory hierarchy Update box and 'Being awake inflated…' bullet; memory anatomy 'Later measurements' box and §7 last bullet; relay §2 'Re-measured'

Problem: The energy manual §4.2 (#reads-by-level) is canonical (D7). Memory hierarchy prints its six values three times: in the Update box, in the spec table and at the end of 'Being awake inflated…'. Memory anatomy spends 245 words comparing 79, 92, 122, 91 and 129 pJ/B plus three per-hop figures, split across its box and §7. Relay §2 discusses memory hierarchy's superseded 148, 2.8 and 6.3 pJ/B, which has nothing to do with the relay.

Proposal: - Memory hierarchy: keep the values in the spec table only. Update box as in IA-11. End 'Being awake inflated…' at '…so this page's two-hart spin loop added 12 W, and that floor was inside every energy per byte measured here.'
- Memory anatomy, in workloads/memprobe/report_template.html: box: 'The energies in §7 are superseded by the energy manual, §4 (DRAM 122 pJ/B against 79 here), and for a mesh hop by Heat per millimetre (about twice this page's 0.9 pJ/B); §7's last note says why they differ. The latencies are not affected.' Cut §7's last bullet to the reasons only: 8-byte loads through the caches, the SP trace reading 14–20% low, and an uninitialised arena.
- Relay §2: delete 'The memory-hierarchy report now quotes these values too; its own 18 September figures (148, 2.8 and 6.3 pJ, taken with the clock left free) are superseded.'

Evidence: Pattern '122 pJ' appears on 7 pages. Memory anatomy's box and §7 bullet total 245 rendered words. The memory hierarchy Update box is 152 words.

Files: docs/reports/2026-09-18-et-soc1-memory-hierarchy.html, workloads/memprobe/report_template.html, docs/reports/sources/on-chip-relay.body.html


#### IA-17 [redundancy/medium] set

Where: Mesh hop energy: energy manual §4.3 wires paragraph; on-chip communication 'Energy per byte moved' and its Sources paragraph; memory anatomy §7; L2 brief primitive table; heat-per-mm Related list

Problem: Heat per millimetre is canonical for a hop's energy (D9). Four other pages carry their own per-hop figures with long reconciliations. The energy manual's 222-word wires paragraph fits 1.81, re-fits 2.09–2.29 over 1–6 hops and ends 'use its figures for wires'. On-chip communication gives 10.0 + 1.9 pJ per hop (18 Sep), and its Sources paragraph converts that to 64 fJ/bit·mm and quotes Heat per millimetre's 47–73 and 36–50. Memory anatomy gives about 0.9 pJ/B per hop. The L2 brief gives about 10 + 1.9 per hop. Heat-per-mm's Related list retells each older figure.

Proposal: - Energy manual §4.3: keep the chart and replace the paragraph with 'Over 1–8 hops the catalogue fits 1.81 pJ/B per hop on random data (aifoundry2), pulled low by the 8-hop point, which only 16 shires reach; over 1–6 hops the same data give 2.1–2.3. For a hop's energy use Heat per millimetre: 2.17 pJ/B per hop on board power and 1.50 on the mesh rail, split into 98 fJ per bit that differs from the previous flit and 129 fJ per one carried. The 7.90 pJ/B intercept, against 4.29 for the shire's own scratchpad, is the array access plus leaving the shire.' This text is also in docs/energy-manual/04a-fine-grain.md, which tools/ettelem/render_catalogue.py writes.
- On-chip communication Sources: delete the fJ/bit·mm conversion sentence. Keep 'One hop is 3.72 mm (Heat per millimetre §2).'
- The L2 brief's table goes with IA-07.
- Heat-per-mm Related: shorten the energy manual, on-chip and anatomy items to a clause each, without numbers.

Evidence: Rendered word count of the energy manual wires paragraph: 222. The canonical values in D9: 2.17 pJ/B on board, 1.50 on the rail, 98 and 129 fJ.

Files: docs/reports/sources/energy-manual.body.html, tools/ettelem/render_catalogue.py, docs/energy-manual/04a-fine-grain.md, docs/reports/2026-09-18-et-soc1-on-chip-communication.html, docs/reports/sources/heat-per-mm.body.html


#### IA-18 [redundancy/medium] set

Where: Firmware-build caveat (et-platform 353f20e against the older build before 60b40c10f) on 8 pages; the Erbium RTL caveat on 8 pages; the firmware-signing chain on hub §5, memory anatomy §1 'Out of reach', spatial brief §3 row 3 and power-temperature

Problem: The same caveats are written out as full sentences or paragraphs on many pages. Power-temperature §6 has a 99-word 'Firmware.' paragraph. Memory anatomy §1, the memory hierarchy sources, Horace §6, the spatial brief sources and why-low-power's method each carry 1–3 sentences. DVFS mentions Erbium 5 times. The signing chain (BL1/BL2, the OTP key hash, no signing tool, possible bricking) is restated wherever a firmware change comes up. The hub's 'firmware caveat' paragraph has no id, so pages cannot link to it.

Proposal: Canonical homes: hub §8 #method ('Which firmware', 'The RTL is…') and DVFS §8 for what the older governor changes.
- Add id='firmware-caveat' to the hub's paragraph 'The firmware caveat. Every firmware row above ends with a reflash…'.
- On every other page, only the C2 byline clause: 'firmware source read at et-platform 353f20e (the cards run an older build; hub §8)' and, where RTL is cited, 'RTL: core-et Erbium b38a1a3, a later configuration of the same core (hub §8)'.
- Delete power-temperature's 'Firmware.' paragraph.
- Replace the signing sentences in memory anatomy §1 and spatial brief §3 row 3 with 'needs a signed firmware image (the firmware caveat)', linked to hub #firmware-caveat.
- Keep the spatial brief's unique fact: the two PVT files differ only in their licence header in the older build.

Evidence: Pattern counts in rendered text: '60b40c10f' on 8 pages; 'Erbium' on 8 pages (DVFS 5); signing on 4 pages. The power-temperature firmware paragraph is 99 words.

Files: docs/reports/sources/limits-of-observability.body.html, docs/reports/sources/power-temperature.body.html, workloads/memprobe/report_template.html, docs/reports/2026-09-22-et-soc1-spatial-temperature-brief.html, docs/reports/2026-09-18-et-soc1-memory-hierarchy.html, docs/reports/sources/horace-experiment.body.html, docs/reports/sources/why-low-power.body.html


#### IA-19 [redundancy/low] et-soc1-heat-per-mm

Where: §10 bullets 'The meter can be starved', 'The meter can be stopped', 'A stray write is invisible'; hub §4.1 paragraph 'The chain has one more limit…'; hub rung 7; the hub ladder's Board power note

Problem: Three findings about the meter are told in full on heat-per-mm §10 (225 words) and again in hub §4.1 (200 words), rung 7 and the Board power note: the column pairs 3 hops apart starving the SP, the poisoned management queue and the stray stores to address 0. The s↔s+16 ring starvation is retold on both pages as well.

Proposal: Hub §4.1 is canonical: it is the meter chain. Heat-per-mm §10 keeps what its own data needs, as one bullet: 'The meter can be starved or stopped: on aifoundry2 the y-only pairs 3 hops apart slowed the service processor to 0.8–1.6 s per reading, so those 6 bursts are dropped (aifoundry3's were kept and give the only y-only 3-hop point); a killed sampler once poisoned the management queue, and a tool bug sent a second of stores to address 0 that nothing on the card reported (limits of observability, §4.1).' The hub's rung 7 and Board power note shrink as in IA-06.

Evidence: Rendered word counts: heat-per-mm §10 meter bullets 225; hub §4.1 paragraph 200.

Files: docs/reports/sources/heat-per-mm.body.html, docs/reports/sources/limits-of-observability.data.json


#### IA-20 [redundancy/low] et-soc1-limits-of-observability

Where: Ladder row 'Cycle counter' note; §3 'A first result from the RTL'; memory anatomy §1 'Time' row and §8 (#a-timer-bug-worth-knowing)

Problem: The hpmcounter3 late-carry bug is explained four times: the hub ladder note (about 80 words), hub §3 (the RTL explanation), memory anatomy §1's table row (about 90 words) and memory anatomy §8, where it was found and fixed.

Proposal: Make memory anatomy §8 canonical for the symptom and the fix, and hub §3 for the RTL cause.
- Hub ladder note: 'Two counters per neighbourhood, not synchronised across neighbourhoods; a read whose low 7 bits are 0–10 is 128 short (§3; fixcyc() in Anatomy of a memory access §8). The standard cycle, time and instret CSRs trap.'
- Memory anatomy §1 'Time' row: '1 cycle (1.67 ns), one load; correct the late carry into bit 7 and reject ±128 outliers (§8). The standard cycle CSR traps.'

Evidence: Pattern 'late carry' or '128 short' appears 5 times on the hub and twice on memory anatomy.

Files: docs/reports/sources/limits-of-observability.data.json, workloads/memprobe/report_template.html


#### IA-21 [redundancy/low] et-soc1-spatial-temperature-brief

Where: §1 'The 6×6 shire mesh, as the latency measurements place it' (36 static cells); §4 'Current best workaround'

Problem: The brief redraws the whole mesh map as 36 labelled cells, which render as 108 text lines. It restates on-chip communication's fit ('150 + 12.02 × (Manhattan distance) cycles, worst residual 1.1 cycles over all 496 pairs'). Its §4 restates Horace's model accuracies (0.5 W rms, 0.92 W rms, loop gain 0.95, 0.65 W/°C). Power-temperature §3 already draws the same MARTY layout per shire, with hover.

Proposal: - Keep the grid, since the sensor channel labels TSn are this brief's contribution. Build it from the same grid code and layout as power-temperature's voltage map (#vmap), with a toggle between 'sensor channel' and 'minion-rail voltage at idle' (data: docs/reports/data/2026-09-20-power-aifoundry2/per-shire-voltage-idle.json). The reader then sees on one grid that voltage reaches the host per shire and temperature does not, which is the brief's point.
- Replace the fit sentence with 'placed on the 6×6 grid by TensorSend latency (On-chip communication)'.
- In §4, keep the three workaround names with one clause each and a link to Horace §2 and §8, without the numbers.

Evidence: Rendered text of the grid: lines 38–109 of the cleaned text. Fit sentence: §1.

Files: docs/reports/2026-09-22-et-soc1-spatial-temperature-brief.html, docs/reports/sources/power-temperature.script.js


#### IA-22 [consistency/low] set

Where: docs/reports/sources/report.template.html colour tokens

Problem: The visualisation standard names var(--c1)…var(--c7), but the template defines only --c1 to --c5, --c7, --ref, --ink, --ink-2, --grid, --axis, --muted, --ok, --warn and --bad. There is no --c6, so a chart that uses var(--c6) would fall back to the default colour in both themes.

Proposal: New charts, VIS-01 to VIS-03 included, should use only --c1 to --c5, --c7 and --ref for series, --grid for connectors and --ink for text. Alternatively, add --c6 to all three blocks of the template (light, dark via prefers-color-scheme, and [data-theme=dark]) before any page uses it.

Evidence: grep of report.template.html: '--c1: #2a78d6; --c2: #eb6834; --c3: #1baf7a; --c4: #eda100; --c5: #e87ba4; --c7: #4a3aa7; --ref: #8c8b85' (lines 13, 21, 29); no --c6.

Files: docs/reports/sources/report.template.html
